using System;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace WiDiD.ImmersiveAPI
{
    public static class AppTermination
    {
        /// <summary>
        /// Raised just before the app is actually torn down, while managed code can still do
        /// something about it - the hook the xAPI runtime uses to get Terminated_Simulation out
        /// (see SimulationTerminationHooks). An event rather than a direct call so this stays a
        /// leaf utility with no knowledge of the Training layer above it.
        ///
        /// Matters most on WebGL, where the exit below navigates the page away: nothing in managed
        /// code is told when a browser tears down a tab, so a deliberate exit is the one teardown
        /// there that can be handled in advance rather than reacted to.
        ///
        /// A listener exception is caught and logged rather than left to propagate, so a broken
        /// listener cannot stop the app from closing.
        /// </summary>
        public static event Action OnTerminating;

        public static void Terminate()
        {
            RaiseTerminating();

#if UNITY_EDITOR
            EditorApplication.isPlaying = false;
#elif UNITY_WEBGL
            Application.OpenURL("about:blank");
#else
            Application.Quit();
#endif
        }

        static void RaiseTerminating()
        {
            try
            {
                OnTerminating?.Invoke();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[AppTermination] A listener threw while handling OnTerminating: {exception}");
            }
        }
    }
}
