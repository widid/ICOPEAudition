using Newtonsoft.Json;
using System;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Authenticates against the given login endpoint and deserializes the response into T.
    /// Uses WebRequestUtility (UnityWebRequest) rather than System.Net.Http.HttpClient, since
    /// HttpClient's default handler depends on OS sockets that aren't available in a WebGL build.
    /// </summary>
    public static class AuthentificationRequestUtility<T>
    {
        public static Task<T> AuthenticateAsync(string email, string password, string url)
        {
            return PostCredentialsAsync(new { email, password }, url);
        }

        public static Task<T> AuthenticateWithCodeAsync(string code, string url)
        {
            return PostCredentialsAsync(new { code }, url);
        }

        static async Task<T> PostCredentialsAsync(object credentials, string url)
        {
            string jsonPayload = JsonConvert.SerializeObject(credentials);
            byte[] body = Encoding.UTF8.GetBytes(jsonPayload);

            try
            {
                WebRequestResult response = await WebRequestUtility.PostAsync(url, body, "application/json");

                if (response.Success)
                {
                    Debug.Log($"Authentication successful. Response: {response.Text}");
                    return JsonConvert.DeserializeObject<T>(response.Text);
                }

                Debug.Log($"Authentication failed. Status code: {response.StatusCode}. Response: {response.Text}");
                return default;
            }
            catch (Exception ex)
            {
                Debug.LogError($"Exception: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Debug.LogError($"Inner Exception: {ex.InnerException.Message}");
                }
                return default;
            }
        }
    }
}
