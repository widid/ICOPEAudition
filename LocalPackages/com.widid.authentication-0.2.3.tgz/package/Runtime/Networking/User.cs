using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking.Authentification.User
{
    [System.Serializable]
    public class UserProfile
    {
        [SerializeField] private string token = null;
        [SerializeField] private ProfileInfo info = null;
        [SerializeField] private int clientId = -1;
        public string Token { get => token; }
        public ProfileInfo Info { get => info; }
        public int ClientId { get => clientId; }

        public UserProfile(string token, ProfileInfo profile, int clientId)
        {
            this.token = token;
            this.info = profile;
            this.clientId = clientId;
        }
    }
    [System.Serializable]
    public class ProfileInfo
    {
        [SerializeField] private int id = -1;
        [SerializeField] private string firstName = string.Empty;
        [SerializeField] private string lastName = string.Empty;
        [SerializeField] private string email = string.Empty;
        [SerializeField] private List<string> roles = new List<string>();
        [SerializeField] private string picture = string.Empty;
        private DateTime lastConnection = DateTime.MinValue;
        [SerializeField] private List<string> managers = new List<string>();
        [SerializeField] private List<int> badges = new List<int>();

        public int Id { get => id; }
        public string FirstName { get => firstName; }
        public string LastName { get => lastName; }
        public string Email { get => email; }
        public List<string> Roles { get => roles; }
        public string Picture { get => picture; }
        public DateTime LastConnection { get => lastConnection; }
        public List<string> Managers { get => managers; }
        public List<int> Badges { get => badges; }

        public ProfileInfo(
            int id,
            string firstName,
            string lastName,
            string email,
            List<string> roles,
            string picture,
            DateTime lastConnection,
            List<string> managers,
            List<int> badges
        )
        {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.roles = roles;
            this.picture = picture;
            this.lastConnection = lastConnection;
            this.managers = managers;
            this.badges = badges;
        }
    }
}


