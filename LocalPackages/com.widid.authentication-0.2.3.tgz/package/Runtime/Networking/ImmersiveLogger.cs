using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking.Authentification
{
    public class ImmersiveLogger : ILogger
    {
        public void Log(string message)
        {
            Debug.Log(message);
        }
    }
}
