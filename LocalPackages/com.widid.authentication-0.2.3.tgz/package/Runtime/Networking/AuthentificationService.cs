using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Networking.Authentification
{
    public class AuthentificationService : IAuthentificationService

    {
        const string pattern =
   @"^([0-9a-zA-Z]" +
   @"([\+\-_\.][0-9a-zA-Z]+)*" +
   @")+" +
   @"@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z0-9]{2,17})$";

        private ILogger logger;
        private IUserService userService;

        public AuthentificationService(ILogger logger, IUserService userService)
        {
            this.logger = logger;
            this.userService = userService;
        }

        public async Task Login(string email, string password, string url)
        {
            Task<UserProfile> loginTask = AuthentificationRequestUtility<UserProfile>.AuthenticateAsync(email, password, $"{url}users/authentication");
            await loginTask;
            if (loginTask.Result == null)
            {
                throw new UserNotFoundException();
            }
            userService.SetUserProfile(loginTask.Result);
        }

        public async Task LoginWithCode(string code, string url)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new InvalidCodeException();
            }

            UserProfile profile = await AuthentificationRequestUtility<UserProfile>.AuthenticateWithCodeAsync(code.Trim(), $"{url}users/authentication/code");
            if (profile == null)
            {
                throw new InvalidCodeException();
            }
            userService.SetUserProfile(profile);
        }

        public void ValidateMail(string email)
        {
            if (!Regex.IsMatch(email, pattern))
            {
                throw new InvalidMailException(email);
            }
        }

    }
}
