namespace WiDiD.ImmersiveAPI
{
    public interface ILogger
    {
        public void Log(string message);
    }
}