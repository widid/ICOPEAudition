using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.Networking.Authentification
{
    public interface IAuthentificationService
    {
        public Task Login(string username, string password, string url);
        public Task LoginWithCode(string code, string url);
        public void ValidateMail(string email);
    }
}
