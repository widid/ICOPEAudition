using System;
using System.Threading.Tasks;
using UnityEngine.Networking;
using WiDiD.Extension;

namespace WiDiD.ImmersiveAPI.Networking
{
    public static class WebRequestUtility
    {
        public static event Action<bool> OnRequestCompleted;

        public static Task<WebRequestResult> GetAsync(string url, string authToken = null)
        {
            UnityWebRequest request = UnityWebRequest.Get(url);
            ApplyAuthHeader(request, authToken);
            return SendAsync(request);
        }

        public static Task<WebRequestResult> PostAsync(string url, byte[] data, string contentType = null, string contentDisposition = null, string authToken = null)
        {
            return SendWithBodyAsync(url, UnityWebRequest.kHttpVerbPOST, data, contentType, contentDisposition, authToken);
        }

        public static Task<WebRequestResult> PutAsync(string url, byte[] data, string contentType = null, string contentDisposition = null, string authToken = null)
        {
            return SendWithBodyAsync(url, UnityWebRequest.kHttpVerbPUT, data, contentType, contentDisposition, authToken);
        }

        private static Task<WebRequestResult> SendWithBodyAsync(string url, string verb, byte[] data, string contentType, string contentDisposition, string authToken)
        {
            UnityWebRequest request = new UnityWebRequest(url, verb)
            {
                uploadHandler = new UploadHandlerRaw(data),
                downloadHandler = new DownloadHandlerBuffer()
            };

            if (!string.IsNullOrEmpty(contentType))
            {
                request.SetRequestHeader("Content-Type", contentType);
                request.uploadHandler.contentType = contentType;
            }
            if (!string.IsNullOrEmpty(contentDisposition))
            {
                request.SetRequestHeader("Content-Disposition", contentDisposition);
            }

            ApplyAuthHeader(request, authToken);

            return SendAsync(request);
        }

        private static void ApplyAuthHeader(UnityWebRequest request, string authToken)
        {
            if (!string.IsNullOrEmpty(authToken))
            {
                request.SetRequestHeader("Authorization", "Bearer " + authToken);
            }
        }

        private static async Task<WebRequestResult> SendAsync(UnityWebRequest request)
        {
            using (request)
            {
                await request.SendWebRequest();

                bool success = request.result == UnityWebRequest.Result.Success;
                OnRequestCompleted?.Invoke(success);

                return new WebRequestResult(success, request.downloadHandler?.data, request.responseCode, success ? null : request.error);
            }
        }
    }
}
