using System;
namespace WiDiD.ImmersiveAPI.Networking.Authentification.User
{
    public class UserNotFoundException : Exception
    {
        public UserNotFoundException() { }

        public UserNotFoundException(string user)
            : base(String.Format("User not found : {0}", user))
        {

        }
    }
}