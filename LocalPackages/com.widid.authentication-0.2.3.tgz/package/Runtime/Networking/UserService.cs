

namespace WiDiD.ImmersiveAPI.Networking.Authentification.User
{
    public interface IUserService
    {
        public UserProfile GetUserProfile();
        public int GetUserId();
        public string GetUserProfilePictureURL();
        public string GetUserFirstName();
        public string GetUserLastName();
        public string GetUserEMail();
        public string GetUserToken();

        public void SetUserProfile(UserProfile userProfile);
    }
    public class UserService : IUserService
    {
        private UserProfile userProfile;

        public UserProfile GetUserProfile()
        {
            return userProfile;
        }

        public string GetUserFirstName()
        {
            return userProfile.Info.FirstName;
        }
        public string GetUserLastName()
        {
            return userProfile.Info.LastName;
        }
        public string GetUserEMail()
        {
            return userProfile.Info.Email;
        }

        public string GetUserToken()
        {
            return userProfile.Token;
        }

        public int GetUserId()
        {
            return userProfile.Info.Id;
        }

        public void SetUserProfile(UserProfile userProfile)
        {
            this.userProfile = userProfile;
        }
        public string GetUserProfilePictureURL()
        {
            return userProfile.Info.Picture;
        }
    }
}

