using System;

namespace WiDiD.ImmersiveAPI.Networking
{
    public class InvalidMailException : Exception
    {
        public InvalidMailException() { }

        public InvalidMailException(string mail)
            : base(String.Format("Invalid Mail: {0}", mail))
        {

        }
    }
}