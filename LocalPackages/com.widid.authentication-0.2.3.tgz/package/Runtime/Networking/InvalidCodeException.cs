using System;

namespace WiDiD.ImmersiveAPI.Networking
{
    public class InvalidCodeException : Exception
    {
        public InvalidCodeException()
            : base("Invalid or expired authentication code") { }
    }
}
