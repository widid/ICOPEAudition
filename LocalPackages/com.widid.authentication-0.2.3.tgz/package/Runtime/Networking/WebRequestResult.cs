using System;
using System.Text;

namespace WiDiD.ImmersiveAPI.Networking
{
    public class WebRequestResult
    {
        public bool Success { get; }
        public byte[] Data { get; }
        public long StatusCode { get; }
        public string Error { get; }

        public string Text => Data != null && Data.Length > 0 ? Encoding.UTF8.GetString(Data) : string.Empty;

        public WebRequestResult(bool success, byte[] data, long statusCode, string error)
        {
            Success = success;
            Data = data ?? Array.Empty<byte>();
            StatusCode = statusCode;
            Error = error;
        }
    }
}
