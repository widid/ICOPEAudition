using UnityEngine;
using WiDiD.Applications.Launch;

namespace WiDiD.ImmersiveAPI.Launch
{
    public static class LaunchArgumentsReaderFactory
    {
        public static ILaunchArgumentsReader Create()
        {
#if UNITY_EDITOR
            Debug.LogWarning("[LaunchArguments] Running in the Unity Editor: no launcher process is available, launch arguments will not be read.");
            return null;
#elif UNITY_ANDROID
            return new LaunchArgumentsAndroidReader();
#elif UNITY_WEBGL
            return new LaunchArgumentsWebGLReader();
#elif UNITY_STANDALONE
            return new LaunchArgumentCommandLineReader();
#else
            Debug.LogError("[LaunchArguments] No launch arguments reader is implemented for this platform.");
            return null;
#endif
        }
    }
}
