using Cysharp.Threading.Tasks;
using UnityEngine;
using WiDiD.Applications.Launch;

namespace WiDiD.ImmersiveAPI.Launch
{
    public static class LaunchArgumentsBootstrap
    {
        static LaunchArgumentsProvider provider;

        // Lazily created so any caller gets a valid Provider no matter the order Unity invokes
        // [RuntimeInitializeOnLoadMethod] methods in - that order is not guaranteed across classes.
        public static LaunchArgumentsProvider Provider => provider ??= CreateProvider();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Initialize()
        {
            // Touching Provider here just starts the read as early as possible.
            _ = Provider;
        }

        static LaunchArgumentsProvider CreateProvider()
        {
            ILaunchArgumentsReader reader = LaunchArgumentsReaderFactory.Create();
            LaunchArgumentsProvider newProvider = new(reader);
            newProvider.InitializeAsync().Forget();
            return newProvider;
        }
    }
}
