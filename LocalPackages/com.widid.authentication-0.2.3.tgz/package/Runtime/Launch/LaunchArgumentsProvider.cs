using System;
using Cysharp.Threading.Tasks;
using UnityEngine;
using WiDiD.Applications.Launch;

namespace WiDiD.ImmersiveAPI.Launch
{
    public class LaunchArgumentsProvider
    {
        readonly ILaunchArgumentsReader reader;
        readonly UniTaskCompletionSource<LaunchArguments> completionSource = new();

        public LaunchArguments Current { get; private set; }
        public bool IsReady { get; private set; }

        public LaunchArgumentsProvider(ILaunchArgumentsReader reader)
        {
            this.reader = reader;
        }

        public async UniTaskVoid InitializeAsync()
        {
            if (reader != null)
            {
                try
                {
                    Current = await reader.WaitForLaunchArguments();
                }
                catch (Exception exception)
                {
                    Debug.LogError($"[LaunchArguments] Reading launch arguments failed: {exception}");
                    Current = null;
                }
            }

            IsReady = true;
            completionSource.TrySetResult(Current);
        }

        public UniTask<LaunchArguments> WaitForLaunchArgumentsAsync()
        {
            return completionSource.Task;
        }
    }
}
