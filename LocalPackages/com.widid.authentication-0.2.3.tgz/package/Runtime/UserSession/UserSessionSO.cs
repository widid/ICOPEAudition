using UnityEngine;

namespace WiDiD.ImmersiveAPI
{
    [CreateAssetMenu(fileName = "NewUserSessionSO", menuName = "Data/User Session")]
    public class UserSessionSO : ScriptableObject, IUserSessionProvider
    {
        // Single source of truth for where this asset must live so it can be found via
        // Resources.Load with no Inspector wiring - see SessionGate and ImmersiveDebugSessionWindow.
        public const string ResourcePath = "ImmersiveAPI/UserSessionSO";

        [field: SerializeField]
        public UserSessionData Data { get; private set; } = new UserSessionData();

        private void OnEnable()
        {
#if !UNITY_EDITOR
            // UserProfile has no parameterless constructor and its own fields aren't
            // [SerializeField], so Unity can't properly reconstruct it across a domain
            // reload - it just leaves the previous in-memory reference in place. In a built
            // Player this only runs once, when the app launches, so this guarantees a clean
            // session rather than whatever happened to be serialized into the build's copy of
            // this asset (e.g. a debug session left logged in at build time).
            //
            // In the Editor, leave existing data alone: domain reloads happen far more often
            // here (every script recompile, every Play Mode entry), and wiping out the debug
            // session (see ImmersiveDebugSessionWindow) on every recompile is disruptive rather
            // than useful - that's exactly the "logged in" state ImmersiveDebugSessionWindow's
            // login is meant to persist across.
            Data.Empty();
#endif
        }
    }
}
