namespace WiDiD.ImmersiveAPI
{
    public interface IUserSessionProvider
    {
        UserSessionData Data { get; }
    }
}
