using System;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI
{
    [Serializable]
    public class UserSessionData
    {
        [SerializeField] string decodedToken = string.Empty;
        [SerializeField] string trainingId = string.Empty;
        [SerializeField] string moduleArgument = string.Empty;
        [SerializeField] string mode = string.Empty;
        [SerializeField] string targetUrl = string.Empty;
        [SerializeField] string launchTime = string.Empty;
        [SerializeField] string userId = string.Empty;
        [SerializeField] UserProfile userProfile = null;

        // xAPI Context.registration (a Guid string) - nothing populates this yet, deliberately: no
        // default/generated value should ever be sent (see RuntimeStatementBuilderProfile, which
        // only sets Context.registration when this parses as a valid Guid). Left as a plain string
        // rather than a Guid so it can sit empty without needing a "not set" sentinel value.
        [SerializeField] string registration = string.Empty;

        public UserSessionData() { }

        public UserSessionData(string decodedToken, string trainingId, string userId, string moduleArgument, string mode, string targetUrl, string launchTime, UserProfile userProfile = null)
        {
            this.decodedToken = decodedToken;
            this.trainingId = trainingId;
            this.moduleArgument = moduleArgument;
            this.mode = mode;
            this.targetUrl = targetUrl;
            this.launchTime = launchTime;
            this.userId = userId;
            this.userProfile = userProfile;
        }
        public bool IsEmpty
        {
            get => UserProfile == null || UserProfile.Info == null || UserProfile.Info.Id == 0;
        }
        public string TrainingId { get => trainingId; set => trainingId = value; }
        public string ModuleArgument { get => moduleArgument; set => moduleArgument = value; }
        public string Mode { get => mode; set => mode = value; }
        public string TargetUrl { get => targetUrl; set => targetUrl = value; }
        public string DecodedToken { get => decodedToken; set => decodedToken = value; }
        public string LaunchTime { get => launchTime; set => launchTime = value; }
        public string UserId { get => userId; set => userId = value; }
        public string Registration { get => registration; set => registration = value; }

        public event Action<UserProfile> OnUserProfileChanged;

        public UserProfile UserProfile
        {
            get => userProfile;
            set
            {
                userProfile = value;
                OnUserProfileChanged?.Invoke(userProfile);
            }
        }

        public void Empty()
        {
            this.decodedToken = string.Empty;
            this.trainingId = string.Empty;
            this.moduleArgument = string.Empty;
            this.mode = string.Empty;
            this.targetUrl = string.Empty;
            this.userId = string.Empty;
            this.launchTime = string.Empty;
            this.registration = string.Empty;
            UserProfile = null;
        }
    }
}