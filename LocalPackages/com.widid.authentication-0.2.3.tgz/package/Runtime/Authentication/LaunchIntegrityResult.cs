namespace WiDiD.ImmersiveAPI.Authentication
{
    public enum LaunchIntegrityResult
    {
        Valid,
        MalformedToken,
        TokenExpired,
        LaunchTooOld
    }
}
