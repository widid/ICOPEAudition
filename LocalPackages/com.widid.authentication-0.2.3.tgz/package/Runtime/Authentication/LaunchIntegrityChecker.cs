using System;
using System.Globalization;

namespace WiDiD.ImmersiveAPI.Authentication
{
    public static class LaunchIntegrityChecker
    {
        public static readonly TimeSpan DefaultMaxLaunchAge = TimeSpan.FromSeconds(60);

        public static LaunchIntegrityResult Validate(string rawToken, string launchedAtUnixSeconds, DateTimeOffset now, out LaunchTokenClaims claims, TimeSpan? maxLaunchAge = null)
        {
            if (!JwtTokenDecoder.TryDecode(rawToken, out claims))
                return LaunchIntegrityResult.MalformedToken;

            if (!TryParseLaunchedAt(launchedAtUnixSeconds, out DateTimeOffset launchedAt))
                return LaunchIntegrityResult.MalformedToken;

            return Validate(claims, launchedAt, now, maxLaunchAge);
        }

        public static LaunchIntegrityResult Validate(LaunchTokenClaims claims, DateTimeOffset launchedAt, DateTimeOffset now, TimeSpan? maxLaunchAge = null)
        {
            DateTimeOffset tokenExpiresAt = DateTimeOffset.FromUnixTimeMilliseconds((long)(claims.ExpiresAtUnixSeconds * 1000));
            if (now >= tokenExpiresAt)
                return LaunchIntegrityResult.TokenExpired;

            TimeSpan allowedDrift = maxLaunchAge ?? DefaultMaxLaunchAge;
            if (now - launchedAt > allowedDrift)
                return LaunchIntegrityResult.LaunchTooOld;

            return LaunchIntegrityResult.Valid;
        }

        /// <summary>
        /// Parses the unix-seconds string launch arguments carry as their launch time (see
        /// UserSessionData.LaunchTime). Public so anything displaying that value renders the same
        /// instant this check validates against, rather than parsing the format a second way.
        /// </summary>
        public static bool TryParseLaunchedAt(string raw, out DateTimeOffset result)
        {
            result = default;
            if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out double seconds))
                return false;

            result = DateTimeOffset.FromUnixTimeMilliseconds((long)(seconds * 1000));
            return true;
        }
    }
}
