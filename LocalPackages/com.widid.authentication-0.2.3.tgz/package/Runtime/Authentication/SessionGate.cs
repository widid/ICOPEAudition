using System;
using Cysharp.Threading.Tasks;
using UnityEngine;
using WiDiD.Applications.Launch;
using WiDiD.ErrorManagement;
using WiDiD.ImmersiveAPI.Launch;

namespace WiDiD.ImmersiveAPI.Authentication
{
    /// <summary>
    /// Runs before any scene loads: waits for the launcher-provided <see cref="LaunchArguments"/>,
    /// validates them, and either fills <see cref="UserSessionSO"/> or reports a critical error and
    /// terminates the app after a short grace period so the player can read what went wrong.
    /// </summary>
    public static class SessionGate
    {
        static readonly TimeSpan CrashDelay = TimeSpan.FromSeconds(5);

        // Fired once, only on success - the signal for anything that needs to know "the real
        // session is filled in, it's safe to act now" (e.g. TrainingRuntime). Never fires at all
        // if session validation fails or is skipped (Editor).
        public static event Action<UserSessionSO> OnSessionReady;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Initialize()
        {
#if UNITY_EDITOR
            Debug.LogWarning("[SessionGate] Running in the Unity Editor: session validation is skipped until an editor debug session exists.");
#else
            RunAsync().Forget();
#endif
        }

        static async UniTaskVoid RunAsync()
        {
            LaunchArguments args = await LaunchArgumentsBootstrap.Provider.WaitForLaunchArgumentsAsync();

            if (args == null)
            {
                Reject("This application must be launched through WiDiD Immersive.");
                return;
            }

            LaunchIntegrityResult result = LaunchIntegrityChecker.Validate(args.UserToken, args.LaunchedAt, DateTimeOffset.UtcNow, out LaunchTokenClaims claims);
            if (result != LaunchIntegrityResult.Valid)
            {
                Reject(DescribeFailure(result));
                return;
            }

            ApplySession(args, claims);
        }

        static void ApplySession(LaunchArguments args, LaunchTokenClaims claims)
        {
            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            if (sessionAsset == null)
            {
                Reject($"UserSessionSO asset could not be found at Resources/{UserSessionSO.ResourcePath}.");
                return;
            }

            UserSessionData data = sessionAsset.Data;
            data.DecodedToken = args.UserToken;
            data.TrainingId = args.TrainingID.ToString();
            data.ModuleArgument = args.ModuleArgument;
            data.TargetUrl = args.ImmersiveURL;
            data.LaunchTime = args.LaunchedAt;
            data.Mode = args.LaunchMode;
            data.UserId = claims.Subject.ToString();

            OnSessionReady?.Invoke(sessionAsset);
        }

        static void Reject(string message)
        {
            ErrorManager.ManageError(new ManagedError(message, ManagedError.EErrorType.CRITICAL));
            ScheduleTermination().Forget();
        }

        static async UniTaskVoid ScheduleTermination()
        {
            await UniTask.Delay(CrashDelay);
            AppTermination.Terminate();
        }

        static string DescribeFailure(LaunchIntegrityResult result) => result switch
        {
            LaunchIntegrityResult.MalformedToken => "Your session token could not be read. Please relaunch through WiDiD Immersive.",
            LaunchIntegrityResult.TokenExpired => "Your license has expired.",
            LaunchIntegrityResult.LaunchTooOld => "This application was not launched through WiDiD Immersive.",
            _ => "An unknown session error occurred."
        };
    }
}
