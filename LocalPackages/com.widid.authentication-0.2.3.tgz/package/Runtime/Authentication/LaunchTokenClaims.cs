using Newtonsoft.Json;

namespace WiDiD.ImmersiveAPI.Authentication
{
    public class LaunchTokenClaims
    {
        [JsonProperty("sub")] public int Subject { get; private set; }
        [JsonProperty("clientId")] public int ClientId { get; private set; }
        [JsonProperty("exp")] public double ExpiresAtUnixSeconds { get; private set; }
        [JsonProperty("auth")] public string Role { get; private set; }
    }
}
