using System;
using System.Globalization;

namespace WiDiD.ImmersiveAPI.Authentication
{
    /// <summary>
    /// Renders UserSessionData.LaunchTime - stored as the raw unix-seconds string launch arguments
    /// carry (see SessionGate.ApplySession) - as a readable local wall-clock time, which is what
    /// makes "was this launched just now?" verifiable at a glance. Shared so every surface showing
    /// it (runtime harness, config window) agrees on the format.
    /// </summary>
    public static class LaunchTimeDisplay
    {
        public static string Format(string launchTime)
        {
            if (string.IsNullOrEmpty(launchTime))
                return "(empty)";

            // Surfaced verbatim rather than hidden: an unparseable value is exactly what the
            // integrity check rejects, so seeing it is the point.
            if (!LaunchIntegrityChecker.TryParseLaunchedAt(launchTime, out DateTimeOffset launchedAt))
                return $"{launchTime} (unreadable)";

            return launchedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + " (local)";
        }
    }
}
