using System;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Authentication
{
    public static class JwtTokenDecoder
    {
        public static bool TryDecode(string token, out LaunchTokenClaims claims)
        {
            claims = null;

            if (string.IsNullOrEmpty(token))
                return false;

            string[] segments = token.Split('.');
            if (segments.Length != 3)
                return false;

            try
            {
                string payloadJson = DecodeBase64UrlSegment(segments[1]);
                claims = JsonConvert.DeserializeObject<LaunchTokenClaims>(payloadJson);
                return claims != null;
            }
            catch (Exception exception)
            {
                Debug.LogError($"[JwtTokenDecoder] Failed to decode token payload: {exception.Message}");
                return false;
            }
        }

        static string DecodeBase64UrlSegment(string segment)
        {
            string base64 = segment.Replace('-', '+').Replace('_', '/');
            int paddingLength = (4 - base64.Length % 4) % 4;
            base64 = base64.PadRight(base64.Length + paddingLength, '=');

            byte[] bytes = Convert.FromBase64String(base64);
            return Encoding.UTF8.GetString(bytes);
        }
    }
}
