# WiDiD Authentication

WiDiD Immersive authentication and user session for Unity. Lets a package read the current
session without depending on `com.widid.immersiveapi3`.

## Layout

| Folder | Assembly | Contents |
|---|---|---|
| `Runtime/UserSession/` | `widid.authentication.runtime` | `UserSessionSO`, `UserSessionData`, `IUserSessionProvider` |
| `Runtime/Authentication/` | `widid.authentication.runtime` | `SessionGate`, launch-token decoding and integrity check |
| `Runtime/Launch/` | `widid.authentication.runtime` | Launch-argument bootstrap/provider |
| `Runtime/Networking/` | `widid.authentication.runtime` | Login service, `UserProfile`, `UserService`, `WebRequestUtility`, `ILogger` |

Namespaces are `WiDiD.ImmersiveAPI.*`.

`widid.authentication.runtime` is **`autoReferenced: false`**: reference it explicitly from the
consuming assembly definition.

## Reading the session

`UserSessionSO` lives at `Resources/` + `UserSessionSO.ResourcePath`
(`Assets/Resources/ImmersiveAPI/UserSessionSO.asset`):

```csharp
UserSessionSO session = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
string token = session.Data.DecodedToken;
```

`SessionGate.OnSessionReady` fires once the launch arguments have been validated and written to it.

## Dependencies

**UniTask** is distributed as a Git URL, and Unity only resolves registry packages listed as a
package dependency. Add it to `Packages/manifest.json` by hand:

```
"com.cysharp.unitask": "https://github.com/Cysharp/UniTask.git?path=src/UniTask/Assets/Plugins/UniTask#2.5.10"
```
