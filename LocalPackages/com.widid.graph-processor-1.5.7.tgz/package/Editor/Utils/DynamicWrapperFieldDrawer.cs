using System;
using System.Reflection;
using UnityEditor;

namespace GraphProcessor
{
    /// <summary>
    /// Resolves the drawer for an input field whose declared type is a polymorphic value wrapper
    /// (any type exposing a public `object Value { get; set; }` property, such as the wrapper types
    /// used by ObjectFieldNode) when the field's real type is only known at runtime through a
    /// CustomPortBehavior-driven dynamic port. Lets ShowAsDrawer work for those "custom input" ports
    /// without graph-processor needing a compile-time reference to the concrete wrapper types.
    /// </summary>
    static class DynamicWrapperFieldDrawer
    {
        public static bool CanWrap(Type wrapperFieldType)
        {
            if (wrapperFieldType == null || wrapperFieldType.IsValueType)
                return false;

            var valueProperty = wrapperFieldType.GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
            return valueProperty != null && valueProperty.PropertyType == typeof(object) && valueProperty.CanRead && valueProperty.CanWrite;
        }

        /// <summary>
        /// Makes sure <paramref name="wrapperProperty"/> holds a concrete wrapper instance able to store
        /// <paramref name="valueType"/>, then returns the SerializedProperty for the value it actually stores.
        /// </summary>
        public static bool TryResolveValueProperty(SerializedProperty wrapperProperty, Type wrapperFieldType, Type valueType, out SerializedProperty valueProperty)
        {
            valueProperty = null;

            if (wrapperProperty == null || wrapperProperty.propertyType != SerializedPropertyType.ManagedReference)
                return false;

            if (!WrapperTypeResolver.TryFindConcreteWrapperType(wrapperFieldType, valueType, out Type concreteType, out FieldInfo valueField))
                return false;

            if (wrapperProperty.managedReferenceValue == null || wrapperProperty.managedReferenceValue.GetType() != concreteType)
            {
                wrapperProperty.serializedObject.Update();
                wrapperProperty.managedReferenceValue = Activator.CreateInstance(concreteType);
                wrapperProperty.serializedObject.ApplyModifiedProperties();
            }

            valueProperty = wrapperProperty.FindPropertyRelative(valueField.Name);
            return valueProperty != null;
        }
    }
}
