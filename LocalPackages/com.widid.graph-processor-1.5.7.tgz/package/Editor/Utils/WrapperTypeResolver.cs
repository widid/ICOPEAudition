using System;
using System.Linq;
using System.Reflection;
using UnityEditor;

namespace GraphProcessor
{
    /// <summary>
    /// Finds, among the concrete subclasses of a "value wrapper" base type (a type that stores an
    /// arbitrary value behind one field declared on the subclass itself - e.g. the IObjectWrapper
    /// wrapper types used for dynamically-typed custom input port drawers, or ExposedParameter's
    /// BoolParameter/IntParameter/... family), the one whose wrapped field best matches a given
    /// value type: an exact type match wins, then any assignable field, then a plain `object`
    /// catch-all field (a generic fallback wrapper, if one exists).
    /// </summary>
    public static class WrapperTypeResolver
    {
        public static bool TryFindConcreteWrapperType(Type wrapperBaseType, Type valueType, out Type concreteType, out FieldInfo valueField)
        {
            Type exactType = null; FieldInfo exactField = null;
            Type assignableType = null; FieldInfo assignableField = null;
            Type objectFallbackType = null; FieldInfo objectFallbackField = null;

            foreach (var candidate in TypeCache.GetTypesDerivedFrom(wrapperBaseType))
            {
                if (candidate.IsAbstract || candidate.IsGenericTypeDefinition || candidate.GetConstructor(Type.EmptyTypes) == null)
                    continue;

                // Skip SerializableType fields: GenericParameter/GenericObjectParameter use one to
                // remember their wrapped type explicitly (see ExposedParameter.cs), it isn't the
                // value-carrying field itself.
                FieldInfo field = candidate
                    .GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                    .FirstOrDefault(f => !f.IsStatic && f.FieldType != typeof(SerializableType));

                if (field == null)
                    continue;

                if (field.FieldType == valueType)
                {
                    exactType = candidate;
                    exactField = field;
                    break;
                }

                if (field.FieldType == typeof(object))
                {
                    objectFallbackType = candidate;
                    objectFallbackField = field;
                }
                else if (field.FieldType.IsAssignableFrom(valueType))
                {
                    assignableType = candidate;
                    assignableField = field;
                }
            }

            concreteType = exactType ?? assignableType ?? objectFallbackType;
            valueField = exactField ?? assignableField ?? objectFallbackField;
            return concreteType != null;
        }
    }
}
