using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Search;
using UnityEngine;

public class TypeSearchWindow : ScriptableObject
{
    private static Action<Type> _onTypeSelected;
    private static SearchProvider _typeSearchProvider;

    public static void Show(Action<Type> onTypeSelected, Type parentType = null)
    {
        var window = ScriptableObject.CreateInstance<TypeSearchWindow>();
        _onTypeSelected = onTypeSelected;

        var context = SearchService.CreateContext(GetTypeProvider(parentType), "");
        SearchService.ShowPicker(context, (item, _) =>
        {
            if (item != null && item.data is Type type)
            {
                _onTypeSelected?.Invoke(type);
            }
        });
    }

    private static SearchProvider GetTypeProvider(Type parentType = null)
    {
        _typeSearchProvider = new SearchProvider("typeProvider", "Types")
        {
            fetchItems = (context, items, provider) =>
            {
                var query = context.searchQuery?.ToLowerInvariant();
                var allTypes = GetAllAvailableTypes()
                .Where(t => (t.IsClass || t.IsValueType)
                    && !t.IsAbstract
                    && !t.IsGenericType
                    && !t.Name.StartsWith("<")
                    && (parentType == null ? true : t.IsSubclassOf(parentType)));

                if (!string.IsNullOrEmpty(query))
                {
                    allTypes = allTypes.Where(t =>
                        t.Name.ToLowerInvariant().Contains(query) ||
                        t.FullName.ToLowerInvariant().Contains(query));
                }

                foreach (var type in allTypes)
                {
                    items.Add(new SearchItem(type.FullName)
                    {
                        label = type.Name,
                        description = type.FullName,
                        data = type
                    });
                }

                return null;
            }
        };

        return _typeSearchProvider;
    }

    private static List<Type> GetAllAvailableTypes()
    {
        var allTypes = new List<Type>();

        foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            if (assembly.IsDynamic)
                continue;

            try
            {
                var types = assembly.GetTypes();
                allTypes.AddRange(types);
            }
            catch (ReflectionTypeLoadException e)
            {
                allTypes.AddRange(e.Types.Where(t => t != null));
            }
            catch
            {
                // Ignore other failures silently
            }
        }

        return allTypes;
    }
}
