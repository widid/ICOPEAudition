﻿using UnityEngine;
using UnityEditor.Experimental.GraphView;

namespace GraphProcessor
{
    public class MiniMapView : MiniMap
    {
        new BaseGraphView graphView;
        Vector2 size;

        public MiniMapView(BaseGraphView baseGraphView)
        {
            this.graphView = baseGraphView;
            SetPosition(new Rect(0, 20, 50, 10));
            size = new Vector2(50, 10);
            anchored = true;
        }
    }
}