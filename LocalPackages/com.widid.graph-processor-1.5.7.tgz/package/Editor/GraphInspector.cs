﻿using UnityEngine;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
using System;
using System.Reflection;

namespace GraphProcessor
{
    [CustomEditor(typeof(BaseGraph))]
    public class GraphInspector : Editor
    {
        protected VisualElement root;
        protected BaseGraph graph;
        protected ExposedParameterFieldFactory exposedParameterFactory;

        VisualElement parameterContainer;

        protected virtual void OnEnable()
        {
            graph = target as BaseGraph;
            graph.onExposedParameterListChanged += UpdateExposedParameters;
            graph.onExposedParameterModified += UpdateExposedParameters;
            if (exposedParameterFactory == null)
                exposedParameterFactory = new ExposedParameterFieldFactory(graph);
        }

        protected virtual void OnDisable()
        {
            graph.onExposedParameterListChanged -= UpdateExposedParameters;
            graph.onExposedParameterModified -= UpdateExposedParameters;
            exposedParameterFactory?.Dispose(); //  Graphs that created in GraphBehaviour sometimes gives null ref.
            exposedParameterFactory = null;
        }

        public sealed override VisualElement CreateInspectorGUI()
        {
            root = new VisualElement();
            CreateInspector();
            return root;
        }

        protected virtual void CreateInspector()
        {
            parameterContainer = new VisualElement
            {
                name = "ExposedParameters"
            };
            FillExposedParameters(parameterContainer);

            root.Add(parameterContainer);
        }

        protected void FillExposedParameters(VisualElement parameterContainer)
        {
            if (graph.exposedParameters.Count == 0)
                return;

            var exposedBox = new Box();
            exposedBox.style.marginTop = 10;
            exposedBox.style.paddingTop = 6;
            exposedBox.style.paddingBottom = 6;
            exposedBox.style.paddingLeft = 10;
            exposedBox.style.paddingRight = 10;
            exposedBox.style.backgroundColor = new Color(0.18f, 0.18f, 0.18f);
            exposedBox.style.borderTopLeftRadius = 4;
            exposedBox.style.borderBottomLeftRadius = 4;
            exposedBox.style.borderTopRightRadius = 4;
            exposedBox.style.borderBottomRightRadius = 4;
            exposedBox.style.borderBottomWidth = 1;
            exposedBox.style.borderTopWidth = 1;

            // Title
            var title = new Label("🧪 Exposed Parameters");
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.marginBottom = 4;
            title.style.fontSize = 13;
            title.style.color = Color.white;
            exposedBox.Add(title);

            foreach (var param in graph.exposedParameters)
            {
                if (param.settings.isHidden)
                    continue;

                var field = exposedParameterFactory.GetParameterValueField(param, (newValue) =>
                {
                    param.value = newValue;
                    serializedObject.ApplyModifiedProperties();
                    graph.NotifyExposedParameterValueChanged(param);
                });

                field.style.marginBottom = 4;
                exposedBox.Add(field);
            }

            parameterContainer.Add(exposedBox);
        }


        void UpdateExposedParameters(ExposedParameter param) => UpdateExposedParameters();

        void UpdateExposedParameters()
        {
            parameterContainer.Clear();
            FillExposedParameters(parameterContainer);
        }

        // Don't use ImGUI
        public sealed override void OnInspectorGUI() { }

    }
}