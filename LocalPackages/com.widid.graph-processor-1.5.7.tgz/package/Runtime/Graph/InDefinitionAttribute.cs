using System;

[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
public class InDefinitionAttribute : Attribute { }

[AttributeUsage(AttributeTargets.Field)]
public class UpdatePortsOnChangeAttribute : Attribute { }