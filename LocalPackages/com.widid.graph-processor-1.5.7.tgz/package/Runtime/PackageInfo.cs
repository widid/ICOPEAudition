﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("com.widid.NodeGraphProcessor.Editor")]