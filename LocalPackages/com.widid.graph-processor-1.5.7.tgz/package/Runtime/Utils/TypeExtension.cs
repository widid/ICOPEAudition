using UnityEngine;
using System;
using System.Linq.Expressions;

namespace GraphProcessor
{
	public static class TypeExtension
	{
		public static bool IsReallyAssignableFrom(this Type type, Type otherType)
		{
			if (type.IsAssignableFrom(otherType))
				return true;
			if (otherType.IsAssignableFrom(type))
				return true;

			try
			{
				var v = Expression.Variable(otherType);
				var expr = Expression.Convert(v, type);
				return expr.Method != null && expr.Method.Name != "op_Implicit";
			}
			catch (InvalidOperationException)
			{
				return false;
			}
		}

        public static Type GetTypeInProject(string typeName)
        {
            Type type = Type.GetType(typeName);
            if (type == null)
            {
                foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    type = assembly.GetType(typeName);
                    if (type != null)
                        break;
                }
            }
            return type;
        }

    }
}