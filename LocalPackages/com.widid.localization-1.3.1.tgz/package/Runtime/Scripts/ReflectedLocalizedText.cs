using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using WiDiD.Reflection;

namespace WiDiD.Localization
{
    public class ReflectedLocalizedText : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI text = null;
        [SerializeField] private ReflectedValue<LanguageDictionary> reflectedLanguageDictionary = null;

        private async void OnEnable()
        {
            while (!UnityEngine.Localization.Settings.LocalizationSettings.InitializationOperation.IsDone)
            {
                await Task.Yield();
            }
            SetLocale(UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged += SetLocale;
        }
        private void OnDisable()
        {
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged -= SetLocale;
        }
        private void SetLocale(UnityEngine.Localization.Locale locale)
        {
            if (reflectedLanguageDictionary == null) return;
            if (reflectedLanguageDictionary.Value.GetLanguageMap().Count == 0) return;
            text.text = reflectedLanguageDictionary.Value.GetLanguageMap()[locale.Identifier.Code.Split('-')[0]];
        }
        private void Reset()
        {
            TryGetComponent(out text);
        }
#if UNITY_EDITOR
        [InspectorMethodButton("Refresh text to current locale")]
        private void RefreshTextToCurrentLocale()
        {
            SetLocale(UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
        }
#endif
    }
}