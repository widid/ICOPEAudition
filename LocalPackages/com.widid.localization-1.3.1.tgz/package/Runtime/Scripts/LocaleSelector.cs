#if ENABLE_LOCALIZATION
using System.Collections;
using UnityEngine;
using UnityEngine.Localization.Settings;
using WiDiD.Extension;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace WiDiD.Localization
{
    public class LocaleSelector : ACoroutine
    {

        private int currentLocaleKey = 0;

        #region Private Methods
        private void Start()
        {
            currentLocaleKey = PlayerPrefs.GetInt("LocaleKey", 0);
            TryStartBehaviour();
        }
        protected override IEnumerator CoroutineBehaviour()
        {
            yield return UnityEngine.Localization.Settings.LocalizationSettings.InitializationOperation;
            yield return new WaitForEndOfFrame();
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale = UnityEngine.Localization.Settings.LocalizationSettings.AvailableLocales.Locales[currentLocaleKey];

            yield return base.CoroutineBehaviour();
        }
        #endregion

        #region Public Methods 
        public void NextLocale()
        {
            if (TryStartBehaviour())
            {
                currentLocaleKey++;
                if (currentLocaleKey >= UnityEngine.Localization.Settings.LocalizationSettings.AvailableLocales.Locales.Count)
                {
                    currentLocaleKey = 0;
                }

            }
        }
        public void PreviousLocale()
        {
            if (TryStartBehaviour())
            {
                currentLocaleKey--;
                if (currentLocaleKey < 0)
                {
                    currentLocaleKey = UnityEngine.Localization.Settings.LocalizationSettings.AvailableLocales.Locales.Count - 1;
                }

                PlayerPrefs.SetInt("LocaleKey", currentLocaleKey);
            }
        }

        #endregion
    }

#if UNITY_EDITOR
    [CustomEditor(typeof(LocaleSelector))]
    public class LocaleSelectorEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            LocaleSelector localeSelectorTarget = (LocaleSelector)target;

            if (Application.isPlaying)
                if (GUILayout.Button(new GUIContent("Next locale")))
                {
                    localeSelectorTarget.NextLocale();
                }
        }
    }
#endif
}
#endif
