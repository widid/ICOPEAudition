using UnityEngine;
using TMPro;
using UnityEngine.Localization.Settings;
using System.Threading.Tasks;

namespace WiDiD.Localization
{
    public class LocalizedText : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI text = null;
        [SerializeField] private LanguageDictionary languageDictionary = null;

        private async void OnEnable()
        {
            while (!UnityEngine.Localization.Settings.LocalizationSettings.InitializationOperation.IsDone)
            {
                await Task.Yield();
            }
            SetLocale(UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged += SetLocale;
        }
        private void OnDisable()
        {
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged -= SetLocale;
        }
        private void SetLocale(UnityEngine.Localization.Locale locale)
        {
            if (languageDictionary == null) return;
            if (languageDictionary.GetLanguageMap().Count == 0) return;
            text.text = languageDictionary.GetLanguageMap()[locale.Identifier.Code.Split('-')[0]];
        }
        private void Reset()
        {
            TryGetComponent(out text);
        }
#if UNITY_EDITOR
        [InspectorMethodButton("Refresh text to current locale")]
        private void RefreshTextToCurrentLocale()
        {
            SetLocale(UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
        }
#endif
    }
}
