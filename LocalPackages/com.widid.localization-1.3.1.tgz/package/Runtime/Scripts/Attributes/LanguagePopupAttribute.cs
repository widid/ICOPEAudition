using UnityEngine;

namespace WiDiD.Localization
{
    public class LanguagePopupAttribute : PropertyAttribute { }
}
