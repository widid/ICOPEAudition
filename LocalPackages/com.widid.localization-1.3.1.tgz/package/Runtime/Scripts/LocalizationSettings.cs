using System;
using UnityEngine.Localization;
using Cysharp.Threading.Tasks;
namespace WiDiD.Localization
{
    public static class LocalizationSettings
    {
        private static Locale serviceLocale;
        public static Locale SelectedServiceLocale
        {
            get
            {
                if (UseUnityEngineLocalization) return UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale;
                return serviceLocale;
            }
            set
            {
                if (value == serviceLocale) return;
                serviceLocale = value;
                SelectedServiceLocaleChanged?.Invoke(value);
            }
        }
        public static Action<Locale> SelectedServiceLocaleChanged;
        public static bool UseUnityEngineLocalization { get; set; } = true;
        static LocalizationSettings()
        {
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged += UnityLocalizationChangedCallback;
            WaitForUnityLocalizationInit();
        }

        public static void UnityLocalizationChangedCallback(Locale locale)
        {
            if (UseUnityEngineLocalization)
            {
                SelectedServiceLocale = locale;
            }
        }
        private static async void WaitForUnityLocalizationInit()
        {
            await UniTask.WaitUntil(() => UnityEngine.Localization.Settings.LocalizationSettings.InitializationOperation.IsDone);
            SelectedServiceLocale = UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale;
        }

    }
}
