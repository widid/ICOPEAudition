using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Localization;

#if UNITY_EDITOR
using UnityEditor;
#endif
using System.Linq;

namespace WiDiD.Localization
{
    [System.Serializable]
    public class LanguageDictionary
    {
        [System.Serializable]
        public struct LanguageKey
        {
            public int localizationIndex;
            public string value;
        }
        public static readonly string[] AvailableLanguages = new string[6] { "en", "fr", "it", "es", "de", "pt" };


        [SerializeField] private bool useLocalizedString;

        // Inspector helper (see LanguageDictionaryDrawer), but it must stay serialized in players
        // as well: #ifdef-ing a serialized field out gives the Editor and the player different
        // serialization layouts, and every asset holding a LanguageDictionary then logs
        // "has a different serialization layout when loading" when a build loads it.
        [SerializeField] private LocalizedString importSource;

        [SerializeField] private LanguageKey[] languageKeys = new LanguageKey[0];
        [SerializeField, HideInInspector] private int[] mandatoryLanguagesIndex = new int[] { 0, 1 };
        public LanguageKey[] LanguageKeys { get => languageKeys; set => languageKeys = value; }
        public LanguageDictionary(LanguageKey[] languageKeys, int[] mandatoryLanguagesIndex)
        {
            this.languageKeys = languageKeys;
            this.mandatoryLanguagesIndex = mandatoryLanguagesIndex;
        }

        public Dictionary<string, string> GetLanguageMap()
        {
            Dictionary<string, string> languageMap = new Dictionary<string, string>();
            foreach (LanguageKey key in languageKeys)
            {
                try
                {
                    languageMap.Add(AvailableLanguages[key.localizationIndex], key.value);
                }
                catch
                {

                }
            }
            return languageMap;
        }
        public bool TryAddLanguage(LanguageKey languageKey)
        {
            if (languageKey.localizationIndex < 0 || languageKey.localizationIndex > 5)
            {
                return false;
            }
            if (languageKeys.Where(key => key.localizationIndex == languageKey.localizationIndex).ToArray().Length > 0)
            {
                return false;
            }
            List<LanguageKey> keys = languageKeys.ToList();
            keys.Add(languageKey);
            languageKeys = keys.ToArray();
            return true;
        }
        public void CheckForMandatoryLanguages(string defaultValue = null)
        {
            foreach (int languageId in mandatoryLanguagesIndex)
            {
                bool languageIsSet = false;
                foreach (LanguageDictionary.LanguageKey language in LanguageKeys)
                {
                    if (language.localizationIndex == languageId)
                    {
                        languageIsSet = true;
                    }
                }
                if (!languageIsSet)
                {
                    TryAddLanguage(new LanguageDictionary.LanguageKey() { localizationIndex = languageId, value = defaultValue != null ? defaultValue : LanguageDictionary.AvailableLanguages[languageId] });
                }
            }
        }
    }
    #region Editor
#if UNITY_EDITOR
    [CustomPropertyDrawer(typeof(LanguageDictionary.LanguageKey))]
    public class LanguageKeyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            // Using BeginProperty / EndProperty on the parent property means that
            // prefab override logic works on the entire property.
            EditorGUI.BeginProperty(position, label, property);

            // Draw label
            //position = EditorGUI.PrefixLabel(position, GUIUtility.GetControlID(FocusType.Passive), label);

            // Don't make child fields be indented
            var indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;

            SerializedProperty serializedLocalization = property.FindPropertyRelative("localizationIndex");
            // Calculate rects
            var localizationRect = new Rect(position.x, position.y, position.width / 6, position.height);
            var valueRect = new Rect(position.x + position.width / 5.5f, position.y, position.width / 1.5f, position.height);

            // Draw fields - pass GUIContent.none to each so they are drawn without labels
            serializedLocalization.intValue = EditorGUI.Popup(localizationRect, serializedLocalization.intValue, LanguageDictionary.AvailableLanguages);
            EditorGUI.PropertyField(valueRect, property.FindPropertyRelative("value"), GUIContent.none);

            // Set indent back to what it was
            EditorGUI.indentLevel = indent;

            EditorGUI.EndProperty();
        }
    }
#endif
    #endregion
}
