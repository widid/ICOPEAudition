using System;
using UnityEditor;
using UnityEngine;
using WiDiD.Localization;

public static class LocalizedTextEditorExtensions
{
    [MenuItem("CONTEXT/LocalizedText/Replace with ReflectedLocalizedText")]
    private static void ReplaceWithReflected(MenuCommand command)
    {
        var source = command.context as LocalizedText;
        var go = source.gameObject;

        // Copy serialized data before destroying
        var so = new SerializedObject(source);
        var textProp = so.FindProperty("text");
        var dictProp = so.FindProperty("languageDictionary");

        Undo.DestroyObjectImmediate(source);
        var target = Undo.AddComponent<ReflectedLocalizedText>(go);

        // Assign copied values
        target.GetType()
            .GetField("text", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
            ?.SetValue(target, textProp.objectReferenceValue);

        // cannot directly convert LanguageDictionary → ReflectedValue<LanguageDictionary>
        // user must assign manually
        Debug.Log("Replaced with ReflectedLocalizedText. Please reassign reflectedLanguageDictionary.");
    }
    [MenuItem("CONTEXT/ReflectedLocalizedText/Replace with LocalizedText")]
    private static void ReplaceWithLocalized(MenuCommand command)
    {
        var source = command.context as ReflectedLocalizedText;
        if (source == null) return;

        var go = source.gameObject;

        // --- Récupère la valeur du ReflectedValue<LanguageDictionary> via reflection ---
        LanguageDictionary dictValue = null;
        var field = typeof(ReflectedLocalizedText).GetField("reflectedLanguageDictionary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

        if (field != null)
        {
            var wrapper = field.GetValue(source); // c'est ton ReflectedValue<LanguageDictionary>
            if (wrapper != null)
            {
                var valueProp = wrapper.GetType().GetProperty("Value");
                if (valueProp != null)
                    dictValue = valueProp.GetValue(wrapper) as LanguageDictionary;
            }
        }

        // --- On détruit l'ancien composant et on ajoute le nouveau ---
        Undo.DestroyObjectImmediate(source);
        var target = Undo.AddComponent<LocalizedText>(go);

        // Copie du champ text
        var textField = typeof(ReflectedLocalizedText).GetField("text",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
        var textValue = textField?.GetValue(source);

        typeof(LocalizedText).GetField("text",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
            ?.SetValue(target, textValue);

        // Copie du dictionnaire si dispo
        if (dictValue != null)
        {
            typeof(LocalizedText).GetField("languageDictionary",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(target, dictValue);
        }

        Debug.Log("Replaced with LocalizedText. ReflectedLanguageDictionary.Value transferred if possible.");
    }
}
