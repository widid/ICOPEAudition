using UnityEngine;
using UnityEditor;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEditor.Localization;
using System.Linq;
using UnityEngine.UIElements;
using UnityEditor.UIElements;
using System.Collections.Generic;

namespace WiDiD.Localization.Editor
{
    [CustomPropertyDrawer(typeof(LanguageDictionary))]
    public class LanguageDictionaryDrawer : PropertyDrawer
    {

        // ==================================================================================
        // IMPLEMENTATION 1: UI TOOLKIT (Modern)
        // ==================================================================================
        public override VisualElement CreatePropertyGUI(SerializedProperty property)
        {
            var root = new VisualElement();

            // 1. Main Foldout
            var foldout = new Foldout { text = property.displayName };
            foldout.BindProperty(property);
            root.Add(foldout);

            // 2. Control Container (Toggle + Import Field)
            var controlContainer = new VisualElement();
            controlContainer.style.marginBottom = 5;
            controlContainer.style.paddingTop = 5;
            controlContainer.style.paddingBottom = 5;
            controlContainer.style.paddingLeft = 5;
            controlContainer.style.paddingRight = 5;
            controlContainer.style.backgroundColor = new StyleColor(new Color(0.1f, 0.1f, 0.1f, 0.1f));
            controlContainer.style.borderBottomWidth = 1;
            controlContainer.style.borderBottomColor = new StyleColor(new Color(0.1f, 0.1f, 0.1f, 0.3f));
            controlContainer.style.minWidth = 400;

            // Properties
            var useLocalizedProp = property.FindPropertyRelative("useLocalizedString");
            var importProp = property.FindPropertyRelative("importSource");

            // Toggle "Use LocalizedString"
            var toggle = new Toggle("Use LocalizedString");
            toggle.BindProperty(useLocalizedProp);
            controlContainer.Add(toggle);

            // Import Field (Hidden by default)
            var importField = new PropertyField(importProp);
            importField.label = "Source";
            importField.style.marginTop = 5;
            // Hide the arrow foldout of the LocalizedString drawer for cleaner look
            importField.RegisterCallback<GeometryChangedEvent>(evt =>
            {
                var internalFoldout = importField.Q(className: "unity-foldout__toggle");
                if (internalFoldout != null) internalFoldout.style.display = DisplayStyle.None;
            });
            controlContainer.Add(importField);

            foldout.contentContainer.Add(controlContainer);

            // 3. ListView
            var keysProp = property.FindPropertyRelative("languageKeys");
            var listView = new ListView();
            listView.bindingPath = "languageKeys";
            listView.showAddRemoveFooter = true;
            listView.reorderable = true;
            listView.showBorder = true;
            listView.showFoldoutHeader = false;
            listView.virtualizationMethod = CollectionVirtualizationMethod.DynamicHeight;

            // Define UI Logic
            void UpdateVisibility()
            {
                bool usingLoc = useLocalizedProp.boolValue;

                // Show/Hide Import Field
                importField.style.display = usingLoc ? DisplayStyle.Flex : DisplayStyle.None;

                // If using LocalizedString, disable list editing (make it read-only visually)
                listView.SetEnabled(!usingLoc);
                listView.showAddRemoveFooter = !usingLoc;
            }

            // Bind Change Callbacks
            toggle.RegisterValueChangedCallback(evt => UpdateVisibility());

            // AUTO-FILL LOGIC: When Import Source changes
            importField.RegisterCallback<SerializedPropertyChangeEvent>(evt =>
            {
                if (useLocalizedProp.boolValue)
                {
                    ImportData(property, importProp);
                    // Refresh ListView
                    listView.Rebuild();
                }
            });

            // Initial State
            UpdateVisibility();

            // --- ListView Setup (Standard) ---
            listView.makeItem = () =>
            {
                var row = new VisualElement();
                row.style.flexDirection = FlexDirection.Row;
                row.style.marginBottom = 2;
                row.style.marginTop = 2;

                var langPopup = new PopupField<string>(LanguageDictionary.AvailableLanguages.ToList(), 0);
                langPopup.name = "lang-popup";
                langPopup.style.width = 60;
                langPopup.style.marginRight = 5;

                langPopup.RegisterValueChangedCallback(evt =>
                {
                    var prop = langPopup.userData as SerializedProperty;
                    if (prop != null)
                    {
                        prop.intValue = LanguageDictionary.AvailableLanguages.ToList().IndexOf(evt.newValue);
                        prop.serializedObject.ApplyModifiedProperties();
                    }
                });

                var textField = new TextField();
                textField.name = "text-field";
                textField.style.flexGrow = 1;

                row.Add(langPopup);
                row.Add(textField);
                return row;
            };

            listView.bindItem = (element, i) =>
            {
                var itemProp = keysProp.GetArrayElementAtIndex(i);
                var indexProp = itemProp.FindPropertyRelative("localizationIndex");
                var valueProp = itemProp.FindPropertyRelative("value");

                var popup = element.Q<PopupField<string>>("lang-popup");
                var textField = element.Q<TextField>("text-field");

                popup.userData = indexProp;

                if (indexProp.intValue >= 0 && indexProp.intValue < LanguageDictionary.AvailableLanguages.Length)
                    popup.SetValueWithoutNotify(LanguageDictionary.AvailableLanguages[indexProp.intValue]);
                else
                    popup.SetValueWithoutNotify(LanguageDictionary.AvailableLanguages[0]);

                textField.BindProperty(valueProp);
            };

            foldout.contentContainer.Add(listView);
            return root;
        }

        // ==================================================================================
        // IMPLEMENTATION 2: IMGUI (OnGUI)
        // ==================================================================================
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            float height = EditorGUIUtility.singleLineHeight; // Header

            if (property.isExpanded)
            {
                SerializedProperty keysProp = property.FindPropertyRelative("languageKeys");
                SerializedProperty useLocProp = property.FindPropertyRelative("useLocalizedString");

                // Toggle Height
                height += EditorGUIUtility.singleLineHeight + 2f;

                // Import Source Height (if toggled)
                if (useLocProp.boolValue)
                {
                    height += EditorGUIUtility.singleLineHeight + 2f;
                }

                // List Header (Size)
                height += EditorGUIUtility.singleLineHeight + 4f;

                // List Elements
                for (int i = 0; i < keysProp.arraySize; i++)
                {
                    height += EditorGUIUtility.singleLineHeight + 2f;
                }
                height += 2f;
            }
            return height;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            EditorGUI.BeginProperty(position, label, property);

            Rect headerRect = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            Rect foldoutRect = new Rect(headerRect);
            foldoutRect.width = EditorGUIUtility.labelWidth;
            property.isExpanded = EditorGUI.Foldout(foldoutRect, property.isExpanded, label, true);

            if (property.isExpanded)
            {
                EditorGUI.indentLevel++;
                float currentY = position.y + EditorGUIUtility.singleLineHeight + 2f;

                var useLocProp = property.FindPropertyRelative("useLocalizedString");
                var importProp = property.FindPropertyRelative("importSource");

                // 1. Toggle
                Rect toggleRect = new Rect(position.x, currentY, position.width, EditorGUIUtility.singleLineHeight);
                EditorGUI.PropertyField(toggleRect, useLocProp, new GUIContent("Use Localized String"));
                currentY += EditorGUIUtility.singleLineHeight + 2f;

                // 2. Import Source (Conditional)
                if (useLocProp.boolValue)
                {
                    Rect importRect = new Rect(position.x, currentY, position.width, EditorGUIUtility.singleLineHeight);

                    EditorGUI.BeginChangeCheck();
                    EditorGUI.PropertyField(importRect, importProp);
                    if (EditorGUI.EndChangeCheck())
                    {
                        // AUTO-FILL ON CHANGE
                        ImportData(property, importProp);
                    }
                    currentY += EditorGUIUtility.singleLineHeight + 2f;
                }

                // 3. List
                SerializedProperty keysProp = property.FindPropertyRelative("languageKeys");

                // Disable editing if using localized string
                EditorGUI.BeginDisabledGroup(useLocProp.boolValue);

                Rect sizeRect = new Rect(position.x, currentY, position.width, EditorGUIUtility.singleLineHeight);
                EditorGUI.PropertyField(sizeRect, keysProp.FindPropertyRelative("Array.size"), new GUIContent("Size"));
                currentY += EditorGUIUtility.singleLineHeight + 2f;

                for (int i = 0; i < keysProp.arraySize; i++)
                {
                    SerializedProperty element = keysProp.GetArrayElementAtIndex(i);
                    SerializedProperty indexProp = element.FindPropertyRelative("localizationIndex");
                    SerializedProperty valueProp = element.FindPropertyRelative("value");

                    Rect rowRect = EditorGUI.IndentedRect(new Rect(position.x, currentY, position.width, EditorGUIUtility.singleLineHeight));
                    float newWidth = (position.x + position.width) - rowRect.x;
                    rowRect.width = newWidth;

                    float langWidth = 45f;
                    float textGap = 2f;
                    float textWidth = rowRect.width - langWidth - textGap;

                    Rect langRect = new Rect(rowRect.x, rowRect.y, langWidth, rowRect.height);
                    Rect textRect = new Rect(rowRect.x + langWidth + textGap, rowRect.y, textWidth, rowRect.height);

                    int oldIndent = EditorGUI.indentLevel;
                    EditorGUI.indentLevel = 0;

                    indexProp.intValue = EditorGUI.Popup(langRect, indexProp.intValue, LanguageDictionary.AvailableLanguages);
                    EditorGUI.PropertyField(textRect, valueProp, GUIContent.none);

                    EditorGUI.indentLevel = oldIndent;
                    currentY += EditorGUIUtility.singleLineHeight + 2f;
                }

                EditorGUI.EndDisabledGroup();
                EditorGUI.indentLevel--;
            }

            EditorGUI.EndProperty();
        }

        // ==================================================================================
        // SHARED LOGIC
        // ==================================================================================
        public static void ImportData(SerializedProperty rootProperty, SerializedProperty sourceProp)
        {
            var localizedString = SerializedPropertyExtensions.GetTargetObjectOfProperty(sourceProp) as LocalizedString;

            if (localizedString == null || localizedString.IsEmpty) return;

            var collection = LocalizationEditorSettings.GetStringTableCollection(localizedString.TableReference);
            if (collection == null) return;

            SerializedProperty keysArray = rootProperty.FindPropertyRelative("languageKeys");
            keysArray.ClearArray();

            string[] availableLangs = LanguageDictionary.AvailableLanguages;

            for (int i = 0; i < availableLangs.Length; i++)
            {
                string targetSimpleCode = availableLangs[i];

                var unityLocale = LocalizationEditorSettings.GetLocales().FirstOrDefault(l =>
                    l.Identifier.CultureInfo.TwoLetterISOLanguageName.Equals(targetSimpleCode, System.StringComparison.OrdinalIgnoreCase));

                if (unityLocale == null) continue;

                var stringTable = collection.GetTable(unityLocale.Identifier) as StringTable;
                if (stringTable == null) continue;

                StringTableEntry entry = null;
                var reference = localizedString.TableEntryReference;

                if (reference.ReferenceType == TableEntryReference.Type.Id)
                    entry = stringTable.GetEntry(reference.KeyId);
                else
                    entry = stringTable.GetEntry(reference.Key);

                if (entry != null && !string.IsNullOrEmpty(entry.Value))
                {
                    int index = keysArray.arraySize;
                    keysArray.InsertArrayElementAtIndex(index);
                    SerializedProperty element = keysArray.GetArrayElementAtIndex(index);

                    element.FindPropertyRelative("localizationIndex").intValue = i;
                    element.FindPropertyRelative("value").stringValue = entry.Value;
                }
            }

            rootProperty.serializedObject.ApplyModifiedProperties();
        }
    }
}