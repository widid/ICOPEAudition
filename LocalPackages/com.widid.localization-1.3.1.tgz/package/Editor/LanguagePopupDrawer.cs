
using UnityEditor;
using UnityEngine;

namespace WiDiD.Localization
{
    [CustomPropertyDrawer(typeof(LanguagePopupAttribute))]
    public class LanguagePopupDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            string[] langs = LanguageDictionary.AvailableLanguages;

            if (property.propertyType == SerializedPropertyType.Integer)
            {
                property.intValue = EditorGUI.Popup(position, label.text, Mathf.Clamp(property.intValue, 0, langs.Length - 1), langs);
            }
            else if (property.propertyType == SerializedPropertyType.String)
            {
                int currentIndex = Mathf.Max(0, System.Array.IndexOf(langs, property.stringValue));
                int newIndex = EditorGUI.Popup(position, label.text, currentIndex, langs);
                property.stringValue = langs[newIndex];
            }
            else
            {
                EditorGUI.LabelField(position, label.text, "Use [LanguagePopup] with int or string.");
            }
        }
    }
}
