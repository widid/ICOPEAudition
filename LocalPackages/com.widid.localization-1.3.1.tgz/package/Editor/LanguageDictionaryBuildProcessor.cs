using UnityEngine;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace WiDiD.Localization.Editor
{
    public class LanguageDictionaryBuildProcessor : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0; // Run early

        public void OnPreprocessBuild(BuildReport report)
        {
            Debug.Log("LanguageDictionary: Updating dictionaries from LocalizedStrings...");
            UpdateAllLanguageDictionaries();
        }

        public static void UpdateAllLanguageDictionaries()
        {
            // 1. Find all ScriptableObjects in the project
            string[] guids = AssetDatabase.FindAssets("t:ScriptableObject");

            int updatedCount = 0;

            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                ScriptableObject so = AssetDatabase.LoadAssetAtPath<ScriptableObject>(path);

                if (so == null) continue;

                // 2. Reflectively check fields for LanguageDictionary
                SerializedObject serializedSO = new SerializedObject(so);
                SerializedProperty iter = serializedSO.GetIterator();
                bool enterChildren = true;
                bool isDirty = false;

                while (iter.NextVisible(enterChildren))
                {
                    enterChildren = false; // Scan top-level properties (and arrays if needed, deeply scanning is expensive)

                    // Check if property is a LanguageDictionary
                    // Note: This matches simple fields. If LanguageDictionary is nested deep in arrays/lists/classes, 
                    // you might need a deep recursive iterator.
                    if (iter.type == nameof(LanguageDictionary))
                    {
                        var useLocProp = iter.FindPropertyRelative("useLocalizedString");
                        var importProp = iter.FindPropertyRelative("importSource");

                        if (useLocProp != null && useLocProp.boolValue)
                        {
                            // Call the static import function we defined in the Drawer
                            LanguageDictionaryDrawer.ImportData(iter, importProp);
                            isDirty = true;
                            updatedCount++;
                        }
                    }
                    // Handle Arrays of LanguageDictionary (common case)
                    else if (iter.isArray && iter.arrayElementType == nameof(LanguageDictionary))
                    {
                        for (int i = 0; i < iter.arraySize; i++)
                        {
                            SerializedProperty element = iter.GetArrayElementAtIndex(i);
                            var useLocProp = element.FindPropertyRelative("useLocalizedString");
                            var importProp = element.FindPropertyRelative("importSource");

                            if (useLocProp != null && useLocProp.boolValue)
                            {
                                LanguageDictionaryDrawer.ImportData(element, importProp);
                                isDirty = true;
                                updatedCount++;
                            }
                        }
                    }
                }

                if (isDirty)
                {
                    serializedSO.ApplyModifiedProperties();
                    EditorUtility.SetDirty(so);
                }
            }

            if (updatedCount > 0)
            {
                AssetDatabase.SaveAssets();
                Debug.Log($"LanguageDictionary: Updated {updatedCount} dictionaries.");
            }
        }
    }
}