using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using WiDiD.Localization;
using UnityEngine.Localization;
using UnityEditor;
using UnityEditor.Localization;
using UnityEngine.Localization.Tables;

namespace WiDiD.Localization.Helpers
{
    public static class LanguageDictionaryConverter
    {
        /// <summary>
        /// Converts a Unity LocalizedString into your custom LanguageDictionary format.
        /// This must be run in the Editor.
        /// </summary>
        public static LanguageDictionary ToLanguageDictionary(LocalizedString unityString)
        {
            if (unityString == null || unityString.IsEmpty)
            {
                Debug.LogWarning("Cannot convert: LocalizedString is null or empty.");
                return new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
            }

            // 1. Get the Collection from the Unity Editor Settings
            var collection = LocalizationEditorSettings.GetStringTableCollection(unityString.TableReference);
            if (collection == null)
            {
                Debug.LogError($"Could not find String Table Collection for reference: {unityString.TableReference}");
                return null;
            }

            List<LanguageDictionary.LanguageKey> newKeys = new List<LanguageDictionary.LanguageKey>();

            // 2. Iterate through your custom class's defined languages (en, fr, it...)
            string[] targetCodes = LanguageDictionary.AvailableLanguages;

            for (int i = 0; i < targetCodes.Length; i++)
            {
                string targetCode = targetCodes[i];

                // 3. Find the matching Unity Locale
                // We compare TwoLetterISOLanguageName to handle cases like "en-US" matching "en"
                var unityLocale = LocalizationEditorSettings.GetLocales().FirstOrDefault(l =>
                    l.Identifier.CultureInfo.TwoLetterISOLanguageName.ToLower() == targetCode.ToLower());

                if (unityLocale == null)
                {
                    // Language exists in your dictionary but not in Unity Localization Settings
                    continue;
                }

                // 4. Get the specific table for this locale
                var stringTable = collection.GetTable(unityLocale.Identifier) as UnityEngine.Localization.Tables.StringTable;

                if (stringTable != null)
                {
                    StringTableEntry entry = null;
                    var reference = unityString.TableEntryReference;

                    if (reference.ReferenceType == TableEntryReference.Type.Name)
                    {
                        entry = stringTable.GetEntry(reference.Key);
                    }
                    else
                    {
                        entry = stringTable.GetEntry(reference.KeyId);
                    }

                    if (entry != null && !string.IsNullOrEmpty(entry.Value))
                    {
                        newKeys.Add(new LanguageDictionary.LanguageKey
                        {
                            localizationIndex = i,
                            value = entry.Value
                        });
                    }
                }
            }

            // 7. Construct and return the new dictionary
            // Defaulting mandatory indices to 0 (en) and 1 (fr) as per your class defaults
            return new LanguageDictionary(newKeys.ToArray(), new int[] { 0, 1 });
        }
    }
}