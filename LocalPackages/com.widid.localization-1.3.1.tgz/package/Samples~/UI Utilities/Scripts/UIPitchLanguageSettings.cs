using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.UI;

namespace WiDiD.Localization
{
    [DefaultExecutionOrder(1)]
    public class UIPitchLanguageSettings : MonoBehaviour
    {
        [SerializeField] private UILanguageSelection languageSelection;
        [SerializeField] private TMP_Dropdown languageDropdown;
        [SerializeField] private Toggle toggleUseForPitch;

        private void OnEnable()
        {
            languageDropdown.onValueChanged.AddListener(OnLanguageDropdownValueChanged);
            toggleUseForPitch.onValueChanged.AddListener(OnToggleValueChanged);
            toggleUseForPitch.isOn = WiDiD.Localization.LocalizationSettings.UseUnityEngineLocalization;
            languageSelection.LanguageDropdown.onValueChanged.AddListener(OnLanguageSelectionDropdownChanged);
            PopulateLanguageDropdown();
        }

        private void OnLanguageSelectionDropdownChanged(int newValue)
        {
            if (toggleUseForPitch.isOn == true) return;

            PopulateLanguageDropdown();
            OnLanguageDropdownValueChanged(languageDropdown.value);
        }

        private void OnDisable()
        {
            languageDropdown.onValueChanged.RemoveListener(OnLanguageDropdownValueChanged);
            toggleUseForPitch.onValueChanged.RemoveListener(OnToggleValueChanged);
            languageSelection.LanguageDropdown.onValueChanged.RemoveListener(OnLanguageSelectionDropdownChanged);
        }
        private void OnLanguageDropdownValueChanged(int newValue)
        {
            string selectedLocaleKey = languageSelection.LocaleNameDictionary.GetLanguageMap().Where(kvp => kvp.Value == languageDropdown.options[newValue].text).First().Key;

            Locale[] availablesLocales = UnityEngine.Localization.Settings.LocalizationSettings.AvailableLocales.Locales.ToArray();
            Locale selectedLocale = availablesLocales.Where(l => l.Identifier.Code.Split("-").First() == selectedLocaleKey).FirstOrDefault();
            if (selectedLocale == null)
            {
                Debug.LogWarning($"There is not any locale in your Localization Settings that match the Selected locale in the dialogue language dropdown selected value : {selectedLocaleKey + ": " + languageDropdown.options[newValue].text}");
                return;
            }

            WiDiD.Localization.LocalizationSettings.SelectedServiceLocale = (selectedLocale);
        }
        private void OnToggleValueChanged(bool newValue)
        {
            languageDropdown.transform.parent.gameObject.SetActive(!newValue);
            if (!newValue)
            {
                PopulateLanguageDropdown();
                OnLanguageDropdownValueChanged(languageDropdown.value);
            }
            else
            {
                WiDiD.Localization.LocalizationSettings.SelectedServiceLocale = (UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
            }
            WiDiD.Localization.LocalizationSettings.UseUnityEngineLocalization = newValue;
        }

        private void PopulateLanguageDropdown()
        {
            List<TMP_Dropdown.OptionData> options = new List<TMP_Dropdown.OptionData>();
            languageDropdown.options.Clear();

            for (int i = 0; i < languageSelection.LanguageDropdown.options.Count; i++)
            {
                if (i == languageSelection.LanguageDropdown.value) continue;

                options.Add(languageSelection.LanguageDropdown.options[i]);
            }
            languageDropdown.options = options;
        }
    }
}