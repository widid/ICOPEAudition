using UnityEngine;
using TMPro;
using System.Linq;
using Cysharp.Threading.Tasks;

namespace WiDiD.Localization
{
    public class UILanguageSelection : MonoBehaviour
    {
        [SerializeField] private TMP_Dropdown languageDropdown;
        [SerializeField] private LanguageDictionary localeNameDictionary;

        public LanguageDictionary LocaleNameDictionary { get => localeNameDictionary; }
        public TMP_Dropdown LanguageDropdown { get => languageDropdown; }

        private void OnEnable()
        {
            PopulateDropdown();
            SetInitialValue();
            languageDropdown.onValueChanged.AddListener(OnDropdownValueChangedCallback);
        }
        private void OnDisable()
        {
            languageDropdown.onValueChanged.RemoveListener(OnDropdownValueChangedCallback);
        }
        private void OnDropdownValueChangedCallback(int index)
        {
            string LocaleIdentifier = localeNameDictionary.GetLanguageMap().Keys.ToList()[index];
            UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale = UnityEngine.Localization.Settings.LocalizationSettings.AvailableLocales.Locales.Where(l => l.Identifier.Code.Split("-").First() == LocaleIdentifier).First();
            PopulateDropdown();
            languageDropdown.SetValueWithoutNotify(index);
        }

        private void PopulateDropdown()
        {
            languageDropdown.ClearOptions();
            foreach (var v in localeNameDictionary.GetLanguageMap().Values)
            {
                languageDropdown.options.Add(new TMP_Dropdown.OptionData(v));
            }
            languageDropdown.captionText.text = localeNameDictionary.GetLanguageMap()[UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale.Identifier.Code.Split("-").First()];
        }
        private void SetInitialValue()
        {
            string localeIdentifier = UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale.Identifier.Code.Split("-").First();
            int index = localeNameDictionary.GetLanguageMap().Keys.ToList().IndexOf(localeIdentifier);
            languageDropdown.SetValueWithoutNotify(index);
        }
    }
}