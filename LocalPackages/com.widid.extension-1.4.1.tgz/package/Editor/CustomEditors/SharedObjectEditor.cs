using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SharedObject))]
public class SharedObjectEditor : Editor
{
    public override void OnInspectorGUI()
    {
        SharedObject shared = (SharedObject)target;

        // Affiche les autres propriétés, sauf le champ privé _guid
        DrawPropertiesExcluding(serializedObject, "_guid");

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("GUID", shared.Guid.ToString());

        if (GUILayout.Button("Copy GUID"))
        {
            EditorGUIUtility.systemCopyBuffer = shared.Guid.ToString();
        }

        serializedObject.ApplyModifiedProperties();
    }
}