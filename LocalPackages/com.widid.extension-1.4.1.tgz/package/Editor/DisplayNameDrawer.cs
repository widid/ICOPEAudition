using UnityEditor;
using UnityEngine;

[CustomPropertyDrawer(typeof(DisplayNameAttribute))]
public class DisplayNameDrawer : PropertyDrawer
{
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        var displayName = (attribute as DisplayNameAttribute)?.DisplayName ?? label.text;
        EditorGUI.PropertyField(position, property, new GUIContent(displayName), true);
    }
}
