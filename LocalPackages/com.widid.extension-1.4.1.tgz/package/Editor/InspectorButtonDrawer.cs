using System.Reflection;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MonoBehaviour), true)]
public class InspectorMethodButtonDrawer : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        var targetObject = target;
        var methods = targetObject.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

        foreach (var method in methods)
        {
            var attributes = method.GetCustomAttributes(typeof(InspectorMethodButtonAttribute), true);
            if (attributes.Length > 0)
            {
                var buttonAttribute = (InspectorMethodButtonAttribute)attributes[0];
                string buttonLabel = string.IsNullOrEmpty(buttonAttribute.ButtonLabel) ? method.Name : buttonAttribute.ButtonLabel;

                if (GUILayout.Button(buttonLabel))
                {
                    method.Invoke(targetObject, null);
                }
            }
        }
    }
}