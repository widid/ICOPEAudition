using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace WiDiD.Extension.Editors
{
    /// <summary>
    /// Static helper for SO management 
    /// </summary>
    public static class ScriptableHelper
    {
        public static List<ScriptableObject> GetSubObjectOfType<T>(ScriptableObject asset)
        {
            UnityEngine.Object[] objs = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(asset));

            List<ScriptableObject> ofType = new List<ScriptableObject>();

            foreach (UnityEngine.Object obj in objs)
            {
                if (obj is T)
                {
                    ofType.Add((ScriptableObject)obj);
                }
            }

            return ofType;
        }
    }
}

