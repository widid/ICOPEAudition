using UnityEngine;

[CreateAssetMenu(fileName = "ObjectID", menuName = "ScriptableObjects/ObjectID")]
public class ObjectIdSO : BaseScriptableObject
{
    [Header("The name of the asset. Can be used with various methods of objectID")]
    [SerializeField] private string objectName;
    public string Name { get => objectName;}    
}
