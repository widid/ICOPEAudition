/// <summary>
/// Struct that represents intervals with 4 bounds.
//  Useful to identify a valid range([bound2,bound3]), an average range [bound1,bound2[&]bound3,bound4] and an out of bounds negative range ]-infinity;bounds1[&]bounds4;+infinity[.
/// </summary>
[System.Serializable]
public struct ValueRanges
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="bound1">Start value, must be less than bound2</param>
    /// <param name="bound2">Must be higher than bound1 and less than bound3</param>
    /// <param name="bound3">Must be higher than bound2 and less than bound3</param>
    /// <param name="bound4">Last value, must be higher than bound3</param>
    public ValueRanges(float bound1, float bound2, float bound3, float bound4)
    {
        this.Bound1 = bound1;
        this.Bound2 = bound2;
        this.Bound3 = bound3;
        this.Bound4 = bound4;
    }
    public float Bound1;
    public float Bound2;
    public float Bound3;
    public float Bound4;
    public float[] Bounds => new float[4] { Bound1, Bound2, Bound3, Bound4 };


    /// <returns>Returns a normalized copy of this</returns>
    public ValueRanges Normalize()
    {
        float factor = 1 / Bound4;
        return new ValueRanges(Bound1 * factor, Bound2 * factor, Bound3 * factor, Bound4 * factor);
    }
}