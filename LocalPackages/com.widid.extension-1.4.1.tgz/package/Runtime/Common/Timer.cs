using System;
using UnityEngine;

namespace WiDiD.Extension
{
    public class Timer
    {
        private float time = 0;
        private float waitingTime = 0;

        public float Time { get => time; set => time = value; }
        public float WaitingTime { get => waitingTime; set => waitingTime = value; }

        public Action OnTimerEnded = null;


        /// <summary>
        /// Timer object
        /// </summary>
        /// <param name="time">Waiting time</param>
        public Timer(float waitingTime)
        {
            time = 0;
            this.waitingTime = waitingTime;
        }

        /// <summary>
        /// Must be called recursively
        /// </summary>
        /// <returns>Returns if the timer reached its waiting time</returns>
        public bool HasEnded()
        {
            bool ended = ((time += UnityEngine.Time.deltaTime) > waitingTime);
            if (ended)
            {
                OnTimerEnded?.Invoke();
            }

            return ended;
        }
        public void ResetTimer()
        {
            time = 0;
        }

    }
}

