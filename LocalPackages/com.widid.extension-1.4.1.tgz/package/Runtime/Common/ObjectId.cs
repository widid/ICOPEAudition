﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


namespace WiDiD.Interaction
{

    /// <summary>
    /// Useful to get specific objects in another scene
    /// </summary>
    [DisallowMultipleComponent]
    public class ObjectId : MonoBehaviour
    {
        public static HashSet<ObjectId> m_ObjectIds = new HashSet<ObjectId>();
        public static UnityEvent<ObjectId> m_ObjectAdded = new UnityEvent<ObjectId>();
        public static UnityEvent<ObjectId> m_ObjectRemoved = new UnityEvent<ObjectId>();

        [SerializeField, Tooltip("Add an ObjectIdSO to allow identification of the object across scenes")]
        private ObjectIdSO m_ObjectIdSO;

        [SerializeField, Tooltip("Set to true if you want to rename the UID based on the parent name (ex : PARENT_THIS")]
        private bool m_RenameAfterParent;

        private bool m_RenamingDone;
        private string m_UniqueID;
        private string m_Name;

        public string Name
        {
            get
            {
                return string.IsNullOrWhiteSpace(m_Name) ? m_ObjectIdSO.Name : m_Name;
            }
        }
        public string UniqueId
        {
            get
            {
                return string.IsNullOrWhiteSpace(m_UniqueID) ? m_ObjectIdSO.Id : m_UniqueID;
            }
        }

        public ObjectIdSO ObjectIdSO { get => m_ObjectIdSO; set => m_ObjectIdSO = value; }

        public static ObjectId GetObjectWithSameName(string pName)
        {
            if (string.IsNullOrWhiteSpace(pName)) return null;

            foreach (var item in m_ObjectIds)
            {
                if (string.Equals(item.Name, pName)) return item;
            }

            return null;
        }

        /// <summary>
        /// Search an ObjectId with the same UID. In its children, get the T component you're looking for.
        /// </summary>
        public static T GetBehaviourWithSameName<T>(string pName)
        {
            var lItem = GetObjectWithSameName(pName);
            if (lItem == null) return default(T);

            return lItem.GetComponentInChildren<T>();
        }

        public static HashSet<ObjectId> GetObjectsWithSameName(List<string> pNames)
        {
            HashSet<ObjectId> lHashSet = new HashSet<ObjectId>();
            if (pNames == null || pNames.Count == 0) return lHashSet;

            pNames.RemoveAll(v => string.IsNullOrWhiteSpace(v));


            foreach (var item in m_ObjectIds)
            {
                if (pNames.Contains(item.Name))
                {
                    lHashSet.Add(item);
                }
            }

            return lHashSet;
        }


        /// <summary>
        /// Return all <see cref="T"/> component which are children of objects which UID are in the list of arguments
        /// </summary>
        public static HashSet<T> GetBehavioursWithSameName<T>(List<string> pNames)
        {
            HashSet<T> lHashSet = new HashSet<T>();
            if (pNames == null || pNames.Count == 0) return lHashSet;

            pNames.RemoveAll(v => string.IsNullOrWhiteSpace(v));

            HashSet<ObjectId> lObjectIds = ObjectId.GetObjectsWithSameName(pNames);
            if (lObjectIds == null || lObjectIds.Count == 0) return lHashSet;

            foreach (var lObjectId in lObjectIds)
            {
                T lScript = lObjectId.GetComponentInChildren<T>();
                if (lScript != null)
                    lHashSet.Add(lScript);
            }
            return lHashSet;
        }


        public static ObjectId GetObjectWhichNameBeginWith(string pPartOfName)
        {
            if (string.IsNullOrWhiteSpace(pPartOfName)) return null;

            foreach (var item in m_ObjectIds)
            {
                if (item.Name.StartsWith(pPartOfName)) return item;
            }

            return null;
        }

        public static T GetBehaviourWhichNameBeginWith<T>(string pPartOfName)
        {
            var lItem = GetObjectWhichNameBeginWith(pPartOfName);
            if (lItem == null) return default(T);

            return lItem.GetComponentInChildren<T>();
        }

        public static HashSet<ObjectId> GetObjectsWhichNameBeginWith(string pPartOfName)
        {
            HashSet<ObjectId> lHashSet = new HashSet<ObjectId>();

            if (string.IsNullOrWhiteSpace(pPartOfName)) return lHashSet;

            foreach (var item in m_ObjectIds)
            {
                if (item.Name.StartsWith(pPartOfName)) lHashSet.Add(item);
            }

            return lHashSet;
        }


        /// <summary>
        /// Return all <see cref="T"/> component which are children of objects which UID begins with the argument
        /// </summary>
        public static HashSet<T> GetBehavioursWhichNameBeginWith<T>(List<string> pPartOfNames)
        {
            HashSet<T> lHashSet = new HashSet<T>();
            foreach (var lName in pPartOfNames)
            {
                HashSet<ObjectId> lObjectIds = ObjectId.GetObjectsWhichNameBeginWith(lName);
                if (lObjectIds == null || lObjectIds.Count == 0) continue;
                foreach (var lObjectId in lObjectIds)
                {
                    T lScript = lObjectId.GetComponentInChildren<T>();
                    if (lScript != null)
                        lHashSet.Add(lScript);
                }
            }
            return lHashSet;
        }


        protected string GetAndSetNewName()
        {

            if (string.IsNullOrWhiteSpace(m_Name))
                m_Name = m_ObjectIdSO.Name;

            if (m_RenamingDone) return m_Name;
            m_RenamingDone = true;

            if (m_RenameAfterParent)
            {
                if (transform.parent == null) return m_Name;

                var lParent = transform.parent.GetComponentInParent<ObjectId>();
                if (lParent == null) return m_Name;

                var lParentUID = lParent.GetAndSetNewName();
                m_Name = lParentUID + "_" + m_Name;
            }

            return m_Name;
        }


        private void Awake()
        {
            GetAndSetNewName();
            if (string.IsNullOrWhiteSpace(m_Name))
            {
                Debug.Log($"ERROR : Missing name on {gameObject.name} with ObjectIdSO {m_ObjectIdSO}");
                return;
            }
            if (string.IsNullOrWhiteSpace(m_UniqueID))
                m_UniqueID = m_ObjectIdSO.Id;
            if (m_ObjectIds.Add(this))
            {
                m_ObjectAdded.Invoke(this);
            }
        }


        private void OnDestroy()
        {
            if (m_ObjectIds.Remove(this))
            {
                m_ObjectRemoved.Invoke(this);
            }
        }

    }
}