using System.IO;
using UnityEditor;
using UnityEngine;

namespace WiDiD.Extension
{
    public enum ImageFormat
    {
        JPG = 0,
        PNG = 1,
        TGA = 2,
    }

    [RequireComponent(typeof(Camera))]
    public class RenderCamera : MonoBehaviour
    {
        [SerializeField, HideInInspector] protected Camera cam = null;
        [SerializeField] private ImageFormat imageFormat = ImageFormat.JPG;
        [Tooltip("Dont add / at the start and at the end")]
        [SerializeField] protected string streamingFolderPath = "";

        public ImageFormat ImageFormat { get => imageFormat; set => imageFormat = value; }
        public Camera Cam { get => cam; }
        /// <summary>
        /// Get <see cref="cam"/> current render texture and returns it to bytes
        /// </summary>
        /// <param name="imageFormat">Format of the image</param>
        /// <returns>Image </returns>
        public byte[] CaptureCam(ImageFormat imageFormat)
        {
            Reset();
            Texture2D image = ReadTexture();
            byte[] bytes = null;
            switch (imageFormat)
            {
                case ImageFormat.JPG:
                    bytes = image.EncodeToJPG();
                    break;
                case ImageFormat.PNG:
                    bytes = image.EncodeToPNG();
                    break;
                case ImageFormat.TGA:
                    bytes = image.EncodeToTGA();
                    break;
            }

            return bytes;
        }
        public Texture2D ReadTexture()
        {
            RenderTexture currentRT = RenderTexture.active;
            RenderTexture.active = cam.targetTexture;
            cam.Render();
            Texture2D image = new Texture2D(cam.targetTexture.width, cam.targetTexture.height, TextureFormat.RGBA32, false);
            image.ReadPixels(new Rect(0, 0, cam.targetTexture.width, cam.targetTexture.height), 0, 0);
            image.Apply();
            RenderTexture.active = currentRT;
            return image;
        }

        /// <summary>
        /// Save <see cref="cam"/> current render texture to file 
        /// </summary>
        /// <param name="fileName">Name of the saved file (dont add format</param>
        /// <param name="imageFormat"></param>
        /// <returns>Path where the capture is stored</returns>
        public string SaveCapture(string fileName, ImageFormat imageFormat)
        {
            string path = string.Empty;

            File.WriteAllBytes(path = Application.streamingAssetsPath + "/" + streamingFolderPath + "/" + fileName + "." + imageFormat.ToString().ToLower(), CaptureCam(imageFormat));
            return path;
        }

        protected void SetAroundTarget(Transform target, Vector3 targetDirection)
        {
            transform.position = target.position + targetDirection;
            transform.LookAt(target);
        }
        internal void Reset()
        {
            if (cam == null)
            {
                cam = GetComponent<Camera>();
            }
            if (cam.targetTexture == null)
            {
                RenderTexture renderTexture = new RenderTexture(new RenderTextureDescriptor(512, 512, UnityEngine.Experimental.Rendering.GraphicsFormat.R8G8B8A8_SRGB, 16));
                renderTexture.Create();
                renderTexture.name = "RenderTexture";
                cam.targetTexture = renderTexture;
            }
        }
    }
}

