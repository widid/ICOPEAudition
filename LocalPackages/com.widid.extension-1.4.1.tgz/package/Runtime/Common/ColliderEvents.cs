using System;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class ColliderEvents : MonoBehaviour
{
    private Collider _collider;
    public Action<Collider> OnTriggerEnterEvent;
    public Action<Collider> OnTriggerExitEvent;
    private LayerMask zoneMask;
    private List<Collider> colliders = new List<Collider>();


    public Collider Collider { get => _collider ? _collider : _collider = GetComponent<Collider>(); set { _collider = value; colliders.Clear(); } }
    public LayerMask ZoneMask { get => zoneMask; set => zoneMask = value; }

    private void OnTriggerEnter(Collider other)
    {
        OnTriggerEnterEvent?.Invoke(other);
    }

    private void OnTriggerExit(Collider other)
    {
        OnTriggerExitEvent?.Invoke(other);
    }

    private void OnTriggerStay(Collider other)
    {
        if (LayerMaskExtension.LayerMaskIncludesGOLayer(zoneMask, other.gameObject))
        {
            if (!colliders.Contains(other))
            {
                colliders.Add(other);
            }
        }
    }

    public bool HasColliders()
    {
        return colliders.Count > 0;
    }
}
