using UnityEngine;
using System;
using UnityEngine.Events;
using Object = UnityEngine.Object;
using System.IO;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace WiDiD.Extension
{
    /// <summary>
    /// Base class for storing and editing dynamicaly datas via scriptable objects in editor
    /// </summary>
    public abstract class ScriptableDynamic : ScriptableObject
    {
        private void OnEnable() => hideFlags = HideFlags.DontUnloadUnusedAsset;

#if UNITY_EDITOR
        [HideInInspector] public UnityEvent OnDelete = null;
        public static Action<ScriptableDynamic> OnCreate = null;
        public Action OnPropertiesChanged;
        protected bool isDestroying = false;
        [SerializeField, HideInInspector] private bool isInstanciated = false;
        public bool IsDestroying { get => isDestroying; }

        protected virtual void Awake()
        {
            if (isInstanciated == false)
            {
                isInstanciated = true;
                OnCreate?.Invoke(this);
            }
        }
        protected virtual void OnValidate()
        {
            OnPropertiesChanged?.Invoke();
            // Debug.Log($"Raised PropertyChanged on ScriptableDynamic with name {name}");
        }
        public virtual void Delete()
        {
            if (isDestroying == false)
            {
                isDestroying = true;
                OnDelete?.Invoke();
                if (!AssetDatabase.IsSubAsset(this))
                {
                    Object[] scriptableDynamics = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(this));
                    foreach (var obj in scriptableDynamics)
                    {
                        if (obj.GetType().IsSubclassOf(typeof(ScriptableDynamic)) && obj != this)
                        {
                            (obj as ScriptableDynamic).OnDelete?.Invoke();
                            DestroyImmediate(obj, true);
                        }
                    }
                }
                else
                {
                    DestroyImmediate(this, true);
                }

                AssetDatabase.Refresh();
            }
        }

        // Sadly OnDestroy is not being called reliably by the editor. So we need this.
        class OnDestroyProcessor : UnityEditor.AssetModificationProcessor
        {
            // Cache the type for reuse.
            static System.Type _type = typeof(ScriptableDynamic);

            // Limit to certain file endings only.
            static string _fileEnding = ".asset";

            public static AssetDeleteResult OnWillDeleteAsset(string path, RemoveAssetOptions _)
            {
                string[] splitPath = path.Split(".");
                string[] subFolders = null;
                if (splitPath.Length <= 1)
                {
                    subFolders = AssetDataBaseExtension.GetSubFoldersRecursive(path, true);

                    foreach (string subFolder in subFolders)
                    {
                        string[] files = Directory.GetFiles(subFolder, "*" + _fileEnding, SearchOption.TopDirectoryOnly);

                        foreach (string file in files)
                        {
                            Object obj = AssetDatabase.LoadAssetAtPath<Object>(file);
                            string objPath = AssetDatabase.GetAssetPath(obj);

                            if (!objPath.EndsWith(_fileEnding))
                            { continue; }

                            CheckAssetTypeAtPathAndDelete(objPath);
                        }
                    }
                }
                else
                {

                    if (!path.EndsWith(_fileEnding))
                        return AssetDeleteResult.DidNotDelete;

                    CheckAssetTypeAtPathAndDelete(path);

                }
                AssetDatabase.Refresh();

                return AssetDeleteResult.DidNotDelete;
            }

            private static void CheckAssetTypeAtPathAndDelete(string path)
            {
                var type = AssetDatabase.GetMainAssetTypeAtPath(path);
                if (type != null && (type == _type || type.IsSubclassOf(_type)))
                {
                    var asset = AssetDatabase.LoadAssetAtPath<ScriptableDynamic>(path);
                    asset.Delete();
                }
            }
        }
#endif
    }
}

