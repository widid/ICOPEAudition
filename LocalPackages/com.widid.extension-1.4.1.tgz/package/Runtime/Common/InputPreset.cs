using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace WiDiD.Extension
{
    [CreateAssetMenu(fileName = "InputsPreset", menuName = "Inputs/Presets")]
    public class InputsPreset : ScriptableObject
    {
        [SerializeField] InputActionReference[] inputs = null;
        public InputActionReference[] Inputs { get => inputs; }
    }
}

