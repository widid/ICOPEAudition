
using System;
using UnityEngine;
[DefaultExecutionOrder(-500)]
public class SharedObject : MonoBehaviour
{
    [SerializeField, HideInInspector]
    private string guid;

    public Guid Guid => string.IsNullOrEmpty(guid) ? Guid.Empty : new Guid(guid);

    private void Reset()
    {
        AssignNewGuidIfNeeded();
    }

    private void OnEnable()
    {
        AssignNewGuidIfNeeded();
        SharedObjectsHolder.AddSharedSceneObject(gameObject);
    }

    private void OnDisable()
    {
        SharedObjectsHolder.RemoveSharedSceneObject(gameObject);
    }

    private void AssignNewGuidIfNeeded()
    {
        if (string.IsNullOrEmpty(guid) || !Guid.TryParse(guid, out _))
        {
            guid = Guid.NewGuid().ToString();
#if UNITY_EDITOR
            if (!Application.isPlaying)
                UnityEditor.EditorUtility.SetDirty(this);
#endif
        }
    }
}
