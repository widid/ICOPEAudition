using System.Collections;
using UnityEngine;

namespace WiDiD.Extension
{
    /// <summary>
    /// Packed Unity coroutines for single & simple loop purposes
    /// </summary>
    public abstract class ACoroutine : MonoBehaviour
    {
        protected IEnumerator behaviour = null;

        public IEnumerator Behaviour { get => behaviour; set => behaviour = value; }

        /// <summary>
        /// Packaged StartCoroutine to avoid starting twice the same coroutine
        /// </summary>
        /// <returns>Returns true if the coroutine managed to start</returns>
        public virtual bool TryStartBehaviour()
        {
            if (behaviour == null)
            {
                behaviour = CoroutineBehaviour();
                StartCoroutine(behaviour);
                return true;
            }
            return false;
        }
        public virtual void StopBehaviour()
        {
            if (behaviour != null)
            {
                StopCoroutine(behaviour);
                behaviour = null;
            }
        }

        /// <summary>
        /// Behaviour of the coroutine, must be implemented locally
        /// </summary>
        /// <returns>Breaks itself at the end of the process</returns>
        protected virtual IEnumerator CoroutineBehaviour()
        {
            yield return new WaitForEndOfFrame();

            behaviour = null;
            yield break;
        }
        private void OnApplicationQuit()
        {
            StopBehaviour();
        }
        protected virtual void OnDisable()
        {
            StopBehaviour();
        }

    }
}

