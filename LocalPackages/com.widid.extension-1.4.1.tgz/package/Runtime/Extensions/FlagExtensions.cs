using System;

namespace WiDiD.Extension
{
    public static class FlagExtensions
    {
        public static void AddFlag<T>(this Enum value, T flag) where T : Enum
        {
            Type underlyingType = Enum.GetUnderlyingType(typeof(T));
            object valueAsInt = Convert.ChangeType(value, underlyingType);
            object flagAsInt = Convert.ChangeType(flag, underlyingType);

            long result = Convert.ToInt64(valueAsInt) | Convert.ToInt64(flagAsInt);
            value = (T)Enum.ToObject(typeof(T), result);
        }

        public static void RemoveFlag<T>(this Enum value, T flag) where T : Enum
        {
            Type underlyingType = Enum.GetUnderlyingType(typeof(T));
            object valueAsInt = Convert.ChangeType(value, underlyingType);
            object flagAsInt = Convert.ChangeType(flag, underlyingType);

            long result = Convert.ToInt64(valueAsInt) &~ Convert.ToInt64(flagAsInt);
            value = (T)Enum.ToObject(typeof(T), result);
        }
    }
}

