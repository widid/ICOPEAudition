using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace WiDiD.Extension
{
    static class GameObjectExtensions
    {
        private static bool Requires(Type obj, Type requirement)
        {
            //also check for m_Type1 and m_Type2 if required
            return Attribute.IsDefined(obj, typeof(RequireComponent)) &&
                   Attribute.GetCustomAttributes(obj, typeof(RequireComponent)).OfType<RequireComponent>()
                   .Any(rc => rc.m_Type0.IsAssignableFrom(requirement) || (rc.m_Type1 != null && rc.m_Type1.IsAssignableFrom(requirement)) || (rc.m_Type2 != null && rc.m_Type2.IsAssignableFrom(requirement)));
        }

        public static bool CanDestroy(this GameObject go, Type t)
        {
            return !go.GetComponents<Component>().Any(c => Requires(c.GetType(), t));
        }

        public static bool RequiresComponent(this GameObject gameObject, Type componentType)
        {
            //iterate all gameObject's components to see if
            //one of them requires the componentType
            foreach (var component in gameObject.GetComponents<Component>())
            {
                //iterate all component's attributes, look for
                //the RequireComponent attributes
                foreach (var attr in component.GetType().GetCustomAttributes(true))
                {
                    //check if the attribute is RequireComponent
                    if (attr is RequireComponent)
                    {
                        //cast the attribute to RequireComponent
                        var rcAttr = (RequireComponent)attr;

                        //check all three of the required types to see if
                        //componentType is required (for some reason, you
                        //can require up to 3 component types per attribute).
                        if ((rcAttr.m_Type0?.IsAssignableFrom(componentType) ?? false) ||
                            (rcAttr.m_Type1?.IsAssignableFrom(componentType) ?? false) ||
                            (rcAttr.m_Type2?.IsAssignableFrom(componentType) ?? false))
                        {
                            //if the component is required, return true
                            return true;
                        }
                    }
                }
            }

            //if no components require it, return false
            return false;
        }

        public static void DestroyRequiredComponents(this MonoBehaviour monoInstanceCaller)
        {
            MemberInfo memberInfo = monoInstanceCaller.GetType();
            RequireComponent[] requiredComponentsAtts = Attribute.GetCustomAttributes(memberInfo, typeof(RequireComponent), true) as RequireComponent[];
            foreach (RequireComponent rc in requiredComponentsAtts)
            {
                if (rc != null && monoInstanceCaller.GetComponent(rc.m_Type0) != null)
                {
                    UnityEngine.Object.Destroy(monoInstanceCaller.GetComponent(rc.m_Type0));
                }
            }
        }
    }
}
