using UnityEngine;

public static class LayerMaskExtension
{
    public static bool LayerMaskIncludesGOLayer(LayerMask layerMask, GameObject gameObject)
    {
        return ((1 << gameObject.layer) & layerMask) != 0;
    }
}
