#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
namespace WiDiD.Extension
{
    /// <summary>
    /// More methods for assets data base management 
    /// </summary>
    public static class AssetDataBaseExtension
    {

        public static string[] GetSubFoldersRecursive(string root, bool includeRoot)
        {
            var paths = new List<string>();
            if (includeRoot)
                paths.Add(root);
            // If there are no further subfolders then AssetDatabase.GetSubFolders returns 
            // an empty array => foreach will not be executed
            // This is the exit point for the recursion
            foreach (var path in AssetDatabase.GetSubFolders(root))
            {
                // add this subfolder itself
                paths.Add(path);

                // If this has no further subfolders then simply no new elements are added
                paths.AddRange(GetSubFoldersRecursive(path, false));
            }

            return paths.ToArray();
        }
    }
}
#endif

