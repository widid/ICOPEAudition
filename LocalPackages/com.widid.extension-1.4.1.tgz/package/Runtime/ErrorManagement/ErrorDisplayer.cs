using TMPro;
using UnityEngine;

namespace WiDiD.ErrorManagement
{
    /// <summary>
    /// Passive error display: only ever shows what it's told to via <see cref="Display"/>.
    /// It does not subscribe to <see cref="ErrorManager.OnErrorOccured"/> itself - that
    /// wiring (and ensuring an instance exists at all) is <see cref="ErrorDisplayProvisioner"/>'s job.
    /// </summary>
    public class ErrorDisplayer : MonoBehaviour
    {
        public static ErrorDisplayer Instance { get; private set; }

        [SerializeField] private TMP_Text tmpText;
        [SerializeField] private GameObject fallbackGameObject;
        [SerializeField, DisplayName("Fallback threshold (inclusive)")] private ManagedError.EErrorType fallbackMinimumErrorType;

        private void Awake()
        {
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this)
                Instance = null;
        }

        public void Initialize(TMP_Text text, GameObject fallback, ManagedError.EErrorType minimumErrorType)
        {
            tmpText = text;
            fallbackGameObject = fallback;
            fallbackMinimumErrorType = minimumErrorType;
        }

        public void Display(ManagedError error)
        {
            if ((int)error.ErrorType < (int)fallbackMinimumErrorType)
                return;

            tmpText.text = error.Message;
            fallbackGameObject.SetActive(true);
        }
    }
}