using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace WiDiD.ErrorManagement
{
    /// <summary>
    /// Guarantees an <see cref="ErrorDisplayer"/> exists as soon as the first error is reported,
    /// with zero setup required by the host app: it instantiates an override prefab if the host
    /// dropped one at <see cref="OverridePrefabResourcePath"/>, otherwise it builds a minimal
    /// default overlay in code.
    /// </summary>
    public static class ErrorDisplayProvisioner
    {
        const string OverridePrefabResourcePath = "ErrorManagement/ErrorDisplayerOverride";

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Initialize()
        {
            ErrorManager.OnErrorOccured += OnErrorOccured;
        }

        static void OnErrorOccured(ManagedError error)
        {
            if (ErrorDisplayer.Instance == null)
                CreateDisplayer();

            ErrorDisplayer.Instance.Display(error);
        }

        static void CreateDisplayer()
        {
            GameObject overridePrefab = Resources.Load<GameObject>(OverridePrefabResourcePath);
            GameObject instance = overridePrefab != null ? Object.Instantiate(overridePrefab) : BuildDefaultDisplayer();
            instance.name = "ErrorDisplayer";
            Object.DontDestroyOnLoad(instance);
        }

        static GameObject BuildDefaultDisplayer()
        {
            GameObject root = new("ErrorDisplayer");
            root.AddComponent<Canvas>();

            CanvasScaler scaler = root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            root.AddComponent<GraphicRaycaster>();

            // Harmless if ScreenSpaceOverlay ends up being picked (that mode ignores sizeDelta and
            // always fills the screen) - only meaningful once VrAwareCanvas switches to world-space.
            RectTransform canvasRect = (RectTransform)root.transform;
            canvasRect.sizeDelta = new Vector2(1920, 1080);
            root.AddComponent<VrAwareCanvas>();

            GameObject panel = new("Panel");
            panel.transform.SetParent(root.transform, false);
            RectTransform panelRect = panel.AddComponent<RectTransform>();
            panelRect.anchorMin = Vector2.zero;
            panelRect.anchorMax = Vector2.one;
            panelRect.offsetMin = Vector2.zero;
            panelRect.offsetMax = Vector2.zero;
            Image panelImage = panel.AddComponent<Image>();
            panelImage.color = new Color(0f, 0f, 0f, 0.85f);
            panel.SetActive(false);

            GameObject textObject = new("Message");
            textObject.transform.SetParent(panel.transform, false);
            RectTransform textRect = textObject.AddComponent<RectTransform>();
            textRect.anchorMin = new Vector2(0.1f, 0.35f);
            textRect.anchorMax = new Vector2(0.9f, 0.65f);
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;
            TextMeshProUGUI text = textObject.AddComponent<TextMeshProUGUI>();
            text.alignment = TextAlignmentOptions.Center;
            text.fontSize = 42;
            text.color = Color.white;
            text.textWrappingMode = TextWrappingModes.Normal;

            ErrorDisplayer displayer = root.AddComponent<ErrorDisplayer>();
            displayer.Initialize(text, panel, ManagedError.EErrorType.WARNING);

            return root;
        }
    }
}
