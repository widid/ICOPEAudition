using UnityEngine;

namespace WiDiD.ErrorManagement
{
    /// <summary>
    /// Drop this on any Canvas (ours or a host-supplied override prefab) to make it render
    /// correctly both on a regular screen and in VR: ScreenSpaceOverlay canvases generally aren't
    /// part of the stereo eye rendering in XR pipelines and simply don't show up in the headset,
    /// so this switches to world-space and anchors the canvas in front of the player instead
    /// whenever an XR device is active. Doesn't touch the canvas's own RectTransform sizing -
    /// only the render mode, scale, and world-space positioning.
    /// </summary>
    [RequireComponent(typeof(Canvas))]
    public class VrAwareCanvas : MonoBehaviour
    {
        [SerializeField] float worldSpaceScale = 0.001f;

        void Awake()
        {
            Canvas canvas = GetComponent<Canvas>();

            if (UnityEngine.XR.XRSettings.isDeviceActive)
            {
                canvas.renderMode = RenderMode.WorldSpace;
                transform.localScale = Vector3.one * worldSpaceScale;

                if (GetComponent<WorldSpaceCameraAnchor>() == null)
                    gameObject.AddComponent<WorldSpaceCameraAnchor>();
            }
            else
            {
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = short.MaxValue;
            }
        }
    }
}
