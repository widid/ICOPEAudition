using UnityEngine;

namespace WiDiD.ErrorManagement
{
    public class ErrorTest : MonoBehaviour
    {
        public string ErrorMessage;
        public ManagedError.EErrorType ErrorType;
        [InspectorMethodButton("Send Error")]
        public void SendError()
        {
            ErrorManager.ManageError(new ManagedError(ErrorMessage, ErrorType));
        }
    }
}