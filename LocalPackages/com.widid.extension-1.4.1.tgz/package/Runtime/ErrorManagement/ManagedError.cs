using UnityEngine;
namespace WiDiD.ErrorManagement
{
    public class ManagedError
    {
        public ManagedError(string message, EErrorType errorType)
        {
            Message = message;
            ErrorType = errorType;
        }

        public string Message { get; private set; }
        public EErrorType ErrorType { get; private set; }

        public override string ToString()
        {
            return $"{ErrorType} : {Message}";
        }


        public enum EErrorType
        {
            LOG,
            WARNING,
            CRITICAL
        }
    }
}