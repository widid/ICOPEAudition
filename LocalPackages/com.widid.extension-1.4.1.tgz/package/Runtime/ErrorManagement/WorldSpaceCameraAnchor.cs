using UnityEngine;

namespace WiDiD.ErrorManagement
{
    /// <summary>
    /// Keeps this transform at a fixed offset in front of the current main camera every frame -
    /// used so a world-space overlay tracks the player's head in VR instead of sitting wherever it
    /// happened to be created. Re-queries <see cref="Camera.main"/> every frame rather than caching
    /// it, so it keeps working across scene loads even if the active camera changes.
    /// </summary>
    public class WorldSpaceCameraAnchor : MonoBehaviour
    {
        [SerializeField] Vector3 localOffsetFromCamera = new(0f, 0f, 2f);

        void LateUpdate()
        {
            Camera targetCamera = Camera.main;
            if (targetCamera == null)
                return;

            Transform cameraTransform = targetCamera.transform;
            transform.SetPositionAndRotation(
                cameraTransform.TransformPoint(localOffsetFromCamera),
                cameraTransform.rotation);
        }
    }
}
