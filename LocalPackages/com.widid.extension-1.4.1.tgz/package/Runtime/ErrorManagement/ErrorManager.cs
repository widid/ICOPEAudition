using System;
using System.Collections.Generic;
using UnityEngine;
namespace WiDiD.ErrorManagement
{
    public static class ErrorManager
    {
        static ErrorManager()
        {
            ManagedErrors = new List<ManagedError>();
        }
        public static List<ManagedError> ManagedErrors { get; private set; }
        public static void ManageError(ManagedError error)
        {
            Debug.Log($"New Error tracked --- {error}");
            ManagedErrors.Add(error);
            OnErrorOccured?.Invoke(error);
        }
        public static Action<ManagedError> OnErrorOccured { get; set; }
    }


}