using System.IO;
using UnityEngine;
using UnityEditor;

namespace WiDiD.Extension
{
    /// <summary>
    /// Inherits to manage your asset path 
    /// </summary>
    public interface IPathable
    {
        abstract string RelativePath { get; }

#if UNITY_EDITOR
        /// <summary>
        /// Creates folder path relative to assets folder if it doesn't exist
        /// </summary>
        /// <returns>Returns relative path</returns>
        string CreateRelativePath()
        {
            DirectoryInfo directory = Directory.CreateDirectory(Directory.GetParent(Application.dataPath) + "/" + RelativePath.Replace("/", "\\"));
            AssetDatabase.Refresh();
            return RelativePath;
        }
#endif
    }
}

