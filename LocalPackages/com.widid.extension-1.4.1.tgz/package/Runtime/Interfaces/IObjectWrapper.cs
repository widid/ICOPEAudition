using System;
using UnityEngine;

public interface IObjectWrapper
{
    object Value { get; set; }
}

[Serializable]
public class DefaultValue : IObjectWrapper
{
    [SerializeReference] public object val;

    public DefaultValue() { val = null; }
    public DefaultValue(object value = null) { val = value; }

    public object Value { get => val; set => val = value; }
}

[Serializable]
public class BoolValue : IObjectWrapper
{
    public bool val;

    public BoolValue() { val = default; }
    public BoolValue(bool value = default) { val = value; }

    public object Value { get => val; set => val = (bool)value; }
}

[Serializable]
public class IntValue : IObjectWrapper
{
    public int val;

    public IntValue() { val = default; }
    public IntValue(int value = default) { val = value; }

    public object Value { get => val; set => val = (int)value; }
}

[Serializable]
public class FloatValue : IObjectWrapper
{
    public float val;

    public FloatValue() { val = default; }
    public FloatValue(float value = default) { val = value; }

    public object Value { get => val; set => val = (float)value; }
}

[Serializable]
public class StringValue : IObjectWrapper
{
    public string val;

    public StringValue() { val = string.Empty; }
    public StringValue(string value = "") { val = value; }

    public object Value { get => val; set => val = (string)value; }
}

[Serializable]
public class Vector2Value : IObjectWrapper
{
    public Vector2 val;

    public Vector2Value() { val = default; }
    public Vector2Value(Vector2 value) { val = value; }

    public object Value { get => val; set => val = (Vector2)value; }
}

[Serializable]
public class Vector3Value : IObjectWrapper
{
    public Vector3 val;

    public Vector3Value() { val = default; }
    public Vector3Value(Vector3 value) { val = value; }

    public object Value { get => val; set => val = (Vector3)value; }
}

[Serializable]
public class Vector4Value : IObjectWrapper
{
    public Vector4 val;

    public Vector4Value() { val = default; }
    public Vector4Value(Vector4 value) { val = value; }

    public object Value { get => val; set => val = (Vector4)value; }
}

[Serializable]
public class QuaternionValue : IObjectWrapper
{
    public Quaternion val;

    public QuaternionValue() { val = default; }
    public QuaternionValue(Quaternion value) { val = value; }

    public object Value { get => val; set => val = (Quaternion)value; }
}

[Serializable]
public class ColorValue : IObjectWrapper
{
    public Color val;

    public ColorValue() { val = default; }
    public ColorValue(Color value) { val = value; }

    public object Value { get => val; set => val = (Color)value; }
}

[Serializable]
public class AnimationCurveValue : IObjectWrapper
{
    public AnimationCurve val;

    public AnimationCurveValue() { val = new AnimationCurve(); }
    public AnimationCurveValue(AnimationCurve value) { val = value; }

    public object Value { get => val; set => val = (AnimationCurve)value; }
}

[Serializable]
public class ObjectValue : IObjectWrapper
{
    public UnityEngine.Object val;

    public ObjectValue() { val = null; }
    public ObjectValue(UnityEngine.Object value) { val = value; }

    public object Value { get => val; set => val = (UnityEngine.Object)value; }
}
