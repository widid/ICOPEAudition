using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class SharedObjectsHolder
{
    private static List<GameObject> sharedSceneObjects = new List<GameObject>();

    public static void AddSharedSceneObject(GameObject gameObject)
    {
        if (!sharedSceneObjects.Contains(gameObject)) sharedSceneObjects.Add(gameObject);
    }
    public static void RemoveSharedSceneObject(GameObject gameObject)
    {
        if (sharedSceneObjects.Contains(gameObject)) sharedSceneObjects.Remove(gameObject);
    }

    public static T[] GetAllSharedObjectsOfType<T>() where T : Component
    {
        List<T> objects = new List<T>();
        T tempComponent = null;
        for (int i = 0; i < sharedSceneObjects.Count; i++)
        {
            if (sharedSceneObjects[i].TryGetComponent(out tempComponent))
            {
                objects.Add(tempComponent);
            }
        }
        return objects.ToArray();
    }
    public static bool TryGetAllSharedObjectsOfType<T>(out List<T> objects) where T : Component
    {
        objects = new List<T>();
        T tempComponent = null;
        for (int i = 0; i < sharedSceneObjects.Count; i++)
        {
            if (sharedSceneObjects[i].TryGetComponent(out tempComponent))
            {
                objects.Add(tempComponent);
            }
        }

        return objects.Count > 0;
    }
    public static GameObject[] GetAllSharedObjectsWithTag(string tag)
    {
        List<GameObject> gameObjects = new List<GameObject>();
        for (int i = 0; i < sharedSceneObjects.Count; i++)
        {
            if (sharedSceneObjects[i].tag == tag)
            {
                gameObjects.Add(sharedSceneObjects[i]);
            }
        }
        return gameObjects.ToArray();
    }
    public static T[] GetAllSharedObjectsOfTypeWithTag<T>(string tag) where T : Component
    {
        List<T> objects = new List<T>();
        T tempComponent = null;
        for (int i = 0; i < sharedSceneObjects.Count; i++)
        {
            if (sharedSceneObjects[i].TryGetComponent(out tempComponent) && tempComponent.tag == tag)
            {
                objects.Add(tempComponent);
            }
        }
        return objects.ToArray();
    }
    public static T[] GetAllSharedObjectsOfTypeWithName<T>(string name) where T : Component
    {
        List<T> objects = new List<T>();
        T tempComponent = null;
        for (int i = 0; i < sharedSceneObjects.Count; i++)
        {
            if (sharedSceneObjects[i].TryGetComponent(out tempComponent) && tempComponent.gameObject.name == name)
            {
                objects.Add(tempComponent);
            }
        }
        return objects.ToArray();
    }
    public static T GetSharedObjectOfTypeWithGuid<T>(string guid) where T : Component
    {
        return sharedSceneObjects.Where(obj => obj.gameObject.GetComponent<SharedObject>().Guid.ToString() == guid).First().GetComponent<T>();
    }

    public static object GetSharedObjectOfTypeWithGuid(string guid, Type componentType)
    {
        GameObject gameObject = sharedSceneObjects.Where(obj => obj.gameObject.GetComponent<SharedObject>().Guid.ToString() == guid).First();
        if (componentType == typeof(GameObject)) return gameObject;
        return gameObject.GetComponent(componentType);
    }

    public static bool TryGetSharedObjectOfTypeWithGuid<T>(string guid, out T component) where T : Component
    {
        component = null;
        GameObject sharedObject = sharedSceneObjects.Where(obj => obj.gameObject.GetComponent<SharedObject>().Guid.ToString() == guid).FirstOrDefault();
        if (sharedObject == null) return false;

        return sharedObject.TryGetComponent<T>(out component);
    }
}
