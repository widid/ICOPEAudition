using System;
namespace WiDiD.Extension.Historic
{
    public record HistoricKey : IComparable<HistoricKey>
    {
        public DateTime Date { get; protected set; }

        public HistoricKey(DateTime date)
        {
            Date = date;
        }

        /// <summary>
        /// In order to be able to sort by descending values (most recent first)
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public int CompareTo(HistoricKey other)
        {
            if (other == null)
                return 1;
            return -this.Date.CompareTo(other.Date);
        }
    }
}