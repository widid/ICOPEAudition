using System;
using System.Collections.Generic;

namespace WiDiD.Extension.Historic
{
    public class Historic<Key> where Key : HistoricKey
    {
        public List<Key> HistoricKeys { get; private set; }

        public Action<Key> OnKeyAdded;
        public Action<Key> OnKeyRemoved;

        public Historic(List<Key> historicKeys)
        {
            HistoricKeys = historicKeys;
            HistoricKeys.Sort();
        }
        public void AddKey(Key historicKey)
        {
            if (historicKey == null || HistoricKeys.Contains(historicKey))
            {
                return;
            }
            HistoricKeys.Add(historicKey);
            HistoricKeys.Sort();
            OnKeyAdded?.Invoke(historicKey);
        }
        public void RemoveKey(Key historicKey)
        {
            if (historicKey == null || !HistoricKeys.Contains(historicKey))
            {
                return;
            }

            HistoricKeys.Remove(historicKey);
            HistoricKeys.Sort();
            OnKeyRemoved?.Invoke(historicKey);
        }
    }
}
