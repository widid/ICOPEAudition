using System;
using UnityEngine;

[AttributeUsage(AttributeTargets.Method)]
public class InspectorMethodButtonAttribute : Attribute
{
    public string ButtonLabel { get; private set; }

    public InspectorMethodButtonAttribute(string buttonLabel)
    {
        ButtonLabel = buttonLabel;
    }
}