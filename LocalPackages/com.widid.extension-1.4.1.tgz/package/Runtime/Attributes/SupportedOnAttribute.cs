using System.Linq;
using UnityEngine;


[System.AttributeUsage(System.AttributeTargets.Class, Inherited = false)]
public class SupportedOnAttribute : System.Attribute
{
    public RuntimePlatform[] Platforms { get; }
    public SupportedOnAttribute(params RuntimePlatform[] platforms)
    {
        Platforms = platforms;
    }
    public bool IsSupported(RuntimePlatform runtimePlatform)
    {
        return Platforms.Contains(runtimePlatform);
    }
}