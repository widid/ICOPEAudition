[System.AttributeUsage(System.AttributeTargets.Class)]
public class EngineNameAttribute : System.Attribute
{
    public string Name { get; }
    public EngineNameAttribute(string name) => Name = name;
}
