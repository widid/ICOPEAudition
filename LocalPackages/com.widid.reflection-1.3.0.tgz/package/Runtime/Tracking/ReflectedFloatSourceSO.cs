using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    [CreateAssetMenu(fileName = "NewReflectedFloatSource", menuName = "Data/Reflection/Reflected Float Source")]
    public class ReflectedFloatSourceSO : ScriptableObject, IReflectedValueSource
    {
        [field: SerializeField] public ReflectedValueSourceData Data { get; private set; } = new ReflectedValueSourceData();

        public float Value => ReflectedValueResolver.Resolve<float>(Data);
    }
}
