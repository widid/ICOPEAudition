namespace WiDiD.Reflection.Tracking
{
    public enum AttachmentImageFormat
    {
        Jpg,
        Png,
        Tga
    }
}
