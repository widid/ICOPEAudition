namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// A component that can produce attachment bytes on demand (e.g. a camera capture) - resolved by
    /// ReflectedAttachmentSourceSO/ReflectedAttachmentResolver the same way a scalar member is
    /// resolved for the other Reflected*SourceSO types, except Capture() actively produces a new
    /// result each call instead of passively re-reading an existing field/property.
    /// </summary>
    public interface IAttachmentProvider
    {
        AttachmentCapture Capture();
    }
}
