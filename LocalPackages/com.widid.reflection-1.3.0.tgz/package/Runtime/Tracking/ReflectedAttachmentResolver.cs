using System;
using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Resolves a ReflectedValueSourceData to a live IAttachmentProvider and invokes Capture() -
    /// same TargetGuid/ComponentTypeName resolution as ReflectedValueResolver (including its
    /// Play-mode-registry-vs-scene-scan fallback), but MemberPath/DirectAsset don't apply here since
    /// there is no member to read - the whole point is to invoke Capture(), not a passive value.
    /// </summary>
    public static class ReflectedAttachmentResolver
    {
        public static AttachmentCapture? Capture(ReflectedValueSourceData data)
        {
            if (data == null || string.IsNullOrEmpty(data.TargetGuid))
                return null;

            TrackableId target = TrackableRegistry.Find(data.TargetGuid);

            if (target == null && !Application.isPlaying)
                target = ReflectedValueResolver.FindInOpenScenes(data.TargetGuid);

            return CaptureFrom(target, data);
        }

        // Split out from Capture so editor tooling that already found the TrackableId (via a scene
        // scan) can invoke the provider directly - same reasoning as ReflectedValueResolver.ResolveFrom.
        public static AttachmentCapture? CaptureFrom(TrackableId target, ReflectedValueSourceData data)
        {
            if (target == null || data == null || string.IsNullOrEmpty(data.ComponentTypeName))
                return null;

            Type componentType = Type.GetType(data.ComponentTypeName);
            if (componentType == null)
                return null;

            return target.GetComponent(componentType) is IAttachmentProvider provider ? provider.Capture() : null;
        }
    }
}
