using System;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Write counterpart to ReflectedValueResolver.Resolve&lt;T&gt; - resolves a
    /// ReflectedValueSourceData's live target the same way (DirectAsset, else TrackableRegistry by
    /// TargetGuid/ComponentTypeName) and writes newValue into it via ReflectionPathUtility.SetValue.
    /// Runtime-only (no Editor-time scene-scan fallback - TrackableRegistry is only populated while
    /// playing anyway), for driving a reflected value live from a runtime debug UI.
    /// </summary>
    public static class ReflectedValueWriter
    {
        public static bool TrySetValue(ReflectedValueSourceData data, object newValue)
        {
            UnityEngine.Object target = ResolveTarget(data);
            return target != null && ReflectionPathUtility.SetValue(target, data.MemberPath, newValue);
        }

        /// <summary>
        /// Whether data's member can be written, judged from its target type alone so it also works
        /// before the target is loaded. Returns true when the target type can't be resolved.
        /// </summary>
        public static bool CanWrite(ReflectedValueSourceData data)
        {
            if (data == null)
                return false;

            Type rootType = data.DirectAsset != null
                ? data.DirectAsset.GetType()
                : string.IsNullOrEmpty(data.ComponentTypeName) ? null : Type.GetType(data.ComponentTypeName);

            return rootType == null || ReflectionPathUtility.CanWrite(rootType, data.MemberPath);
        }

        static UnityEngine.Object ResolveTarget(ReflectedValueSourceData data)
        {
            if (data.DirectAsset != null)
                return data.DirectAsset;

            if (string.IsNullOrEmpty(data.TargetGuid) || string.IsNullOrEmpty(data.ComponentTypeName))
                return null;

            TrackableId trackable = TrackableRegistry.Find(data.TargetGuid);
            if (trackable == null)
                return null;

            Type componentType = Type.GetType(data.ComponentTypeName);
            return componentType != null ? trackable.GetComponent(componentType) : null;
        }
    }
}
