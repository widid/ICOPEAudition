using System;
using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Renders its Camera on demand and encodes the result as a jpg/png/tga attachment - drop this
    /// on the same GameObject as the Camera to capture. Rendering is on-demand (Capture() calls
    /// Camera.Render() itself) rather than relying on the camera's normal per-frame render, so it
    /// works even for a camera that isn't otherwise actively rendering every frame.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class CameraAttachmentProvider : MonoBehaviour, IAttachmentProvider
    {
        [field: SerializeField] public AttachmentImageFormat Format { get; private set; } = AttachmentImageFormat.Jpg;
        [field: SerializeField] public int Width { get; private set; } = 512;
        [field: SerializeField] public int Height { get; private set; } = 512;

        public AttachmentCapture Capture()
        {
            Camera camera = GetComponent<Camera>();
            Texture2D image = RenderToTexture(camera);

            byte[] bytes = Encode(image);

            // Destroy() logs an error and no-ops outside Play mode (e.g. the "Capture Preview"
            // button in ReflectedAttachmentSourceSOEditor, which calls Capture() directly in the
            // Editor) - DestroyImmediate is the correct call there.
            if (Application.isPlaying)
                Destroy(image);
            else
                DestroyImmediate(image);

            string extension = Format.ToString().ToLowerInvariant();
            return new AttachmentCapture(bytes, $"image/{extension}", $"{gameObject.name}.{extension}");
        }

        Texture2D RenderToTexture(Camera camera)
        {
            RenderTexture renderTexture = RenderTexture.GetTemporary(Width, Height, 24, RenderTextureFormat.ARGB32);
            RenderTexture previousTarget = camera.targetTexture;
            RenderTexture previousActive = RenderTexture.active;

            camera.targetTexture = renderTexture;
            camera.Render();
            RenderTexture.active = renderTexture;

            Texture2D image = new(Width, Height, TextureFormat.RGBA32, false);
            image.ReadPixels(new Rect(0, 0, Width, Height), 0, 0);
            image.Apply();

            camera.targetTexture = previousTarget;
            RenderTexture.active = previousActive;
            RenderTexture.ReleaseTemporary(renderTexture);

            return image;
        }

        byte[] Encode(Texture2D image) => Format switch
        {
            AttachmentImageFormat.Jpg => image.EncodeToJPG(),
            AttachmentImageFormat.Png => image.EncodeToPNG(),
            AttachmentImageFormat.Tga => image.EncodeToTGA(),
            _ => throw new ArgumentOutOfRangeException(nameof(Format), Format, null)
        };
    }
}
