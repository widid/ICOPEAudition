using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    [CreateAssetMenu(fileName = "NewReflectedStringSource", menuName = "Data/Reflection/Reflected String Source")]
    public class ReflectedStringSourceSO : ScriptableObject, IReflectedValueSource
    {
        [field: SerializeField] public ReflectedValueSourceData Data { get; private set; } = new ReflectedValueSourceData();

        public string Value => ReflectedValueResolver.Resolve<string>(Data);
    }
}
