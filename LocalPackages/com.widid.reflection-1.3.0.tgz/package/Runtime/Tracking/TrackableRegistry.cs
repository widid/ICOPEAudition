using System.Collections.Generic;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Process-wide lookup from a TrackableId's Guid to its live instance - what lets a
    /// ReflectedFloatSourceSO (or similar) re-find a scene object at read time instead of holding a
    /// direct reference an asset can't serialize durably across scenes/builds.
    /// </summary>
    public static class TrackableRegistry
    {
        static readonly Dictionary<string, TrackableId> instances = new();

        public static void Register(string guid, TrackableId instance) => instances[guid] = instance;

        public static void Unregister(string guid, TrackableId instance)
        {
            if (instances.TryGetValue(guid, out TrackableId registered) && registered == instance)
                instances.Remove(guid);
        }

        public static TrackableId Find(string guid) => instances.TryGetValue(guid, out TrackableId instance) ? instance : null;
    }
}
