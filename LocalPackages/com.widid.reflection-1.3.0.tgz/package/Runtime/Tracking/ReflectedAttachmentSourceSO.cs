using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Points at a scene component implementing IAttachmentProvider (e.g. CameraAttachmentProvider),
    /// same TrackableId-based binding as ReflectedFloatSourceSO/etc. Unlike those, Capture() actively
    /// invokes the provider rather than passively re-reading a member - see IAttachmentProvider.
    /// </summary>
    [CreateAssetMenu(fileName = "NewReflectedAttachmentSource", menuName = "Data/Reflection/Reflected Attachment Source")]
    public class ReflectedAttachmentSourceSO : ScriptableObject, IReflectedValueSource
    {
        [field: SerializeField] public ReflectedValueSourceData Data { get; private set; } = new ReflectedValueSourceData();

        /// <summary>
        /// Whether Capture() has anything to resolve at all - the two fields
        /// ReflectedAttachmentResolver needs. MemberPath/DirectAsset never apply here, so a
        /// created-but-never-bound asset is only recognizable by these being empty.
        /// </summary>
        public bool IsBound => !string.IsNullOrEmpty(Data.TargetGuid) && !string.IsNullOrEmpty(Data.ComponentTypeName);

        public AttachmentCapture? Capture() => ReflectedAttachmentResolver.Capture(Data);
    }
}
