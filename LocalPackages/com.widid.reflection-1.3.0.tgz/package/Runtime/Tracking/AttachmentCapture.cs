namespace WiDiD.Reflection.Tracking
{
    /// <summary>Result of an IAttachmentProvider.Capture() call - raw bytes plus enough metadata to upload and describe them as an xAPI attachment.</summary>
    public readonly struct AttachmentCapture
    {
        public byte[] Bytes { get; }
        public string ContentType { get; }
        public string FileName { get; }

        public AttachmentCapture(byte[] bytes, string contentType, string fileName)
        {
            Bytes = bytes;
            ContentType = contentType;
            FileName = fileName;
        }
    }
}
