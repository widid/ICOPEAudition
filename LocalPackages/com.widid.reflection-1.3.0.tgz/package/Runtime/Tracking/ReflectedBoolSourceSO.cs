using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    [CreateAssetMenu(fileName = "NewReflectedBoolSource", menuName = "Data/Reflection/Reflected Bool Source")]
    public class ReflectedBoolSourceSO : ScriptableObject, IReflectedValueSource
    {
        [field: SerializeField] public ReflectedValueSourceData Data { get; private set; } = new ReflectedValueSourceData();

        public bool Value => ReflectedValueResolver.Resolve<bool>(Data);
    }
}
