using System;
using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    [Serializable]
    public class ReflectedValueSourceData
    {
        [field: SerializeField] public string TargetGuid { get; set; } = string.Empty;
        [field: SerializeField] public string ComponentTypeName { get; set; } = string.Empty;
        [field: SerializeField] public string MemberPath { get; set; } = string.Empty;

        // Last known scene/GameObject the target was resolved in - cached by the editor tooling
        // whenever it manages to find the live target, purely so the source stays identifiable
        // (see ReflectedFloatSourceSOEditor) after that scene is unloaded, and so
        // ReflectedSourcePathUtility.DrawMissingTargetWarning can offer a "Load Scene" button
        // (needs the actual asset path, not just the display name) and tell an unloaded scene
        // apart from a target deleted out of a scene that's still open. Never read at runtime;
        // TargetGuid is the only thing actual resolution depends on.
        [field: SerializeField] public string LastKnownSceneName { get; set; } = string.Empty;
        [field: SerializeField] public string LastKnownScenePath { get; set; } = string.Empty;
        [field: SerializeField] public string LastKnownObjectName { get; set; } = string.Empty;

        // Set instead of TargetGuid/ComponentTypeName when the source is a ScriptableObject (or any
        // other plain asset) rather than a scene object - assets are already safely serializable by
        // direct reference, so none of the TrackableId/scene-rediscovery machinery above applies.
        [field: SerializeField] public UnityEngine.Object DirectAsset { get; set; }
    }
}
