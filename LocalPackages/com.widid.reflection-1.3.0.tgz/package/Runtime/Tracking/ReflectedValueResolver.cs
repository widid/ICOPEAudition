using System;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Resolves a ReflectedValueSourceData either directly off its DirectAsset (a ScriptableObject/
    /// plain asset reference, always safe to hold onto and resolvable in Edit mode) or, for scene
    /// objects, against a live TrackableId - re-resolved on every call, never cached, so a
    /// scene-based value naturally reads as default(T) while its source object is unloaded and
    /// picks back up the moment it (re)registers, matching TrackableId's own Awake/OnDestroy
    /// lifecycle.
    /// </summary>
    public static class ReflectedValueResolver
    {
        public static T Resolve<T>(ReflectedValueSourceData data)
        {
            if (data == null)
                return default;

            if (data.DirectAsset != null)
                return ResolveFromObject<T>(data.DirectAsset, data);

            if (string.IsNullOrEmpty(data.TargetGuid))
                return default;

            TrackableId target = TrackableRegistry.Find(data.TargetGuid);

            // The registry is only populated by TrackableId.Awake(), so outside Play mode (e.g.
            // StatementPreviewWindow building a preview statement) it's always empty even for a
            // perfectly valid binding - fall back to a live scene scan so scene-based sources still
            // resolve for Editor-time tooling, not just DirectAsset ones.
            if (target == null && !UnityEngine.Application.isPlaying)
                target = FindInOpenScenes(data.TargetGuid);

            return ResolveFrom<T>(target, data);
        }

        // Internal (not private) so ReflectedAttachmentResolver - which resolves the same
        // TargetGuid-based scene binding but invokes an IAttachmentProvider instead of reading a
        // member - can reuse this instead of duplicating the scan.
        internal static TrackableId FindInOpenScenes(string guid)
        {
            foreach (TrackableId candidate in UnityEngine.Object.FindObjectsByType<TrackableId>(UnityEngine.FindObjectsInactive.Include, UnityEngine.FindObjectsSortMode.None))
            {
                if (candidate.Guid == guid)
                    return candidate;
            }

            return null;
        }

        // Split out from Resolve so editor tooling (e.g. ReflectedFloatSourceSOEditor's debug
        // preview) can supply a TrackableId found by scanning open scenes directly - the registry
        // above only has entries while playing, since it's populated by TrackableId.Awake(). Checks
        // DirectAsset first (same as Resolve) so every existing caller of this overload - which all
        // predate DirectAsset - gets correct behavior for asset-based sources without changes,
        // regardless of whether they had a live TrackableId to pass in.
        public static T ResolveFrom<T>(TrackableId target, ReflectedValueSourceData data)
        {
            if (data == null)
                return default;

            if (data.DirectAsset != null)
                return ResolveFromObject<T>(data.DirectAsset, data);

            if (target == null || string.IsNullOrEmpty(data.ComponentTypeName))
                return default;

            Type componentType = Type.GetType(data.ComponentTypeName);
            if (componentType == null)
                return default;

            UnityEngine.Object component = target.GetComponent(componentType);
            return ResolveFromObject<T>(component, data);
        }

        static T ResolveFromObject<T>(UnityEngine.Object target, ReflectedValueSourceData data)
        {
            if (target == null || data == null)
                return default;

            return ReflectionPathUtility.GetValue(target, data.MemberPath) is T cast ? cast : default;
        }
    }
}
