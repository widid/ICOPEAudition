using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    [CreateAssetMenu(fileName = "NewReflectedIntSource", menuName = "Data/Reflection/Reflected Int Source")]
    public class ReflectedIntSourceSO : ScriptableObject, IReflectedValueSource
    {
        [field: SerializeField] public ReflectedValueSourceData Data { get; private set; } = new ReflectedValueSourceData();

        public int Value => ReflectedValueResolver.Resolve<int>(Data);
    }
}
