namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Common shape shared by every concrete ReflectedXSourceSO (Float/Int/String/...) - lets editor
    /// tooling (path display, creation, debug views) work generically across all of them without a
    /// generic ScriptableObject base, which risks silent serialization issues for the wrapped
    /// ReflectedValueSourceData (see ReflectedValueSourceSO-style generics avoided elsewhere in this
    /// codebase, e.g. DataReference&lt;T&gt;'s concrete Boolean/Numeric/StringDataReference subclasses).
    /// </summary>
    public interface IReflectedValueSource
    {
        ReflectedValueSourceData Data { get; }
    }
}
