using UnityEngine;

namespace WiDiD.Reflection.Tracking
{
    /// <summary>
    /// Drop this on any GameObject whose live values need to be read from an asset that can't hold
    /// a direct scene reference (see ReflectedValueResolver). Guid is normally authored once via the
    /// reflected-source editor window and stays fixed for that object; the runtime fallback
    /// assignment only covers instances added without going through that window.
    /// </summary>
    public class TrackableId : MonoBehaviour
    {
        [field: SerializeField] public string Guid { get; private set; } = string.Empty;

        public void AssignGuidIfEmpty()
        {
            if (string.IsNullOrEmpty(Guid))
                Guid = System.Guid.NewGuid().ToString();
        }

        void Awake()
        {
            AssignGuidIfEmpty();
            TrackableRegistry.Register(Guid, this);
        }

        void OnDestroy()
        {
            TrackableRegistry.Unregister(Guid, this);
        }
    }
}
