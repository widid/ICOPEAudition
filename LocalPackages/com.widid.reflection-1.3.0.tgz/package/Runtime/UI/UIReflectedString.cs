namespace WiDiD.Reflection.UI
{
    public class UIReflectedString : UIReflectedData<string>
    {
        protected override string GetDefaultValueDisplay()
        {
            return "/";
        }

        protected override string GetDisplayedValue(string value)
        {
            return value;
        }
    }
}