using System;
using TMPro;
using UnityEngine;
namespace WiDiD.Reflection.UI
{
    public abstract class UIReflectedData<T> : MonoBehaviour
    {
        public ReflectedValue<T> ReflectedValue;
        [Header("Text displayal")]
        [SerializeField, DisplayName("Text Value (optional)")] protected TextMeshProUGUI textValue;
        [SerializeField] protected string unit;
        protected T value;

        public virtual void RefreshValue()
        {
            value = ReflectedValue.Value;
            if (value.Equals(default(T))) { if (textValue) textValue.text = GetDefaultValueDisplay(); return; }
            if (textValue)
                textValue.text = GetDisplayedValue(value);
        }
        protected abstract string GetDisplayedValue(T value);
        protected abstract string GetDefaultValueDisplay();

        private void OnEnable()
        {
            UIReflectedDatasHolder.RegisterUIReflectedData<T>(this);
        }
        private void OnDisable()
        {
            UIReflectedDatasHolder.UnregisterUIReflectedData<T>(this);
        }
    }
}