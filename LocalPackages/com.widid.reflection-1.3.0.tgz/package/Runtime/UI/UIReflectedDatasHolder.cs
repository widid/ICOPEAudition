using System.Collections.Generic;
namespace WiDiD.Reflection.UI
{
    public static class UIReflectedDatasHolder
    {
        private static List<UIReflectedInt> reflectedInts = new List<UIReflectedInt>();
        private static List<UIReflectedString> reflectedStrings = new List<UIReflectedString>();
        private static List<UIReflectedFloat> reflectedFloats = new List<UIReflectedFloat>();

        public static void RefreshAllActiveUIReflectedDatas()
        {
            reflectedInts.ForEach(r => r.RefreshValue());
            reflectedStrings.ForEach(r => r.RefreshValue());
            reflectedFloats.ForEach(r => r.RefreshValue());
        }

        public static void RegisterUIReflectedData<T>(UIReflectedData<T> uiReflectedData)
        {
            if (uiReflectedData is UIReflectedInt)
            {
                reflectedInts.Add(uiReflectedData as UIReflectedInt);
            }
            else if (uiReflectedData is UIReflectedFloat)
            {
                reflectedFloats.Add(uiReflectedData as UIReflectedFloat);
            }
            else if (uiReflectedData is UIReflectedString)
            {
                reflectedStrings.Add(uiReflectedData as UIReflectedString);
            }
        }
        public static void UnregisterUIReflectedData<T>(UIReflectedData<T> uiReflectedData)
        {
            if (uiReflectedData is UIReflectedInt)
            {
                reflectedInts.Remove(uiReflectedData as UIReflectedInt);
            }
            else if (uiReflectedData is UIReflectedFloat)
            {
                reflectedFloats.Remove(uiReflectedData as UIReflectedFloat);
            }
            else if (uiReflectedData is UIReflectedString)
            {
                reflectedStrings.Remove(uiReflectedData as UIReflectedString);
            }
        }
    }
}