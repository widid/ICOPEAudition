using UnityEngine;
using UnityEngine.UI;
namespace WiDiD.Reflection.UI
{
    public class UIReflectedFloat : UIReflectedData<float>
    {
        [SerializeField] private float multiplier = 1;
        [Header("Slider displayal")]
        [SerializeField, DisplayName("Slider Value (optional)")] private Slider sliderValue;
        protected override string GetDefaultValueDisplay()
        {
            return $"0{unit}";
        }

        protected override string GetDisplayedValue(float value)
        {
            if (multiplier == 0) multiplier = 1;
            return $"{(value * multiplier).ToString("0.#")}{unit}";
        }
        public override void RefreshValue()
        {
            base.RefreshValue();
            if (sliderValue != null) sliderValue.value = value;
        }
    }
}