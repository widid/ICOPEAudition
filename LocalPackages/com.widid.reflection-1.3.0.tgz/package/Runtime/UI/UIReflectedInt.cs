using UnityEngine;
using UnityEngine.UI;
namespace WiDiD.Reflection.UI
{
    public class UIReflectedInt : UIReflectedData<int>
    {
        [Header("Slider displayal")]
        [SerializeField, DisplayName("Slider Value (optional)")] private Slider sliderValue;

        protected override string GetDefaultValueDisplay()
        {
            return "0";
        }

        protected override string GetDisplayedValue(int value)
        {
            return $"{value}{unit}";
        }
        public override void RefreshValue()
        {
            base.RefreshValue();
            if (sliderValue != null) sliderValue.value = value;
        }
    }
}