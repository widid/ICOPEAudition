#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using System;

namespace WiDiD.Reflection
{
    /// <summary>
    /// Inherit <see cref="ReflectedProperty"/> with a generic type that must be inherited for sorting reflected properties and field based on that type
    /// </summary>
    /// <typeparam name="T">Sorting type for reflected properties options displayed</typeparam>
    [Serializable]
    public class SortableReflectedProperty<T> : ReflectedProperty
    {
        [SerializeField] private T sortedType = default;

        /// <summary>
        /// Try accessing field or property value thanks to serialized <see cref="fieldName"/> or <see cref="propertyName"/> and returns it
        /// </summary>
        /// <returns>Value as <see cref="T"/></returns>
        public new T GetValue()
        {
            return (T)base.GetValue();
        }

    }
}
