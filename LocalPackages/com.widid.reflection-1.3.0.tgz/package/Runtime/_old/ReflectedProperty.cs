using UnityEngine;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

namespace WiDiD.Reflection
{
    /// <summary>
    /// Class used to dynamically access fields & properties values of objects without referencing them explicitly in scripts
    /// </summary>
    [Serializable]
    public class ReflectedProperty
    {
        [SerializeField] protected Object mainObj = null;
        [SerializeField] protected Component selectedComponent = null;
        [SerializeField] protected string fieldName = string.Empty;
        [SerializeField] protected string propertyName = string.Empty;
        [SerializeField] protected bool isScriptable = false;

        public bool IsValid {get => (IsField || IsProperty); }
        public Object MainObj { get => mainObj;}
        private bool IsField => !string.IsNullOrEmpty(fieldName);
        private bool IsProperty => !string.IsNullOrEmpty(propertyName);
        public bool IsScriptable { get => isScriptable; set => isScriptable = value; }

        public const BindingFlags Flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.GetField | BindingFlags.GetProperty | BindingFlags.NonPublic;

        /// <summary>
        /// Try accessing field or property value thanks to serialized <see cref="fieldName"/> or <see cref="propertyName"/> and returns it
        /// </summary>
        /// <returns>Value as object type</returns>
        public object GetValue()
        {
            if (!IsValid)
            {
                Debug.LogWarning("You tried to get value from an unvalid reflected property");
                return null;
            }

            Object reflectedObject = isScriptable ? mainObj : selectedComponent;
            if (IsField)
            {
                return GetObjectFieldInfoFromName(reflectedObject, fieldName).GetValue(reflectedObject);
            }
            else
            {
                return GetObjectPropertyInfoFromName(reflectedObject, propertyName).GetValue(reflectedObject);
            }
        }
        /// <summary>
        /// Try accessing field or property value thanks to serialized <see cref="fieldName"/> or <see cref="propertyName"/> and sets it
        /// </summary>
        /// <param name="value">Value to set</param>
        public void SetValue(object value)
        {
            if (!IsValid)
            {
                Debug.LogWarning("You tried to set value to an unvalid reflected property");
                return;
            }
            Object reflectedObject = isScriptable ? mainObj : selectedComponent;
            if (IsField)
            {
                GetObjectFieldInfoFromName(reflectedObject, fieldName).SetValue(reflectedObject, value);
            }
            else if (IsProperty)
            {
                GetObjectPropertyInfoFromName(reflectedObject, propertyName).SetValue(reflectedObject,value);
            }
        }
        /// <summary>
        /// Returns path of this property, format contains holding component if <see cref="mainObj"/> is gameObject,not if  its scriptableObject 
        /// </summary>
        /// <returns>Returns path of this reflected property as format : holdingObjectName/holdingComponentTypeName/fieldName</returns>
        public string GetPath()
        {
            if (!IsValid)
            {
                Debug.LogWarning("You tried to get path from an unvalid reflected property");
                return "";
            }
            string valueName = string.Empty;

            Object reflectedObject = isScriptable ? mainObj : selectedComponent;
            if (IsField)
                valueName = GetObjectFieldInfoFromName(reflectedObject, fieldName).Name;
            else
                valueName = GetObjectPropertyInfoFromName(reflectedObject, propertyName).Name;

            return mainObj.name + "/"  +(isScriptable? valueName : selectedComponent.GetType() + "/" + valueName);
        }
        /// <summary>
        /// Resets all serialized objets to null or empty
        /// </summary>
        public void Reset()
        {
            fieldName = string.Empty;
            propertyName = string.Empty;
            mainObj = null;
            selectedComponent = null;
        }
        private FieldInfo GetObjectFieldInfoFromName(Object obj, string fieldName)
        {
            return obj.GetType().GetField(fieldName, Flags);
        }
        private PropertyInfo GetObjectPropertyInfoFromName(Object obj, string propertyName)
        {
            return obj.GetType().GetProperty(propertyName, Flags);
        }

    }
}

