using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace WiDiD.Reflection
{
    public static class ReflectionPathUtility
    {
        public static object GetValue(object root, string path)
        {
            if (root == null || string.IsNullOrEmpty(path))
                return null;

            string[] parts = path.Split('/');
            object current = root;

            if (root is GameObject go)
            {
                string first = parts[0];

                if (first == "GameObject")
                {
                    current = go;
                    return parts.Length > 1 ? GetValueRecursive(current, parts, 1) : current;
                }
                else
                {
                    var comp = go.GetComponent(first);
                    if (comp == null) return null;
                    current = comp;
                    return parts.Length > 1 ? GetValueRecursive(current, parts, 1) : current;
                }
            }

            return GetValueRecursive(current, parts, 0);
        }

        private static object GetValueRecursive(object current, string[] parts, int index)
        {
            if (current == null || index >= parts.Length) return current;

            string part = parts[index];
            object next = GetMemberValue(current, part);
            return GetValueRecursive(next, parts, index + 1);
        }

        public static bool SetValue(object root, string path, object newValue)
        {
            if (root == null || string.IsNullOrEmpty(path))
                return false;

            string[] parts = path.Split('/');
            object current = root;

            if (root is GameObject go)
            {
                string first = parts[0];

                if (first == "GameObject")
                {
                    current = go;
                    return SetValueRecursive(current, parts, 1, newValue);
                }
                else
                {
                    var comp = go.GetComponent(first);
                    if (comp == null) return false;
                    current = comp;
                    return SetValueRecursive(current, parts, 1, newValue);
                }
            }

            return SetValueRecursive(current, parts, 0, newValue);
        }

        private static bool SetValueRecursive(object current, string[] parts, int index, object newValue)
        {
            if (current == null) return false;

            string part = parts[index];

            // last segment → assign
            if (index == parts.Length - 1)
            {
                return SetMemberValue(current, part, newValue);
            }

            // otherwise recurse
            object next = GetMemberValue(current, part);
            return SetValueRecursive(next, parts, index + 1, newValue);
        }

        /// <summary>
        /// Whether the member path can be assigned on an instance of rootType, judged from types alone
        /// so no live target is needed. Returns true when it can't be told (a GameObject component segment).
        /// </summary>
        public static bool CanWrite(Type rootType, string path)
        {
            if (rootType == null || string.IsNullOrEmpty(path))
                return false;

            string[] parts = path.Split('/');
            int start = 0;

            if (typeof(GameObject).IsAssignableFrom(rootType))
            {
                if (parts[0] != "GameObject")
                    return true;

                start = 1;
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            Type current = rootType;

            for (int i = start; i < parts.Length; i++)
            {
                string memberName = parts[i];
                bool indexed = false;

                int idxStart = memberName.IndexOf('[');
                if (idxStart >= 0 && memberName.EndsWith("]"))
                {
                    memberName = memberName.Substring(0, idxStart);
                    indexed = true;
                }

                bool last = i == parts.Length - 1;
                FieldInfo field = current.GetField(memberName, flags);
                PropertyInfo property = field == null ? current.GetProperty(memberName, flags) : null;

                if (field == null && property == null)
                    return false;

                if (last && !indexed)
                    return field != null ? !field.IsInitOnly && !field.IsLiteral : property.CanWrite;

                Type memberType = field != null ? field.FieldType : property.PropertyType;
                current = indexed ? ElementType(memberType) : memberType;

                if (current == null)
                    return false;

                if (last)
                    return true;
            }

            return false;
        }

        private static Type ElementType(Type collectionType)
        {
            if (collectionType.IsArray)
                return collectionType.GetElementType();

            Type[] arguments = collectionType.IsGenericType ? collectionType.GetGenericArguments() : Type.EmptyTypes;
            return arguments.Length > 0 ? arguments[arguments.Length - 1] : null;
        }

        // Discovers every field/property path on root's type whose value type matches targetType,
        // recursing into nested non-primitive/non-Unity members up to maxDepth - used by editor
        // tooling (e.g. the reflected-source creation window) to populate a path picker.
        public static string[] GetMemberPaths(object root, Type targetType, int maxDepth = 4)
        {
            List<string> paths = new List<string>();
            if (root != null)
                CollectMemberPaths(root.GetType(), string.Empty, paths, 0, maxDepth, targetType);
            return paths.ToArray();
        }

        private static void CollectMemberPaths(Type type, string prefix, List<string> paths, int depth, int maxDepth, Type targetType)
        {
            if (type == null || depth > maxDepth) return;

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            foreach (FieldInfo field in type.GetFields(flags))
            {
                string path = string.IsNullOrEmpty(prefix) ? field.Name : $"{prefix}/{field.Name}";
                if (targetType.IsAssignableFrom(field.FieldType))
                    paths.Add(path);
                else if (ShouldRecurseInto(field.FieldType))
                    CollectMemberPaths(field.FieldType, path, paths, depth + 1, maxDepth, targetType);
            }

            foreach (PropertyInfo property in type.GetProperties(flags))
            {
                if (!property.CanRead || property.GetIndexParameters().Length > 0) continue;

                string path = string.IsNullOrEmpty(prefix) ? property.Name : $"{prefix}/{property.Name}";
                if (targetType.IsAssignableFrom(property.PropertyType))
                    paths.Add(path);
                else if (ShouldRecurseInto(property.PropertyType))
                    CollectMemberPaths(property.PropertyType, path, paths, depth + 1, maxDepth, targetType);
            }
        }

        private static bool ShouldRecurseInto(Type type)
        {
            if (type == typeof(string) || type.IsPrimitive || type.IsEnum) return false;
            if (type.Namespace != null && type.Namespace.StartsWith("UnityEngine")) return false;
            return true;
        }

        // ------------------------
        // Helpers
        // ------------------------

        private static object GetMemberValue(object obj, string part)
        {
            if (obj == null) return null;

            string memberName = part;
            string indexer = null;

            // handle collection index
            int idxStart = part.IndexOf('[');
            if (idxStart >= 0 && part.EndsWith("]"))
            {
                memberName = part.Substring(0, idxStart);
                indexer = part.Substring(idxStart + 1, part.Length - idxStart - 2);
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            Type type = obj.GetType();

            object value = null;

            if (!string.IsNullOrEmpty(memberName))
            {
                FieldInfo field = type.GetField(memberName, flags);
                if (field != null)
                    value = field.GetValue(obj);

                PropertyInfo prop = type.GetProperty(memberName, flags);
                if (prop != null && prop.CanRead)
                    value = prop.GetValue(obj);
            }
            else
            {
                value = obj; // directly index root
            }

            if (value != null && indexer != null)
            {
                // array / list
                if (value is IList list && int.TryParse(indexer, out int i))
                {
                    if (i >= 0 && i < list.Count)
                        return list[i];
                }

                // dictionary
                if (value is IDictionary dict)
                {
                    return dict[indexer];
                }
            }

            return value;
        }

        private static bool SetMemberValue(object obj, string part, object newValue)
        {
            if (obj == null) return false;

            string memberName = part;
            string indexer = null;

            int idxStart = part.IndexOf('[');
            if (idxStart >= 0 && part.EndsWith("]"))
            {
                memberName = part.Substring(0, idxStart);
                indexer = part.Substring(idxStart + 1, part.Length - idxStart - 2);
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            Type type = obj.GetType();

            object container = null;

            if (!string.IsNullOrEmpty(memberName))
            {
                FieldInfo field = type.GetField(memberName, flags);
                if (field != null)
                {
                    container = field.GetValue(obj);
                    if (indexer == null)
                    {
                        field.SetValue(obj, newValue);
                        return true;
                    }
                }

                PropertyInfo prop = type.GetProperty(memberName, flags);
                if (prop != null)
                {
                    container = prop.GetValue(obj);
                    if (indexer == null && prop.CanWrite)
                    {
                        prop.SetValue(obj, newValue);
                        return true;
                    }
                }
            }
            else
            {
                container = obj; // directly index root
            }

            if (container != null && indexer != null)
            {
                // array / list
                if (container is IList list && int.TryParse(indexer, out int i))
                {
                    if (i >= 0 && i < list.Count)
                    {
                        list[i] = newValue;
                        return true;
                    }
                }

                // dictionary
                if (container is IDictionary dict)
                {
                    dict[indexer] = newValue;
                    return true;
                }
            }

            return false;
        }
    }
}
