using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Enumerates public / [SerializeField] instance fields on a Component, ScriptableObject or any
    /// other object (no type filter), for editors that let the user pick a field by name - see
    /// AReflectedFieldNodeView (com.widid.runtimenodal) for the field picker built on top of it.
    /// </summary>
    public static class ReflectedFieldUtility
    {
        const BindingFlags FieldFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        public static List<Component> GetComponentsWithPickableFields(GameObject go)
        {
            return go.GetComponents<Component>()
                .Where(component => component != null && GetPickableFields(component.GetType()).Count > 0)
                .ToList();
        }

        public static List<FieldInfo> GetPickableFields(Type type)
        {
            return type.GetFields(FieldFlags).Where(IsPickable).ToList();
        }

        static bool IsPickable(FieldInfo field)
        {
            if (field.IsStatic || field.IsInitOnly || field.IsLiteral)
                return false;
            if (field.Name.EndsWith("k__BackingField"))
                return false;
            if (field.IsDefined(typeof(NonSerializedAttribute), true))
                return false;

            return field.IsPublic || field.IsDefined(typeof(SerializeField), true);
        }
    }
}
