using UnityEditor;

namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(SortableReflectedProperty<bool>))]
    public class BoolReflectedPropertyDrawer : SortableReflectedPropertyDrawer
    {
    }
}

