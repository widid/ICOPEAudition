using UnityEngine;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;
using UnityEditor;
using System;

using System.Linq;
using Object = UnityEngine.Object;
using System.Reflection;

namespace WiDiD.Reflection.Editors
{
    public class DropdownReflectedProperty : AdvancedDropdown
    {
        protected const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.GetField | BindingFlags.GetProperty | BindingFlags.NonPublic;

        private SerializedProperty mainObj = null;
        private SerializedProperty selectedComponent = null;
        private SerializedProperty propertyName = null;
        private SerializedProperty fieldName = null;
        private SerializedProperty isScriptable = null;
        private string filterTypeName = null;

        private AdvancedDropdownItem root = null;
        private GameObject go = null;
        private Component componentObj = null;
        private Component[] goComponents = new Component[0];
        private List<ReflectedItem> reflectedItems = null;

        public DropdownReflectedProperty(AdvancedDropdownState state, SerializedProperty mainObj, SerializedProperty selectedComponent,
            SerializedProperty propertyName, SerializedProperty fieldName, SerializedProperty isScriptable, string filterTypeName = null) : base(state)
        {
            this.mainObj = mainObj;
            this.selectedComponent = selectedComponent;
            this.isScriptable = isScriptable;
            this.propertyName = propertyName;
            this.fieldName = fieldName;
            this.filterTypeName = filterTypeName;

            minimumSize = new Vector2(100, 200);
        }
        protected override AdvancedDropdownItem BuildRoot()
        {
            if (mainObj.objectReferenceValue == null)
                return null;

            root = new AdvancedDropdownItem("ReflectedProperty");
            Type objType = mainObj.objectReferenceValue.GetType();
            reflectedItems = new List<ReflectedItem>();

            if (objType.IsSubclassOf(typeof(Object)))
            {
                if (objType == typeof(GameObject))
                {
                    FillRootWithComponentOptions(root);
                    isScriptable.boolValue = false;
                }
                else if (objType.IsSubclassOf(typeof(ScriptableObject)))
                {
                    root.AddChild(BuildPropertyFieldTree<ScriptableObject>((ScriptableObject)mainObj.objectReferenceValue));
                    isScriptable.boolValue = true;
                }
            }

            return root;
        }
        protected void FillRootWithComponentOptions(AdvancedDropdownItem root)
        {
            go = (GameObject)mainObj.objectReferenceValue;
            componentObj = go.GetComponent<Transform>();
            goComponents = componentObj.GetComponents<Component>();
            foreach (Component component in goComponents)
            {
                AdvancedDropdownItem childTree = BuildPropertyFieldTree<Component>(component);
                if (childTree.childList.Count() > 0)
                {
                    root.AddChild(BuildPropertyFieldTree<Component>(component));
                }
            }
        }
        protected AdvancedDropdownItem BuildPropertyFieldTree<T>(T obj) where T : Object
        {
            AdvancedDropdownItem tree = new AdvancedDropdownItem(obj.GetType().Name);
            FieldInfo[] fieldInfos = obj.GetType().GetFields(flags);
            PropertyInfo[] propertyInfos = obj.GetType().GetProperties(flags);
            foreach (FieldInfo fieldInfo in fieldInfos)
            {
                if (fieldInfo.FieldType.Name == filterTypeName)
                {
                    AdvancedDropdownItem advancedDropdownItem = new AdvancedDropdownItem(fieldInfo.Name);
                    tree.AddChild(advancedDropdownItem);
                    reflectedItems.Add(ReflectedItem.New(obj, advancedDropdownItem, false));
                }
            }
            foreach (PropertyInfo propertyInfo in propertyInfos)
            {
                if (propertyInfo.PropertyType.Name == filterTypeName)
                {
                    AdvancedDropdownItem advancedDropdownItem = new AdvancedDropdownItem(propertyInfo.Name);
                    tree.AddChild(advancedDropdownItem);
                    reflectedItems.Add(ReflectedItem.New(obj, advancedDropdownItem, true));
                }
            }

            return tree;
        }
        protected override void ItemSelected(AdvancedDropdownItem item)
        {
            ReflectedItem selectedReflectedItem = reflectedItems.Find(reflectedItem => reflectedItem.Item == item);
            if (isScriptable.boolValue == false)
            {
                selectedComponent.objectReferenceValue = (Component)selectedReflectedItem.ParentComponent;
            }

            if (selectedReflectedItem.Item == null)
            {
                Debug.LogError("The referenced object " + selectedComponent.objectReferenceValue.name + " doesnt have field or property of type " + filterTypeName);
                return;
            }
            if (selectedReflectedItem.IsProperty)
            {
                propertyName.stringValue = selectedReflectedItem.Item.name;
                fieldName.stringValue = string.Empty;
                propertyName.serializedObject.ApplyModifiedProperties();
            }
            else
            {
                propertyName.stringValue = string.Empty;
                fieldName.stringValue = selectedReflectedItem.Item.name;
                fieldName.serializedObject.ApplyModifiedProperties();
            }
            mainObj.serializedObject.ApplyModifiedProperties();
            EditorUtility.SetDirty(mainObj.serializedObject.targetObject);
        }

        private struct ReflectedItem
        {
            private Object parentComponent;
            private AdvancedDropdownItem item;
            private bool isProperty;

            public static ReflectedItem New(Object parent, AdvancedDropdownItem item, bool isProperty)
            {
                ReflectedItem reflectedItem = new ReflectedItem();
                reflectedItem.parentComponent = parent;
                reflectedItem.item = item;
                reflectedItem.isProperty = isProperty;

                return reflectedItem;
            }
            public Object ParentComponent { get => parentComponent; set => parentComponent = value; }
            public bool IsProperty { get => isProperty; set => isProperty = value; }
            public AdvancedDropdownItem Item { get => item; set => item = value; }
        }

    }

}