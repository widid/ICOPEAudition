using UnityEditor;
using UnityEngine;
using System.Linq;
using System;
using System.Reflection;

namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(SortableReflectedProperty<DefaultAsset>))]
    public class SortableReflectedPropertyDrawer : ReflectedPropertyDrawer
    {
        protected override void DrawDropdown(Rect rect)
        {
            var target = serializedProperty.serializedObject.targetObject;
            SerializedProperty sortedTypeProperty = serializedProperty.FindPropertyRelative("sortedType");
            string typeName = GetSystemTypeFromPropertyPath(target, sortedTypeProperty.propertyPath)?.Name;

            var dropdown = new DropdownReflectedProperty(new UnityEditor.IMGUI.Controls.AdvancedDropdownState(), mainObj, selectedComponent, propertyName, fieldName, isScriptable, typeName);
            dropdown.Show(rect);
        }

        public Type GetSystemTypeFromPropertyPath(object targetObject, string propertyPath)
        {
            if (targetObject == null || string.IsNullOrEmpty(propertyPath))
                return null;

            var type = targetObject.GetType();
            FieldInfo fieldInfo = null;

            var parts = propertyPath.Replace(".Array.data[", "[").Split('.');
            object currentObject = targetObject;

            foreach (var part in parts)
            {
                if (part.Contains("["))
                {
                    // Array or List access
                    var fieldName = part.Substring(0, part.IndexOf("["));
                    var indexStr = part.Substring(part.IndexOf("[") + 1).TrimEnd(']');
                    int index = int.Parse(indexStr);

                    fieldInfo = type.GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (fieldInfo == null) return null;

                    var enumerable = fieldInfo.GetValue(currentObject) as System.Collections.IEnumerable;
                    if (enumerable == null) return null;

                    var enumerator = enumerable.GetEnumerator();
                    for (int i = 0; i <= index; i++) enumerator.MoveNext();
                    currentObject = enumerator.Current;
                    if (currentObject == null) return null;

                    type = currentObject.GetType();
                }
                else
                {
                    while (type != null)
                    {
                        fieldInfo = type.GetField(part, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        if (fieldInfo != null) break;

                        type = type.BaseType;
                    }
                    if (fieldInfo == null) return null;

                    currentObject = fieldInfo.GetValue(currentObject);
                    type = fieldInfo.FieldType;
                }
            }

            return type;
        }
    }
}

