using UnityEditor;

namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(SortableReflectedProperty<float>))]
    public class FloatReflectedPropertyDrawer : SortableReflectedPropertyDrawer
    {
    }
}

