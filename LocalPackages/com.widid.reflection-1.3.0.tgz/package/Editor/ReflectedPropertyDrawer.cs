using UnityEditor;
using UnityEngine;
using System;
using UnityEngine.UIElements;
using UnityEditor.UIElements;
namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(ReflectedProperty))]
    public class ReflectedPropertyDrawer : PropertyDrawer
    {
        #region Fields
        protected int fieldCounts = 3;
        protected const float spacing = 5;
        protected SerializedProperty serializedProperty = null;
        protected SerializedProperty mainObj = null;
        protected SerializedProperty selectedComponent = null;
        protected SerializedProperty propertyName = null;
        protected SerializedProperty fieldName = null;
        protected SerializedProperty isScriptable = null;
        protected string labelDropdown = "Select a property";
        public static Action OnRequestRefresh = null;
        #endregion

        public override void OnGUI(Rect rect, SerializedProperty mainSerializedProperty, GUIContent label)
        {
            this.serializedProperty = mainSerializedProperty;
            EditorGUI.BeginProperty(rect, label, serializedProperty);
            Rect labelRect = new Rect(rect.x, rect.y, rect.width / 4, rect.height);
            EditorGUI.LabelField(labelRect, label);
            float fieldSize = (rect.xMax - rect.x) / fieldCounts;
            // Don't make child fields be indented
            var indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;

            rect = new Rect(rect.x + labelRect.width, rect.y, fieldSize - spacing / 2, rect.height);

            serializedProperty.serializedObject.Update();
            mainObj = serializedProperty.FindPropertyRelative("mainObj");
            propertyName = serializedProperty.FindPropertyRelative("propertyName");
            fieldName = serializedProperty.FindPropertyRelative("fieldName");
            isScriptable = serializedProperty.FindPropertyRelative("isScriptable");

            EditorGUI.BeginChangeCheck();

            EditorGUI.PropertyField(rect, mainObj, GUIContent.none);
            if (mainObj.objectReferenceValue != null)
                isScriptable.boolValue = mainObj.objectReferenceValue.GetType().IsSubclassOf(typeof(ScriptableObject));


            if (EditorGUI.EndChangeCheck())
            {
                fieldName.stringValue = string.Empty;
                propertyName.stringValue = string.Empty;
                serializedProperty.serializedObject.ApplyModifiedProperties();
            }

            selectedComponent = serializedProperty.FindPropertyRelative("selectedComponent");


            EditorGUI.BeginChangeCheck();

            if (mainObj.objectReferenceValue == null)
            {
                EndProperty();
                return;
            }
            else
            {
                rect = new Rect(rect.x + fieldSize, rect.y, fieldSize + labelRect.width / 3, rect.height);
                labelDropdown = "Select a property";
                if (fieldName.stringValue != string.Empty)
                {
                    labelDropdown = isScriptable.boolValue ? fieldName.stringValue : selectedComponent.objectReferenceValue.GetType().Name + "/" + fieldName.stringValue;
                }
                else if (propertyName.stringValue != string.Empty)
                {
                    labelDropdown = isScriptable.boolValue ? propertyName.stringValue : selectedComponent.objectReferenceValue.GetType().Name + "/" + propertyName.stringValue;
                }
                GUIStyle guiStyle = EditorStyles.popup;
                if (EditorGUI.DropdownButton(rect, new GUIContent(labelDropdown), FocusType.Passive, guiStyle))
                    DrawDropdown(rect);

                EditorGUI.indentLevel = indent;
            }
            EndProperty();
        }

        public override VisualElement CreatePropertyGUI(SerializedProperty property)
        {
            this.serializedProperty = property;
            serializedProperty.serializedObject.Update();
            VisualElement container = new VisualElement();
            container.style.flexDirection = FlexDirection.Row;

            mainObj = serializedProperty.FindPropertyRelative("mainObj");
            propertyName = serializedProperty.FindPropertyRelative("propertyName");
            fieldName = serializedProperty.FindPropertyRelative("fieldName");
            isScriptable = serializedProperty.FindPropertyRelative("isScriptable");
            selectedComponent = serializedProperty.FindPropertyRelative("selectedComponent");

            DropdownField propertyDropdown = new DropdownField();
            propertyDropdown.style.flexGrow = 1;
            propertyDropdown.RegisterCallback<ClickEvent>(evt =>
            {
                Vector2 dropdownWorldPos = propertyDropdown.worldBound.position;
                dropdownWorldPos.y += propertyDropdown.worldBound.height;

                DrawDropdown(new Rect(dropdownWorldPos, Vector2.zero));
            });

            PropertyField mainObjField = new PropertyField();
            mainObjField.BindProperty(mainObj);
            mainObjField.label = "";
            mainObjField.style.minWidth = 80;
            mainObjField.style.maxWidth = 100;
            container.Add(mainObjField);
            mainObjField.RegisterValueChangeCallback((e) =>
            {
                if (mainObj.objectReferenceValue != null)
                    isScriptable.boolValue = mainObj.objectReferenceValue.GetType().IsSubclassOf(typeof(ScriptableObject));
                serializedProperty.serializedObject.ApplyModifiedProperties();
            if (mainObj.objectReferenceValue != null) container.Add(propertyDropdown);
            else if (container.Contains(propertyDropdown)) container.Remove(propertyDropdown);
            });

            UpdateLabelDropdown();

            container.TrackPropertyValue(fieldName, (prop) => UpdateLabelDropdown());
            container.TrackPropertyValue(propertyName, (prop) => UpdateLabelDropdown());
            container.TrackPropertyValue(mainObj, (prop) =>
            {
                fieldName.stringValue = string.Empty;
                propertyName.stringValue = string.Empty;
            });
            return container;

            void UpdateLabelDropdown()
            {
                labelDropdown = "Select a property";
                if (fieldName.stringValue != string.Empty)
                {
                    labelDropdown = isScriptable.boolValue ? fieldName.stringValue : selectedComponent.objectReferenceValue.GetType().Name + "/" + fieldName.stringValue;
                }
                else if (propertyName.stringValue != string.Empty)
                {
                    labelDropdown = isScriptable.boolValue ? propertyName.stringValue : selectedComponent.objectReferenceValue.GetType().Name + "/" + propertyName.stringValue;
                }
                propertyDropdown.value = labelDropdown;
                serializedProperty.serializedObject.ApplyModifiedProperties();
            }
        }

        protected virtual void DrawDropdown(Rect rect)
        {
            var dropdown = new DropdownReflectedProperty(new UnityEditor.IMGUI.Controls.AdvancedDropdownState(), mainObj, selectedComponent, propertyName, fieldName, isScriptable);
            dropdown.Show(rect);
        }



        protected void EndProperty()
        {
            //Apply changes to GUI & Properties
            if (EditorGUI.EndChangeCheck())
            {
                serializedProperty.serializedObject.ApplyModifiedProperties();
                EditorUtility.SetDirty(serializedProperty.serializedObject.targetObject);
            }
            EditorGUI.EndProperty();
        }
    }
}

