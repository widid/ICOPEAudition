using UnityEditor;

namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(SortableReflectedProperty<int>))]
    public class IntReflectedPropertyDrawer : SortableReflectedPropertyDrawer
    {
    }
}

