using UnityEditor;

namespace WiDiD.Reflection.Editors
{
    [CustomPropertyDrawer(typeof(SortableReflectedProperty<string>))]
    public class StringReflectedPropertyDrawer : SortableReflectedPropertyDrawer
    {
    }
}

