using System;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Turns an ObjectField into a reflected source field: sets its objectType and appends a quick
    /// create button opening ReflectedValueSourceEditorWindow for that type. The created asset is
    /// assigned through objectField.value, so the field's own value-changed callbacks apply it.
    /// </summary>
    public static class ReflectedSourceField
    {
        const string ButtonName = "ReflectedSourceCreateButton";

        public static void Attach(ObjectField objectField, Type sourceType)
        {
            if (!typeof(ScriptableObject).IsAssignableFrom(sourceType) || !typeof(IReflectedValueSource).IsAssignableFrom(sourceType))
                throw new ArgumentException($"{sourceType.Name} must be a ScriptableObject implementing {nameof(IReflectedValueSource)}.", nameof(sourceType));

            objectField.objectType = sourceType;

            if (objectField.Q<Button>(ButtonName) != null)
                return;

            Button button = new() { name = ButtonName, text = "+", tooltip = "Create a new reflected source" };
            button.style.width = 20f;
            button.style.marginLeft = 2f;
            button.style.marginRight = 0f;
            button.style.paddingLeft = 0f;
            button.style.paddingRight = 0f;
            button.style.flexShrink = 0f;
            button.clicked += () => ReflectedValueSourceEditorWindow.OpenFor(sourceType, asset => objectField.value = asset);

            objectField.Add(button);
        }
    }
}
