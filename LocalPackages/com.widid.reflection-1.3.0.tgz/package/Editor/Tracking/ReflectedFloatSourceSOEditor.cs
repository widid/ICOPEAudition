using UnityEditor;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    [CustomEditor(typeof(ReflectedFloatSourceSO))]
    public class ReflectedFloatSourceSOEditor : ReflectedValueSourceEditorBase<float>
    {
        protected override void DrawValueField(float value) => EditorGUILayout.FloatField("Current Value", value);
    }
}
