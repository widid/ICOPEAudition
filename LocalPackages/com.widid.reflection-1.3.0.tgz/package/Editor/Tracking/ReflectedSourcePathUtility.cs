using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Shared "resolve + display" logic for any IReflectedValueSource's binding, used by every
    /// concrete source's custom Editor and by any other tool that wants to show the same friendly
    /// path inline (e.g. Performance authoring). Caches the last known scene/object name onto the
    /// asset whenever the target is found live, so BuildFriendlyPath can still show something
    /// useful once that scene is unloaded - see ReflectedValueSourceData.LastKnownSceneName/
    /// LastKnownObjectName.
    /// </summary>
    public static class ReflectedSourcePathUtility
    {
        public static TrackableId FindTrackable(string guid)
        {
            if (string.IsNullOrEmpty(guid))
                return null;

            foreach (TrackableId candidate in Object.FindObjectsByType<TrackableId>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (candidate.Guid == guid)
                    return candidate;
            }

            return null;
        }

        public static void CacheLastKnownLocation(Object source, ReflectedValueSourceData data, TrackableId target)
        {
            if (target == null)
                return;

            string sceneName = string.IsNullOrEmpty(target.gameObject.scene.name) ? "(unsaved scene)" : target.gameObject.scene.name;
            string scenePath = target.gameObject.scene.path;
            string objectName = target.gameObject.name;

            if (data.LastKnownSceneName == sceneName && data.LastKnownScenePath == scenePath && data.LastKnownObjectName == objectName)
                return;

            data.LastKnownSceneName = sceneName;
            data.LastKnownScenePath = scenePath;
            data.LastKnownObjectName = objectName;
            EditorUtility.SetDirty(source);
        }

        public static string BuildFriendlyPath(ReflectedValueSourceData data, TrackableId target)
        {
            if (data.DirectAsset != null)
                return $"{AssetDatabase.GetAssetPath(data.DirectAsset)} / {data.MemberPath}";

            if (string.IsNullOrEmpty(data.TargetGuid))
                return "(not bound)";

            string memberSegment = BuildMemberSegment(data);

            if (target != null)
                return $"{data.LastKnownSceneName}/{target.gameObject.name}/{memberSegment}";

            if (!string.IsNullOrEmpty(data.LastKnownSceneName) || !string.IsNullOrEmpty(data.LastKnownObjectName))
                return $"{data.LastKnownSceneName}/{data.LastKnownObjectName}/{memberSegment}  (scene not currently loaded)";

            return $"(not found in open scenes)/{memberSegment}";
        }

        // Decides whether a missing-target warning applies and what it should say, without drawing
        // anything - shared by DrawMissingTargetWarning (IMGUI, used by the per-asset custom
        // Editors) and ReflectedValuesWindow (its own IMGUI, but a different layout - a compact
        // per-row summary rather than a full Inspector) so both present the exact same distinction
        // between "scene not loaded" (Load Scene will likely fix it) and "deleted from an open
        // scene" (Load Scene wouldn't help) without duplicating the scene-lookup logic twice.
        public static MissingTargetInfo GetMissingTargetInfo(ReflectedValueSourceData data, TrackableId target)
        {
            if (data.DirectAsset != null || string.IsNullOrEmpty(data.TargetGuid) || target != null)
                return default;

            if (string.IsNullOrEmpty(data.LastKnownScenePath))
                return new MissingTargetInfo(true, "Tracked object could not be found in any open scene, and no scene location is cached for it - it may never have been bound correctly, or its TrackableId component may have been deleted.", false, null, null);

            Scene scene = SceneManager.GetSceneByPath(data.LastKnownScenePath);
            if (scene.IsValid() && scene.isLoaded)
                return new MissingTargetInfo(true, $"'{data.LastKnownObjectName}' could not be found in '{data.LastKnownSceneName}', which is already open - it, or its TrackableId component, may have been deleted.", false, data.LastKnownSceneName, data.LastKnownScenePath);

            return new MissingTargetInfo(true, $"'{data.LastKnownSceneName}' is not currently loaded - load it to check whether this binding still resolves.", true, data.LastKnownSceneName, data.LastKnownScenePath);
        }

        // Shared by every concrete source's custom Editor (see ReflectedValueSourceEditorBase,
        // ReflectedAttachmentSourceSOEditor) - shown right under the friendly path whenever the
        // target can't currently be resolved.
        public static void DrawMissingTargetWarning(ReflectedValueSourceData data, TrackableId target)
        {
            MissingTargetInfo info = GetMissingTargetInfo(data, target);
            if (!info.HasWarning)
                return;

            EditorGUILayout.HelpBox(info.Message, MessageType.Warning);

            if (info.CanLoadScene && GUILayout.Button($"Load Scene '{info.SceneName}'"))
                EditorSceneManager.OpenScene(info.ScenePath, OpenSceneMode.Additive);
        }

        // MemberPath is empty for a source with no member to reflect (e.g. ReflectedAttachmentSourceSO,
        // which invokes IAttachmentProvider.Capture() on the bound component instead of reading a
        // field) - fall back to the component's own short type name so the path still identifies
        // *which* component is bound, live or cached.
        static string BuildMemberSegment(ReflectedValueSourceData data)
        {
            if (!string.IsNullOrEmpty(data.MemberPath))
                return data.MemberPath;

            if (string.IsNullOrEmpty(data.ComponentTypeName))
                return string.Empty;

            System.Type componentType = System.Type.GetType(data.ComponentTypeName);
            return componentType != null ? componentType.Name : data.ComponentTypeName;
        }
    }
}
