using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Draws one source row of ReflectedValuesWindow: the bound/unbound stripe and the kebab strip
    /// down the left edge, the name and friendly path (plus any binding warning) in the middle,
    /// and the value on the right.
    /// Both side columns only reserve the height they need during layout and are then painted into
    /// the finished row's rect, so they span its full height without making the row itself
    /// stretchable - a row that stretches gets handed all the spare space in the scroll view. The
    /// details in the middle stay in normal layout, since they are what gives the row its height,
    /// and are centered against a taller value column by padding instead.
    /// </summary>
    public class ReflectedSourceRowDrawer
    {
        const float Border = 1f;

        readonly ReflectedValuePreviewDrawer preview = new();
        readonly Dictionary<ScriptableObject, float> detailHeights = new();
        readonly Action onSourcesChanged;

        /// <param name="onSourcesChanged">Raised when a row action invalidates the listing - deleting the asset it draws.</param>
        public ReflectedSourceRowDrawer(Action onSourcesChanged) => this.onSourcesChanged = onSourcesChanged;

        public void Draw(ReflectedSourceEntry entry)
        {
            TrackableId target = ReflectedSourcePathUtility.FindTrackable(entry.Data.TargetGuid);
            ReflectedSourcePathUtility.CacheLastKnownLocation(entry.Asset, entry.Data, target);
            MissingTargetInfo info = ReflectedSourcePathUtility.GetMissingTargetInfo(entry.Data, target);

            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);

            Rect statusColumn = GUILayoutUtility.GetRect(ReflectedBindingStatus.StripeWidth, EditorGUIUtility.singleLineHeight, GUILayout.Width(ReflectedBindingStatus.StripeWidth));
            Rect menuColumn = GUILayoutUtility.GetRect(ReflectedSourceRowActions.StripWidth, EditorGUIUtility.singleLineHeight, GUILayout.Width(ReflectedSourceRowActions.StripWidth));

            float valueHeight = preview.MeasureHeight(entry);
            float padding = ResolveCenteringPadding(entry.Asset, valueHeight);

            EditorGUILayout.BeginVertical();
            GUILayout.Space(padding);
            EditorGUILayout.LabelField(entry.Asset.name, EditorStyles.boldLabel);
            EditorGUILayout.LabelField(ReflectedSourcePathUtility.BuildFriendlyPath(entry.Data, target), EditorStyles.wordWrappedMiniLabel);

            if (info.HasWarning)
                EditorGUILayout.HelpBox(info.Message, MessageType.Warning);

            EditorGUILayout.EndVertical();
            MeasureDetails(entry.Asset, padding);

            Rect valueColumn = GUILayoutUtility.GetRect(ReflectedValuePreviewDrawer.ColumnWidth, valueHeight, GUILayout.Width(ReflectedValuePreviewDrawer.ColumnWidth));

            EditorGUILayout.EndHorizontal();

            // Dummy rects during the layout pass - both calls below still run every event so their
            // control ids stay stable, they just have nothing real to draw into yet.
            Rect row = GUILayoutUtility.GetLastRect();
            ReflectedBindingStatus.DrawStripe(StretchToRow(statusColumn, row), ReflectedBindingStatus.IsBound(entry.Data, target));
            ReflectedSourceRowActions.Draw(StretchToRow(menuColumn, row), entry, target, info, onSourcesChanged);
            preview.Draw(StretchToRow(valueColumn, row), entry, target);
        }

        public void Clear()
        {
            detailHeights.Clear();
            preview.Clear();
        }

        // How tall the details actually came out can only be known once they have been laid out -
        // a path wraps, a warning appears - so the previous repaint's measurement decides it. The
        // padding already applied is subtracted back out, otherwise the measurement would feed on
        // itself and the block would creep down the row.
        float ResolveCenteringPadding(ScriptableObject asset, float valueHeight)
        {
            if (!detailHeights.TryGetValue(asset, out float detailHeight))
                return 0f;

            return Mathf.Max(0f, (valueHeight - detailHeight) * 0.5f);
        }

        void MeasureDetails(ScriptableObject asset, float appliedPadding)
        {
            if (Event.current.type == EventType.Repaint)
                detailHeights[asset] = GUILayoutUtility.GetLastRect().height - appliedPadding;
        }

        // Inset by the helpBox's own border so a full-height column doesn't paint over the frame.
        static Rect StretchToRow(Rect column, Rect row) => new(column.x, row.y + Border, column.width, row.height - Border * 2f);
    }
}
