using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Finds every IReflectedValueSource asset in the project - any concrete ScriptableObject type
    /// discovered via TypeCache, same "no editing needed for a new family" convention as
    /// ReflectedValueSourceEditorWindow's ValueType picker - and wraps each one as a
    /// ReflectedSourceEntry for ReflectedValuesWindow to list.
    /// </summary>
    public static class ReflectedSourceCollector
    {
        public static List<ReflectedSourceEntry> Collect()
        {
            List<ReflectedSourceEntry> entries = new();

            foreach (Type sourceType in TypeCache.GetTypesDerivedFrom<ScriptableObject>())
            {
                if (sourceType.IsAbstract || !typeof(IReflectedValueSource).IsAssignableFrom(sourceType))
                    continue;

                foreach (string guid in AssetDatabase.FindAssets($"t:{sourceType.Name}"))
                {
                    ScriptableObject asset = AssetDatabase.LoadAssetAtPath<ScriptableObject>(AssetDatabase.GUIDToAssetPath(guid));
                    if (asset is IReflectedValueSource source)
                        entries.Add(new ReflectedSourceEntry(asset, source));
                }
            }

            return entries.OrderBy(entry => entry.Asset.name).ToList();
        }
    }
}
