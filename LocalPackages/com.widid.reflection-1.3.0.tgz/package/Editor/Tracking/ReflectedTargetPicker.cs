using System;
using System.Linq;
using UnityEngine;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Shared "given a dragged object, which component (if any) should reflection actually target"
    /// logic - used by both ReflectedValueSourceEditorWindow (creating a new source) and
    /// ReflectedValueSourceEditorBase (rebinding an existing one) so a GameObject/Component target
    /// always gets the same component-picker behavior. A ScriptableObject (or any other plain asset)
    /// has no components, so it always resolves to itself.
    ///
    /// requiredComponentType narrows the offered components to those a component-bound source can
    /// actually invoke (ReflectedAttachmentSourceSO -> IAttachmentProvider), so an unusable one is
    /// never selectable in the first place.
    /// </summary>
    public static class ReflectedTargetPicker
    {
        public static Component[] ComputeAvailableComponents(UnityEngine.Object target, Type requiredComponentType = null)
        {
            Component[] components = target switch
            {
                GameObject gameObject => gameObject.GetComponents<Component>(),
                Component component => component.gameObject.GetComponents<Component>(),
                _ => Array.Empty<Component>()
            };

            // Missing-script slots come back as null entries.
            return components
                .Where(component => component != null && (requiredComponentType == null || requiredComponentType.IsInstanceOfType(component)))
                .ToArray();
        }

        // Whichever component was actually dragged in, if any - else the first one.
        public static int ResolvePreselectedIndex(UnityEngine.Object target, Component[] availableComponents)
        {
            if (target is Component draggedComponent)
            {
                int index = Array.IndexOf(availableComponents, draggedComponent);
                if (index >= 0)
                    return index;
            }

            return 0;
        }

        public static UnityEngine.Object ResolveReflectionTarget(UnityEngine.Object target, Component[] availableComponents, int selectedIndex)
        {
            return availableComponents.Length > 0 ? availableComponents[selectedIndex] : target;
        }
    }
}
