using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Shared mechanics behind creating any concrete IReflectedValueSource
    /// (ReflectedFloatSourceSO/ReflectedIntSourceSO/ReflectedStringSourceSO) - used by the
    /// standalone reflected-source window and by any other tool that wants to create-and-link a
    /// source inline instead of pointing at a pre-existing asset. sourceType must be a concrete
    /// ScriptableObject implementing IReflectedValueSource. Returns null if the user cancels the
    /// save dialog.
    ///
    /// target may be a ScriptableObject (or any other plain asset) - stored as DirectAsset, resolved
    /// by direct reference, no scene tracking needed - or a Component - ensures a TrackableId on its
    /// GameObject and stores TargetGuid/ComponentTypeName instead, same as before.
    /// </summary>
    public static class ReflectedValueSourceFactory
    {
        public static ScriptableObject CreateAsset(Type sourceType, UnityEngine.Object target, string memberPath, string dialogTitle = "Save Reflected Source")
        {
            string savePath = EditorUtility.SaveFilePanelInProject(dialogTitle, BuildDefaultAssetName(sourceType, target, memberPath), "asset", "Choose where to save the source asset.");
            if (string.IsNullOrEmpty(savePath))
                return null;

            ScriptableObject instance = ScriptableObject.CreateInstance(sourceType);
            IReflectedValueSource source = (IReflectedValueSource)instance;
            Bind(source.Data, target, memberPath);

            AssetDatabase.CreateAsset(instance, savePath);
            AssetDatabase.SaveAssets();

            return instance;
        }

        // Points data at target/memberPath, clearing whichever mode's fields no longer apply -
        // shared by CreateAsset and any "edit binding" UI (see ReflectedValueSourceEditorBase)
        // rebinding an existing asset, e.g. from a Component source to a DirectAsset one or back.
        public static void Bind(ReflectedValueSourceData data, UnityEngine.Object target, string memberPath)
        {
            data.MemberPath = memberPath;

            if (target is Component component)
            {
                BindSceneComponent(data, component);
                data.DirectAsset = null;
            }
            else
            {
                data.DirectAsset = target;
                data.TargetGuid = string.Empty;
                data.ComponentTypeName = string.Empty;
            }
        }

        // "Reflected{Type}_{ObjectName}_{Component}_{MemberName}" - Component segment is only
        // present when target is a Component, since a plain asset (ScriptableObject etc.) has none,
        // and the member segment only when there is a member to reflect (empty for
        // ReflectedAttachmentSourceSO, which binds to the component itself).
        // Type is derived from sourceType's own name (e.g. "ReflectedFloatSourceSO" -> "Float")
        // rather than hardcoded, so any future ReflectedXSourceSO just works without changes here.
        // Public so "edit binding" UIs can offer renaming an existing asset to match its new target.
        public static string BuildDefaultAssetName(Type sourceType, UnityEngine.Object target, string memberPath)
        {
            string valueTypeName = sourceType.Name.Replace("Reflected", string.Empty).Replace("SourceSO", string.Empty);
            string memberSegment = string.IsNullOrEmpty(memberPath) ? string.Empty : $"_{memberPath.Replace('/', '_')}";

            if (target is Component component)
                return $"Reflected{valueTypeName}_{component.gameObject.name}_{component.GetType().Name}{memberSegment}";

            return $"Reflected{valueTypeName}_{target.name}{memberSegment}";
        }

        static void BindSceneComponent(ReflectedValueSourceData data, Component component)
        {
            TrackableId trackableId = component.GetComponent<TrackableId>();
            if (trackableId == null)
                trackableId = Undo.AddComponent<TrackableId>(component.gameObject);

            trackableId.AssignGuidIfEmpty();
            EditorUtility.SetDirty(trackableId);
            EditorSceneManager.MarkSceneDirty(trackableId.gameObject.scene);

            data.TargetGuid = trackableId.Guid;
            data.ComponentTypeName = component.GetType().AssemblyQualifiedName;
            data.LastKnownSceneName = string.IsNullOrEmpty(component.gameObject.scene.name) ? "(unsaved scene)" : component.gameObject.scene.name;
            data.LastKnownScenePath = component.gameObject.scene.path;
            data.LastKnownObjectName = component.gameObject.name;
        }
    }
}
