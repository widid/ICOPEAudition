using UnityEditor;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    [CustomEditor(typeof(ReflectedStringSourceSO))]
    public class ReflectedStringSourceSOEditor : ReflectedValueSourceEditorBase<string>
    {
        protected override void DrawValueField(string value) => EditorGUILayout.TextField("Current Value", value);
    }
}
