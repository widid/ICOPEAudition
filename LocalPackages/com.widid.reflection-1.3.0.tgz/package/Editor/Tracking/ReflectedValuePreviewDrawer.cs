using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// The value column docked to the right of every row in ReflectedValuesWindow - no container
    /// and no caption, just the value, centered in both directions over the row's full height.
    /// Drawn into a rect the row measures with MeasureHeight rather than through layout stretching,
    /// which would make every row expand to fill the scroll view. Member-based sources show their
    /// live value (ReflectedSourceValueSummary); attachment sources show a Capture button and the
    /// resulting thumbnail (ReflectedAttachmentPreviewCache).
    /// </summary>
    public class ReflectedValuePreviewDrawer
    {
        public const float ColumnWidth = 70f;

        const float ButtonHeight = 18f;
        const float ThumbnailHeight = 48f;
        const float Spacing = 2f;

        static GUIStyle valueStyle;
        static GUIStyle summaryStyle;

        readonly ReflectedAttachmentPreviewCache attachments = new();

        /// <summary>How much height this column needs, so a row never ends up shorter than its own value.</summary>
        public float MeasureHeight(ReflectedSourceEntry entry)
        {
            if (entry.Asset is not ReflectedAttachmentSourceSO)
                return EditorGUIUtility.singleLineHeight;

            attachments.TryGet(entry.Asset, out Texture2D texture, out string _);
            float height = ButtonHeight + Spacing + EditorGUIUtility.singleLineHeight;
            return texture != null ? height + ThumbnailHeight + Spacing : height;
        }

        public void Draw(Rect area, ReflectedSourceEntry entry, TrackableId target)
        {
            if (entry.Asset is ReflectedAttachmentSourceSO)
                DrawAttachmentPreview(area, entry, target);
            else
                GUI.Label(area, ReflectedSourceValueSummary.Build(entry.Asset, target, entry.Data), ValueStyle);
        }

        public void Clear() => attachments.Clear();

        void DrawAttachmentPreview(Rect area, ReflectedSourceEntry entry, TrackableId target)
        {
            attachments.TryGet(entry.Asset, out Texture2D texture, out string summary);

            float cursor = area.y + Mathf.Max(0f, (area.height - MeasureHeight(entry)) * 0.5f);

            // Nothing to capture while the tracked target can't be resolved - Capture() would just
            // fail anyway (same guard as ReflectedAttachmentSourceSOEditor).
            using (new EditorGUI.DisabledScope(target == null))
            {
                if (GUI.Button(new Rect(area.x, cursor, area.width, ButtonHeight), "Capture", EditorStyles.miniButton))
                    attachments.Capture(entry.Asset, target, entry.Data);
            }

            cursor += ButtonHeight + Spacing;

            if (texture != null)
            {
                EditorGUI.DrawPreviewTexture(new Rect(area.x, cursor, area.width, ThumbnailHeight), texture, null, ScaleMode.ScaleToFit);
                cursor += ThumbnailHeight + Spacing;
            }

            GUI.Label(new Rect(area.x, cursor, area.width, EditorGUIUtility.singleLineHeight), summary, SummaryStyle);
        }

        static GUIStyle ValueStyle => valueStyle ??= new GUIStyle(EditorStyles.label)
        {
            alignment = TextAnchor.MiddleCenter,
            wordWrap = true
        };

        static GUIStyle SummaryStyle => summaryStyle ??= new GUIStyle(EditorStyles.miniLabel)
        {
            alignment = TextAnchor.MiddleCenter,
            wordWrap = true
        };
    }
}
