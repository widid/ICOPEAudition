using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Builds the "Edit Binding" section that fits a given source asset, so rebinding works the
    /// same from ReflectedValuesWindow as it does from the asset's own Inspector. Mirrors the
    /// ForMember/ForComponent split the concrete editors make: a member-reading source exposes the
    /// value it reads as a Value property (see ReflectedFloatSourceSO), while a component-bound one
    /// has none and is invoked through an interface instead (ReflectedAttachmentSourceSO ->
    /// IAttachmentProvider).
    /// </summary>
    public static class ReflectedRebindSectionFactory
    {
        public static ReflectedRebindSection Create(ScriptableObject asset)
        {
            if (asset is ReflectedAttachmentSourceSO)
                return ReflectedRebindSection.ForComponent(typeof(IAttachmentProvider));

            Type memberType = asset.GetType().GetProperty("Value")?.PropertyType;
            return memberType != null ? ReflectedRebindSection.ForMember(memberType) : null;
        }
    }
}
