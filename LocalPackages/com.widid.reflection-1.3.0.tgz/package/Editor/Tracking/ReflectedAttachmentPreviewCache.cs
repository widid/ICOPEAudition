using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Holds the last capture taken for each ReflectedAttachmentSourceSO listed in
    /// ReflectedValuesWindow. Attachment sources can't be previewed passively - Capture() actively
    /// renders and encodes bytes, unlike the scalar types re-resolved on every repaint - so a
    /// capture only happens on demand and is kept here until the next capture, refresh, or window
    /// close. Textures are owned by the cache: Clear destroys them.
    /// </summary>
    public class ReflectedAttachmentPreviewCache
    {
        readonly Dictionary<ScriptableObject, (Texture2D texture, string summary)> previews = new();

        public bool TryGet(ScriptableObject asset, out Texture2D texture, out string summary)
        {
            if (previews.TryGetValue(asset, out (Texture2D texture, string summary) preview))
            {
                texture = preview.texture;
                summary = preview.summary;
                return true;
            }

            texture = null;
            summary = "(not captured)";
            return false;
        }

        public void Capture(ScriptableObject asset, TrackableId target, ReflectedValueSourceData data)
        {
            Release(asset);

            AttachmentCapture? capture;
            try
            {
                capture = ReflectedAttachmentResolver.CaptureFrom(target, data);
            }
            catch (Exception exception)
            {
                previews[asset] = (null, $"Capture threw: {exception.Message}");
                Debug.LogException(exception);
                return;
            }

            if (capture == null)
            {
                previews[asset] = (null, "Capture failed.");
                return;
            }

            // LoadImage only decodes PNG/JPG - a Tga-formatted capture still reports its size, it
            // just can't be shown as a thumbnail (same limitation as ReflectedAttachmentSourceSOEditor).
            Texture2D texture = new(2, 2);
            if (!texture.LoadImage(capture.Value.Bytes))
            {
                UnityEngine.Object.DestroyImmediate(texture);
                texture = null;
            }

            previews[asset] = (texture, $"{capture.Value.ContentType}, {capture.Value.Bytes.Length:N0} bytes");
        }

        public void Clear()
        {
            foreach ((Texture2D texture, string _) in previews.Values)
            {
                if (texture != null)
                    UnityEngine.Object.DestroyImmediate(texture);
            }

            previews.Clear();
        }

        void Release(ScriptableObject asset)
        {
            if (previews.TryGetValue(asset, out (Texture2D texture, string summary) previous) && previous.texture != null)
                UnityEngine.Object.DestroyImmediate(previous.texture);
        }
    }
}
