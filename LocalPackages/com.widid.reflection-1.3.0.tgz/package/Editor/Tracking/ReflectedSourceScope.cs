namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Which of ReflectedValuesWindow's two tabs a source belongs to - decided by how its binding is
    /// stored (see ReflectedSourceEntry), not by whether it currently resolves.
    /// </summary>
    public enum ReflectedSourceScope
    {
        /// <summary>Bound to a scene object through a TrackableId guid.</summary>
        Scene,

        /// <summary>Bound straight to an asset (DirectAsset), or not bound at all yet.</summary>
        Other
    }
}
