using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// The "Edit Binding" foldout an IReflectedValueSource's inspector shows: drag in a target, pick
    /// which of its components to reflect from, pick what to read, and repoint the existing asset
    /// instead of recreating it. Built on the same ReflectedTargetPicker/ReflectedValueSourceFactory
    /// pieces ReflectedValueSourceEditorWindow creates a new source with, so a rebound source and a
    /// freshly created one can't end up shaped differently.
    ///
    /// Draw hosts it in the foldout an inspector shows; DrawBody is the same editor without that
    /// wrapper, for a host that is already dedicated to rebinding (see ReflectedRebindWindow).
    ///
    /// ForMember drives the member-reading sources (ReflectedFloatSourceSO etc., through
    /// ReflectedValueSourceEditorBase); ForComponent drives one that binds to a component itself
    /// with no member to pick - ReflectedAttachmentSourceSO, which invokes IAttachmentProvider.
    /// Capture() - mirroring the creation window's own RequiresMemberPath split.
    /// </summary>
    public class ReflectedRebindSection
    {
        readonly Type memberType;
        readonly Type requiredComponentType;

        bool expanded;
        UnityEngine.Object target;
        Component[] components = Array.Empty<Component>();
        int componentIndex;
        string[] paths = Array.Empty<string>();
        int pathIndex;
        bool renameOnRebind = true;

        ReflectedRebindSection(Type memberType, Type requiredComponentType)
        {
            this.memberType = memberType;
            this.requiredComponentType = requiredComponentType;
        }

        public static ReflectedRebindSection ForMember(Type memberType) => new ReflectedRebindSection(memberType, null);

        public static ReflectedRebindSection ForComponent(Type requiredComponentType) => new ReflectedRebindSection(null, requiredComponentType);

        bool PicksMember => memberType != null;

        public void Draw(UnityEngine.Object source, ReflectedValueSourceData data)
        {
            expanded = EditorGUILayout.Foldout(expanded, "Edit Binding", true);
            if (!expanded)
                return;

            if (DrawBody(source, data))
                expanded = false;
        }

        /// <summary>Returns true once a new binding has been applied, so a host that owns the whole view can close itself.</summary>
        public bool DrawBody(UnityEngine.Object source, ReflectedValueSourceData data)
        {
            UnityEngine.Object newTarget = EditorGUILayout.ObjectField("Target", target, typeof(UnityEngine.Object), true);
            if (newTarget != target)
            {
                target = newTarget;
                RefreshComponents();
            }

            if (target == null)
                return false;

            if (components.Length > 1)
            {
                string[] componentNames = components.Select(component => component.GetType().Name).ToArray();
                int newComponentIndex = EditorGUILayout.Popup("Component", componentIndex, componentNames);
                if (newComponentIndex != componentIndex)
                {
                    componentIndex = newComponentIndex;
                    RefreshPaths();
                }
            }

            if (!DrawWhatToRead())
                return false;

            renameOnRebind = EditorGUILayout.ToggleLeft("Rename asset to match new binding", renameOnRebind);

            if (!GUILayout.Button("Update Binding"))
                return false;

            Apply(source, data);
            return true;
        }

        // Returns whether the picked target can actually be bound: a member source needs a member of
        // the right type to select, a component source needs the picked component to implement the
        // interface it will be invoked through.
        bool DrawWhatToRead()
        {
            if (PicksMember)
            {
                if (paths.Length == 0)
                {
                    EditorGUILayout.HelpBox("No matching fields or properties found on this target.", MessageType.Warning);
                    return false;
                }

                pathIndex = EditorGUILayout.Popup("Member", pathIndex, paths);
                return true;
            }

            return ReflectedComponentRequirement.Draw(requiredComponentType, ResolveReflectionTarget());
        }

        void Apply(UnityEngine.Object source, ReflectedValueSourceData data)
        {
            UnityEngine.Object reflectionTarget = ResolveReflectionTarget();
            string memberPath = PicksMember ? paths[pathIndex] : string.Empty;

            ReflectedValueSourceFactory.Bind(data, reflectionTarget, memberPath);
            EditorUtility.SetDirty(source);

            if (renameOnRebind)
            {
                string newName = ReflectedValueSourceFactory.BuildDefaultAssetName(source.GetType(), reflectionTarget, memberPath);
                AssetDatabase.RenameAsset(AssetDatabase.GetAssetPath(source), newName);
                AssetDatabase.SaveAssets();
            }

            ClearPick();
        }

        void ClearPick()
        {
            target = null;
            components = Array.Empty<Component>();
            componentIndex = 0;
            paths = Array.Empty<string>();
            pathIndex = 0;
        }

        void RefreshComponents()
        {
            components = ReflectedTargetPicker.ComputeAvailableComponents(target, requiredComponentType);
            componentIndex = ReflectedTargetPicker.ResolvePreselectedIndex(target, components);
            RefreshPaths();
        }

        void RefreshPaths()
        {
            UnityEngine.Object reflectionTarget = target != null ? ResolveReflectionTarget() : null;
            paths = PicksMember && reflectionTarget != null ? ReflectionPathUtility.GetMemberPaths(reflectionTarget, memberType) : Array.Empty<string>();
            pathIndex = 0;
        }

        UnityEngine.Object ResolveReflectionTarget() => ReflectedTargetPicker.ResolveReflectionTarget(target, components, componentIndex);
    }
}
