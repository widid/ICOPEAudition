namespace WiDiD.Reflection.Editors
{
    /// <summary>Result of ReflectedSourcePathUtility.GetMissingTargetInfo - whether a bound target currently fails to resolve, why, and whether loading its cached scene would help.</summary>
    public readonly struct MissingTargetInfo
    {
        public bool HasWarning { get; }
        public string Message { get; }
        public bool CanLoadScene { get; }
        public string SceneName { get; }
        public string ScenePath { get; }

        public MissingTargetInfo(bool hasWarning, string message, bool canLoadScene, string sceneName, string scenePath)
        {
            HasWarning = hasWarning;
            Message = message;
            CanLoadScene = canLoadScene;
            SceneName = sceneName;
            ScenePath = scenePath;
        }
    }
}
