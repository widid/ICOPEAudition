using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Reads a member-based source's current value for ReflectedValuesWindow's preview panel.
    /// Resolved fresh on every call (cheap, and never cached - same as
    /// ReflectedValueSourceEditorBase's own Debug section) against whatever TrackableId is currently
    /// found in the open scenes, so a value shows in Edit mode too. Attachment sources have no
    /// passive value to read and are previewed through ReflectedAttachmentPreviewCache instead.
    /// </summary>
    public static class ReflectedSourceValueSummary
    {
        public static string Build(ScriptableObject asset, TrackableId target, ReflectedValueSourceData data) => asset switch
        {
            ReflectedFloatSourceSO => $"{ReflectedValueResolver.ResolveFrom<float>(target, data):0.####}",
            ReflectedIntSourceSO => $"{ReflectedValueResolver.ResolveFrom<int>(target, data)}",
            ReflectedStringSourceSO => ReflectedValueResolver.ResolveFrom<string>(target, data) ?? "(null)",
            ReflectedBoolSourceSO => $"{ReflectedValueResolver.ResolveFrom<bool>(target, data)}",
            _ => "(no preview)"
        };
    }
}
