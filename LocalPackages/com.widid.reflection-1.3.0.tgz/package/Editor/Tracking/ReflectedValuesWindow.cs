using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Project-wide overview of every IReflectedValueSource asset (see ReflectedSourceCollector)
    /// with its resolved status, its live value and its binding, so a broken or stale binding can
    /// be found - and fixed in place - without opening every asset's Inspector one at a time.
    /// Scene-tracked sources and everything else (asset-bound or not yet bound) get a tab each,
    /// and within a tab sources are grouped into one foldout per value type. Plain IMGUI, matching
    /// ReflectedValueSourceEditorWindow in this same folder.
    /// </summary>
    public class ReflectedValuesWindow : EditorWindow
    {
        static readonly ReflectedSourceScope[] Scopes = { ReflectedSourceScope.Scene, ReflectedSourceScope.Other };

        string search = string.Empty;
        Vector2 scrollPosition;
        ReflectedSourceScope activeScope = ReflectedSourceScope.Scene;
        List<ReflectedSourceEntry> allSources = new();

        readonly Dictionary<string, bool> expandedGroups = new();

        ReflectedSourceRowDrawer rowDrawer;

        [MenuItem("WiDiD_API/Reflection/Reflected Values Overview")]
        public static void ShowWindow()
        {
            ReflectedValuesWindow window = GetWindow<ReflectedValuesWindow>();
            window.titleContent = new GUIContent("Reflected Values");
            window.minSize = new Vector2(620, 400);
            window.Refresh();
        }

        void OnEnable() => Refresh();

        void OnDisable() => RowDrawer.Clear();

        // Rebuilt on demand rather than in a field initializer, which can't hand rows the window's
        // own Refresh - a row deleting its asset invalidates the whole listing.
        ReflectedSourceRowDrawer RowDrawer => rowDrawer ??= new ReflectedSourceRowDrawer(Refresh);

        void Refresh()
        {
            RowDrawer.Clear();
            allSources = ReflectedSourceCollector.Collect();
            Repaint();
        }

        void OnGUI()
        {
            DrawToolbar();

            // An asset deleted from anywhere else in the editor leaves a destroyed entry behind
            // until the next Refresh - drawing one would throw, so they're dropped here.
            List<ReflectedSourceEntry> live = allSources.Where(entry => entry.Asset != null).ToList();
            List<ReflectedSourceEntry> matches = live.Where(MatchesSearch).ToList();
            DrawTabs(matches);

            List<ReflectedSourceEntry> visible = matches.Where(entry => entry.Scope == activeScope).ToList();
            EditorGUILayout.LabelField($"{visible.Count} of {live.Count} reflected value source(s)", EditorStyles.miniLabel);

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

            foreach (IGrouping<string, ReflectedSourceEntry> group in visible.GroupBy(entry => entry.TypeLabel).OrderBy(group => group.Key))
                DrawGroup(group);

            EditorGUILayout.EndScrollView();
        }

        void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField);

            if (GUILayout.Button("Refresh", EditorStyles.toolbarButton, GUILayout.Width(60)))
                Refresh();

            if (GUILayout.Button("New Source...", EditorStyles.toolbarButton, GUILayout.Width(90)))
                GetWindow<ReflectedValueSourceEditorWindow>("Reflected Source");

            EditorGUILayout.EndHorizontal();
        }

        void DrawTabs(List<ReflectedSourceEntry> matches)
        {
            string[] labels = Scopes.Select(scope => $"{BuildScopeLabel(scope)} ({matches.Count(entry => entry.Scope == scope)})").ToArray();
            int selected = GUILayout.Toolbar(Array.IndexOf(Scopes, activeScope), labels);
            activeScope = Scopes[selected];
        }

        void DrawGroup(IGrouping<string, ReflectedSourceEntry> group)
        {
            string key = $"{activeScope}/{group.Key}";
            if (!expandedGroups.TryGetValue(key, out bool expanded))
                expanded = true;

            expanded = EditorGUILayout.BeginFoldoutHeaderGroup(expanded, $"{group.Key} ({group.Count()})");
            expandedGroups[key] = expanded;

            if (expanded)
            {
                foreach (ReflectedSourceEntry entry in group)
                    RowDrawer.Draw(entry);
            }

            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        bool MatchesSearch(ReflectedSourceEntry entry)
        {
            if (string.IsNullOrEmpty(search))
                return true;

            return entry.Asset.name.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        static string BuildScopeLabel(ReflectedSourceScope scope) => scope == ReflectedSourceScope.Scene ? "Scene Values" : "Other Values";
    }
}
