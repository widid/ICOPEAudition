using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// The kebab strip down the left edge of a ReflectedValuesWindow row - the whole strip is the
    /// button, drawn over the row's full height with the icon centered, so every per-row action
    /// (rebind, ping the asset, ping its live target, load its cached scene, delete it) stays one
    /// click away
    /// without any of them taking up room on the line. An action whose precondition isn't met is
    /// listed disabled rather than hidden, so a row never silently loses an entry.
    /// </summary>
    public static class ReflectedSourceRowActions
    {
        public const float StripWidth = 22f;

        static GUIStyle stripStyle;

        public static void Draw(Rect area, ReflectedSourceEntry entry, TrackableId target, MissingTargetInfo info, Action onDeleted)
        {
            // Captured while the row is still being drawn: a GenericMenu callback runs outside
            // OnGUI, where Event.current no longer carries a usable mouse position.
            Vector2 screenPosition = GUIUtility.GUIToScreenPoint(area.center);

            if (GUI.Button(area, EditorGUIUtility.IconContent("_Menu"), StripStyle))
                BuildMenu(entry, target, info, screenPosition, onDeleted).DropDown(area);
        }

        static GenericMenu BuildMenu(ReflectedSourceEntry entry, TrackableId target, MissingTargetInfo info, Vector2 screenPosition, Action onDeleted)
        {
            GenericMenu menu = new();

            menu.AddItem(new GUIContent("Edit Binding..."), false, () => ReflectedRebindWindow.Open(entry.Asset, screenPosition));
            menu.AddSeparator(string.Empty);
            menu.AddItem(new GUIContent("Ping Asset"), false, () => Ping(entry.Asset));

            if (target != null)
                menu.AddItem(new GUIContent("Ping Target"), false, () => Ping(target.gameObject));
            else
                menu.AddDisabledItem(new GUIContent("Ping Target"));

            if (info.CanLoadScene)
                menu.AddItem(new GUIContent($"Load Scene '{info.SceneName}'"), false, () => EditorSceneManager.OpenScene(info.ScenePath, OpenSceneMode.Additive));
            else
                menu.AddDisabledItem(new GUIContent("Load Scene"));

            menu.AddSeparator(string.Empty);
            menu.AddItem(new GUIContent("Delete Source"), false, () => Delete(entry.Asset, onDeleted));

            return menu;
        }

        // Trashed rather than deleted outright, so a source removed by a stray click on a list row
        // is still recoverable - anything referencing it only loses its value.
        static void Delete(ScriptableObject asset, Action onDeleted)
        {
            string assetPath = AssetDatabase.GetAssetPath(asset);
            string message = $"Move '{asset.name}' to the trash?" + Environment.NewLine + Environment.NewLine + assetPath + Environment.NewLine + Environment.NewLine + "Anything still bound to it will stop resolving.";

            if (!EditorUtility.DisplayDialog("Delete Reflected Source", message, "Delete", "Cancel"))
                return;

            if (AssetDatabase.MoveAssetToTrash(assetPath))
                onDeleted?.Invoke();
        }

        static void Ping(UnityEngine.Object target)
        {
            Selection.activeObject = target;
            EditorGUIUtility.PingObject(target);
        }

        // iconButton sizes itself to a single icon - cleared here so the style can back the whole
        // strip and still center what it draws.
        static GUIStyle StripStyle => stripStyle ??= new GUIStyle(EditorStyles.iconButton)
        {
            alignment = TextAnchor.MiddleCenter,
            fixedWidth = 0f,
            fixedHeight = 0f,
            stretchWidth = true,
            stretchHeight = true
        };
    }
}
