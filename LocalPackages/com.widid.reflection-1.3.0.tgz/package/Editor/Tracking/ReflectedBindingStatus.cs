using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// The bound/unbound stripe down the very left edge of a ReflectedValuesWindow row - green
    /// once the source has something to read from right now, red while it hasn't, so a broken or
    /// stale binding stands out in a long list before reading a single path. Hovering it says
    /// which; the row's own warning says why when it's red.
    /// </summary>
    public static class ReflectedBindingStatus
    {
        public const float StripeWidth = 4f;

        static readonly Color BoundColor = new(0.30f, 0.72f, 0.42f);
        static readonly Color UnboundColor = new(0.83f, 0.27f, 0.27f);

        static readonly GUIContent BoundTooltip = new(string.Empty, "Bound - this source resolves right now.");
        static readonly GUIContent UnboundTooltip = new(string.Empty, "Unbound - nothing resolves for this source right now.");

        // An asset-bound source resolves by direct reference; a scene-bound one only while its
        // TrackableId is actually found in an open scene (see ReflectedSourcePathUtility).
        public static bool IsBound(ReflectedValueSourceData data, TrackableId target) => data.DirectAsset != null || target != null;

        public static void DrawStripe(Rect area, bool bound)
        {
            EditorGUI.DrawRect(area, bound ? BoundColor : UnboundColor);
            GUI.Label(area, bound ? BoundTooltip : UnboundTooltip, GUIStyle.none);
        }
    }
}
