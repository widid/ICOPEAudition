using UnityEditor;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    [CustomEditor(typeof(ReflectedIntSourceSO))]
    public class ReflectedIntSourceSOEditor : ReflectedValueSourceEditorBase<int>
    {
        protected override void DrawValueField(int value) => EditorGUILayout.IntField("Current Value", value);
    }
}
