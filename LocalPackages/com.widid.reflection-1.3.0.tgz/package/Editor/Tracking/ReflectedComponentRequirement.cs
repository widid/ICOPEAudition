using System;
using UnityEditor;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// The "can this target actually be bound" check every component-bound source shares - one
    /// that invokes an interface on the component itself (ReflectedAttachmentSourceSO through
    /// IAttachmentProvider) rather than reading a member. Used by both the creation window and the
    /// rebind section so neither can produce a source pointing at something with nothing to invoke,
    /// and so both say the same thing when it can't.
    /// </summary>
    public static class ReflectedComponentRequirement
    {
        public static bool Draw(Type requiredComponentType, UnityEngine.Object reflectionTarget)
        {
            if (!requiredComponentType.IsInstanceOfType(reflectionTarget))
            {
                EditorGUILayout.HelpBox($"Nothing on this target implements {requiredComponentType.Name} - it has nothing for this source to invoke.", MessageType.Warning);
                return false;
            }

            EditorGUILayout.HelpBox($"Binds to the selected component itself, through {requiredComponentType.Name} - no member to pick.", MessageType.Info);
            return true;
        }
    }
}
