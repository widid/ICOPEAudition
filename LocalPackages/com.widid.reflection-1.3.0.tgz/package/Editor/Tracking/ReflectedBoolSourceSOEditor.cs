using UnityEditor;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    [CustomEditor(typeof(ReflectedBoolSourceSO))]
    public class ReflectedBoolSourceSOEditor : ReflectedValueSourceEditorBase<bool>
    {
        protected override void DrawValueField(bool value) => EditorGUILayout.Toggle("Current Value", value);
    }
}
