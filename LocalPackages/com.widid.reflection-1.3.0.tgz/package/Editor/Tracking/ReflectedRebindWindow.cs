using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Floating "Edit Binding" editor opened from a ReflectedValuesWindow row's kebab menu, so a
    /// source can be repointed without the overview itself carrying a rebind form on every line.
    /// Hosts the same ReflectedRebindSection every source's inspector uses - in its bodyless form,
    /// since this window is already dedicated to the one job - and closes itself as soon as the
    /// new binding is applied.
    /// </summary>
    public class ReflectedRebindWindow : EditorWindow
    {
        static readonly Vector2 WindowSize = new(360f, 150f);

        [SerializeField] ScriptableObject asset;

        ReflectedValueSourceData data;
        ReflectedRebindSection section;
        bool initialized;

        public static void Open(ScriptableObject asset, Vector2 screenPosition)
        {
            ReflectedRebindWindow window = CreateInstance<ReflectedRebindWindow>();
            window.titleContent = new GUIContent("Edit Binding");
            window.asset = asset;
            window.position = new Rect(screenPosition, WindowSize);
            window.ShowUtility();
        }

        void OnGUI()
        {
            if (asset == null)
            {
                Close();
                return;
            }

            // Re-resolved rather than serialized: neither the data reference nor the section's
            // in-progress pick survive a domain reload, so both are rebuilt from the asset.
            EnsureInitialized();

            EditorGUILayout.LabelField(asset.name, EditorStyles.boldLabel);
            EditorGUILayout.LabelField(ReflectedSourcePathUtility.BuildFriendlyPath(data, ReflectedSourcePathUtility.FindTrackable(data.TargetGuid)), EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space();

            if (section == null)
            {
                EditorGUILayout.HelpBox("This source type exposes no value to rebind against.", MessageType.Info);
                return;
            }

            if (section.DrawBody(asset, data))
                Close();
        }

        void EnsureInitialized()
        {
            if (initialized)
                return;

            initialized = true;
            data = ((IReflectedValueSource)asset).Data;
            section = ReflectedRebindSectionFactory.Create(asset);
        }
    }
}
