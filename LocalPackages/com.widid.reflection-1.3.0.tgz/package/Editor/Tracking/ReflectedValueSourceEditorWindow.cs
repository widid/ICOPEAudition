using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// No-code authoring tool for any IReflectedValueSource: drag in any object - a ScriptableObject
    /// (or other plain asset) reflects its own members directly, same as always; a GameObject or
    /// Component exposes a Component picker first (defaulting to whichever one was actually
    /// dragged), since a scene object can have several components worth reflecting from - then pick
    /// a value type and member, and this saves the resulting source asset. The target script itself
    /// is never touched.
    /// </summary>
    public class ReflectedValueSourceEditorWindow : EditorWindow
    {
        enum ValueType { Float, Int, String, Bool, Attachment }

        static Type SourceTypeFor(ValueType valueType) => valueType switch
        {
            ValueType.Float => typeof(ReflectedFloatSourceSO),
            ValueType.Int => typeof(ReflectedIntSourceSO),
            ValueType.String => typeof(ReflectedStringSourceSO),
            ValueType.Bool => typeof(ReflectedBoolSourceSO),
            ValueType.Attachment => typeof(ReflectedAttachmentSourceSO),
            _ => throw new ArgumentOutOfRangeException(nameof(valueType))
        };

        // Meaningless for Attachment - it invokes IAttachmentProvider.Capture() on the picked
        // component rather than reflecting a member of a matching type - callers must check
        // RequiresMemberPath first instead of calling this for Attachment.
        static Type MemberTypeFor(ValueType valueType) => valueType switch
        {
            ValueType.Float => typeof(float),
            ValueType.Int => typeof(int),
            ValueType.String => typeof(string),
            ValueType.Bool => typeof(bool),
            _ => throw new ArgumentOutOfRangeException(nameof(valueType))
        };

        // Non-null for a value type that binds to a component itself rather than reading a member -
        // the interface that component is invoked through. Single source of truth for the split:
        // RequiresMemberPath is just its inverse.
        static Type RequiredComponentTypeFor(ValueType valueType) => valueType == ValueType.Attachment ? typeof(IAttachmentProvider) : null;

        static bool RequiresMemberPath(ValueType valueType) => RequiredComponentTypeFor(valueType) == null;

        ValueType valueType;
        bool valueTypeLocked;
        Action<ScriptableObject> onCreated;
        UnityEngine.Object target;
        Component[] availableComponents = Array.Empty<Component>();
        int selectedComponentIndex;
        string[] paths = Array.Empty<string>();
        int selectedPathIndex;

        [MenuItem("WiDiD_API/Reflection/New Reflected Source...")]
        static void Open()
        {
            ReflectedValueSourceEditorWindow window = GetWindow<ReflectedValueSourceEditorWindow>("Reflected Source");
            window.valueTypeLocked = false;
            window.onCreated = null;
        }

        // Opens with the value type fixed to sourceType's; onCreated receives the saved asset.
        public static void OpenFor(Type sourceType, Action<ScriptableObject> onCreated)
        {
            ReflectedValueSourceEditorWindow window = GetWindow<ReflectedValueSourceEditorWindow>(true, "Reflected Source");
            window.valueType = ValueTypeFor(sourceType);
            window.valueTypeLocked = true;
            window.onCreated = onCreated;
            window.RefreshComponents();
        }

        static ValueType ValueTypeFor(Type sourceType)
        {
            foreach (ValueType candidate in Enum.GetValues(typeof(ValueType)))
            {
                if (SourceTypeFor(candidate) == sourceType)
                    return candidate;
            }

            throw new ArgumentOutOfRangeException(nameof(sourceType), $"No value type creates {sourceType.Name}.");
        }

        void OnGUI()
        {
            EditorGUILayout.HelpBox("Pick a value type, drag any object - a ScriptableObject reflects itself directly; a GameObject/Component lets you pick which component to reflect from - then pick which member it should report, and create the source asset.", MessageType.Info);

            ValueType newValueType;
            using (new EditorGUI.DisabledScope(valueTypeLocked))
                newValueType = (ValueType)EditorGUILayout.EnumPopup("Value Type", valueType);

            if (newValueType != valueType)
            {
                valueType = newValueType;

                // Components, not just paths: which ones are offered depends on the value type -
                // an Attachment only lists the ones it can actually invoke.
                RefreshComponents();
            }

            UnityEngine.Object newTarget = EditorGUILayout.ObjectField("Target", target, typeof(UnityEngine.Object), true);
            if (newTarget != target)
            {
                target = newTarget;
                RefreshComponents();
            }

            if (target == null)
                return;

            if (availableComponents.Length > 1)
            {
                string[] componentNames = availableComponents.Select(component => component.GetType().Name).ToArray();
                int newComponentIndex = EditorGUILayout.Popup("Component", selectedComponentIndex, componentNames);
                if (newComponentIndex != selectedComponentIndex)
                {
                    selectedComponentIndex = newComponentIndex;
                    RefreshPaths();
                }
            }

            if (RequiresMemberPath(valueType))
            {
                if (paths.Length == 0)
                {
                    EditorGUILayout.HelpBox($"No {valueType} fields or properties found on this target.", MessageType.Warning);
                    return;
                }

                selectedPathIndex = EditorGUILayout.Popup("Member", selectedPathIndex, paths);
            }
            else if (!ReflectedComponentRequirement.Draw(RequiredComponentTypeFor(valueType), ResolveReflectionTarget()))
            {
                return;
            }

            if (GUILayout.Button("Create Source Asset"))
                CreateSourceAsset(ResolveReflectionTarget(), RequiresMemberPath(valueType) ? paths[selectedPathIndex] : string.Empty);
        }

        // Populates the Component picker for a GameObject/Component target (empty for a
        // ScriptableObject or other plain asset - nothing to pick between), pre-selecting whichever
        // component was actually dragged in.
        void RefreshComponents()
        {
            availableComponents = ReflectedTargetPicker.ComputeAvailableComponents(target, RequiredComponentTypeFor(valueType));
            selectedComponentIndex = ReflectedTargetPicker.ResolvePreselectedIndex(target, availableComponents);
            RefreshPaths();
        }

        UnityEngine.Object ResolveReflectionTarget() => ReflectedTargetPicker.ResolveReflectionTarget(target, availableComponents, selectedComponentIndex);

        void RefreshPaths()
        {
            UnityEngine.Object reflectionTarget = target != null ? ResolveReflectionTarget() : null;
            paths = reflectionTarget != null && RequiresMemberPath(valueType) ? ReflectionPathUtility.GetMemberPaths(reflectionTarget, MemberTypeFor(valueType)) : Array.Empty<string>();
            selectedPathIndex = 0;
        }

        void CreateSourceAsset(UnityEngine.Object reflectionTarget, string path)
        {
            ScriptableObject source = ReflectedValueSourceFactory.CreateAsset(SourceTypeFor(valueType), reflectionTarget, path);

            // Null means the save dialog was cancelled - nothing was created, so the window stays
            // open with the pick intact.
            if (source == null)
                return;

            if (onCreated != null)
                onCreated(source);
            else
                Selection.activeObject = source;

            EditorGUIUtility.PingObject(source);

            Close();
            GUIUtility.ExitGUI();
        }
    }
}
