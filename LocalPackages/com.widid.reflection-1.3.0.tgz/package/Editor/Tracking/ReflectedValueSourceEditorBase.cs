using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Shared debug view for any IReflectedValueSource - Value is never cached (see
    /// ReflectedValueResolver), so this just re-reads and displays it on demand, useful to confirm a
    /// binding resolves correctly during Play mode without wiring up any runtime UI. Concrete
    /// editors (ReflectedFloatSourceSOEditor etc.) only need to say how to draw their own value type.
    /// Also exposes the shared "Edit Binding" section (see ReflectedRebindSection), so an existing
    /// source's target can be repointed without recreating the asset.
    /// </summary>
    public abstract class ReflectedValueSourceEditorBase<T> : Editor
    {
        readonly ReflectedRebindSection rebind = ReflectedRebindSection.ForMember(typeof(T));

        bool showRawData;

        public override void OnInspectorGUI()
        {
            IReflectedValueSource source = (IReflectedValueSource)target;
            ReflectedValueSourceData data = source.Data;
            TrackableId trackedTarget = ReflectedSourcePathUtility.FindTrackable(data.TargetGuid);

            ReflectedSourcePathUtility.CacheLastKnownLocation((UnityEngine.Object)source, data, trackedTarget);

            EditorGUILayout.LabelField("Tracked Path", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(ReflectedSourcePathUtility.BuildFriendlyPath(data, trackedTarget), EditorStyles.wordWrappedLabel);
            ReflectedSourcePathUtility.DrawMissingTargetWarning(data, trackedTarget);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Debug", EditorStyles.boldLabel);

            // Resolved from whatever TrackableId is currently found in open scenes rather than the
            // source's own Value (which goes through TrackableRegistry) - the registry is only
            // populated by TrackableId.Awake(), so it's always empty outside Play mode and Value
            // would just read as default(T) in the editor even with a valid binding.
            T value = ReflectedValueResolver.ResolveFrom<T>(trackedTarget, data);
            using (new EditorGUI.DisabledScope(true))
                DrawValueField(value);
            if (GUILayout.Button("Refresh"))
                Repaint();

            EditorGUILayout.Space();
            rebind.Draw(target, data);

            EditorGUILayout.Space();
            showRawData = EditorGUILayout.Foldout(showRawData, "Raw Data", true);
            if (showRawData)
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.TextField("Target Guid", data.TargetGuid);
                    EditorGUILayout.TextField("Component Type", data.ComponentTypeName);
                    EditorGUILayout.TextField("Member Path", data.MemberPath);
                    EditorGUILayout.ObjectField("Direct Asset", data.DirectAsset, typeof(UnityEngine.Object), false);
                }
            }
        }

        protected abstract void DrawValueField(T value);
    }
}
