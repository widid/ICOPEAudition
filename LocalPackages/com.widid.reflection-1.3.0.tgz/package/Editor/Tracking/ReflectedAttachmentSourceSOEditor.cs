using System;
using UnityEditor;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// Custom inspector for ReflectedAttachmentSourceSO - can't reuse ReflectedValueSourceEditorBase&lt;T&gt;
    /// since that assumes a passive member-path read; this instead offers an explicit "Capture
    /// Preview" button (Capture() renders/encodes real bytes, not something to redo on every
    /// repaint) that renders the resulting image and reports its size. The "Edit Binding" section is
    /// the shared one every other source shows (see ReflectedRebindSection), in its component mode -
    /// an attachment binds to the IAttachmentProvider component itself, with no member to pick.
    /// </summary>
    [CustomEditor(typeof(ReflectedAttachmentSourceSO))]
    public class ReflectedAttachmentSourceSOEditor : Editor
    {
        readonly ReflectedRebindSection rebind = ReflectedRebindSection.ForComponent(typeof(IAttachmentProvider));

        Texture2D previewTexture;
        string previewSummary = string.Empty;

        public override void OnInspectorGUI()
        {
            ReflectedAttachmentSourceSO source = (ReflectedAttachmentSourceSO)target;
            ReflectedValueSourceData data = source.Data;
            TrackableId trackedTarget = ReflectedSourcePathUtility.FindTrackable(data.TargetGuid);

            ReflectedSourcePathUtility.CacheLastKnownLocation(source, data, trackedTarget);

            EditorGUILayout.LabelField("Tracked Path", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(ReflectedSourcePathUtility.BuildFriendlyPath(data, trackedTarget), EditorStyles.wordWrappedLabel);
            ReflectedSourcePathUtility.DrawMissingTargetWarning(data, trackedTarget);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Debug", EditorStyles.boldLabel);

            // Nothing to capture when the tracked target isn't resolvable right now - either
            // unbound, or its scene isn't currently open (see ReflectedSourcePathUtility.
            // BuildFriendlyPath's distinction) - Capture() would just fail anyway.
            using (new EditorGUI.DisabledScope(trackedTarget == null))
            {
                if (GUILayout.Button("Capture Preview"))
                    RefreshPreview(trackedTarget, data);
            }

            if (previewTexture != null)
            {
                EditorGUILayout.LabelField(previewSummary);
                Rect previewRect = GUILayoutUtility.GetAspectRect((float)previewTexture.width / previewTexture.height, GUILayout.MaxHeight(200));
                EditorGUI.DrawPreviewTexture(previewRect, previewTexture);
            }

            EditorGUILayout.Space();
            rebind.Draw(source, data);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Raw Data", EditorStyles.boldLabel);
            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.TextField("Target Guid", data.TargetGuid);
                EditorGUILayout.TextField("Component Type", data.ComponentTypeName);
            }
        }

        void RefreshPreview(TrackableId trackedTarget, ReflectedValueSourceData data)
        {
            AttachmentCapture? capture;
            try
            {
                capture = ReflectedAttachmentResolver.CaptureFrom(trackedTarget, data);
            }
            catch (Exception exception)
            {
                if (previewTexture != null)
                    DestroyImmediate(previewTexture);

                previewTexture = null;
                previewSummary = $"Capture threw: {exception.Message}";
                Debug.LogException(exception);
                return;
            }

            if (previewTexture != null)
                DestroyImmediate(previewTexture);

            if (capture == null)
            {
                previewTexture = null;
                previewSummary = "Capture failed - is the tracked target found in an open scene and does it implement IAttachmentProvider?";
                return;
            }

            // LoadImage only decodes PNG/JPG - a Tga-formatted capture still reports its size below,
            // it just can't be shown as a preview thumbnail.
            previewTexture = new Texture2D(2, 2);
            if (!previewTexture.LoadImage(capture.Value.Bytes))
            {
                DestroyImmediate(previewTexture);
                previewTexture = null;
            }

            previewSummary = $"{capture.Value.ContentType}, {capture.Value.Bytes.Length:N0} bytes";
        }

        void OnDisable()
        {
            if (previewTexture != null)
                DestroyImmediate(previewTexture);
        }
    }
}
