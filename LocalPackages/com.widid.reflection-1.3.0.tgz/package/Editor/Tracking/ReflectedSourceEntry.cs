using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.Reflection.Editors
{
    /// <summary>
    /// One IReflectedValueSource asset as listed by ReflectedValuesWindow, paired with the type
    /// foldout it sorts into. Scope is read off the binding on every access rather than captured
    /// once, so a source rebound from within the window moves to the matching tab immediately.
    /// </summary>
    public class ReflectedSourceEntry
    {
        public ScriptableObject Asset { get; }
        public ReflectedValueSourceData Data { get; }
        public string TypeLabel { get; }

        public ReflectedSourceEntry(ScriptableObject asset, IReflectedValueSource source)
        {
            Asset = asset;
            Data = source.Data;
            TypeLabel = BuildTypeLabel(asset);
        }

        public ReflectedSourceScope Scope => Data.DirectAsset == null && !string.IsNullOrEmpty(Data.TargetGuid) ? ReflectedSourceScope.Scene : ReflectedSourceScope.Other;

        // "ReflectedFloatSourceSO" -> "Float" - same stripping convention as
        // ReflectedValueSourceFactory.BuildDefaultAssetName, so a new family's foldout just works.
        static string BuildTypeLabel(ScriptableObject asset) => asset.GetType().Name.Replace("Reflected", string.Empty).Replace("SourceSO", string.Empty);
    }
}
