using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Networking.Authentification;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Editor
{
    /// <summary>
    /// Editor-only tool to authenticate against the Immersive backend, by mail + password or by
    /// code, and fill the real <see cref="UserSessionSO"/> with the result - which Training to
    /// target is set separately, via TrainingEditorWindow's "Set Active" button
    /// (WiDiD.ImmersiveAPI.Editor.Trainings), not here. Self-contained (own UXML/USS, hardcoded
    /// Dev/Prod URLs) so it can be copied into another project along with the rest of the
    /// ImmersiveAPI package without extra setup: when no asset exists at
    /// Resources/<see cref="UserSessionSO.ResourcePath"/> the window offers to create one rather
    /// than reporting a dead end.
    /// </summary>
    public class ImmersiveDebugSessionWindow : EditorWindow
    {
        const string DevUrl = "https://widid-new.dev2.dev-id.fr/api/v1/";
        const string ProdUrl = "https://widid-immersive.fr/api/v1/";
        const string ActiveTabClass = "wid-catalog-tab-button-active";
        const string InputErrorClass = "wid-input-error";
        const int ErrorFeedbackDurationMs = 2000;

        VisualElement missingAssetPanel;
        VisualElement loginPanel;
        VisualElement userInfoPanel;
        VisualElement mailPasswordTab;
        VisualElement codeTab;
        Button mailPasswordTabButton;
        Button codeTabButton;
        Label missingAssetLabel;
        DropdownField targetUrlDropdown;
        TextField emailField;
        TextField passwordField;
        TextField codeField;
        Label statusLabel;
        Label nameLabel;
        Label emailLabel;
        Label rolesLabel;
        Label environmentLabel;
        Label tokenLabel;

        IAuthentificationService authentificationService;
        IUserService userService;
        DebugSessionStore sessionStore;

        [MenuItem("WiDiD_API/ImmersiveAPI/Debug Session")]
        public static void ShowWindow()
        {
            ImmersiveDebugSessionWindow window = GetWindow<ImmersiveDebugSessionWindow>();
            window.titleContent = new GUIContent("Immersive Debug Session");
            window.minSize = new Vector2(360, 300);
        }

        public void CreateGUI()
        {
            userService = new UserService();
            authentificationService = new AuthentificationService(new ImmersiveLogger(), userService);
            sessionStore = new DebugSessionStore();

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.ImmersiveDebugSessionWindow;
            visualTree.CloneTree(rootVisualElement);

            rootVisualElement.Q<Image>("LogoImage").image = ImmersiveEditorUIConfigLoader.Assets.Logo;

            missingAssetPanel = rootVisualElement.Q<VisualElement>("MissingAssetPanel");
            loginPanel = rootVisualElement.Q<VisualElement>("LoginPanel");
            userInfoPanel = rootVisualElement.Q<VisualElement>("UserInfoPanel");
            mailPasswordTab = rootVisualElement.Q<VisualElement>("MailPasswordTab");
            codeTab = rootVisualElement.Q<VisualElement>("CodeTab");
            mailPasswordTabButton = rootVisualElement.Q<Button>("ButtonTabMailPassword");
            codeTabButton = rootVisualElement.Q<Button>("ButtonTabCode");
            missingAssetLabel = rootVisualElement.Q<Label>("LabelMissingAsset");
            targetUrlDropdown = rootVisualElement.Q<DropdownField>("DropdownTargetUrl");
            emailField = rootVisualElement.Q<TextField>("TextFieldEmail");
            passwordField = rootVisualElement.Q<TextField>("TextFieldPassword");
            codeField = rootVisualElement.Q<TextField>("TextFieldCode");
            statusLabel = rootVisualElement.Q<Label>("LabelStatus");
            nameLabel = rootVisualElement.Q<Label>("LabelNameValue");
            emailLabel = rootVisualElement.Q<Label>("LabelEmailValue");
            rolesLabel = rootVisualElement.Q<Label>("LabelRolesValue");
            environmentLabel = rootVisualElement.Q<Label>("LabelEnvironmentValue");
            tokenLabel = rootVisualElement.Q<Label>("LabelTokenValue");

            targetUrlDropdown.choices = new List<string> { "Prod", "Dev" };
            targetUrlDropdown.index = 0;

            mailPasswordTabButton.clicked += () => SelectTab(isCodeTab: false);
            codeTabButton.clicked += () => SelectTab(isCodeTab: true);
            rootVisualElement.Q<Button>("ButtonLogIn").clicked += OnMailPasswordLoginClicked;
            rootVisualElement.Q<Button>("ButtonLogInCode").clicked += OnCodeLoginClicked;
            rootVisualElement.Q<Button>("ButtonLogOut").clicked += OnLogOutClicked;
            rootVisualElement.Q<Button>("ButtonCreateSessionAsset").clicked += OnCreateSessionAssetClicked;

            SelectTab(isCodeTab: false);
            RestoreSessionDisplay();
        }

        void OnFocus()
        {
            if (sessionStore != null)
                RestoreSessionDisplay();
        }

        void SelectTab(bool isCodeTab)
        {
            mailPasswordTab.style.display = isCodeTab ? DisplayStyle.None : DisplayStyle.Flex;
            codeTab.style.display = isCodeTab ? DisplayStyle.Flex : DisplayStyle.None;
            mailPasswordTabButton.EnableInClassList(ActiveTabClass, !isCodeTab);
            codeTabButton.EnableInClassList(ActiveTabClass, isCodeTab);
            statusLabel.text = string.Empty;
        }

        void OnMailPasswordLoginClicked()
        {
            string email = emailField.value;
            string password = passwordField.value;

            SignIn(url =>
            {
                authentificationService.ValidateMail(email);
                return authentificationService.Login(email, password, url);
            }, emailField, passwordField);
        }

        void OnCodeLoginClicked()
        {
            string code = codeField.value;

            SignIn(url => authentificationService.LoginWithCode(code, url), codeField);
        }

        async void SignIn(Func<string, Task> login, params TextField[] inputFields)
        {
            if (!RequireSessionAsset())
                return;

            string url = targetUrlDropdown.value == "Dev" ? DevUrl : ProdUrl;
            statusLabel.text = "Signing in...";

            try
            {
                await login(url);

                UserProfile profile = userService.GetUserProfile();
                if (profile == null)
                    throw new UserNotFoundException();

                sessionStore.SignIn(profile, url);
                ClearCredentialFields();
                ShowUserInfoPanel();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[ImmersiveDebugSessionWindow] Login failed: {exception.Message}");
                ShowLoginError(exception.Message, inputFields);
            }
        }

        void OnLogOutClicked()
        {
            if (!RequireSessionAsset())
                return;

            sessionStore.SignOut();
            ClearCredentialFields();
            ShowLoginPanel();
        }

        /// <summary>
        /// Guards everything that writes to the asset, which can be deleted while this window is open.
        /// </summary>
        bool RequireSessionAsset()
        {
            if (sessionStore.HasAsset)
                return true;

            ShowMissingAssetPanel();
            return false;
        }

        void OnCreateSessionAssetClicked()
        {
            sessionStore.CreateAsset();
            RestoreSessionDisplay();
        }

        void RestoreSessionDisplay()
        {
            if (!RequireSessionAsset())
                return;

            if (sessionStore.IsSignedIn)
                ShowUserInfoPanel();
            else
                ShowLoginPanel();
        }

        void ShowMissingAssetPanel()
        {
            missingAssetPanel.style.display = DisplayStyle.Flex;
            loginPanel.style.display = DisplayStyle.None;
            userInfoPanel.style.display = DisplayStyle.None;

            missingAssetLabel.text = $"No UserSessionSO at Resources/{UserSessionSO.ResourcePath}. "
                                   + "One is needed to hold a debug session.";
        }

        void ShowLoginPanel()
        {
            missingAssetPanel.style.display = DisplayStyle.None;
            loginPanel.style.display = DisplayStyle.Flex;
            userInfoPanel.style.display = DisplayStyle.None;
        }

        void ShowUserInfoPanel()
        {
            missingAssetPanel.style.display = DisplayStyle.None;
            loginPanel.style.display = DisplayStyle.None;
            userInfoPanel.style.display = DisplayStyle.Flex;
            statusLabel.text = string.Empty;

            UserSessionData data = sessionStore.Data;
            ProfileInfo info = data.UserProfile.Info;
            nameLabel.text = $"{info.FirstName} {info.LastName}".Trim();
            emailLabel.text = info.Email;
            rolesLabel.text = info.Roles != null ? string.Join(", ", info.Roles) : string.Empty;
            environmentLabel.text = GetEnvironmentName(data.TargetUrl);
            tokenLabel.text = MaskToken(data.DecodedToken);
        }

        void ShowLoginError(string message, TextField[] inputFields)
        {
            statusLabel.text = message;
            passwordField.value = string.Empty;

            foreach (TextField field in inputFields)
                field.AddToClassList(InputErrorClass);

            rootVisualElement.schedule.Execute(() =>
            {
                foreach (TextField field in inputFields)
                    field.RemoveFromClassList(InputErrorClass);
            }).ExecuteLater(ErrorFeedbackDurationMs);
        }

        void ClearCredentialFields()
        {
            passwordField.value = string.Empty;
            codeField.value = string.Empty;
        }

        static string GetEnvironmentName(string url)
        {
            if (url == DevUrl)
                return "Dev";

            return url == ProdUrl ? "Prod" : url;
        }

        static string MaskToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                return string.Empty;

            return token.Length > 8 ? token.Substring(0, 8) + "..." : "...";
        }
    }
}
