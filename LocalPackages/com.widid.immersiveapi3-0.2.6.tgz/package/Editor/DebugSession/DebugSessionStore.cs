using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Editor
{
    /// <summary>
    /// Reads and writes the debug session held by the <see cref="UserSessionSO"/> at
    /// Resources/<see cref="UserSessionSO.ResourcePath"/>, saving it to disk on every change.
    /// </summary>
    public class DebugSessionStore
    {
        const string DebugSessionMode = "Online";

        UserSessionSO sessionAsset;

        public bool HasAsset => Asset != null;
        public bool IsSignedIn => HasAsset && !sessionAsset.Data.IsEmpty;
        public UserSessionData Data => sessionAsset.Data;

        UserSessionSO Asset
        {
            get
            {
                if (sessionAsset == null)
                    sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);

                return sessionAsset;
            }
        }

        public void CreateAsset()
        {
            sessionAsset = (UserSessionSO)ImmersiveResourceAsset.EnsureExists(typeof(UserSessionSO), UserSessionSO.ResourcePath);
            EditorGUIUtility.PingObject(sessionAsset);
        }

        public void SignIn(UserProfile profile, string url)
        {
            UserSessionData data = sessionAsset.Data;
            data.UserProfile = profile;
            data.DecodedToken = profile.Token;
            data.UserId = profile.Info.Id.ToString();
            data.TargetUrl = url;
            data.Mode = DebugSessionMode;
            Save();
        }

        public void SignOut()
        {
            sessionAsset.Data.Empty();
            Save();
        }

        void Save()
        {
            EditorUtility.SetDirty(sessionAsset);
            AssetDatabase.SaveAssetIfDirty(sessionAsset);
        }
    }
}
