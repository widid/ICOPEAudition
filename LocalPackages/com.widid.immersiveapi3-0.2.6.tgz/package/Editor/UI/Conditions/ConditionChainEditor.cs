using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.UI
{
    /// <summary>
    /// Shared, self-contained Editor UI for authoring any ConditionChain - clone-and-wire
    /// ConditionEntry.uxml per entry (same idiom as PerformanceEntry.uxml/InteractionEntry.uxml),
    /// plus "+ Add Condition"/"+ Add Group" buttons. Callers (PerformanceEditorWindow,
    /// InteractionEditorWindow, any future one) just call Bind() into an empty VisualElement - no
    /// knowledge of Condition/ConditionChain's own fields required, so a ConditionChain field is a
    /// one-line drop-in wherever a general-purpose authored bool is useful. A group entry (see
    /// ConditionChainEntry.IsGroup) recurses back into Bind() for its own nested chain, so
    /// parenthesized expressions like "(x AND y) OR a OR b" nest to any depth.
    /// </summary>
    public static class ConditionChainEditor
    {
        static readonly string[] NumericOperatorChoices = { "Equals", "NotEquals", "GreaterThan", "GreaterOrEqual", "LessThan", "LessOrEqual" };
        static readonly string[] EqualityOperatorChoices = { "Equals", "NotEquals" };
        static readonly string[] ValueTypeChoices = { "Float", "Int", "String", "Bool" };
        static readonly string[] CombinatorChoices = { "And", "Or" };

        public static void Bind(VisualElement container, ConditionChain chain, UnityEngine.Object dirtyTarget, Action onChanged = null)
        {
            void Rebuild()
            {
                container.Clear();

                for (int i = 0; i < chain.Entries.Count; i++)
                    container.Add(BuildEntry(chain, i, dirtyTarget, Rebuild, onChanged));

                VisualElement addRow = new();
                addRow.AddToClassList("wid-button-center-row");

                Button addConditionButton = new(() =>
                {
                    chain.Entries.Add(new ConditionChainEntry());
                    EditorUtility.SetDirty(dirtyTarget);
                    EditorApplication.delayCall += Rebuild;
                    onChanged?.Invoke();
                })
                { text = "+ Add Condition" };
                addRow.Add(addConditionButton);

                // A group's IsGroup is set once here, at creation - never toggled afterward (see
                // ConditionChainEntry) - so there's no ambiguity for BuildEntry to resolve later.
                Button addGroupButton = new(() =>
                {
                    chain.Entries.Add(new ConditionChainEntry { IsGroup = true, Group = new ConditionChain() });
                    EditorUtility.SetDirty(dirtyTarget);
                    EditorApplication.delayCall += Rebuild;
                    onChanged?.Invoke();
                })
                { text = "+ Add Group ( )" };
                addRow.Add(addGroupButton);

                container.Add(addRow);
            }

            Rebuild();
        }

        static VisualElement BuildEntry(ConditionChain chain, int index, UnityEngine.Object dirtyTarget, Action rebuild, Action onChanged)
        {
            ConditionChainEntry entry = chain.Entries[index];

            VisualElement wrapper = ImmersiveEditorUIConfigLoader.Assets.ConditionEntry.CloneTree();

            DropdownField combinatorDropdown = wrapper.Q<DropdownField>("DropdownCombinator");
            combinatorDropdown.choices = CombinatorChoices.ToList();
            combinatorDropdown.SetValueWithoutNotify(entry.Combinator.ToString());
            combinatorDropdown.style.display = index == 0 ? DisplayStyle.None : DisplayStyle.Flex;
            combinatorDropdown.RegisterValueChangedCallback(evt =>
            {
                entry.Combinator = (LogicalOperator)Enum.Parse(typeof(LogicalOperator), evt.newValue);
                EditorUtility.SetDirty(dirtyTarget);
                onChanged?.Invoke();
            });

            Button deleteButton = wrapper.Q<Button>("ButtonDeleteCondition");
            deleteButton.clicked += () =>
            {
                chain.Entries.RemoveAt(index);
                EditorUtility.SetDirty(dirtyTarget);
                EditorApplication.delayCall += () => rebuild();
                onChanged?.Invoke();
            };

            if (entry.IsGroup)
            {
                wrapper.Q<VisualElement>("LeafRow").style.display = DisplayStyle.None;
                wrapper.Q<Label>("LabelGroup").style.display = DisplayStyle.Flex;

                VisualElement groupContainer = wrapper.Q<VisualElement>("GroupContainer");
                groupContainer.style.display = DisplayStyle.Flex;

                // Group is a managed reference (see ConditionChainEntry) and so can deserialize to
                // null; a group entry always needs a chain to author into.
                entry.Group ??= new ConditionChain();
                Bind(groupContainer, entry.Group, dirtyTarget, onChanged);

                return wrapper;
            }

            wrapper.Q<Label>("LabelGroup").style.display = DisplayStyle.None;
            wrapper.Q<VisualElement>("GroupContainer").style.display = DisplayStyle.None;

            Condition condition = entry.Condition;

            DropdownField valueTypeDropdown = wrapper.Q<DropdownField>("DropdownValueType");
            DropdownField operatorDropdown = wrapper.Q<DropdownField>("DropdownOperator");

            // Recomputes the choices list for the current ValueType and, only if the operator
            // dropdown's CURRENT value (which must already reflect condition.Operator - see call
            // order below) isn't valid for it, clamps both the display and condition.Operator
            // itself to the first valid choice - keeping data and UI in sync even across a
            // ValueType switch that invalidates a previously-valid GreaterThan/LessThan etc.
            void RefreshOperatorChoices()
            {
                // String actually supports ordinal ordering too (see Condition.CompareString), but
                // keep the dropdown to Equals/NotEquals for both String and Bool anyway - ordering a
                // string/bool comparison is rarely what's intended here.
                bool equalityOnly = condition.ValueType is ConditionValueType.String or ConditionValueType.Bool;
                operatorDropdown.choices = (equalityOnly ? EqualityOperatorChoices : NumericOperatorChoices).ToList();

                if (!operatorDropdown.choices.Contains(operatorDropdown.value))
                {
                    string fallback = operatorDropdown.choices[0];
                    operatorDropdown.SetValueWithoutNotify(fallback);
                    condition.Operator = (ComparisonOperator)Enum.Parse(typeof(ComparisonOperator), fallback);
                    EditorUtility.SetDirty(dirtyTarget);
                }
            }

            void RefreshRowVisibility()
            {
                SetRowVisible(wrapper, "OperandLeftFloat", condition.ValueType == ConditionValueType.Float);
                SetRowVisible(wrapper, "OperandLeftInt", condition.ValueType == ConditionValueType.Int);
                SetRowVisible(wrapper, "OperandLeftString", condition.ValueType == ConditionValueType.String);
                SetRowVisible(wrapper, "OperandLeftBool", condition.ValueType == ConditionValueType.Bool);

                SetRowVisible(wrapper, "OperandRightFloat", condition.ValueType == ConditionValueType.Float);
                SetRowVisible(wrapper, "OperandRightInt", condition.ValueType == ConditionValueType.Int);
                SetRowVisible(wrapper, "OperandRightString", condition.ValueType == ConditionValueType.String);
                SetRowVisible(wrapper, "OperandRightBool", condition.ValueType == ConditionValueType.Bool);
            }

            valueTypeDropdown.choices = ValueTypeChoices.ToList();
            valueTypeDropdown.SetValueWithoutNotify(condition.ValueType.ToString());
            valueTypeDropdown.RegisterValueChangedCallback(evt =>
            {
                condition.ValueType = (ConditionValueType)Enum.Parse(typeof(ConditionValueType), evt.newValue);
                EditorUtility.SetDirty(dirtyTarget);
                RefreshOperatorChoices();
                RefreshRowVisibility();
                onChanged?.Invoke();
            });

            // Set the dropdown's real current value BEFORE computing/clamping choices, so
            // RefreshOperatorChoices only overwrites condition.Operator when it's genuinely invalid
            // for the current ValueType - never merely because the dropdown hadn't been told the
            // saved value yet.
            operatorDropdown.SetValueWithoutNotify(condition.Operator.ToString());
            RefreshOperatorChoices();
            operatorDropdown.RegisterValueChangedCallback(evt =>
            {
                condition.Operator = (ComparisonOperator)Enum.Parse(typeof(ComparisonOperator), evt.newValue);
                EditorUtility.SetDirty(dirtyTarget);
                onChanged?.Invoke();
            });

            RefreshRowVisibility();

            WireFloatRow(wrapper, "LeftFloat", condition.FloatLeft, dirtyTarget, onChanged);
            WireFloatRow(wrapper, "RightFloat", condition.FloatRight, dirtyTarget, onChanged);
            WireIntRow(wrapper, "LeftInt", condition.IntLeft, dirtyTarget, onChanged);
            WireIntRow(wrapper, "RightInt", condition.IntRight, dirtyTarget, onChanged);
            WireStringRow(wrapper, "LeftString", condition.StringLeft, dirtyTarget, onChanged);
            WireStringRow(wrapper, "RightString", condition.StringRight, dirtyTarget, onChanged);
            WireBoolRow(wrapper, "LeftBool", condition.BoolLeft, dirtyTarget, onChanged);
            WireBoolRow(wrapper, "RightBool", condition.BoolRight, dirtyTarget, onChanged);

            return wrapper;
        }

        static void SetRowVisible(VisualElement root, string rowName, bool visible) => root.Q<VisualElement>(rowName).style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;

        // No Enabled toggle on any of these - a condition operand is never meaningfully "off"
        // (comparing anything needs both sides to have a value), so Enabled is just forced on here
        // and the operand is always either a fixed value or a reflected source (see
        // Condition.FloatLeft etc.'s own field initializers for the same default). The friendly
        // path, when a reflected source is picked, becomes the object field's tooltip instead of a
        // separate label row, to keep the whole condition on one line.
        static void WireFloatRow(VisualElement root, string rowKey, PerformanceValueSource source, UnityEngine.Object dirtyTarget, Action onChanged)
        {
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{rowKey}Source");
            FloatField fixedField = root.Q<FloatField>($"Field{rowKey}Fixed");

            ForceEnabled(source, dirtyTarget);
            ReflectedSourceField.Attach(objectField, typeof(ReflectedFloatSourceSO));
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh() => RefreshOperand(objectField, fixedField, source.ReflectedSource);

            objectField.RegisterValueChangedCallback(evt => { source.ReflectedSource = (ReflectedFloatSourceSO)evt.newValue; EditorUtility.SetDirty(dirtyTarget); Refresh(); onChanged?.Invoke(); });
            fixedField.RegisterValueChangedCallback(evt => { source.FixedValue = evt.newValue; EditorUtility.SetDirty(dirtyTarget); onChanged?.Invoke(); });

            Refresh();
        }

        static void WireIntRow(VisualElement root, string rowKey, PerformanceIntValueSource source, UnityEngine.Object dirtyTarget, Action onChanged)
        {
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{rowKey}Source");
            IntegerField fixedField = root.Q<IntegerField>($"Field{rowKey}Fixed");

            ForceEnabled(source, dirtyTarget);
            ReflectedSourceField.Attach(objectField, typeof(ReflectedIntSourceSO));
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh() => RefreshOperand(objectField, fixedField, source.ReflectedSource);

            objectField.RegisterValueChangedCallback(evt => { source.ReflectedSource = (ReflectedIntSourceSO)evt.newValue; EditorUtility.SetDirty(dirtyTarget); Refresh(); onChanged?.Invoke(); });
            fixedField.RegisterValueChangedCallback(evt => { source.FixedValue = evt.newValue; EditorUtility.SetDirty(dirtyTarget); onChanged?.Invoke(); });

            Refresh();
        }

        static void WireStringRow(VisualElement root, string rowKey, PerformanceStringValueSource source, UnityEngine.Object dirtyTarget, Action onChanged)
        {
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{rowKey}Source");
            TextField fixedField = root.Q<TextField>($"Field{rowKey}Fixed");

            ForceEnabled(source, dirtyTarget);
            ReflectedSourceField.Attach(objectField, typeof(ReflectedStringSourceSO));
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh() => RefreshOperand(objectField, fixedField, source.ReflectedSource);

            objectField.RegisterValueChangedCallback(evt => { source.ReflectedSource = (ReflectedStringSourceSO)evt.newValue; EditorUtility.SetDirty(dirtyTarget); Refresh(); onChanged?.Invoke(); });
            fixedField.RegisterValueChangedCallback(evt => { source.FixedValue = evt.newValue; EditorUtility.SetDirty(dirtyTarget); onChanged?.Invoke(); });

            Refresh();
        }

        static void WireBoolRow(VisualElement root, string rowKey, PerformanceBoolValueSource source, UnityEngine.Object dirtyTarget, Action onChanged)
        {
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{rowKey}Source");
            Toggle fixedField = root.Q<Toggle>($"Field{rowKey}Fixed");

            ForceEnabled(source, dirtyTarget);
            ReflectedSourceField.Attach(objectField, typeof(ReflectedBoolSourceSO));
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh() => RefreshOperand(objectField, fixedField, source.ReflectedSource);

            objectField.RegisterValueChangedCallback(evt => { source.ReflectedSource = (ReflectedBoolSourceSO)evt.newValue; EditorUtility.SetDirty(dirtyTarget); Refresh(); onChanged?.Invoke(); });
            fixedField.RegisterValueChangedCallback(evt => { source.FixedValue = evt.newValue; EditorUtility.SetDirty(dirtyTarget); onChanged?.Invoke(); });

            Refresh();
        }

        // Marks dirty only when actually flipping legacy data (a Condition serialized before this
        // Enabled-is-always-true convention) - never unconditionally, so simply viewing/rebuilding
        // this UI doesn't spuriously dirty the asset every time.
        static void ForceEnabled(PerformanceValueSource source, UnityEngine.Object dirtyTarget)
        {
            if (source.Enabled)
                return;

            source.Enabled = true;
            EditorUtility.SetDirty(dirtyTarget);
        }

        static void ForceEnabled(PerformanceIntValueSource source, UnityEngine.Object dirtyTarget)
        {
            if (source.Enabled)
                return;

            source.Enabled = true;
            EditorUtility.SetDirty(dirtyTarget);
        }

        static void ForceEnabled(PerformanceStringValueSource source, UnityEngine.Object dirtyTarget)
        {
            if (source.Enabled)
                return;

            source.Enabled = true;
            EditorUtility.SetDirty(dirtyTarget);
        }

        static void ForceEnabled(PerformanceBoolValueSource source, UnityEngine.Object dirtyTarget)
        {
            if (source.Enabled)
                return;

            source.Enabled = true;
            EditorUtility.SetDirty(dirtyTarget);
        }

        // Shared reflected-vs-fixed display logic behind every WireXRow above - fixedField is
        // VisualElement rather than a typed field since the four callers each use a different
        // concrete field type (FloatField/IntegerField/TextField/Toggle) with no common base beyond
        // VisualElement itself. Hides the fixed field once a reflected source is picked (it
        // wouldn't be used - see PerformanceValueSource.Resolve()'s own priority) and shows the
        // resolved path as the object field's tooltip.
        static void RefreshOperand(ObjectField objectField, VisualElement fixedField, IReflectedValueSource reflectedSource)
        {
            bool usingReflected = reflectedSource != null;
            fixedField.style.display = usingReflected ? DisplayStyle.None : DisplayStyle.Flex;

            if (!usingReflected)
            {
                objectField.tooltip = string.Empty;
                return;
            }

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(reflectedSource.Data.TargetGuid);
            ReflectedSourcePathUtility.CacheLastKnownLocation((UnityEngine.Object)reflectedSource, reflectedSource.Data, target);
            objectField.tooltip = ReflectedSourcePathUtility.BuildFriendlyPath(reflectedSource.Data, target);
        }
    }
}
