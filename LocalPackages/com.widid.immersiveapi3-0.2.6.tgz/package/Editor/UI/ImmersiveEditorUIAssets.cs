using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.UI
{
    [Serializable]
    public class ImmersiveEditorUIAssets
    {
        [field: SerializeField] public VisualTreeAsset TrainingEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset TrainingEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset TrainingCatalogWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset PerformanceEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset PerformanceEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset SkillEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset SkillEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset InteractionEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset InteractionEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset BadgeEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset BadgeEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset RewardEditorWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset RewardEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset LanguageRow { get; private set; }
        [field: SerializeField] public VisualTreeAsset AttachmentRow { get; private set; }
        [field: SerializeField] public VisualTreeAsset ConditionEntry { get; private set; }
        [field: SerializeField] public VisualTreeAsset ImmersiveDebugSessionWindow { get; private set; }
        [field: SerializeField] public VisualTreeAsset StatementPreviewWindow { get; private set; }
        [field: SerializeField] public Texture2D Logo { get; private set; }
        [field: SerializeField] public Texture2D IconGameFlow { get; private set; }
        [field: SerializeField] public Texture2D IconPerformances { get; private set; }
        [field: SerializeField] public Texture2D IconSkills { get; private set; }
        [field: SerializeField] public Texture2D IconInteractions { get; private set; }
        [field: SerializeField] public Texture2D IconBadges { get; private set; }
        [field: SerializeField] public Texture2D IconRewards { get; private set; }
    }
}
