using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor.UI
{
    // Loads the singleton ImmersiveEditorUIConfigSO from Resources - every Editor window pulls its
    // VisualTreeAsset/Texture2D references from Assets here instead of hardcoding its own path.
    public static class ImmersiveEditorUIConfigLoader
    {
        static ImmersiveEditorUIConfigSO config;

        public static ImmersiveEditorUIAssets Assets
        {
            get
            {
                if (config == null)
                {
                    config = Resources.Load<ImmersiveEditorUIConfigSO>("ImmersiveEditorUIConfig");
                    if (config == null)
                        Debug.LogError("ImmersiveEditorUIConfig asset not found in Resources!");
                }

                return config != null ? config.Assets : null;
            }
        }
    }
}
