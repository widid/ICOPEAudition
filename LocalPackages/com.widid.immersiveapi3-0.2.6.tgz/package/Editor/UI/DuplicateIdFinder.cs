using System;
using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Editor.UI
{
    // Shared rule behind every catalog editor's duplicate-Id warning (Performance/Skill/Interaction,
    // and any future one): within whatever scope idSelector's items were collected from, no two
    // entries of the same type may share an Id - each Statementable's canonical Uri is derived from
    // its Id (see XapiUriHelper), so a duplicate would silently collide two distinct statements.
    // Empty/null Ids are ignored here - that's a "not filled in yet" state, not a duplicate.
    public static class DuplicateIdFinder
    {
        public static HashSet<string> Find<T>(IEnumerable<T> items, Func<T, string> idSelector)
        {
            Dictionary<string, int> counts = new();
            foreach (T item in items)
            {
                string id = idSelector(item);
                if (string.IsNullOrEmpty(id))
                    continue;

                counts[id] = counts.GetValueOrDefault(id) + 1;
            }

            HashSet<string> duplicates = new();
            foreach (KeyValuePair<string, int> pair in counts)
            {
                if (pair.Value > 1)
                    duplicates.Add(pair.Key);
            }

            return duplicates;
        }
    }
}
