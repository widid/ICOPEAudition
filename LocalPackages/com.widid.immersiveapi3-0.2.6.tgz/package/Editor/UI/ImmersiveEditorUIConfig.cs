using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor.UI
{
    // Single inspector-editable place for every UXML/USS/texture path an ImmersiveAPI Editor window
    // needs, so those paths live as drag-and-drop object references here instead of hardcoded string
    // constants scattered across each window's .cs file - see ImmersiveEditorUIConfigLoader for how
    // windows consume it.
    [CreateAssetMenu(fileName = "ImmersiveEditorUIConfig", menuName = "Data/Editor/Immersive Editor UI Config")]
    public class ImmersiveEditorUIConfigSO : ScriptableObject
    {
        [field: SerializeField] public ImmersiveEditorUIAssets Assets { get; private set; }
    }
}
