using System;
using UnityEditor;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor
{
    /// <summary>
    /// Turns a Resources path into a project path and creates the asset there. Single owner of that
    /// rule, so everything the package loads through Resources.Load is created where Resources.Load
    /// will look for it - see ImmersiveSettingsEntry for a setting's Create button and
    /// ImmersiveDebugSessionWindow for the session asset's.
    /// </summary>
    public static class ImmersiveResourceAsset
    {
        const string ResourcesRoot = "Assets/Resources";

        public static string ProjectPath(string resourcePath) => $"{ResourcesRoot}/{resourcePath}.asset";

        public static ScriptableObject Load(Type type, string resourcePath) =>
            Resources.Load(resourcePath, type) as ScriptableObject;

        /// <summary>
        /// Returns the existing asset, or creates it - folders included - when there is none, so
        /// callers can treat this as "make sure this exists".
        /// </summary>
        public static ScriptableObject EnsureExists(Type type, string resourcePath)
        {
            ScriptableObject existing = Load(type, resourcePath);
            if (existing != null)
                return existing;

            string projectPath = ProjectPath(resourcePath);
            AssetFolders.EnsureExists(projectPath[..projectPath.LastIndexOf('/')]);

            ScriptableObject instance = ScriptableObject.CreateInstance(type);
            AssetDatabase.CreateAsset(instance, projectPath);
            AssetDatabase.SaveAssets();

            return instance;
        }
    }
}
