using UnityEditor;

namespace WiDiD.ImmersiveAPI.Editor
{
    /// <summary>
    /// Creates the folders an asset path needs. AssetDatabase.CreateFolder only accepts a parent
    /// that already exists, and reports failure by returning an empty string rather than throwing,
    /// so every segment is walked from the project root instead of assuming any part of the path
    /// is already there - in a project that has just imported this package, none of it is.
    /// </summary>
    public static class AssetFolders
    {
        /// <summary>
        /// Ensures every folder in <paramref name="folderPath"/> exists, e.g.
        /// "Assets/Resources/ImmersiveAPI/Trainings". Rooted at Assets and '/'-separated, the same
        /// shape AssetDatabase uses everywhere else.
        /// </summary>
        public static void EnsureExists(string folderPath)
        {
            string[] segments = folderPath.Split('/');
            string currentPath = segments[0];

            for (int i = 1; i < segments.Length; i++)
            {
                string nextPath = $"{currentPath}/{segments[i]}";
                if (!AssetDatabase.IsValidFolder(nextPath))
                    AssetDatabase.CreateFolder(currentPath, segments[i]);

                currentPath = nextPath;
            }
        }
    }
}
