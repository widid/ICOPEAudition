using System;
using System.Linq;
using GraphProcessor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Shared behavior for StrategyNodeView/StepNodeView: the RequireAllPreviousCompleted/
    /// RequireAllPreviousPassed fields have no effect at all on a node with no Previous
    /// connections (unlock evaluation always treats "no previous" as unlocked, ignoring them) - so
    /// hide them entirely in that case instead of showing settings that do nothing. Re-evaluated
    /// live as Previous edges connect/disconnect.
    /// </summary>
    public abstract class UnlockConditionNodeView : BaseNodeView
    {
        static readonly string[] UnlockConditionFieldNames =
        {
            "requireAllPreviousCompleted",
            "requireAllPreviousPassed"
        };

        public override void Enable()
        {
            base.Enable();

            RefreshUnlockConditionVisibility();
            nodeTarget.onAfterEdgeConnected += _ => RefreshUnlockConditionVisibility();
            nodeTarget.onAfterEdgeDisconnected += _ => RefreshUnlockConditionVisibility();

            SetFieldTooltip("requireAllPreviousCompleted", "Locked until every Previous node is Completed. Ignored if there's no Previous connection.");
        }

        /// <summary>
        /// Keeps the node's title in sync with its Name field as it's edited - StrategyNode/StepNode
        /// compute `name` from that field already, but the title bar is only read from it once
        /// (on Enable/rename), so this re-applies it live. Respects a manual rename
        /// (GetCustomName() prefers that over the computed name).
        /// </summary>
        protected void RefreshTitleOnNameChanged(string nameFieldName)
        {
            PropertyField nameField = controlsContainer.Q<PropertyField>(nameFieldName);
            nameField?.RegisterValueChangeCallback(_ => title = nodeTarget.GetCustomName());
        }

        protected void SetFieldTooltip(string fieldName, string tooltip)
        {
            VisualElement element = controlsContainer.Q<VisualElement>(fieldName);
            if (element != null)
                element.tooltip = tooltip;
        }

        // Shared by StrategyNodeView/StepNodeView, whose customId duplicate scope differs (same
        // GameFlowGraph vs whole-Training) - isDuplicate encapsulates that difference, this just
        // owns showing/hiding a warning label under the field and re-checking on every graph
        // change. Hooked to the graph's own onGraphChanges (what NotifyNodeChanged - fired by every
        // auto-drawn field's PropertyField, see GraphProcessor's BaseNodeView.AddControlField -
        // actually raises) rather than this field's own PropertyField.RegisterValueChangeCallback:
        // that callback never fired reliably for a plain string field, and using the graph-level
        // event also means editing THIS node's id refreshes every OTHER node's warning too, not
        // just this one's.
        protected void WireDuplicateIdCheck(Func<bool> isDuplicate)
        {
            RefreshIdWarning(isDuplicate);

            if (nodeTarget.Graph != null)
                nodeTarget.Graph.onGraphChanges += _ => RefreshIdWarning(isDuplicate);
        }

        void RefreshIdWarning(Func<bool> isDuplicate)
        {
            Label warningLabel = controlsContainer.Q<Label>("wid-duplicate-id-warning");
            if (warningLabel == null)
            {
                warningLabel = new Label { name = "wid-duplicate-id-warning" };
                warningLabel.style.color = new StyleColor(new Color(0.86f, 0.15f, 0.15f));
                warningLabel.style.whiteSpace = WhiteSpace.Normal;
                controlsContainer.Add(warningLabel);
            }

            bool duplicate = isDuplicate();
            warningLabel.text = duplicate ? "Duplicate Id - must be unique." : string.Empty;
            warningLabel.style.display = duplicate ? DisplayStyle.Flex : DisplayStyle.None;
        }

        void RefreshUnlockConditionVisibility()
        {
            bool hasPrevious = nodeTarget.GetInputNodes().Any();
            DisplayStyle display = hasPrevious ? DisplayStyle.Flex : DisplayStyle.None;

            foreach (string fieldName in UnlockConditionFieldNames)
            {
                VisualElement element = controlsContainer.Q<VisualElement>(fieldName);
                if (element != null)
                    element.style.display = display;
            }
        }
    }
}
