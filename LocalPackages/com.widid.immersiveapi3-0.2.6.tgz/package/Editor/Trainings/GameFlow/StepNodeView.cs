using System.Linq;
using GraphProcessor;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Adds to the shared unlock-condition field visibility from UnlockConditionNodeView: also
    /// hides triggersStrategyCompletion whenever this step has a Next connection - it's only
    /// meaningful on a step with none (see TrainingStepData.TriggersStrategyCompletion).
    /// </summary>
    [NodeCustomEditor(typeof(StepNode))]
    public class StepNodeView : UnlockConditionNodeView
    {
        public override void Enable()
        {
            base.Enable();

            tooltip = "One step within a Strategy's GameFlow (xAPI Step).";
            RefreshTitleOnNameChanged("stepName");
            SetFieldTooltip("requireAllPreviousPassed", "Locked until every Previous step's own recorded Score meets that step's own Passing Score. Ignored if there's no Previous connection.");
            SetFieldTooltip("passingScore", "Threshold this step's own recorded Score is compared against to decide Passed - used by downstream steps' \"Require All Previous Passed\" check.");
            SetFieldTooltip("triggersStrategyCompletion", "Only meaningful with no Next connection. When this step Completes, ends its owning strategy: Passed/Failed then Completed are sent for it.");
            SetFieldTooltip("customId", "Leave empty to use the auto-generated Guid as this Step's xAPI Id. Must stay unique across the whole Training, not just this Strategy's own Steps.");

            RefreshTriggersCompletionVisibility();
            nodeTarget.onAfterEdgeConnected += _ => RefreshTriggersCompletionVisibility();
            nodeTarget.onAfterEdgeDisconnected += _ => RefreshTriggersCompletionVisibility();

            WireDuplicateIdCheck(() => IsDuplicateId((StepNode)nodeTarget));
        }

        // Unlike Strategy's same-graph check, a Step must be unique across every Strategy's own
        // StepGraph in the Training, not just its own - other StepGraphs aren't necessarily open/
        // loaded as live node objects right now, so this checks the owning Training's already-
        // synced data (excluding this node's own entry by NodeGuid) rather than live sibling nodes,
        // plus a same-graph live check to catch a just-duplicated node before the next Sync() runs.
        static bool IsDuplicateId(StepNode node)
        {
            if (node.Graph is StepGraph stepGraph && stepGraph.nodes.OfType<StepNode>().Count(other => other.ResolvedId == node.ResolvedId) > 1)
                return true;

            if (node.Graph is not StepGraph { owningTraining: not null } ownerGraph)
                return false;

            return ownerGraph.owningTraining.Data.GameFlow.Strategies
                .SelectMany(strategy => strategy.Steps)
                .Any(step => step.NodeGuid != node.GUID && step.Id == node.ResolvedId);
        }

        void RefreshTriggersCompletionVisibility()
        {
            bool hasNext = nodeTarget.GetOutputNodes().Any();
            VisualElement element = controlsContainer.Q<VisualElement>("triggersStrategyCompletion");
            if (element != null)
                element.style.display = hasNext ? DisplayStyle.None : DisplayStyle.Flex;
        }
    }
}
