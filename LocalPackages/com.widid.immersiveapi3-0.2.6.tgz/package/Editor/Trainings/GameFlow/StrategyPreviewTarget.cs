using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>Previews the six statements a Strategy can send (see StrategyStatementFactory), using placeholder progress/score values since no real playthrough is running.</summary>
    class StrategyPreviewTarget : IStatementPreviewTarget
    {
        const float PreviewProgress = 0.5f;

        static readonly string[] VerbNames = { "Launched", "Progressed", "Failed", "Passed", "Completed", "Exited" };

        readonly TrainingSO training;
        readonly Simulation simulation;
        readonly TrainingStrategyData data;

        public StrategyPreviewTarget(TrainingSO training, Simulation simulation, TrainingStrategyData data)
        {
            this.training = training;
            this.simulation = simulation;
            this.data = data;
        }

        public string FamilyName => "GameFlow";
        public IReadOnlyList<string> PathSegments => new[] { training.Data.Id, data.Name.GetDisplayName(data.Id), "(Strategy)" };
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Launched" => (Verbs.Launched, StrategyStatementFactory.Launched(simulation, data)),
                "Progressed" => (Verbs.Progressed, StrategyStatementFactory.Progressed(simulation, data, PreviewProgress)),
                "Failed" => (Verbs.Failed, StrategyStatementFactory.Failed(simulation, data, data.PassingScore)),
                "Passed" => (Verbs.Passed, StrategyStatementFactory.Passed(simulation, data, data.PassingScore)),
                "Completed" => (Verbs.Completed, StrategyStatementFactory.Completed(simulation, data, data.PassingScore)),
                "Exited" => (Verbs.Exited, StrategyStatementFactory.Exited(simulation, data)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
