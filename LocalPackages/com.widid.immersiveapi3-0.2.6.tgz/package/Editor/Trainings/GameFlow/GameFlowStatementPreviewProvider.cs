using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Exposes every Training/Strategy/Step in the project as a StatementPreviewWindow target -
    /// discovered automatically via IStatementPreviewProvider, no manual registration.
    /// </summary>
    public class GameFlowStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);
                targets.Add(new TrainingPreviewTarget(training, sessionTrainingId));

                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    targets.Add(new StrategyPreviewTarget(training, simulation, strategy));

                    string strategyLabel = strategy.Name.GetDisplayName(strategy.Id);
                    Strategy parentStrategy = StrategyStatementFactory.Launched(simulation, strategy);
                    foreach (TrainingStepData step in strategy.Steps)
                        targets.Add(new StepPreviewTarget(training, strategyLabel, simulation, parentStrategy, step));
                }
            }

            return targets;
        }
    }
}
