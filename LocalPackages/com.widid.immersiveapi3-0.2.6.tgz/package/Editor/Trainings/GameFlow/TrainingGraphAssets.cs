using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Single owner of where a Training's authoring graphs live on disk: one companion asset per
    /// Training, holding its <see cref="GameFlowGraph"/> as the main object and that Training's
    /// nested <see cref="StepGraph"/>s as sub-assets.
    ///
    /// They deliberately do not live inside the TrainingSO asset. TrainingSOs sit under
    /// Assets/Resources so TrainingRuntime can Resources.LoadAll them, and that force-includes
    /// every one of their sub-assets in a player build - where GameFlowGraph/StepGraph don't
    /// exist, since they're compiled only into the Editor-only assembly.
    /// </summary>
    public static class TrainingGraphAssets
    {
        const string EditorFolderName = "Editor";
        const string ResourcesFolderName = "Resources";

        /// <summary>
        /// Resolved by <see cref="GameFlowGraph.owningTraining"/> rather than by location, so
        /// moving or renaming either asset - or editing the Training's authored Id - can't break
        /// the link.
        /// </summary>
        public static GameFlowGraph Find(TrainingSO training)
        {
            if (training == null)
                return null;

            return AssetDatabase.FindAssets($"t:{nameof(GameFlowGraph)}")
                .Select(guid => AssetDatabase.LoadAssetAtPath<GameFlowGraph>(AssetDatabase.GUIDToAssetPath(guid)))
                .FirstOrDefault(graph => graph != null && graph.owningTraining == training);
        }

        public static GameFlowGraph FindOrCreate(TrainingSO training)
        {
            GameFlowGraph existing = Find(training);
            if (existing != null)
                return existing;

            AssetFolders.EnsureExists(CompanionFolderFor(training));

            GameFlowGraph gameFlowGraph = ScriptableObject.CreateInstance<GameFlowGraph>();
            gameFlowGraph.owningTraining = training;

            AssetDatabase.CreateAsset(gameFlowGraph, AssetDatabase.GenerateUniqueAssetPath(CompanionPathFor(training)));
            AssetDatabase.SaveAssets();

            return gameFlowGraph;
        }

        /// <summary>
        /// Where a Training's companion asset is created. Naming only - the link itself is the
        /// graph's owningTraining reference (see <see cref="Find"/>).
        /// </summary>
        public static string CompanionPathFor(TrainingSO training) =>
            $"{CompanionFolderFor(training)}/GameFlow_{training.Data.Id}.asset";

        /// <summary>
        /// Deletes a Training's companion asset (its GameFlowGraph and every nested StepGraph).
        /// Must run before the TrainingSO itself is deleted - the lookup needs it to still exist.
        /// </summary>
        public static void Delete(TrainingSO training)
        {
            GameFlowGraph gameFlowGraph = Find(training);
            if (gameFlowGraph == null)
                return;

            AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(gameFlowGraph));
        }

        /// <summary>
        /// The Training's own folder with its Resources root swapped for Unity's Editor special
        /// folder - Assets/Resources/ImmersiveAPI/Trainings becomes Assets/Editor/ImmersiveAPI/
        /// Trainings. Derived from where the Training actually sits rather than declared as a
        /// project path of its own, so the two can't drift apart; Editor folders are never
        /// included in a player build.
        /// </summary>
        static string CompanionFolderFor(TrainingSO training)
        {
            // AssetDatabase paths are always '/'-separated and always rooted at Assets/.
            string assetPath = AssetDatabase.GetAssetPath(training);
            string trainingFolder = assetPath[..assetPath.LastIndexOf('/')];

            string[] segments = trainingFolder.Split('/');
            int resourcesIndex = Array.LastIndexOf(segments, ResourcesFolderName);

            // A Training authored outside Resources isn't force-included in a build, so its graphs
            // only need the Editor folder, not the swap.
            if (resourcesIndex < 0)
                return $"{trainingFolder}/{EditorFolderName}";

            segments[resourcesIndex] = EditorFolderName;
            return string.Join("/", segments);
        }
    }
}
