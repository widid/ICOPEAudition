using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Renders a StrategyReference field as a "Training/Strategy" dropdown instead of a raw id
    /// text field, scanning every TrainingSO asset in the project for its strategies. Matches/
    /// stores by NodeGuid (not Id) - see StrategyReference - so a strategy already picked here
    /// stays correctly selected (just re-labeled) even after its Id is edited via
    /// StrategyNode.customId, instead of silently falling back to "<None>".
    /// </summary>
    [CustomPropertyDrawer(typeof(StrategyReference))]
    public class StrategyReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "strategyNodeGuid";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                    results.Add(new TrainingReferenceOption(strategy.NodeGuid, $"{training.Data.Id}/{strategy.Name.GetDisplayName("Strategy")}"));
            }

            return results;
        }
    }
}
