using GraphProcessor;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Single reusable graph window for both GameFlow nesting levels - a Training's top-level
    /// Strategies graph (<see cref="GameFlowGraph"/>) and a strategy's nested Steps graph
    /// (<see cref="StepGraph"/>) are both just a <see cref="BaseGraph"/> as far as this window
    /// is concerned. Supports multiple simultaneous instances (e.g. two different Trainings'
    /// GameFlow, or a Strategies graph and one of its Steps graphs, all open at once).
    /// </summary>
    public class GameFlowGraphWindow : BaseGraphWindow
    {
        public BaseGraph CurrentGraph => graph;

        public static GameFlowGraphWindow Open(BaseGraph graph, string title)
        {
            // Focus an already-open window for this exact graph instead of opening a duplicate.
            foreach (GameFlowGraphWindow existing in Resources.FindObjectsOfTypeAll<GameFlowGraphWindow>())
            {
                if (existing.CurrentGraph == graph)
                {
                    existing.Focus();
                    return existing;
                }
            }

            // Dock alongside any already-open GameFlowGraphWindow (Strategies or Steps, any Training)
            // instead of popping up as a separate floating window.
            GameFlowGraphWindow window = CreateWindow<GameFlowGraphWindow>(typeof(GameFlowGraphWindow));
            window.titleContent = new GUIContent(title);
            window.InitializeGraph(graph);
            window.Show();
            window.Focus();

            return window;
        }

        protected override void InitializeWindow(BaseGraph graph)
        {
            GameFlowGraphView view = new(this);
            rootView.Add(view);

            if (graph is StepGraph stepGraph)
                rootView.Add(BuildBackToStrategiesButton(stepGraph));
        }

        static VisualElement BuildBackToStrategiesButton(StepGraph stepGraph)
        {
            Button backButton = new(() => OpenParentStrategiesGraph(stepGraph)) { text = "< Back to Strategies" };
            backButton.style.position = Position.Absolute;
            backButton.style.top = 4;
            backButton.style.left = 4;
            return backButton;
        }

        static void OpenParentStrategiesGraph(StepGraph stepGraph)
        {
            if (stepGraph.owningTraining == null)
            {
                Debug.LogError("This step graph has no owning Training - can't find its parent Strategies graph.");
                return;
            }

            GameFlowGraph gameFlowGraph = TrainingGraphAssets.Find(stepGraph.owningTraining);

            if (gameFlowGraph == null)
            {
                Debug.LogError("No GameFlowGraph found for this Training.");
                return;
            }

            Open(gameFlowGraph, $"GameFlow - {stepGraph.owningTraining.Data.Id}");
        }
    }
}
