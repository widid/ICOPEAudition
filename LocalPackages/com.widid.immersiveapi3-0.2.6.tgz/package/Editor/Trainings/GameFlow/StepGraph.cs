using System.Collections.Generic;
using System.Linq;
using GraphProcessor;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Nested graph of <see cref="StepNode"/>s for a single strategy - the "using nesting" parenting
    /// from the old ImmersiveAPI system, just visually authored instead of hand-maintained.
    /// Editor-only tool: on every change it rebuilds only its own strategy's Steps list inside the
    /// owning Training, leaving everything else (the strategies list, other strategies' steps) alone.
    /// </summary>
    [CreateAssetMenu(fileName = "NewStepGraph", menuName = "Data/GameFlow/Step Graph")]
    public class StepGraph : BaseGraph
    {
        public TrainingSO owningTraining;

        // The owning StrategyNode's GraphProcessor GUID (TrainingStrategyData.NodeGuid), captured
        // once at CreateDefault time - deliberately NOT the strategy's authored Id, since that can
        // be edited later (see StrategyNode.customId) and this needs to keep resolving to the same
        // strategy regardless.
        public string ownerStrategyId;

        public override void OnEnable()
        {
            base.OnEnable();
            onGraphChanges += _ => Sync();
        }

        /// <summary>
        /// Creates a strategy's nested StepGraph pre-populated with one default StepNode - a
        /// strategy must always have at least one step (see GameFlowGraphView, which blocks
        /// deleting the last one), so nothing should ever construct one without it. Nested as a
        /// sub-asset of the owning GameFlowGraph's companion asset, never of the TrainingSO - see
        /// <see cref="TrainingGraphAssets"/>.
        /// </summary>
        public static StepGraph CreateDefault(GameFlowGraph owner, string ownerStrategyId)
        {
            StepGraph stepGraph = CreateInstance<StepGraph>();
            stepGraph.name = $"Steps_{ownerStrategyId}";
            stepGraph.owningTraining = owner.owningTraining;
            stepGraph.ownerStrategyId = ownerStrategyId;

            stepGraph.AddNode(BaseNode.CreateFromType<StepNode>(Vector2.zero));

            AssetDatabase.AddObjectToAsset(stepGraph, AssetDatabase.GetAssetPath(owner));
            AssetDatabase.SaveAssets();

            return stepGraph;
        }

        public void Sync()
        {
            if (owningTraining == null || string.IsNullOrEmpty(ownerStrategyId))
                return;

            // Matched by NodeGuid, not Id - the strategy's authored Id may have been edited since
            // this StepGraph was created (see StrategyNode.customId), but ownerStrategyId always
            // stays the strategy's original, immutable GraphProcessor GUID.
            var strategy = owningTraining.Data.GameFlow.Strategies.FirstOrDefault(s => s.NodeGuid == ownerStrategyId);
            if (strategy == null)
                return;

            // previousSteps carries forward each step's Performances/Interactions by NodeGuid (not
            // Id - see the matching note above) - StepNode has no Performances/Interactions field
            // of its own, so they'd otherwise be lost on every graph edit.
            List<TrainingStepData> previousSteps = strategy.Steps;

            strategy.Steps = nodes.OfType<StepNode>().Select(node => new TrainingStepData
            {
                NodeGuid = node.GUID,
                Id = node.ResolvedId,
                Name = node.stepName,
                Description = node.stepDescription,
                Previous = node.GetInputNodes().OfType<StepNode>().Select(p => p.ResolvedId).ToList(),
                RequireAllPreviousCompleted = node.requireAllPreviousCompleted,
                RequireAllPreviousPassed = node.requireAllPreviousPassed,
                PassingScore = node.passingScore,
                TriggersStrategyCompletion = node.triggersStrategyCompletion,
                Performances = previousSteps.FirstOrDefault(s => s.NodeGuid == node.GUID)?.Performances ?? new List<TrainingPerformanceData>(),
                Interactions = previousSteps.FirstOrDefault(s => s.NodeGuid == node.GUID)?.Interactions ?? new List<TrainingInteractionData>()
            }).ToList();

            EditorUtility.SetDirty(owningTraining);
        }
    }
}
