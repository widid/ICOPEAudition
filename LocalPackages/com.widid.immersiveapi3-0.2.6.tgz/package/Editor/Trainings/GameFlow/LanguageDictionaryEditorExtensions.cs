using System.Collections.Generic;
using System.Linq;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Editor-only display helper shared by anything that needs to show a LanguageDictionary as a
    /// single label (node titles, reference picker dropdowns) - picks "en", falling back to the
    /// first non-empty language.
    /// </summary>
    public static class LanguageDictionaryEditorExtensions
    {
        public static string GetDisplayName(this LanguageDictionary name, string fallback)
        {
            Dictionary<string, string> languageMap = name.GetLanguageMap();
            if (languageMap.TryGetValue("en", out string english) && !string.IsNullOrEmpty(english))
                return english;

            return languageMap.Values.FirstOrDefault(value => !string.IsNullOrEmpty(value)) ?? fallback;
        }
    }
}
