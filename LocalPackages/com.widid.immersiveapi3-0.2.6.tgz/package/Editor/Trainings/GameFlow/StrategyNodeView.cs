using System.Linq;
using GraphProcessor;
using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Adds the "Edit Steps" button that opens (lazily creating if needed) a strategy's nested
    /// StepGraph - the nesting/parenting navigation from the old ImmersiveAPI system.
    /// </summary>
    [NodeCustomEditor(typeof(StrategyNode))]
    public class StrategyNodeView : UnlockConditionNodeView
    {
        public override void Enable()
        {
            base.Enable();

            tooltip = "One phase of the Training's GameFlow (xAPI Strategy) - contains an ordered set of Steps.";
            RefreshTitleOnNameChanged("strategyName");
            SetFieldTooltip("requireAllPreviousPassed", "Locked until every Previous strategy's own recorded Score meets that strategy's own Passing Score. Ignored if there's no Previous connection.");
            SetFieldTooltip("passingScore", "Threshold the average score of this strategy's completed steps is compared against, once every step is done, to decide Passed vs Failed.");
            SetFieldTooltip("customId", "Leave empty to use the auto-generated Guid as this Strategy's xAPI Id. Must stay unique across the whole Training.");
            SetFieldTooltip("completeSimulation", "Only meaningful with no Next connection. When this strategy Completes, ends the whole Simulation: a final Progressed(1) is sent, then Passed/Failed based on the average score of every completed Strategy.");

            StrategyNode strategyNode = (StrategyNode)nodeTarget;
            WireDuplicateIdCheck(() => IsDuplicateId(strategyNode));

            RefreshCompleteSimulationVisibility();
            nodeTarget.onAfterEdgeConnected += _ => RefreshCompleteSimulationVisibility();
            nodeTarget.onAfterEdgeDisconnected += _ => RefreshCompleteSimulationVisibility();

            Button editStepsButton = new(() => OpenStepGraph(strategyNode)) { text = "Edit Steps" };
            controlsContainer.Add(editStepsButton);
        }

        // Same shape as StepNodeView's own RefreshTriggersCompletionVisibility, one level up:
        // completeSimulation is only meaningful on a strategy with no Next connection.
        void RefreshCompleteSimulationVisibility()
        {
            bool hasNext = nodeTarget.GetOutputNodes().Any();
            VisualElement element = controlsContainer.Q<VisualElement>("completeSimulation");
            if (element != null)
                element.style.display = hasNext ? DisplayStyle.None : DisplayStyle.Flex;
        }

        // Two-pronged like StepNodeView's own check: the live same-graph comparison alone wasn't
        // reliably picking up a duplicate (unclear exactly why - possibly the node list GraphView
        // holds isn't always the same live instances this check would need), so this also
        // cross-checks against the owning Training's already-synced data, which GameFlowGraph.Sync()
        // keeps accurate on every graph change regardless.
        static bool IsDuplicateId(StrategyNode node)
        {
            if (node.Graph is GameFlowGraph gameFlowGraph && gameFlowGraph.nodes.OfType<StrategyNode>().Count(other => other.ResolvedId == node.ResolvedId) > 1)
                return true;

            if (node.Graph is not GameFlowGraph { owningTraining: not null } ownerGraph)
                return false;

            return ownerGraph.owningTraining.Data.GameFlow.Strategies.Any(strategy => strategy.NodeGuid != node.GUID && strategy.Id == node.ResolvedId);
        }

        static void OpenStepGraph(StrategyNode strategyNode)
        {
            if (strategyNode.Graph is not GameFlowGraph gameFlowGraph || gameFlowGraph.owningTraining == null)
            {
                Debug.LogError("This strategy isn't part of a GameFlowGraph with an owning Training - can't create/open its step graph.");
                return;
            }

            // Normally already created the moment this strategy was added (see
            // GameFlowGraph.HandleGraphChanges) - this is just a defensive fallback for strategies
            // authored before that existed.
            if (strategyNode.stepGraph == null)
            {
                strategyNode.stepGraph = StepGraph.CreateDefault(gameFlowGraph, strategyNode.GUID);
                gameFlowGraph.NotifyNodeChanged(strategyNode);
            }

            string trainingId = gameFlowGraph.owningTraining.Data.Id;
            string strategyLabel = strategyNode.strategyName.GetDisplayName("Strategy");
            GameFlowGraphWindow.Open(strategyNode.stepGraph, $"{trainingId} - {strategyLabel} - Steps");
        }
    }
}
