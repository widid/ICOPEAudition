using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Renders a StepReference field as a "Training/Strategy/Step" dropdown instead of a raw id
    /// text field, scanning every TrainingSO asset in the project for its steps. Matches/stores by
    /// NodeGuid (not Id) - see StepReference - so a step already picked here stays correctly
    /// selected (just re-labeled) even after its Id is edited via StepNode.customId, instead of
    /// silently falling back to "<None>".
    /// </summary>
    [CustomPropertyDrawer(typeof(StepReference))]
    public class StepReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "stepNodeGuid";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    string strategyLabel = strategy.Name.GetDisplayName("Strategy");
                    foreach (TrainingStepData step in strategy.Steps)
                        results.Add(new TrainingReferenceOption(step.NodeGuid, $"{training.Data.Id}/{strategyLabel}/{step.Name.GetDisplayName("Step")}"));
                }
            }

            return results;
        }
    }
}
