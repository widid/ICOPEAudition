namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Marker type for GameFlow's Previous/Next ports - no value ever flows through it, it exists
    /// purely so NodeGraphProcessor edges can connect nodes to record topology (which strategy/step
    /// comes after which). Never call graph Process() on these graphs; only the port connections
    /// (edges) are meaningful here.
    /// </summary>
    public class FlowSignal { }
}
