using System.Linq;
using GraphProcessor;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// The default BaseGraphView behavior (node creation menu, drag-connect ports, context menu)
    /// is exactly what GameFlow needs, with one addition: a Training's GameFlow must always have
    /// at least one strategy, and a strategy must always have at least one step (see
    /// GameFlowGraph/StrategyNodeView, which create the defaults), so deleting the last
    /// StrategyNode/StepNode of either is blocked here.
    /// </summary>
    public class GameFlowGraphView : BaseGraphView
    {
        public GameFlowGraphView(EditorWindow window) : base(window)
        {
            GraphViewChanged baseGraphViewChanged = graphViewChanged;
            graphViewChanged = changes => PreventEmptyingGraph(changes, baseGraphViewChanged);
        }

        GraphViewChange PreventEmptyingGraph(GraphViewChange changes, GraphViewChanged baseGraphViewChanged)
        {
            if (changes.elementsToRemove != null)
            {
                if (graph is StepGraph)
                    BlockIfWouldEmpty<StepNode>(changes, "step");
                else if (graph is GameFlowGraph)
                    BlockIfWouldEmpty<StrategyNode>(changes, "strategy");
            }

            return baseGraphViewChanged(changes);
        }

        void BlockIfWouldEmpty<TNode>(GraphViewChange changes, string nodeLabel) where TNode : BaseNode
        {
            int removedCount = changes.elementsToRemove.OfType<BaseNodeView>().Count(view => view.nodeTarget is TNode);
            int remainingCount = graph.nodes.OfType<TNode>().Count() - removedCount;

            if (remainingCount <= 0)
            {
                changes.elementsToRemove.RemoveAll(element => element is BaseNodeView view && view.nodeTarget is TNode);
                Debug.LogWarning($"There must always be at least one {nodeLabel} here - can't delete the last one.");
            }
        }
    }
}
