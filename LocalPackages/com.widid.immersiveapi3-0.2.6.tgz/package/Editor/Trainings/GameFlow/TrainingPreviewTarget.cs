using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>Previews the six statements a Training's Simulation can send (see SimulationStatementFactory), using placeholder progress/score values since no real playthrough is running.</summary>
    class TrainingPreviewTarget : IStatementPreviewTarget
    {
        const float PreviewProgress = 0.5f;
        const float PreviewScore = 0.5f;

        static readonly string[] VerbNames = { "Initialized", "Progressed", "Passed", "Failed", "Completed", "Exited" };

        readonly TrainingSO training;
        readonly string sessionTrainingId;

        public TrainingPreviewTarget(TrainingSO training, string sessionTrainingId)
        {
            this.training = training;
            this.sessionTrainingId = sessionTrainingId;
        }

        public string FamilyName => "GameFlow";
        public IReadOnlyList<string> PathSegments => new[] { training.Data.Id, "(Training)" };
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Initialized" => (Verbs.Initialized, SimulationStatementFactory.Initialized(training, sessionTrainingId)),
                "Progressed" => (Verbs.Progressed, SimulationStatementFactory.Progressed(training, sessionTrainingId, PreviewProgress)),
                "Failed" => (Verbs.Failed, SimulationStatementFactory.Failed(training, sessionTrainingId, PreviewScore)),
                "Passed" => (Verbs.Passed, SimulationStatementFactory.Passed(training, sessionTrainingId, PreviewScore)),
                "Completed" => (Verbs.Completed, SimulationStatementFactory.Completed(training, sessionTrainingId, PreviewScore)),
                "Exited" => (Verbs.Exited, SimulationStatementFactory.Exited(training, sessionTrainingId)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
