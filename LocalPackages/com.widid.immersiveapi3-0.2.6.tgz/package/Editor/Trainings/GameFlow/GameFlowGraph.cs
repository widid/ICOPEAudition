using System.Collections.Generic;
using System.Linq;
using GraphProcessor;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// Top-level graph of <see cref="StrategyNode"/>s for one Training - the "Formation graph"
    /// equivalent. Editor-only authoring tool: on every change it rebuilds the owning Training's
    /// Strategies list (Id/Name/Previous) from these nodes/edges. Each strategy's Steps are pulled
    /// live from that StrategyNode's own nested StepGraph if one exists (so a strategy-level edit
    /// never wipes out steps already authored in the nested graph), otherwise whatever was already
    /// there is preserved.
    /// </summary>
    [CreateAssetMenu(fileName = "NewGameFlowGraph", menuName = "Data/GameFlow/Game Flow Graph")]
    public class GameFlowGraph : BaseGraph
    {
        public TrainingSO owningTraining;

        public override void OnEnable()
        {
            base.OnEnable();
            onGraphChanges += HandleGraphChanges;
        }

        void HandleGraphChanges(GraphChanges changes)
        {
            if (owningTraining != null)
            {
                // A new strategy always needs its own step graph (see GameFlowGraphView, which
                // also blocks deleting the last one) - create it immediately rather than waiting
                // for "Edit Steps" to be clicked, so the strategy is never briefly step-less.
                if (changes.addedNode is StrategyNode addedStrategy && addedStrategy.stepGraph == null)
                    addedStrategy.stepGraph = StepGraph.CreateDefault(this, addedStrategy.GUID);

                // A deleted strategy's nested step graph would otherwise linger as an orphaned
                // sub-asset on this graph's asset forever - remove it along with its owning strategy.
                if (changes.removedNode is StrategyNode removedStrategy && removedStrategy.stepGraph != null)
                    DeleteStepGraph(removedStrategy.stepGraph);
            }

            Sync();
        }

        static void DeleteStepGraph(StepGraph stepGraph)
        {
            AssetDatabase.RemoveObjectFromAsset(stepGraph);
            DestroyImmediate(stepGraph, true);
            AssetDatabase.SaveAssets();
        }

        public void Sync()
        {
            if (owningTraining == null)
                return;

            List<TrainingStrategyData> previousStrategies = owningTraining.Data.GameFlow.Strategies;
            List<TrainingStrategyData> rebuilt = new();

            foreach (StrategyNode node in nodes.OfType<StrategyNode>())
            {
                // Matched by NodeGuid (GraphProcessor's own stable node identity), not Id - Id may
                // have been edited to a custom value since the last sync (see StrategyNode.customId),
                // so it can't be trusted to still point at the same node it did before.
                TrainingStrategyData previous = previousStrategies.FirstOrDefault(s => s.NodeGuid == node.GUID);

                TrainingStrategyData data = new()
                {
                    NodeGuid = node.GUID,
                    Id = node.ResolvedId,
                    Name = node.strategyName,
                    Description = node.strategyDescription,
                    Previous = node.GetInputNodes().OfType<StrategyNode>().Select(n => n.ResolvedId).ToList(),
                    RequireAllPreviousCompleted = node.requireAllPreviousCompleted,
                    RequireAllPreviousPassed = node.requireAllPreviousPassed,
                    PassingScore = node.passingScore,
                    CompleteSimulation = node.completeSimulation,
                    Performances = previous?.Performances ?? new List<TrainingPerformanceData>(),
                    Steps = node.stepGraph != null
                        ? BuildStepsFromGraph(node.stepGraph, previous?.Steps ?? new List<TrainingStepData>())
                        : previous?.Steps ?? new List<TrainingStepData>()
                };

                rebuilt.Add(data);
            }

            owningTraining.Data.GameFlow.Strategies = rebuilt;
            EditorUtility.SetDirty(owningTraining);
        }

        // previousSteps carries forward each step's Performances by NodeGuid (not Id - see the
        // matching note on the Strategy side above) - StepNode has no Performances field of its
        // own, so it would otherwise be lost every time this rebuilds.
        static List<TrainingStepData> BuildStepsFromGraph(StepGraph stepGraph, List<TrainingStepData> previousSteps)
        {
            return stepGraph.nodes.OfType<StepNode>().Select(node => new TrainingStepData
            {
                NodeGuid = node.GUID,
                Id = node.ResolvedId,
                Name = node.stepName,
                Description = node.stepDescription,
                Previous = node.GetInputNodes().OfType<StepNode>().Select(p => p.ResolvedId).ToList(),
                RequireAllPreviousCompleted = node.requireAllPreviousCompleted,
                RequireAllPreviousPassed = node.requireAllPreviousPassed,
                PassingScore = node.passingScore,
                TriggersStrategyCompletion = node.triggersStrategyCompletion,
                Performances = previousSteps.FirstOrDefault(s => s.NodeGuid == node.GUID)?.Performances ?? new List<TrainingPerformanceData>(),
                Interactions = previousSteps.FirstOrDefault(s => s.NodeGuid == node.GUID)?.Interactions ?? new List<TrainingInteractionData>()
            }).ToList();
        }
    }
}
