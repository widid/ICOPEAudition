using GraphProcessor;
using UnityEngine.Scripting.APIUpdating;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// One step, authored inside a strategy's nested <see cref="StepGraph"/>. Purely an authoring
    /// node - the actual data it produces lives in TrainingStepData (runtime assembly), rebuilt
    /// by StepGraph.Sync() from these nodes/edges.
    /// </summary>
    // Graphs authored before this assembly was renamed store their nodes as managed references
    // stamped with the assembly they were written from, so the old name has to stay resolvable or
    // those nodes come back null and the graph loads empty.
    [MovedFrom(false, sourceAssembly: "widid.immersiveapi.editor")]
    [NodeMenuItem("Step", onlyCompatibleWithGraph: typeof(StepGraph))]
    [System.Serializable]
    public class StepNode : BaseNode
    {
        public override string name => stepName.GetDisplayName("Step (no name)");
        public override Color color => new(0.35f, 0.65f, 0.35f);

        public LanguageDictionary stepName = new(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        public LanguageDictionary stepDescription = new(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        // Empty by default - this Step's xAPI Id is then just its auto-generated GUID (see
        // ResolvedId). Set this to author a stable, readable Id instead; clear it to fall back to
        // the GUID again. Must stay unique across the whole Training, not just this Strategy's own
        // Steps (see StepNodeView's duplicate-Id check and StepProgressController, which keys
        // progress by Id across every strategy) - StepGraph.Sync() uses ResolvedId, not GUID, for
        // TrainingStepData.Id/Previous once this is set.
        [InspectorName("Custom Id (optional)")]
        public string customId = string.Empty;

        // Unlock conditions - see TrainingStepData for the semantics, this just mirrors it in the
        // authoring node so StepGraph.Sync() can carry the values over.
        public bool requireAllPreviousCompleted = true;
        public bool requireAllPreviousPassed = false;
        public float passingScore = 0.5f;

        // Only meaningful on a step with no Next connection - see TrainingStepData.TriggersStrategyCompletion.
        public bool triggersStrategyCompletion = false;

        [Input("Previous", allowMultiple: true)] public FlowSignal previous;
        [Output("Next")] public FlowSignal next;

        public string ResolvedId => string.IsNullOrEmpty(customId) ? GUID : customId;
    }
}
