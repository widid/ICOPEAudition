using GraphProcessor;
using UnityEngine.Scripting.APIUpdating;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>
    /// One strategy (xAPI Strategy - a "session" in the old ImmersiveAPI system's terms, renamed
    /// to match the actual xAPI vocabulary), authored inside a Training's top-level
    /// <see cref="GameFlowGraph"/>. Purely an authoring node - the actual data it produces lives
    /// in TrainingStrategyData (runtime assembly), rebuilt by GameFlowGraph.Sync() from these
    /// nodes/edges. Opens a nested <see cref="StepGraph"/> for its own steps (see
    /// StrategyNodeView's "Edit Steps" button).
    /// </summary>
    // Graphs authored before this assembly was renamed store their nodes as managed references
    // stamped with the assembly they were written from, so the old name has to stay resolvable or
    // those nodes come back null and the graph loads empty.
    [MovedFrom(false, sourceAssembly: "widid.immersiveapi.editor")]
    [NodeMenuItem("Strategy", onlyCompatibleWithGraph: typeof(GameFlowGraph))]
    [System.Serializable]
    public class StrategyNode : BaseNode
    {
        public override string name => strategyName.GetDisplayName("Strategy (no name)");
        public override Color color => new(0.35f, 0.45f, 0.75f);

        public LanguageDictionary strategyName = new(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        public LanguageDictionary strategyDescription = new(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        // Empty by default - this Strategy's xAPI Id is then just its auto-generated GUID (see
        // ResolvedId). Set this to author a stable, readable Id instead; clear it to fall back to
        // the GUID again. Must stay unique across the whole Training (see StrategyNodeView's
        // duplicate-Id check) - GameFlowGraph.Sync() uses ResolvedId, not GUID, for
        // TrainingStrategyData.Id/Previous once this is set.
        [InspectorName("Custom Id (optional)")]
        public string customId = string.Empty;

        // Unlock conditions - see TrainingStrategyData for the semantics, this just mirrors them in
        // the authoring node so GameFlowGraph.Sync() can carry the values over.
        public bool requireAllPreviousCompleted = true;
        public bool requireAllPreviousPassed = false;

        // Passing threshold for the auto Pass/Fail decision once all of this strategy's steps are
        // done - see StrategyProgressController and TrainingStrategyData.PassingScore.
        public float passingScore = 0.5f;

        // Only meaningful with no Next connection - see TrainingStrategyData.CompleteSimulation,
        // which this mirrors in the authoring node so GameFlowGraph.Sync() can carry the value over.
        public bool completeSimulation = false;

        [HideInInspector] public StepGraph stepGraph;

        [Input("Previous", allowMultiple: true)] public FlowSignal previous;
        [Output("Next")] public FlowSignal next;

        public string ResolvedId => string.IsNullOrEmpty(customId) ? GUID : customId;
    }
}
