using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow
{
    /// <summary>Previews the six statements a Step can send (see StepStatementFactory), using placeholder progress/score values since no real playthrough is running.</summary>
    class StepPreviewTarget : IStatementPreviewTarget
    {
        const float PreviewProgress = 0.5f;

        static readonly string[] VerbNames = { "Launched", "Progressed", "Failed", "Passed", "Completed", "Exited" };

        readonly TrainingSO training;
        readonly string strategyLabel;
        readonly Simulation simulation;
        readonly Strategy parentStrategy;
        readonly TrainingStepData data;

        public StepPreviewTarget(TrainingSO training, string strategyLabel, Simulation simulation, Strategy parentStrategy, TrainingStepData data)
        {
            this.training = training;
            this.strategyLabel = strategyLabel;
            this.simulation = simulation;
            this.parentStrategy = parentStrategy;
            this.data = data;
        }

        public string FamilyName => "GameFlow";
        public IReadOnlyList<string> PathSegments => new[] { training.Data.Id, strategyLabel, data.Name.GetDisplayName(data.Id) };
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Launched" => (Verbs.Launched, StepStatementFactory.Launched(simulation, parentStrategy, data)),
                "Progressed" => (Verbs.Progressed, StepStatementFactory.Progressed(simulation, parentStrategy, data, PreviewProgress)),
                "Failed" => (Verbs.Failed, StepStatementFactory.Failed(simulation, parentStrategy, data, data.PassingScore)),
                "Passed" => (Verbs.Passed, StepStatementFactory.Passed(simulation, parentStrategy, data, data.PassingScore)),
                "Completed" => (Verbs.Completed, StepStatementFactory.Completed(simulation, parentStrategy, data, data.PassingScore)),
                "Exited" => (Verbs.Exited, StepStatementFactory.Exited(simulation, parentStrategy, data)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
