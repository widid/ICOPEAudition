using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Trainings;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>Every TrainingSO in the project, for the pickers that list their contents.</summary>
    public static class TrainingAssetCatalog
    {
        public static IEnumerable<TrainingSO> LoadAll()
        {
            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training != null)
                    yield return training;
            }
        }
    }
}
