using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>
    /// A built picker list, holding everything EditorGUI.Popup needs so a repaint costs a lookup
    /// rather than a rebuild: the labels array the popup takes as-is, and a value -> index map in
    /// place of a linear scan. First duplicate of a value wins, matching the order entries were
    /// collected in.
    /// </summary>
    public class TrainingReferenceOptionList
    {
        readonly Dictionary<string, int> indexByValue;
        readonly TrainingReferenceOption[] options;

        public string[] DisplayNames { get; }

        public TrainingReferenceOptionList(List<TrainingReferenceOption> collected)
        {
            options = collected.ToArray();
            DisplayNames = new string[options.Length];
            indexByValue = new Dictionary<string, int>(options.Length);

            for (int index = 0; index < options.Length; index++)
            {
                DisplayNames[index] = options[index].Display;
                if (!indexByValue.ContainsKey(options[index].Value))
                    indexByValue[options[index].Value] = index;
            }
        }

        /// <summary>Index of the stored value, falling back to the first entry when it no longer exists.</summary>
        public int IndexOf(string value)
        {
            return value != null && indexByValue.TryGetValue(value, out int index) ? index : 0;
        }

        public string ValueAt(int index)
        {
            return index >= 0 && index < options.Length ? options[index].Value : string.Empty;
        }
    }
}
