namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>One entry of a reference picker dropdown: the value stored on the reference, and
    /// the label shown for it.</summary>
    public readonly struct TrainingReferenceOption
    {
        public static readonly TrainingReferenceOption None = new TrainingReferenceOption(string.Empty, "<None>");

        public string Value { get; }
        public string Display { get; }

        public TrainingReferenceOption(string value, string display)
        {
            Value = value;
            Display = display;
        }
    }
}
