using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>
    /// Shared popup rendering for every XReference picker. Options come from
    /// TrainingReferenceOptionsCache, keyed per drawer type, so OnGUI never rebuilds them - the
    /// collect pass walks the whole project and would otherwise run on each of the several IMGUI
    /// events a frame, for every drawer on screen.
    /// </summary>
    public abstract class ATrainingReferenceDrawer : PropertyDrawer
    {
        /// <summary>Serialized field on the reference type holding the picked value.</summary>
        protected abstract string ValuePropertyName { get; }

        protected abstract List<TrainingReferenceOption> CollectOptions();

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            SerializedProperty valueProperty = property.FindPropertyRelative(ValuePropertyName);

            string cacheKey = GetType().Name;
            if (!TrainingReferenceOptionsCache.TryGet(cacheKey, out TrainingReferenceOptionList options))
                options = TrainingReferenceOptionsCache.Store(cacheKey, CollectOptions());

            int currentIndex = options.IndexOf(valueProperty.stringValue);

            EditorGUI.BeginProperty(position, label, property);

            int newIndex = EditorGUI.Popup(position, label.text, currentIndex, options.DisplayNames);
            if (newIndex != currentIndex)
                valueProperty.stringValue = options.ValueAt(newIndex);

            EditorGUI.EndProperty();
        }
    }
}
