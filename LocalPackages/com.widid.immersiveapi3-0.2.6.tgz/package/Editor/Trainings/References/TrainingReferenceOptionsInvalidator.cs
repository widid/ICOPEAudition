using UnityEditor;
using WiDiD.ImmersiveAPI.Trainings;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>
    /// Drops the cached picker lists when a TrainingSO is edited in memory, so a strategy/step
    /// renamed or added in the Training editor shows up in the dropdowns without waiting for a
    /// save. Import/delete/move is covered by TrainingReferenceCacheAssetWatcher instead.
    /// </summary>
    [InitializeOnLoad]
    public static class TrainingReferenceOptionsInvalidator
    {
        static TrainingReferenceOptionsInvalidator()
        {
            Undo.undoRedoPerformed += TrainingReferenceOptionsCache.Invalidate;
            ObjectChangeEvents.changesPublished += HandleChangesPublished;
        }

        static void HandleChangesPublished(ref ObjectChangeEventStream stream)
        {
            for (int index = 0; index < stream.length; index++)
            {
                if (stream.GetEventType(index) != ObjectChangeKind.ChangeAssetObjectProperties)
                    continue;

                stream.GetChangeAssetObjectPropertiesEvent(index, out ChangeAssetObjectPropertiesEventArgs changed);
                if (EditorUtility.EntityIdToObject(changed.entityId) is TrainingSO)
                {
                    TrainingReferenceOptionsCache.Invalidate();
                    return;
                }
            }
        }
    }
}
