using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>
    /// Holds each picker's built option list until something invalidates it (see
    /// TrainingReferenceOptionsInvalidator/TrainingReferenceCacheAssetWatcher). Collecting options
    /// scans every TrainingSO in the project, which a PropertyDrawer must not do per repaint -
    /// IMGUI redraws several times a frame, once per visible drawer.
    ///
    /// Shared across drawer instances, so a graph showing many picker nodes still collects once.
    /// </summary>
    public static class TrainingReferenceOptionsCache
    {
        static readonly Dictionary<string, TrainingReferenceOptionList> listsByKey = new Dictionary<string, TrainingReferenceOptionList>();

        public static bool TryGet(string key, out TrainingReferenceOptionList options)
        {
            return listsByKey.TryGetValue(key, out options);
        }

        public static TrainingReferenceOptionList Store(string key, List<TrainingReferenceOption> collected)
        {
            TrainingReferenceOptionList options = new TrainingReferenceOptionList(collected);
            listsByKey[key] = options;
            return options;
        }

        public static void Invalidate()
        {
            listsByKey.Clear();
        }
    }
}
