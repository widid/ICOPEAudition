using UnityEditor;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.References
{
    /// <summary>
    /// Drops the cached picker lists whenever assets are imported, deleted or moved - a TrainingSO
    /// saved, added or removed changes what the dropdowns should offer.
    /// </summary>
    public class TrainingReferenceCacheAssetWatcher : AssetPostprocessor
    {
        static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
        {
            TrainingReferenceOptionsCache.Invalidate();
        }
    }
}
