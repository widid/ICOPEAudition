using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// The yellow warning sign shown wherever a whole group is affected rather than one entry - a
    /// Strategy/Step section title, or a Training Editor catalog button. Its own element (not a
    /// glyph prefixed into the surrounding text) so it can be colored independently, and it carries
    /// the tooltip itself: putting that on the container instead would hand it down to every child
    /// with no tooltip of its own.
    /// </summary>
    public class ValidationWarningSign : Label
    {
        const string Glyph = "⚠";

        public ValidationWarningSign(string tooltipText) : base(Glyph)
        {
            tooltip = tooltipText;
            style.color = ValidationColors.Warning;
            style.unityFontStyleAndWeight = FontStyle.Bold;
            style.marginRight = 2;
            style.marginLeft = 2;
            style.flexShrink = 0;
        }

        public void SetVisible(bool visible)
        {
            style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
        }
    }
}
