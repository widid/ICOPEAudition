namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// Outcome of one authored entry's validation - the message is what the indicator shows on
    /// hover, so it states the rule that isn't met rather than just "invalid".
    /// </summary>
    public class ValidationResult
    {
        public bool Ok { get; }
        public string Message { get; }

        ValidationResult(bool ok, string message)
        {
            Ok = ok;
            Message = message;
        }

        public static ValidationResult Valid() => new ValidationResult(true, "Ready to send.");

        public static ValidationResult Invalid(string message) => new ValidationResult(false, message);
    }
}
