using UnityEngine;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// Shared colors for the authoring validation feedback, so the per-entry dots and the section
    /// warning signs can't drift apart.
    /// </summary>
    public static class ValidationColors
    {
        public static readonly Color Ok = new Color(0.35f, 0.78f, 0.4f);
        public static readonly Color Error = new Color(0.85f, 0.33f, 0.33f);

        // Yellow rather than the dots' red: a section marker reports "something inside needs
        // attention", not "this is broken", and yellow reads clearly against both Editor skins.
        public static readonly Color Warning = new Color(1f, 0.79f, 0.16f);
    }
}
