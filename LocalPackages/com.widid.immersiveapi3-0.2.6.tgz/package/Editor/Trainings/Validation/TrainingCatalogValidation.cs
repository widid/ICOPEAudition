using System.Collections.Generic;
using System.Linq;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// Rolls TrainingEntryValidator up over a group of entries, at each scope something needs it:
    /// one container (an editor panel's Step section), one Strategy including its Steps, or a whole
    /// Training (the Training Editor's per-catalog buttons). Kept in one place so a button's
    /// warning sign and the panel's own can't disagree about what counts as invalid.
    /// </summary>
    public static class TrainingCatalogValidation
    {
        public static bool HasInvalidPerformances(TrainingSO training)
        {
            return HasInvalidPerformances(training.Data.GameFlow.Performances)
                || training.Data.GameFlow.Strategies.Any(strategy => HasInvalidPerformances(strategy));
        }

        public static bool HasInvalidPerformances(TrainingStrategyData strategy)
        {
            return HasInvalidPerformances(strategy.Performances)
                || strategy.Steps.Any(step => HasInvalidPerformances(step.Performances));
        }

        public static bool HasInvalidPerformances(List<TrainingPerformanceData> performances)
        {
            return performances.Any(performance => !TrainingEntryValidator.Validate(performance).Ok);
        }

        // A Strategy carries no Interactions of its own (they're always Step-scoped), so this is
        // purely its Steps' - which is the point: it surfaces a problem hidden inside a collapsed
        // Step.
        public static bool HasInvalidInteractions(TrainingStrategyData strategy)
        {
            return strategy.Steps.Any(step => HasInvalidInteractions(step));
        }

        public static bool HasInvalidInteractions(TrainingStepData step)
        {
            return step.Interactions.Any(interaction => !TrainingEntryValidator.Validate(interaction).Ok);
        }

        public static bool HasInvalidSkills(TrainingSO training)
        {
            return training.Data.GameFlow.Skills.Any(skill => !TrainingEntryValidator.Validate(skill).Ok);
        }

        public static bool HasInvalidRewards(TrainingSO training)
        {
            return training.Data.GameFlow.Rewards.Any(reward => !TrainingEntryValidator.Validate(reward).Ok);
        }

        public static bool HasInvalidBadges(TrainingSO training)
        {
            return training.Data.GameFlow.Badges.Any(badge => !TrainingEntryValidator.Validate(badge).Ok);
        }
    }
}
