using System;
using System.Collections.Generic;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// Keeps every validation indicator and section warning sign of one editor panel up to date.
    /// Panels register what to watch while building their tree, then call Refresh() from the same
    /// value-changed callbacks that already refresh headers - updating in place rather than
    /// rebuilding, for the same reason the duplicate-Id warnings do it that way: rebuilding the
    /// tree a field is being typed into drops focus every keystroke.
    ///
    /// A section's sign is its own element on the foldout's title line, and carries the section
    /// tooltip itself - never the Foldout, which contains every entry inside it and would hand its
    /// tooltip down to all of them (UI Toolkit shows the nearest ancestor's tooltip wherever the
    /// hovered element has none of its own). Each entry's title line carries its own message for
    /// the same reason.
    /// </summary>
    public class TrainingValidationView
    {
        const string SectionTooltip = "Contains entries that are missing something - open to see which.";

        readonly List<(Func<ValidationResult> Validate, ValidationIndicator Indicator, VisualElement TitleLine)> indicators = new();
        readonly List<(Func<bool> HasInvalid, ValidationWarningSign Sign)> sections = new();

        public void Clear()
        {
            indicators.Clear();
            sections.Clear();
        }

        /// <summary>
        /// Adds a dot to an entry's header row, and puts the same message on the entry's own title
        /// line so hovering the entry explains what's missing. Returns the dot so a caller can
        /// position it itself.
        /// </summary>
        public ValidationIndicator AddIndicator(VisualElement headerRow, Foldout entryFoldout, Func<ValidationResult> validate)
        {
            ValidationIndicator indicator = new ValidationIndicator();
            VisualElement titleLine = TitleLine(entryFoldout);

            indicators.Add((validate, indicator, titleLine));
            headerRow.Insert(0, indicator);
            ApplyIndicator(validate, indicator, titleLine);

            return indicator;
        }

        public void AddSection(Foldout foldout, Func<bool> hasInvalid)
        {
            ValidationWarningSign sign = AddSignToTitleLine(foldout);

            sections.Add((hasInvalid, sign));
            ApplySection(hasInvalid, sign);
        }

        public void Refresh()
        {
            foreach ((Func<ValidationResult> validate, ValidationIndicator indicator, VisualElement titleLine) in indicators)
                ApplyIndicator(validate, indicator, titleLine);

            foreach ((Func<bool> hasInvalid, ValidationWarningSign sign) in sections)
                ApplySection(hasInvalid, sign);
        }

        static void ApplyIndicator(Func<ValidationResult> validate, ValidationIndicator indicator, VisualElement titleLine)
        {
            ValidationResult result = validate();
            indicator.Set(result);

            if (titleLine != null)
                titleLine.tooltip = result.Message;
        }

        static void ApplySection(Func<bool> hasInvalid, ValidationWarningSign sign)
        {
            sign.SetVisible(hasInvalid());
        }

        // Inserted as the title label's own preceding sibling, so it reads as part of the title
        // without the title text having to carry it.
        static ValidationWarningSign AddSignToTitleLine(Foldout foldout)
        {
            ValidationWarningSign sign = new ValidationWarningSign(SectionTooltip);

            VisualElement titleLine = TitleLine(foldout);
            Label titleLabel = titleLine?.Q<Label>();

            if (titleLabel?.parent != null)
                titleLabel.parent.Insert(titleLabel.parent.IndexOf(titleLabel), sign);
            else
                (titleLine ?? foldout).Add(sign);

            return sign;
        }

        // A Foldout's title line is its own Toggle - its first child, so a depth-first Q finds it
        // before any Toggle an entry's content might hold.
        static VisualElement TitleLine(Foldout foldout) => foldout.Q<Toggle>();
    }
}
