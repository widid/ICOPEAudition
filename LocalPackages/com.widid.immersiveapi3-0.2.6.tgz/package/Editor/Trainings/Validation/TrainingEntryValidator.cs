using System.Linq;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// Whether an authored entry carries enough to produce a meaningful statement. These are
    /// authoring rules, not xAPI validity: an entry that fails one still builds a statement, it
    /// just reports nothing useful (a Skill with no scaled score, a Reward with no raw value, a
    /// Performance whose enabled attachment has no bound source), or can't be triggered at all (no
    /// Id - see the recorders' own id lookups). Duplicate Ids are a separate, cross-entry check
    /// with its own warning in each panel (see DuplicateIdFinder).
    /// </summary>
    public static class TrainingEntryValidator
    {
        public static ValidationResult Validate(TrainingPerformanceData performance)
        {
            if (string.IsNullOrEmpty(performance.Id))
                return ValidationResult.Invalid("No Id - a Performance needs one to be scored.");

            // An enabled attachment reports something in its own right, so it counts here too - a
            // Performance can be authored to send nothing but a capture (see
            // PerformanceAttachmentFactory), with no Score or Response of its own.
            if (!performance.Scaled.Enabled && !performance.Raw.Enabled && !performance.Response.Enabled
                && !performance.Attachments.Any(attachment => attachment.Enabled))
                return ValidationResult.Invalid("Nothing to report - enable at least one of Scaled, Raw, Response or an Attachment.");

            return ValidateAttachments(performance);
        }

        // An enabled attachment whose source is missing or never bound to a component captures
        // nothing at trigger time (see PerformanceAttachmentSource.Resolve/
        // ReflectedAttachmentResolver) and drops out of the statement silently, so it's reported
        // here rather than left to be noticed as a missing attachment on the LRS.
        static ValidationResult ValidateAttachments(TrainingPerformanceData performance)
        {
            for (int i = 0; i < performance.Attachments.Count; i++)
            {
                PerformanceAttachmentSource attachment = performance.Attachments[i];
                if (!attachment.Enabled)
                    continue;

                if (attachment.ReflectedSource == null)
                    return ValidationResult.Invalid($"Attachment {i + 1} is enabled with no source - assign a Reflected Attachment Source, or disable it.");

                if (!attachment.ReflectedSource.IsBound)
                    return ValidationResult.Invalid($"Attachment {i + 1}'s source '{attachment.ReflectedSource.name}' isn't bound to a component - bind it from the source's Edit Binding section, or disable the attachment.");
            }

            return ValidationResult.Valid();
        }

        public static ValidationResult Validate(TrainingSkillData skill)
        {
            if (string.IsNullOrEmpty(skill.Id))
                return ValidationResult.Invalid("No Id - a Skill needs one to be scored.");

            if (!skill.Scaled.Enabled)
                return ValidationResult.Invalid("Scaled score is disabled - a Skill is reported by its scaled score.");

            return ValidationResult.Valid();
        }

        public static ValidationResult Validate(TrainingRewardData reward)
        {
            if (string.IsNullOrEmpty(reward.Id))
                return ValidationResult.Invalid("No Id - a Reward needs one to be scored.");

            if (!reward.Raw.Enabled)
                return ValidationResult.Invalid("Raw value is disabled - a Reward is reported by the points it awards.");

            return ValidationResult.Valid();
        }

        public static ValidationResult Validate(TrainingBadgeData badge)
        {
            if (badge.UnlockCondition == null || badge.UnlockCondition.Entries.Count == 0)
                return ValidationResult.Invalid("No unlock condition - this badge slot can never trigger on its own.");

            return ValidationResult.Valid();
        }

        public static ValidationResult Validate(TrainingInteractionData interaction)
        {
            if (string.IsNullOrEmpty(interaction.Id))
                return ValidationResult.Invalid("No Id - an Interaction is triggered by its Id.");

            return ValidationResult.Valid();
        }
    }
}
