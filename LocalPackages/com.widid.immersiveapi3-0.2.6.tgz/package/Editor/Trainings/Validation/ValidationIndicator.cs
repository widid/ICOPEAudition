using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Validation
{
    /// <summary>
    /// The green/red dot shown next to an authored entry's header, with the unmet rule as its
    /// tooltip. Styled in code rather than through Common.uss so it can be dropped into any panel's
    /// tree - including ones cloned from a UXML that doesn't import that stylesheet.
    /// </summary>
    public class ValidationIndicator : VisualElement
    {
        const int Diameter = 10;

        public ValidationIndicator()
        {
            style.width = Diameter;
            style.height = Diameter;
            style.minWidth = Diameter;
            style.flexShrink = 0;

            // The header row is a centering flex row that also contains the entry's whole expanded
            // body (see .wid-entry-header / each *Entry.uxml), so without this the dot drifts to the
            // vertical middle of an open entry instead of staying on its title line.
            style.alignSelf = Align.FlexStart;
            style.marginLeft = 2;
            style.marginRight = 4;
            style.marginTop = 5;
            style.borderTopLeftRadius = Diameter;
            style.borderTopRightRadius = Diameter;
            style.borderBottomLeftRadius = Diameter;
            style.borderBottomRightRadius = Diameter;
        }

        public void Set(ValidationResult result)
        {
            style.backgroundColor = result.Ok ? ValidationColors.Ok : ValidationColors.Error;
            tooltip = result.Message;
        }
    }
}
