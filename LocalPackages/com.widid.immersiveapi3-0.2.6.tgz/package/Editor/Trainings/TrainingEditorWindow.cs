using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using GraphProcessor;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Networking.Authentification;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.Remote;

namespace WiDiD.ImmersiveAPI.Editor.Trainings
{
    /// <summary>
    /// Editor-only tool to create local <see cref="TrainingSO"/> assets (the "Formation"
    /// equivalent from the old ImmersiveAPI system): enforces a project-wide unique Id and lets an
    /// optional Module Id be set, matched against UserSessionSO.Data.ModuleArgument at launch to
    /// pick which Training to start. Each row's "Edit GameFlow" button opens (lazily creating) the
    /// Training's nodal Strategies graph - see WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow.
    ///
    /// Each row also links the local Training to a backend catalog Training
    /// (<see cref="TrainingData.RemoteTrainingId"/>, picked from the same backend fetch the
    /// runtime Demo's training selection uses) and can "activate" it (see ActivateTraining),
    /// which fills both <see cref="UserSessionData.TrainingId"/> - the field that decides where
    /// debug statement-sends actually post to - and <see cref="UserSessionData.ModuleArgument"/>
    /// (from this Training's ModuleId) - the field TrainingRuntime.ResolveActiveTraining matches
    /// to decide which local Training's GameFlow actually runs. Whichever row's RemoteTrainingId
    /// currently matches TrainingId is highlighted as active; RefreshTrainingsList keeps one row
    /// active by default whenever at least one Training has been linked to a remote id.
    /// </summary>
    public class TrainingEditorWindow : EditorWindow
    {
        const string LangCode = "en";

        // Catalogs are authored in a separate window (TrainingCatalogWindow), so a button's warning
        // sign can't just be set while building its row - it would go stale the moment something is
        // fixed over there. Polled instead: there's no change notification to hook, same reasoning
        // as SessionInfoPanelController's own refresh loop.
        const int CatalogWarningRefreshMs = 500;

        static readonly Regex IdPattern = new(@"^[A-Za-z0-9_-]+$");
        static string TrainingsFolderPath => $"Assets/Resources/{TrainingSO.ResourcesFolder}";

        VisualElement createPanel;
        TextField idField;
        TextField moduleIdField;
        Label statusLabel;
        Foldout errorFoldout;
        Label errorDetailsLabel;
        ScrollView trainingsList;
        VisualTreeAsset entryTemplate;

        ITrainingService trainingService;
        ITrainingLocalizationService localizationService;
        UserSessionSO sessionAsset;
        List<TrainingDTO> cachedRemoteTrainings = new();

        readonly List<Action> catalogWarningRefreshers = new();

        [MenuItem("WiDiD_API/ImmersiveAPI/Training Editor")]
        public static void ShowWindow()
        {
            TrainingEditorWindow window = GetWindow<TrainingEditorWindow>();
            window.titleContent = new GUIContent("Training Editor");
            window.minSize = new Vector2(360, 320);
        }

        public void CreateGUI()
        {
            trainingService = new TrainingService(new ImmersiveLogger());
            localizationService = new TrainingLocalizationService();
            sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.TrainingEntry;

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.TrainingEditorWindow;
            visualTree.CloneTree(rootVisualElement);

            createPanel = rootVisualElement.Q<VisualElement>("CreatePanel");
            idField = rootVisualElement.Q<TextField>("TextFieldId");
            moduleIdField = rootVisualElement.Q<TextField>("TextFieldModuleId");
            statusLabel = rootVisualElement.Q<Label>("LabelStatus");
            errorFoldout = rootVisualElement.Q<Foldout>("FoldoutErrorDetails");
            errorDetailsLabel = rootVisualElement.Q<Label>("LabelErrorDetails");
            trainingsList = rootVisualElement.Q<ScrollView>("TrainingsList");

            // Responsive grid, not a vertical list - cards (TrainingEntry.uxml) wrap onto more rows
            // as the window narrows instead of one long column.
            trainingsList.contentContainer.style.flexDirection = FlexDirection.Row;
            trainingsList.contentContainer.style.flexWrap = Wrap.Wrap;

            rootVisualElement.Q<Button>("ButtonToggleCreatePanel").clicked += () => SetCreatePanelVisible(createPanel.resolvedStyle.display == DisplayStyle.None);
            rootVisualElement.Q<Button>("ButtonCreateTraining").clicked += OnCreateClicked;
            rootVisualElement.Q<Button>("ButtonRefreshRemoteTrainings").clicked += RefreshRemoteTrainingsAsync;

            RefreshTrainingsList();
            RefreshRemoteTrainingsAsync();

            rootVisualElement.schedule.Execute(RefreshCatalogWarnings).Every(CatalogWarningRefreshMs);
        }

        /// <summary>Shows a short summary in LabelStatus and the full exception in the collapsible FoldoutErrorDetails, at the bottom of the window.</summary>
        void ShowError(string summary, string detail)
        {
            statusLabel.text = summary;
            errorDetailsLabel.text = detail;
            errorFoldout.style.display = DisplayStyle.Flex;
        }

        /// <summary>Shows a plain (non-error) status message and hides FoldoutErrorDetails.</summary>
        void ClearStatus(string message = "")
        {
            statusLabel.text = message;
            errorFoldout.style.display = DisplayStyle.None;
        }

        async void RefreshRemoteTrainingsAsync()
        {
            if (sessionAsset == null || string.IsNullOrEmpty(sessionAsset.Data.DecodedToken))
            {
                ClearStatus("Log in via the Debug Session window to link remote trainings.");
                return;
            }

            try
            {
                List<TrainingDTO> trainings = await trainingService.FetchTrainings(sessionAsset.Data.TargetUrl, sessionAsset.Data.DecodedToken, LangCode);
                cachedRemoteTrainings = trainings ?? new List<TrainingDTO>();
                ClearStatus();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[TrainingEditorWindow] Failed to fetch remote trainings: {exception.Message}");
                ShowError("Failed to fetch remote trainings.", exception.ToString());
            }

            RefreshTrainingsList();
        }

        void SetCreatePanelVisible(bool visible)
        {
            createPanel.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            if (visible)
                idField.Focus();
        }

        void OnCreateClicked()
        {
            string id = idField.value != null ? idField.value.Trim() : string.Empty;
            string moduleId = moduleIdField.value != null ? moduleIdField.value.Trim() : string.Empty;

            List<TrainingSO> existingTrainings = FindAllTrainings();

            if (!ValidateId(id, existingTrainings, out string error))
            {
                ClearStatus(error);
                return;
            }

            AssetFolders.EnsureExists(TrainingsFolderPath);

            TrainingSO training = ScriptableObject.CreateInstance<TrainingSO>();
            training.Data.Id = id;
            training.Data.ModuleId = moduleId;

            AssetDatabase.CreateAsset(training, $"{TrainingsFolderPath}/{id}.asset");
            AssetDatabase.SaveAssets();

            idField.value = string.Empty;
            moduleIdField.value = string.Empty;
            SetCreatePanelVisible(false);
            ClearStatus($"Created '{id}'.");

            EditorGUIUtility.PingObject(training);
            RefreshTrainingsList();
        }

        static bool ValidateId(string id, List<TrainingSO> existingTrainings, out string error)
        {
            if (string.IsNullOrEmpty(id))
            {
                error = "Id is required.";
                return false;
            }

            if (!IdPattern.IsMatch(id))
            {
                error = "Id can only contain letters, digits, underscores and hyphens.";
                return false;
            }

            foreach (TrainingSO existing in existingTrainings)
            {
                if (string.Equals(existing.Data.Id, id, StringComparison.OrdinalIgnoreCase))
                {
                    error = $"Id '{id}' is already used by another Training in this project.";
                    return false;
                }
            }

            error = null;
            return true;
        }

        void RefreshTrainingsList()
        {
            trainingsList.Clear();
            catalogWarningRefreshers.Clear();

            List<TrainingSO> trainings = FindAllTrainings();
            EnsureActiveTraining(trainings);

            foreach (TrainingSO training in trainings)
            {
                trainingsList.Add(BuildTrainingRow(training));
            }
        }

        /// <summary>
        /// There must always be an active training if at least one exists. If none of them is
        /// currently active (per IsActive), fall back to the first one that's already linked to a
        /// remote training - nothing to meaningfully activate if none are linked yet.
        /// </summary>
        void EnsureActiveTraining(List<TrainingSO> trainings)
        {
            if (sessionAsset == null || trainings.Count == 0 || trainings.Any(t => IsActive(t)))
                return;

            TrainingSO fallback = trainings.FirstOrDefault(t => !string.IsNullOrEmpty(t.Data.RemoteTrainingId));
            if (fallback == null)
                return;

            ActivateTraining(fallback);
        }

        /// <summary>
        /// Fills both halves of "which training is active": TrainingId (matched against
        /// RemoteTrainingId - see IsActive) decides where debug statement-sends post to, and
        /// ModuleArgument (matched against ModuleId - see TrainingRuntime.ResolveActiveTraining)
        /// decides which local Training's GameFlow actually runs. Keeping them in lockstep means
        /// activating a training here is enough on its own - no separate ModuleId wiring needed.
        /// </summary>
        void ActivateTraining(TrainingSO training)
        {
            sessionAsset.Data.TrainingId = training.Data.RemoteTrainingId;
            sessionAsset.Data.ModuleArgument = training.Data.ModuleId;
            EditorUtility.SetDirty(sessionAsset);
        }

        bool IsActive(TrainingSO training)
        {
            return sessionAsset != null
                && !string.IsNullOrEmpty(training.Data.RemoteTrainingId)
                && training.Data.RemoteTrainingId == sessionAsset.Data.TrainingId;
        }

        VisualElement BuildTrainingRow(TrainingSO training)
        {
            VisualElement row = entryTemplate.CloneTree();

            bool isActive = IsActive(training);
            if (isActive)
                row.AddToClassList("wid-list-row-active");

            row.Q<Label>("LabelId").text = training.Data.Id;
            row.Q<Label>("LabelModuleId").text = string.IsNullOrEmpty(training.Data.ModuleId) ? "-" : training.Data.ModuleId;

            WireRemoteTrainingDropdown(row, training);

            Button fetchLocalizationButton = row.Q<Button>("ButtonFetchLocalization");
            fetchLocalizationButton.clicked += () => _ = FetchAndCacheLocalizationAsync(training);
            fetchLocalizationButton.SetEnabled(!string.IsNullOrEmpty(training.Data.RemoteTrainingId));

            row.Q<Button>("ButtonSelect").clicked += () => EditorGUIUtility.PingObject(training);

            // No text - checked and disabled once active (matches EnsureActiveTraining's "always
            // exactly one active, no explicit deactivate" invariant), otherwise unchecked and
            // clickable to activate. SetValueWithoutNotify since ticking it is what triggers
            // OnSetActiveClicked, not the other way around.
            Toggle activeToggle = row.Q<Toggle>("ToggleSetActive");
            activeToggle.SetValueWithoutNotify(isActive);
            activeToggle.SetEnabled(!isActive && !string.IsNullOrEmpty(training.Data.RemoteTrainingId));
            activeToggle.RegisterValueChangedCallback(evt =>
            {
                if (evt.newValue)
                    OnSetActiveClicked(training);
                else
                    activeToggle.SetValueWithoutNotify(true);
            });

            row.Q<Button>("ButtonGameFlow").clicked += () => OpenGameFlow(training);
            row.Q<Button>("ButtonPerformances").clicked += () => TrainingCatalogWindow.Open(training, TrainingCatalogTab.Performances);
            row.Q<Button>("ButtonSkills").clicked += () => TrainingCatalogWindow.Open(training, TrainingCatalogTab.Skills);
            row.Q<Button>("ButtonInteractions").clicked += () => TrainingCatalogWindow.Open(training, TrainingCatalogTab.Interactions);
            row.Q<Button>("ButtonBadges").clicked += () => TrainingCatalogWindow.Open(training, TrainingCatalogTab.Badges);
            row.Q<Button>("ButtonRewards").clicked += () => TrainingCatalogWindow.Open(training, TrainingCatalogTab.Rewards);
            row.Q<Button>("ButtonDelete").clicked += () => OnDeleteClicked(training);

            row.Q<Image>("IconGameFlow").image = ImmersiveEditorUIConfigLoader.Assets.IconGameFlow;
            row.Q<Image>("IconPerformances").image = ImmersiveEditorUIConfigLoader.Assets.IconPerformances;
            row.Q<Image>("IconSkills").image = ImmersiveEditorUIConfigLoader.Assets.IconSkills;
            row.Q<Image>("IconInteractions").image = ImmersiveEditorUIConfigLoader.Assets.IconInteractions;
            row.Q<Image>("IconBadges").image = ImmersiveEditorUIConfigLoader.Assets.IconBadges;
            row.Q<Image>("IconRewards").image = ImmersiveEditorUIConfigLoader.Assets.IconRewards;

            WireCatalogWarning(row, "ButtonPerformances", () => TrainingCatalogValidation.HasInvalidPerformances(training));
            WireCatalogWarning(row, "ButtonSkills", () => TrainingCatalogValidation.HasInvalidSkills(training));
            WireCatalogWarning(row, "ButtonBadges", () => TrainingCatalogValidation.HasInvalidBadges(training));
            WireCatalogWarning(row, "ButtonRewards", () => TrainingCatalogValidation.HasInvalidRewards(training));

            return row;
        }

        // Appended inside the catalog button itself (after its icon and label - .wid-icon-button is
        // a centered flex row), so a Training's card shows which of its catalogs needs attention
        // without opening any of them.
        void WireCatalogWarning(VisualElement row, string buttonName, Func<bool> hasInvalid)
        {
            ValidationWarningSign sign = new ValidationWarningSign("This catalog has entries that are missing something - open it to see which.");
            row.Q<Button>(buttonName).Add(sign);

            void Refresh() => sign.SetVisible(hasInvalid());

            Refresh();
            catalogWarningRefreshers.Add(Refresh);
        }

        void RefreshCatalogWarnings()
        {
            foreach (Action refresh in catalogWarningRefreshers)
                refresh();
        }

        void WireRemoteTrainingDropdown(VisualElement row, TrainingSO training)
        {
            const string noneChoice = "<None>";

            DropdownField dropdown = row.Q<DropdownField>("DropdownRemoteTraining");

            List<string> choices = new() { noneChoice };
            choices.AddRange(cachedRemoteTrainings.Select(remote => remote.Training != null ? remote.Training.Title : $"Training {remote.Id}"));
            dropdown.choices = choices;

            int remoteIndex = cachedRemoteTrainings.FindIndex(remote => remote.Id.ToString() == training.Data.RemoteTrainingId);
            dropdown.SetValueWithoutNotify(remoteIndex >= 0 ? choices[remoteIndex + 1] : noneChoice);

            dropdown.RegisterValueChangedCallback(async evt =>
            {
                int selectedIndex = dropdown.index - 1;
                training.Data.RemoteTrainingId = selectedIndex >= 0 ? cachedRemoteTrainings[selectedIndex].Id.ToString() : string.Empty;
                EditorUtility.SetDirty(training);
                AssetDatabase.SaveAssets();

                if (!string.IsNullOrEmpty(training.Data.RemoteTrainingId))
                    await FetchAndCacheLocalizationAsync(training);

                RefreshTrainingsList();
            });
        }

        void OnSetActiveClicked(TrainingSO training)
        {
            if (sessionAsset == null)
            {
                ClearStatus($"UserSessionSO asset could not be found at Resources/{UserSessionSO.ResourcePath}.");
                return;
            }

            if (string.IsNullOrEmpty(training.Data.RemoteTrainingId))
            {
                ClearStatus($"Link '{training.Data.Id}' to a remote training first.");
                return;
            }

            ActivateTraining(training);
            ClearStatus($"'{training.Data.Id}' is now the active training.");

            RefreshTrainingsList();
        }

        async Task FetchAndCacheLocalizationAsync(TrainingSO training)
        {
            if (sessionAsset == null || string.IsNullOrEmpty(sessionAsset.Data.DecodedToken))
            {
                ClearStatus("Log in via the Debug Session window to fetch training localization.");
                return;
            }

            if (string.IsNullOrEmpty(training.Data.RemoteTrainingId))
                return;

            string url = $"{sessionAsset.Data.TargetUrl}trainings/{training.Data.RemoteTrainingId}";

            try
            {
                TrainingLocalizationResult result = await localizationService.Fetch(url, sessionAsset.Data.DecodedToken);

                training.Data.LocalizedName = result.NameTranslations;
                training.Data.LocalizedDescription = result.DescriptionTranslations;
                EditorUtility.SetDirty(training);
                AssetDatabase.SaveAssets();
                ClearStatus($"Fetched localization for '{training.Data.Id}'.");
            }
            catch (Exception exception)
            {
                Debug.LogError($"[TrainingEditorWindow] Failed to fetch training localization: {exception.Message}");
                ShowError($"Failed to fetch localization for '{training.Data.Id}'.", exception.ToString());
            }
        }

        void OnDeleteClicked(TrainingSO training)
        {
            string id = training.Data.Id;
            bool confirmed = EditorUtility.DisplayDialog(
                "Delete Training",
                $"Delete training '{id}'? This also deletes its GameFlow graph and cannot be undone.",
                "Yes",
                "No");

            if (!confirmed)
                return;

            // Before the Training itself - TrainingGraphAssets resolves the companion asset by
            // its owningTraining reference, so it has to still be loadable.
            TrainingGraphAssets.Delete(training);

            AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(training));
            AssetDatabase.SaveAssets();

            ClearStatus($"Deleted '{id}'.");
            RefreshTrainingsList();
        }

        static void OpenGameFlow(TrainingSO training)
        {
            bool created = TrainingGraphAssets.Find(training) == null;
            GameFlowGraph gameFlowGraph = TrainingGraphAssets.FindOrCreate(training);

            if (created)
            {
                // A training's GameFlow must always have at least one strategy - see
                // GameFlowGraphView, which also blocks deleting the last one. This cascades into a
                // default step too, via GameFlowGraph's own onGraphChanges handling.
                gameFlowGraph.AddNode(BaseNode.CreateFromType<StrategyNode>(Vector2.zero));
            }

            GameFlowGraphWindow.Open(gameFlowGraph, $"GameFlow - {training.Data.Id}");
        }

        static List<TrainingSO> FindAllTrainings()
        {
            string[] guids = AssetDatabase.FindAssets("t:TrainingSO");
            List<TrainingSO> trainings = new(guids.Length);

            foreach (string guid in guids)
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training != null)
                    trainings.Add(training);
            }

            return trainings;
        }
    }
}
