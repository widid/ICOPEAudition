using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Skills
{
    /// <summary>
    /// Renders a SkillReference field as a "Training/Skills/Name" dropdown instead of a raw id text
    /// field, scanning every TrainingSO asset in the project for its Skills (Simulation-scoped only,
    /// matching TrainingSkillData's current scope) - same convention as
    /// StepReferenceDrawer/StrategyReferenceDrawer.
    /// </summary>
    [CustomPropertyDrawer(typeof(SkillReference))]
    public class SkillReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "skillId";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingSkillData skill in training.Data.GameFlow.Skills)
                    results.Add(new TrainingReferenceOption(skill.Id, $"{training.Data.Id}/Skills/{skill.Name.GetDisplayName(skill.Id)}"));
            }

            return results;
        }
    }
}
