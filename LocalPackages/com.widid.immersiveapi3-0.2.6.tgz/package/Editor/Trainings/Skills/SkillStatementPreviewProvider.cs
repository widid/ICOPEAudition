using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Skills
{
    /// <summary>
    /// Exposes every Skill in the project (Simulation-scoped only, matching TrainingSkillData's
    /// current scope - see there) as a StatementPreviewWindow target, discovered automatically via
    /// IStatementPreviewProvider, same convention as GameFlowStatementPreviewProvider.
    /// </summary>
    public class SkillStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);

                foreach (TrainingSkillData skill in training.Data.GameFlow.Skills)
                    targets.Add(new SkillPreviewTarget(new[] { training.Data.Id, "Skills", skill.Name.GetDisplayName(skill.Id) }, simulation, skill));
            }

            return targets;
        }
    }
}
