using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Skills
{
    /// <summary>Previews the three statements a Skill can send (see SkillStatementFactory) - progressed/scored/mastered all carry the same data, just under a different verb.</summary>
    class SkillPreviewTarget : IStatementPreviewTarget
    {
        static readonly string[] VerbNames = { "Progressed", "Scored", "Mastered" };

        readonly IReadOnlyList<string> pathSegments;
        readonly Simulation simulation;
        readonly TrainingSkillData data;

        public SkillPreviewTarget(IReadOnlyList<string> pathSegments, Simulation simulation, TrainingSkillData data)
        {
            this.pathSegments = pathSegments;
            this.simulation = simulation;
            this.data = data;
        }

        public string FamilyName => "Skills";
        public IReadOnlyList<string> PathSegments => pathSegments;
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Progressed" => (Verbs.Progressed, SkillStatementFactory.Progressed(simulation, data)),
                "Scored" => (Verbs.Scored, SkillStatementFactory.Scored(simulation, data)),
                "Mastered" => (Verbs.Mastered, SkillStatementFactory.Mastered(simulation, data)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
