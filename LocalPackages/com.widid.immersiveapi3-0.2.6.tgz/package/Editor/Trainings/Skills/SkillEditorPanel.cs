using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Networking.Authentification;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Trainings.Remote;
using WiDiD.Localization;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Skills
{
    /// <summary>
    /// Authoring tool for a Training's Skill catalog (see TrainingSkillData/SkillStatementFactory,
    /// xAPI-Statements/Skill/README.md). Simulation-scoped only for now - TrainingGameFlowData.Skills
    /// is a flat list, matching how TrainingPerformanceData looked before Strategy/Step containers
    /// were added; extending Skill to those scopes later is the same small diff
    /// PerformanceEditorWindow already went through, not a redesign. UI Toolkit window
    /// (SkillEditorWindow.uxml/SkillEntry.uxml + shared Packages/com.widid.immersiveapi/Editor/UI/
    /// Common.uss/LanguageRow.uxml), same conventions as PerformanceEditorWindow/TrainingEditorWindow.
    /// </summary>
    public class SkillEditorPanel
    {
        const string LangCode = "en";

        TrainingSO training;
        ObjectField trainingField;
        ScrollView contentScroll;
        VisualTreeAsset entryTemplate;
        VisualTreeAsset languageRowTemplate;

        UserSessionSO sessionAsset;
        ISkillCatalogService skillCatalogService;
        List<PrimarySkillDTO> cachedPrimarySkills = new();

        // Keyed by a stable string id, same reasoning as PerformanceEditorWindow.foldouts - never by
        // object reference, and each Foldout also gets a matching viewDataKey so UI Toolkit's own
        // built-in persistence can't collide across sibling entries that share the same template.
        readonly Dictionary<string, bool> foldouts = new();

        readonly TrainingValidationView validation = new();

        public VisualElement CreateView()
        {
            VisualElement root = new();

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.SkillEntry;
            languageRowTemplate = ImmersiveEditorUIConfigLoader.Assets.LanguageRow;

            sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            skillCatalogService = new SkillCatalogService(new ImmersiveLogger());

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.SkillEditorWindow;
            visualTree.CloneTree(root);

            trainingField = root.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            root.Q<Button>("ButtonRefreshSkillCatalog").clicked += RefreshSkillCatalogAsync;

            contentScroll = root.Q<ScrollView>("ContentScroll");

            RefreshSkillCatalogAsync();
            Rebuild();

            return root;
        }

        // Populates each entry's sub-category picker (see WireCategories) - fire-and-forget from
        // CreateGUI/the Refresh button, same pattern as TrainingEditorWindow.RefreshRemoteTrainingsAsync.
        async void RefreshSkillCatalogAsync()
        {
            if (sessionAsset == null || string.IsNullOrEmpty(sessionAsset.Data.DecodedToken))
                return;

            try
            {
                SkillCatalogDTO catalog = await skillCatalogService.FetchSkillCatalog(sessionAsset.Data.TargetUrl, sessionAsset.Data.DecodedToken, LangCode);
                cachedPrimarySkills = catalog?.PrimarySkills ?? new List<PrimarySkillDTO>();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[SkillEditorWindow] Failed to fetch primary skills: {exception.Message}");
            }

            EditorApplication.delayCall += Rebuild;
        }

        public void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            Rebuild();
        }

        void Rebuild()
        {
            if (contentScroll == null)
                return;

            contentScroll.Clear();
            validation.Clear();

            if (training == null)
            {
                contentScroll.Add(new Label("Pick a Training to edit its Skill catalog.") { style = { opacity = 0.7f, marginTop = 8 } });
                return;
            }

            HashSet<string> duplicateIds = DuplicateIdFinder.Find(training.Data.GameFlow.Skills, skill => skill.Id);

            Foldout simulationFoldout = CreateFoldout($"simulation:{training.Data.Id}", $"Simulation: {training.Data.Id}");
            simulationFoldout.AddToClassList("wid-foldout-level-simulation");
            simulationFoldout.Add(BuildSkillGroup(training.Data.GameFlow.Skills, duplicateIds));
            validation.AddSection(simulationFoldout, () => TrainingCatalogValidation.HasInvalidSkills(training));
            contentScroll.Add(simulationFoldout);
        }

        Foldout CreateFoldout(string key, string text, bool defaultExpanded = true)
        {
            bool expanded = foldouts.TryGetValue(key, out bool state) ? state : defaultExpanded;
            Foldout foldout = new() { text = text, value = expanded, viewDataKey = key };
            foldout.AddToClassList("wid-foldout-spaced");
            foldout.RegisterValueChangedCallback(evt => foldouts[key] = evt.newValue);
            return foldout;
        }

        VisualElement BuildSkillGroup(List<TrainingSkillData> skills, HashSet<string> duplicateIds)
        {
            VisualElement container = new();
            container.AddToClassList("wid-depth-0");

            foreach (TrainingSkillData skill in skills)
                container.Add(BuildSkillEntry(skill, skills, duplicateIds));

            VisualElement addRow = new();
            addRow.AddToClassList("wid-button-center-row");
            Button addButton = new(() =>
            {
                TrainingSkillData newSkill = new() { Id = Guid.NewGuid().ToString("N").Substring(0, 8) };
                skills.Add(newSkill);
                foldouts[$"skill:{newSkill.Id}"] = true;
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            })
            { text = "+ Add Skill" };
            addRow.Add(addButton);
            container.Add(addRow);

            return container;
        }

        VisualElement BuildSkillEntry(TrainingSkillData skill, List<TrainingSkillData> currentContainer, HashSet<string> duplicateIds)
        {
            string skillFoldoutKey = $"skill:{skill.Id}";

            VisualElement wrapper = entryTemplate.CloneTree();
            wrapper.AddToClassList("wid-depth-1");

            Foldout foldout = wrapper.Q<Foldout>("FoldoutHeader");
            foldout.viewDataKey = skillFoldoutKey;
            foldout.text = BuildHeaderText(skill);
            foldout.value = foldouts.TryGetValue(skillFoldoutKey, out bool expanded) ? expanded : false;
            foldout.RegisterValueChangedCallback(evt => foldouts[skillFoldoutKey] = evt.newValue);

            Label previewLabel = wrapper.Q<Label>("LabelPreview");
            previewLabel.text = BuildValuePreview(skill) ?? string.Empty;

            validation.AddIndicator(wrapper.Q<VisualElement>("HeaderRow"), foldout, () => TrainingEntryValidator.Validate(skill));

            Button deleteButton = wrapper.Q<Button>("ButtonDelete");
            deleteButton.clicked += () =>
            {
                string idLabel = string.IsNullOrEmpty(skill.Id) ? "(no id)" : skill.Id;
                bool confirmed = EditorUtility.DisplayDialog("Delete Skill", $"Delete skill '{idLabel}'? This cannot be undone.", "Yes", "No");
                if (!confirmed)
                    return;

                currentContainer.Remove(skill);
                foldouts.Remove(skillFoldoutKey);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            };

            if (!string.IsNullOrEmpty(skill.Id) && duplicateIds.Contains(skill.Id))
            {
                HelpBox duplicateWarning = new($"Duplicate Id '{skill.Id}' - each Skill needs a unique Id within this Training.", HelpBoxMessageType.Error);
                wrapper.Q<VisualElement>("DuplicateWarningSlot").Add(duplicateWarning);
            }

            void RefreshHeader()
            {
                foldout.text = BuildHeaderText(skill);
                previewLabel.text = BuildValuePreview(skill) ?? string.Empty;
                validation.Refresh();
            }

            TextField idField = wrapper.Q<TextField>("FieldId");
            idField.value = skill.Id;
            idField.RegisterValueChangedCallback(evt =>
            {
                skill.Id = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshHeader();
            });

            WireLocalizedSection(wrapper, $"{skillFoldoutKey}:name", "FoldoutName", "NameRows", "ButtonAddNameLanguage", skill.Name, RefreshHeader);
            WireLocalizedSection(wrapper, $"{skillFoldoutKey}:description", "FoldoutDescription", "DescriptionRows", "ButtonAddDescriptionLanguage", skill.Description);

            WireCategories(wrapper, skillFoldoutKey, skill);

            WireValueSourceRow(wrapper, "Scaled", skill.Scaled, RefreshHeader);

            return wrapper;
        }

        static string BuildHeaderText(TrainingSkillData skill)
        {
            string idLabel = string.IsNullOrEmpty(skill.Id) ? "(no id)" : skill.Id;
            string nameLabel = skill.Name.GetDisplayName("(no name)");
            return $"{idLabel} - {nameLabel}";
        }

        static string BuildValuePreview(TrainingSkillData skill)
        {
            float? scaled = ResolvePreview(skill.Scaled);
            return scaled.HasValue ? scaled.Value.ToString("0.##") : null;
        }

        static float? ResolvePreview(PerformanceValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<float>(target, source.ReflectedSource.Data);
        }

        void WireCategories(VisualElement root, string skillFoldoutKey, TrainingSkillData skill)
        {
            string categoriesFoldoutKey = $"{skillFoldoutKey}:categories";
            Foldout categoriesFoldout = root.Q<Foldout>("FoldoutCategories");
            categoriesFoldout.viewDataKey = categoriesFoldoutKey;
            categoriesFoldout.value = foldouts.TryGetValue(categoriesFoldoutKey, out bool expanded) ? expanded : categoriesFoldout.value;
            categoriesFoldout.RegisterValueChangedCallback(evt => foldouts[categoriesFoldoutKey] = evt.newValue);

            // Resolved via DropdownSubCategoryPicker below, not typed directly - the picker is what
            // actually writes into skill.SubCategoryId; this just displays the result.
            TextField subCategoryIdField = root.Q<TextField>("FieldSubCategoryId");
            subCategoryIdField.value = skill.SubCategoryId;
            subCategoryIdField.SetEnabled(false);

            DropdownField subCategoryPicker = root.Q<DropdownField>("DropdownSubCategoryPicker");

            void RefreshSubCategoryPicker()
            {
                (string name, string idNumber)[] options = FilterPrimarySkills(skill.MainCategoryKey);
                List<string> choices = options.Select(option => option.name).ToList();
                if (choices.Count == 0)
                    choices.Add("<no skills fetched - click Refresh Skill Catalog>");

                subCategoryPicker.choices = choices;

                int currentIndex = Array.FindIndex(options, option => option.idNumber == skill.SubCategoryId);
                subCategoryPicker.SetValueWithoutNotify(currentIndex >= 0 ? choices[currentIndex] : choices[0]);
            }

            subCategoryPicker.RegisterValueChangedCallback(evt =>
            {
                (string name, string idNumber)[] options = FilterPrimarySkills(skill.MainCategoryKey);
                int index = Array.FindIndex(options, option => option.name == evt.newValue);
                if (index < 0)
                    return;

                skill.SubCategoryId = options[index].idNumber;
                subCategoryIdField.value = skill.SubCategoryId;
                EditorUtility.SetDirty(training);
            });

            DropdownField mainCategoryDropdown = root.Q<DropdownField>("DropdownMainCategory");
            List<string> mainCategoryChoices = SkillCategories.All.Keys.ToList();
            mainCategoryDropdown.choices = mainCategoryChoices;
            mainCategoryDropdown.SetValueWithoutNotify(mainCategoryChoices.Contains(skill.MainCategoryKey) ? skill.MainCategoryKey : mainCategoryChoices.FirstOrDefault());
            mainCategoryDropdown.RegisterValueChangedCallback(evt =>
            {
                skill.MainCategoryKey = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshSubCategoryPicker();
            });

            RefreshSubCategoryPicker();

            WireLocalizedSection(root, $"{skillFoldoutKey}:subcategoryname", "FoldoutSubCategoryName", "SubCategoryNameRows", "ButtonAddSubCategoryNameLanguage", skill.SubCategoryName);
            WireLocalizedSection(root, $"{skillFoldoutKey}:subcategorydescription", "FoldoutSubCategoryDescription", "SubCategoryDescriptionRows", "ButtonAddSubCategoryDescriptionLanguage", skill.SubCategoryDescription);
        }

        // (display name, id number) for every primarySkill matching the Main Category's prefix -
        // the id number is the part after "soft_skill_"/"hard_skill_" in skillType, per the
        // SkillsEndpoint response, never the response's own numeric "id" field.
        (string name, string idNumber)[] FilterPrimarySkills(string mainCategoryKey)
        {
            string prefix = mainCategoryKey == nameof(SkillCategories.HardSkill) ? "hard_skill" : "soft_skill";
            string prefixWithUnderscore = $"{prefix}_";

            return cachedPrimarySkills
                .Where(primarySkill => !string.IsNullOrEmpty(primarySkill.SkillType) && primarySkill.SkillType.StartsWith(prefixWithUnderscore, StringComparison.OrdinalIgnoreCase))
                .Select(primarySkill => (primarySkill.Name, idNumber: primarySkill.SkillType.Substring(prefixWithUnderscore.Length)))
                .ToArray();
        }

        void WireLocalizedSection(VisualElement root, string foldoutKey, string foldoutName, string rowsContainerName, string addButtonName, LanguageDictionary dictionary, Action onChanged = null)
        {
            Foldout sectionFoldout = root.Q<Foldout>(foldoutName);
            sectionFoldout.viewDataKey = foldoutKey;
            sectionFoldout.value = foldouts.TryGetValue(foldoutKey, out bool expanded) ? expanded : sectionFoldout.value;
            sectionFoldout.RegisterValueChangedCallback(evt => foldouts[foldoutKey] = evt.newValue);

            VisualElement rowsContainer = root.Q<VisualElement>(rowsContainerName);

            void RebuildRows()
            {
                rowsContainer.Clear();
                LanguageDictionary.LanguageKey[] keys = dictionary.LanguageKeys;

                for (int i = 0; i < keys.Length; i++)
                {
                    int index = i;

                    languageRowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    DropdownField languagePopup = row.Q<DropdownField>("DropdownLanguageCode");
                    languagePopup.choices = LanguageDictionary.AvailableLanguages.ToList();
                    languagePopup.index = keys[index].localizationIndex;
                    languagePopup.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        int newLanguageIndex = Array.IndexOf(LanguageDictionary.AvailableLanguages, evt.newValue);
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = newLanguageIndex, value = current[index].value };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    TextField valueField = row.Q<TextField>("FieldLanguageValue");
                    valueField.value = keys[index].value;
                    valueField.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = current[index].localizationIndex, value = evt.newValue };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    Button removeButton = row.Q<Button>("ButtonRemoveLanguage");
                    removeButton.clicked += () =>
                    {
                        dictionary.LanguageKeys = dictionary.LanguageKeys.Where((_, keyIndex) => keyIndex != index).ToArray();
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                        RebuildRows();
                    };
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>(addButtonName);
            addButton.clicked += () =>
            {
                int nextLanguage = NextAvailableLanguageIndex(dictionary);
                dictionary.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = nextLanguage, value = string.Empty });
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
                RebuildRows();
            };
        }

        static int NextAvailableLanguageIndex(LanguageDictionary dictionary)
        {
            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (!dictionary.LanguageKeys.Any(key => key.localizationIndex == i))
                    return i;
            }

            return 0;
        }

        void WireValueSourceRow(VisualElement root, string namePrefix, PerformanceValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            FloatField fixedField = root.Q<FloatField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedFloatSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedFloatSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }
    }
}
