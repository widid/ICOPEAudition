using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Rewards
{
    /// <summary>
    /// Exposes every Reward in the project as a StatementPreviewWindow target, discovered
    /// automatically via IStatementPreviewProvider, same convention as
    /// PerformanceStatementPreviewProvider/BadgeStatementPreviewProvider.
    /// </summary>
    public class RewardStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);

                foreach (TrainingRewardData reward in training.Data.GameFlow.Rewards)
                    targets.Add(new RewardPreviewTarget(new[] { training.Data.Id, "Rewards", reward.Name.GetDisplayName(reward.Id) }, simulation, reward));
            }

            return targets;
        }
    }
}
