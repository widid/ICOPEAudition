using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Rewards
{
    /// <summary>Previews the single `scored` statement a Reward can send (see RewardStatementFactory), the same statement RewardRecorder sends whenever host game code calls TrainingRuntime.ScoreReward.</summary>
    class RewardPreviewTarget : IStatementPreviewTarget
    {
        static readonly string[] VerbNames = { "Scored" };

        readonly IReadOnlyList<string> pathSegments;
        readonly Simulation simulation;
        readonly TrainingRewardData data;

        public RewardPreviewTarget(IReadOnlyList<string> pathSegments, Simulation simulation, TrainingRewardData data)
        {
            this.pathSegments = pathSegments;
            this.simulation = simulation;
            this.data = data;
        }

        public string FamilyName => "Rewards";
        public IReadOnlyList<string> PathSegments => pathSegments;
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Scored" => (Verbs.Scored, RewardStatementFactory.Scored(simulation, data)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
