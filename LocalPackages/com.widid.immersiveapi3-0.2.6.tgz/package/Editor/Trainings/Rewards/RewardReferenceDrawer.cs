using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Rewards
{
    /// <summary>
    /// Renders a RewardReference field as a "Training/Rewards/Name" dropdown instead of a raw id
    /// text field, scanning every TrainingSO asset in the project for its Rewards - same convention
    /// as StepReferenceDrawer/StrategyReferenceDrawer.
    /// </summary>
    [CustomPropertyDrawer(typeof(RewardReference))]
    public class RewardReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "rewardId";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingRewardData reward in training.Data.GameFlow.Rewards)
                    results.Add(new TrainingReferenceOption(reward.Id, $"{training.Data.Id}/Rewards/{reward.Name.GetDisplayName(reward.Id)}"));
            }

            return results;
        }
    }
}
