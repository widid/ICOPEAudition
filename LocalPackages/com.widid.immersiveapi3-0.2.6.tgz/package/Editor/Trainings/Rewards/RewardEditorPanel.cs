using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Localization;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Rewards
{
    /// <summary>
    /// Authoring tool for a Training's Reward catalog (see TrainingRewardData/
    /// RewardStatementFactory, xAPI-Statements/Reward/README.md) - Simulation-scoped only, like
    /// SkillEditorWindow, since Reward has no Strategy/Step parenting. Each entry's Score section
    /// (Scaled/Raw/Min/Max) is wired exactly like PerformanceEditorWindow's own - fixed constant or
    /// live reflected source, float for Scaled, int for Raw/Min/Max. Unlike Performance, nothing
    /// auto-sends a Reward - host game code calls TrainingRuntime.ScoreReward whenever points are
    /// actually awarded, and the same Id can legitimately be scored many times over a session. UI
    /// Toolkit window (RewardEditorWindow.uxml/RewardEntry.uxml + shared Common.uss/
    /// LanguageRow.uxml), same conventions as PerformanceEditorWindow/SkillEditorWindow.
    /// </summary>
    public class RewardEditorPanel
    {
        TrainingSO training;
        ObjectField trainingField;
        ScrollView contentScroll;
        VisualTreeAsset entryTemplate;
        VisualTreeAsset languageRowTemplate;

        readonly Dictionary<string, bool> foldouts = new();

        // Tracked so RefreshDuplicateWarnings can update every entry's warning slot in place
        // whenever any Id field changes, without a full Rebuild() - rebuilding the tree the
        // TextField the user is actively typing into lives in would drop focus every keystroke.
        readonly List<(TrainingRewardData reward, VisualElement warningSlot)> duplicateWarningSlots = new();

        readonly TrainingValidationView validation = new();

        public VisualElement CreateView()
        {
            VisualElement root = new();

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.RewardEntry;
            languageRowTemplate = ImmersiveEditorUIConfigLoader.Assets.LanguageRow;

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.RewardEditorWindow;
            visualTree.CloneTree(root);

            trainingField = root.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            contentScroll = root.Q<ScrollView>("ContentScroll");

            Rebuild();

            return root;
        }

        public void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            Rebuild();
        }

        void Rebuild()
        {
            if (contentScroll == null)
                return;

            contentScroll.Clear();
            duplicateWarningSlots.Clear();
            validation.Clear();

            if (training == null)
            {
                contentScroll.Add(new Label("Pick a Training to edit its Reward catalog.") { style = { opacity = 0.7f, marginTop = 8 } });
                return;
            }

            Foldout simulationFoldout = CreateFoldout($"simulation:{training.Data.Id}", $"Simulation: {training.Data.Id}");
            simulationFoldout.AddToClassList("wid-foldout-level-simulation");
            simulationFoldout.Add(BuildRewardGroup(training.Data.GameFlow.Rewards));
            validation.AddSection(simulationFoldout, () => TrainingCatalogValidation.HasInvalidRewards(training));
            contentScroll.Add(simulationFoldout);

            RefreshDuplicateWarnings();
        }

        Foldout CreateFoldout(string key, string text, bool defaultExpanded = true)
        {
            bool expanded = foldouts.TryGetValue(key, out bool state) ? state : defaultExpanded;
            Foldout foldout = new() { text = text, value = expanded, viewDataKey = key };
            foldout.AddToClassList("wid-foldout-spaced");
            foldout.RegisterValueChangedCallback(evt => foldouts[key] = evt.newValue);
            return foldout;
        }

        VisualElement BuildRewardGroup(List<TrainingRewardData> rewards)
        {
            VisualElement container = new();
            container.AddToClassList("wid-depth-0");

            foreach (TrainingRewardData reward in rewards)
                container.Add(BuildRewardEntry(reward, rewards));

            VisualElement addRow = new();
            addRow.AddToClassList("wid-button-center-row");
            Button addButton = new(() =>
            {
                TrainingRewardData newReward = new() { Id = Guid.NewGuid().ToString("N").Substring(0, 8) };
                rewards.Add(newReward);
                foldouts[$"reward:{newReward.Id}"] = true;
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            })
            { text = "+ Add Reward" };
            addRow.Add(addButton);
            container.Add(addRow);

            return container;
        }

        VisualElement BuildRewardEntry(TrainingRewardData reward, List<TrainingRewardData> currentContainer)
        {
            string rewardFoldoutKey = $"reward:{reward.Id}";

            VisualElement wrapper = entryTemplate.CloneTree();
            wrapper.AddToClassList("wid-depth-1");

            Foldout foldout = wrapper.Q<Foldout>("FoldoutHeader");
            foldout.viewDataKey = rewardFoldoutKey;
            foldout.text = BuildHeaderText(reward);
            foldout.value = foldouts.TryGetValue(rewardFoldoutKey, out bool expanded) ? expanded : false;
            foldout.RegisterValueChangedCallback(evt => foldouts[rewardFoldoutKey] = evt.newValue);

            Label previewLabel = wrapper.Q<Label>("LabelPreview");
            previewLabel.text = BuildValuePreview(reward);

            validation.AddIndicator(wrapper.Q<VisualElement>("HeaderRow"), foldout, () => TrainingEntryValidator.Validate(reward));

            Button deleteButton = wrapper.Q<Button>("ButtonDelete");
            deleteButton.clicked += () =>
            {
                string idLabel = string.IsNullOrEmpty(reward.Id) ? "(no id)" : reward.Id;
                bool confirmed = EditorUtility.DisplayDialog("Delete Reward", $"Delete reward '{idLabel}'? This cannot be undone.", "Yes", "No");
                if (!confirmed)
                    return;

                currentContainer.Remove(reward);
                foldouts.Remove(rewardFoldoutKey);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            };

            duplicateWarningSlots.Add((reward, wrapper.Q<VisualElement>("DuplicateWarningSlot")));

            void RefreshHeader()
            {
                foldout.text = BuildHeaderText(reward);
                previewLabel.text = BuildValuePreview(reward);
                validation.Refresh();
            }

            TextField idField = wrapper.Q<TextField>("FieldId");
            idField.value = reward.Id;
            idField.RegisterValueChangedCallback(evt =>
            {
                reward.Id = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshHeader();
                RefreshDuplicateWarnings();
            });

            WireLocalizedSection(wrapper, $"{rewardFoldoutKey}:name", "FoldoutName", "NameRows", "ButtonAddNameLanguage", reward.Name, RefreshHeader);
            WireLocalizedSection(wrapper, $"{rewardFoldoutKey}:description", "FoldoutDescription", "DescriptionRows", "ButtonAddDescriptionLanguage", reward.Description);

            Foldout resultFoldout = wrapper.Q<Foldout>("FoldoutResult");
            string resultFoldoutKey = $"{rewardFoldoutKey}:result";
            resultFoldout.viewDataKey = resultFoldoutKey;
            resultFoldout.value = foldouts.TryGetValue(resultFoldoutKey, out bool resultExpanded) ? resultExpanded : resultFoldout.value;
            resultFoldout.RegisterValueChangedCallback(evt => foldouts[resultFoldoutKey] = evt.newValue);

            WireValueSourceRow(wrapper, "Scaled", reward.Scaled, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Raw", reward.Raw, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Min", reward.Min, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Max", reward.Max, RefreshHeader);

            return wrapper;
        }

        // Recomputes duplicates across the whole catalog and updates every already-built entry's
        // warning slot in place - called after every Id edit (not just on Rebuild(), which only
        // happens on add/delete) so two entries typed to match immediately both show the warning,
        // and so editing entry A's Id also refreshes entry B's slot, not just its own.
        void RefreshDuplicateWarnings()
        {
            if (training == null)
                return;

            HashSet<string> duplicateIds = DuplicateIdFinder.Find(training.Data.GameFlow.Rewards, reward => reward.Id);

            foreach ((TrainingRewardData reward, VisualElement warningSlot) in duplicateWarningSlots)
            {
                warningSlot.Clear();
                if (!string.IsNullOrEmpty(reward.Id) && duplicateIds.Contains(reward.Id))
                    warningSlot.Add(new HelpBox($"Duplicate Id '{reward.Id}' - each Reward needs a unique Id within this Training.", HelpBoxMessageType.Error));
            }
        }

        static string BuildHeaderText(TrainingRewardData reward)
        {
            string idLabel = string.IsNullOrEmpty(reward.Id) ? "(no id)" : reward.Id;
            string nameLabel = reward.Name.GetDisplayName("(no name)");
            return $"{idLabel} - {nameLabel}";
        }

        // Same priority as PerformanceEditorWindow.BuildValuePreview - Raw > Scaled.
        static string BuildValuePreview(TrainingRewardData reward)
        {
            int? raw = ResolvePreview(reward.Raw);
            if (raw.HasValue)
                return raw.Value.ToString();

            float? scaled = ResolvePreview(reward.Scaled);
            return scaled.HasValue ? scaled.Value.ToString("0.##") : string.Empty;
        }

        static float? ResolvePreview(PerformanceValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<float>(target, source.ReflectedSource.Data);
        }

        static int? ResolvePreview(PerformanceIntValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<int>(target, source.ReflectedSource.Data);
        }

        void WireLocalizedSection(VisualElement root, string foldoutKey, string foldoutName, string rowsContainerName, string addButtonName, LanguageDictionary dictionary, Action onChanged = null)
        {
            Foldout sectionFoldout = root.Q<Foldout>(foldoutName);
            sectionFoldout.viewDataKey = foldoutKey;
            sectionFoldout.value = foldouts.TryGetValue(foldoutKey, out bool expanded) ? expanded : sectionFoldout.value;
            sectionFoldout.RegisterValueChangedCallback(evt => foldouts[foldoutKey] = evt.newValue);

            VisualElement rowsContainer = root.Q<VisualElement>(rowsContainerName);

            void RebuildRows()
            {
                rowsContainer.Clear();
                LanguageDictionary.LanguageKey[] keys = dictionary.LanguageKeys;

                for (int i = 0; i < keys.Length; i++)
                {
                    int index = i;

                    languageRowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    DropdownField languagePopup = row.Q<DropdownField>("DropdownLanguageCode");
                    languagePopup.choices = LanguageDictionary.AvailableLanguages.ToList();
                    languagePopup.index = keys[index].localizationIndex;
                    languagePopup.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        int newLanguageIndex = Array.IndexOf(LanguageDictionary.AvailableLanguages, evt.newValue);
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = newLanguageIndex, value = current[index].value };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    TextField valueField = row.Q<TextField>("FieldLanguageValue");
                    valueField.value = keys[index].value;
                    valueField.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = current[index].localizationIndex, value = evt.newValue };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    Button removeButton = row.Q<Button>("ButtonRemoveLanguage");
                    removeButton.clicked += () =>
                    {
                        dictionary.LanguageKeys = dictionary.LanguageKeys.Where((_, keyIndex) => keyIndex != index).ToArray();
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                        RebuildRows();
                    };
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>(addButtonName);
            addButton.clicked += () =>
            {
                int nextLanguage = NextAvailableLanguageIndex(dictionary);
                dictionary.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = nextLanguage, value = string.Empty });
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
                RebuildRows();
            };
        }

        static int NextAvailableLanguageIndex(LanguageDictionary dictionary)
        {
            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (!dictionary.LanguageKeys.Any(key => key.localizationIndex == i))
                    return i;
            }

            return 0;
        }

        void WireValueSourceRow(VisualElement root, string namePrefix, PerformanceValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            FloatField fixedField = root.Q<FloatField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedFloatSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedFloatSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }

        void WireIntValueSourceRow(VisualElement root, string namePrefix, PerformanceIntValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            IntegerField fixedField = root.Q<IntegerField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedIntSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedIntSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }
    }
}
