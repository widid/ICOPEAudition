using System;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.Badges;
using WiDiD.ImmersiveAPI.Editor.Trainings.Interactions;
using WiDiD.ImmersiveAPI.Editor.Trainings.Performance;
using WiDiD.ImmersiveAPI.Editor.Trainings.Rewards;
using WiDiD.ImmersiveAPI.Editor.Trainings.Skills;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Trainings;

namespace WiDiD.ImmersiveAPI.Editor.Trainings
{
    public enum TrainingCatalogTab
    {
        Performances,
        Skills,
        Interactions,
        Badges,
        Rewards
    }

    /// <summary>
    /// Single holding window for every per-Training statementable catalog editor (Performance/
    /// Skill/Interaction/Badge/Reward) - each used to be its own standalone EditorWindow (see
    /// PerformanceEditorPanel etc., now plain classes exposing CreateView()/SetTraining() instead of
    /// EditorWindow.CreateGUI()/GetWindow()), opened here as tabs instead so a Training's whole
    /// catalog lives in one window. GameFlow keeps its own separate window
    /// (GameFlowGraphWindow) - it's a node graph, not a flat catalog, so it doesn't fit this tabbed
    /// shape.
    /// </summary>
    public class TrainingCatalogWindow : EditorWindow
    {
        TrainingSO training;
        ObjectField trainingField;
        VisualElement tabBar;
        VisualElement contentHost;

        PerformanceEditorPanel performancePanel;
        SkillEditorPanel skillPanel;
        InteractionEditorPanel interactionPanel;
        BadgeEditorPanel badgePanel;
        RewardEditorPanel rewardPanel;

        (TrainingCatalogTab tab, VisualElement content, Button tabButton)[] tabs;

        public static void Open(TrainingSO training, TrainingCatalogTab tab = TrainingCatalogTab.Performances)
        {
            TrainingCatalogWindow window = GetWindow<TrainingCatalogWindow>();
            window.titleContent = new GUIContent("Training Catalog");
            window.minSize = new Vector2(480, 400);
            window.SetTraining(training);
            window.SelectTab(tab);
        }

        public void CreateGUI()
        {
            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.TrainingCatalogWindow;
            visualTree.CloneTree(rootVisualElement);

            trainingField = rootVisualElement.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            tabBar = rootVisualElement.Q<VisualElement>("TabBar");
            contentHost = rootVisualElement.Q<VisualElement>("ContentHost");

            performancePanel = new PerformanceEditorPanel();
            skillPanel = new SkillEditorPanel();
            interactionPanel = new InteractionEditorPanel();
            badgePanel = new BadgeEditorPanel();
            rewardPanel = new RewardEditorPanel();

            tabs = new (TrainingCatalogTab tab, VisualElement content, Button tabButton)[]
            {
                (TrainingCatalogTab.Performances, BuildPanelView(performancePanel.CreateView()), null),
                (TrainingCatalogTab.Skills, BuildPanelView(skillPanel.CreateView()), null),
                (TrainingCatalogTab.Interactions, BuildPanelView(interactionPanel.CreateView()), null),
                (TrainingCatalogTab.Badges, BuildPanelView(badgePanel.CreateView()), null),
                (TrainingCatalogTab.Rewards, BuildPanelView(rewardPanel.CreateView()), null),
            };

            for (int i = 0; i < tabs.Length; i++)
            {
                TrainingCatalogTab tab = tabs[i].tab;
                Button tabButton = BuildTabButton(tab, () => SelectTab(tab));
                tabBar.Add(tabButton);
                contentHost.Add(tabs[i].content);
                tabs[i] = (tabs[i].tab, tabs[i].content, tabButton);
            }

            SelectTab(TrainingCatalogTab.Performances);
        }

        static Button BuildTabButton(TrainingCatalogTab tab, Action onClick)
        {
            Button button = new(onClick);
            button.AddToClassList("wid-catalog-tab-button");
            button.AddToClassList("wid-icon-button");

            Image icon = new() { image = GetTabIcon(tab) };
            icon.AddToClassList("wid-icon-button-image");
            button.Add(icon);
            button.Add(new Label(tab.ToString()));

            return button;
        }

        static Texture2D GetTabIcon(TrainingCatalogTab tab) => tab switch
        {
            TrainingCatalogTab.Performances => ImmersiveEditorUIConfigLoader.Assets.IconPerformances,
            TrainingCatalogTab.Skills => ImmersiveEditorUIConfigLoader.Assets.IconSkills,
            TrainingCatalogTab.Interactions => ImmersiveEditorUIConfigLoader.Assets.IconInteractions,
            TrainingCatalogTab.Badges => ImmersiveEditorUIConfigLoader.Assets.IconBadges,
            TrainingCatalogTab.Rewards => ImmersiveEditorUIConfigLoader.Assets.IconRewards,
            _ => null
        };

        // Each panel's own UXML still declares an "ObjectFieldTraining" - hidden here since this
        // window's own field above is the single source of truth for which Training every tab edits.
        static VisualElement BuildPanelView(VisualElement panelRoot)
        {
            ObjectField ownTrainingField = panelRoot.Q<ObjectField>("ObjectFieldTraining");
            if (ownTrainingField != null)
                ownTrainingField.style.display = DisplayStyle.None;

            return panelRoot;
        }

        void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            performancePanel?.SetTraining(training);
            skillPanel?.SetTraining(training);
            interactionPanel?.SetTraining(training);
            badgePanel?.SetTraining(training);
            rewardPanel?.SetTraining(training);
        }

        void SelectTab(TrainingCatalogTab tab)
        {
            if (tabs == null)
                return;

            foreach ((TrainingCatalogTab tabId, VisualElement content, Button tabButton) in tabs)
            {
                bool isSelected = tabId == tab;
                content.style.display = isSelected ? DisplayStyle.Flex : DisplayStyle.None;
                tabButton.EnableInClassList("wid-catalog-tab-button-active", isSelected);
            }
        }
    }
}
