using System.IO;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Json;

namespace WiDiD.ImmersiveAPI.Editor.Trainings
{
    /// <summary>
    /// Adds a read-only JSON preview of this Training's GameFlow below the default Inspector, plus
    /// a button to save it as a .json file anywhere on disk - in the project or elsewhere - so
    /// what TrainingEditorWindow/the nodal GameFlow graphs have actually produced can be
    /// sanity-checked or shared without a separate tool. The JSON itself is built by
    /// GameFlowJsonExporter, which lives in the Runtime assembly so a shipped player can export
    /// the same shape (see that file for what the shape is and why).
    /// </summary>
    [CustomEditor(typeof(TrainingSO))]
    public class TrainingSOEditor : UnityEditor.Editor
    {
        Vector2 jsonScrollPosition;
        GUIStyle jsonStyle;

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            TrainingSO training = (TrainingSO)target;

            EditorGUILayout.Space();
            if (GUILayout.Button("Open Performance Editor..."))
                TrainingCatalogWindow.Open(training, TrainingCatalogTab.Performances);

            if (GUILayout.Button("Open Skill Editor..."))
                TrainingCatalogWindow.Open(training, TrainingCatalogTab.Skills);

            if (GUILayout.Button("Open Interaction Editor..."))
                TrainingCatalogWindow.Open(training, TrainingCatalogTab.Interactions);

            if (GUILayout.Button("Open Badge Editor..."))
                TrainingCatalogWindow.Open(training, TrainingCatalogTab.Badges);

            if (GUILayout.Button("Open Reward Editor..."))
                TrainingCatalogWindow.Open(training, TrainingCatalogTab.Rewards);

            string json = training.Data.GameFlow.ToJson();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("GameFlow JSON", EditorStyles.boldLabel);

            // wordWrap stays off so height only depends on line count, not on whatever width the
            // layout system guesses. SelectableLabel's automatic height still isn't reliable
            // though, so its height is computed explicitly via CalcHeight and passed in - without
            // that it renders only a couple of lines and leaves the rest of the ScrollView blank.
            jsonStyle ??= new GUIStyle(EditorStyles.textArea) { wordWrap = false };

            float contentWidth = EditorGUIUtility.currentViewWidth - 40f;
            float contentHeight = jsonStyle.CalcHeight(new GUIContent(json), contentWidth);

            jsonScrollPosition = EditorGUILayout.BeginScrollView(jsonScrollPosition, GUILayout.Height(600));
            EditorGUILayout.SelectableLabel(json, jsonStyle, GUILayout.ExpandWidth(true), GUILayout.Height(contentHeight));
            EditorGUILayout.EndScrollView();

            if (GUILayout.Button("Save JSON..."))
                SaveJson(json);
        }

        static void SaveJson(string json)
        {
            string path = EditorUtility.SaveFilePanel("Save GameFlow JSON", Application.dataPath, "gameflow", "json");
            if (string.IsNullOrEmpty(path))
                return;

            File.WriteAllText(path, json);

            if (path.StartsWith(Application.dataPath))
                AssetDatabase.Refresh();
        }
    }
}
