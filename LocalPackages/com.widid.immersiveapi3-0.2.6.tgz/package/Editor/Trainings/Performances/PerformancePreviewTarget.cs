using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Previews the single `scored` statement a Performance can send (see
    /// PerformanceStatementFactory), regardless of which container (Simulation/Strategy/Step) it's
    /// scoped to. Build() shows a realistic-but-unsent preview of any attachments (see
    /// PerformanceAttachmentFactory.BuildPreviewAttachments - real bytes/contentType/length, but a
    /// placeholder fileUrl since nothing has actually been uploaded yet); BuildForSend performs the
    /// real upload first, same sequencing PerformanceRecorder uses for an actual in-game send.
    /// </summary>
    class PerformancePreviewTarget : IStatementPreviewTarget
    {
        static readonly string[] VerbNames = { "Scored" };

        readonly IReadOnlyList<string> pathSegments;
        readonly Simulation simulation;
        readonly TrainingPerformanceData data;
        readonly Step parentStep;
        readonly Strategy parentStrategy;
        readonly IImmersiveEndpoints endpoints;
        readonly string bearerToken;
        readonly ImmersiveImageSender imageSender;

        public PerformancePreviewTarget(IReadOnlyList<string> pathSegments, Simulation simulation, TrainingPerformanceData data, IImmersiveEndpoints endpoints, string bearerToken, ImmersiveImageSender imageSender, Step parentStep = null, Strategy parentStrategy = null)
        {
            this.pathSegments = pathSegments;
            this.simulation = simulation;
            this.data = data;
            this.endpoints = endpoints;
            this.bearerToken = bearerToken;
            this.imageSender = imageSender;
            this.parentStep = parentStep;
            this.parentStrategy = parentStrategy;
        }

        public string FamilyName => "Performances";
        public IReadOnlyList<string> PathSegments => pathSegments;
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Scored" => (Verbs.Scored, PerformanceStatementFactory.Scored(simulation, data, parentStep, parentStrategy, PerformanceAttachmentFactory.BuildPreviewAttachments(data))),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }

        public async Task<(Verb Verb, IStatementable Statementable)> BuildForSend(string verbName)
        {
            if (verbName != "Scored")
                throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null);

            List<Attachment> attachments = await PerformanceAttachmentFactory.BuildAsync(data, endpoints, bearerToken, imageSender);
            return (Verbs.Scored, PerformanceStatementFactory.Scored(simulation, data, parentStep, parentStrategy, attachments));
        }
    }
}
