using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Headline value shown in a Performance entry's header.
    /// </summary>
    public static class PerformanceValuePreview
    {
        // Priority mirrors what's most likely to be the "headline" number for a quick scan:
        // Response (already a display string) > Raw+Unit > Scaled+Unit.
        public static string Build(TrainingPerformanceData performance)
        {
            string response = ResolvePreview(performance.Response);
            if (!string.IsNullOrEmpty(response))
                return response;

            int? raw = ResolvePreview(performance.Raw);
            if (raw.HasValue)
                return FormatWithUnit(raw.Value, performance.Unit);

            float? scaled = ResolvePreview(performance.Scaled);
            if (scaled.HasValue)
                return FormatWithUnit(scaled.Value, performance.Unit);

            return null;
        }

        static string FormatWithUnit(float value, string unit) => string.IsNullOrEmpty(unit) ? value.ToString("0.##") : $"{value:0.##} {unit}";
        static string FormatWithUnit(int value, string unit) => string.IsNullOrEmpty(unit) ? value.ToString() : $"{value} {unit}";

        static float? ResolvePreview(PerformanceValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<float>(target, source.ReflectedSource.Data);
        }

        static int? ResolvePreview(PerformanceIntValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<int>(target, source.ReflectedSource.Data);
        }

        static string ResolvePreview(PerformanceStringValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<string>(target, source.ReflectedSource.Data);
        }
    }
}
