using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Renders a PerformanceReference field as a "Training/[Strategy/[Step/]]Performances/Name"
    /// dropdown instead of a raw id text field, scanning every TrainingSO asset in the project for
    /// its Simulation/Strategy/Step-scoped Performances alike - same convention as
    /// StepReferenceDrawer/StrategyReferenceDrawer.
    /// </summary>
    [CustomPropertyDrawer(typeof(PerformanceReference))]
    public class PerformanceReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "performanceId";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingPerformanceData performance in training.Data.GameFlow.Performances)
                    results.Add(new TrainingReferenceOption(performance.Id, $"{training.Data.Id}/Performances/{performance.Name.GetDisplayName(performance.Id)}"));

                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    string strategyLabel = strategy.Name.GetDisplayName("Strategy");

                    foreach (TrainingPerformanceData performance in strategy.Performances)
                        results.Add(new TrainingReferenceOption(performance.Id, $"{training.Data.Id}/{strategyLabel}/Performances/{performance.Name.GetDisplayName(performance.Id)}"));

                    foreach (TrainingStepData step in strategy.Steps)
                    {
                        string stepLabel = step.Name.GetDisplayName("Step");
                        foreach (TrainingPerformanceData performance in step.Performances)
                            results.Add(new TrainingReferenceOption(performance.Id, $"{training.Data.Id}/{strategyLabel}/{stepLabel}/Performances/{performance.Name.GetDisplayName(performance.Id)}"));
                    }
                }
            }

            return results;
        }
    }
}
