using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Exposes every Performance in the project - Simulation/Strategy/Step-scoped alike - as a
    /// StatementPreviewWindow target, discovered automatically via IStatementPreviewProvider, same
    /// convention as GameFlowStatementPreviewProvider. Passes the same endpoints/bearerToken every
    /// other real send uses, so PerformancePreviewTarget.BuildForSend can upload attachments for
    /// real when the user actually clicks Send Statement.
    /// </summary>
    public class PerformanceStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;
            string bearerToken = sessionAsset != null ? sessionAsset.Data.DecodedToken : string.Empty;
            IImmersiveEndpoints endpoints = sessionAsset != null ? new ImmersiveEndpoints(sessionAsset) : null;
            ImmersiveImageSender imageSender = new();

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);

                foreach (TrainingPerformanceData performance in training.Data.GameFlow.Performances)
                    targets.Add(new PerformancePreviewTarget(new[] { training.Data.Id, "Performances", performance.Name.GetDisplayName(performance.Id) }, simulation, performance, endpoints, bearerToken, imageSender));

                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    string strategyLabel = strategy.Name.GetDisplayName(strategy.Id);
                    Strategy parentStrategy = StrategyStatementFactory.Launched(simulation, strategy);

                    foreach (TrainingPerformanceData performance in strategy.Performances)
                        targets.Add(new PerformancePreviewTarget(new[] { training.Data.Id, strategyLabel, "Performances", performance.Name.GetDisplayName(performance.Id) }, simulation, performance, endpoints, bearerToken, imageSender, parentStrategy: parentStrategy));

                    foreach (TrainingStepData step in strategy.Steps)
                    {
                        string stepLabel = step.Name.GetDisplayName(step.Id);
                        Step parentStep = StepStatementFactory.Launched(simulation, parentStrategy, step);

                        foreach (TrainingPerformanceData performance in step.Performances)
                            targets.Add(new PerformancePreviewTarget(new[] { training.Data.Id, strategyLabel, stepLabel, "Performances", performance.Name.GetDisplayName(performance.Id) }, simulation, performance, endpoints, bearerToken, imageSender, parentStep: parentStep));
                    }
                }
            }

            return targets;
        }
    }
}
