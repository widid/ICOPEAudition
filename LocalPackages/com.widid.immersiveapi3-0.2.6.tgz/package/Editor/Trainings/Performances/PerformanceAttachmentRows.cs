using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Binds a Performance entry's Attachments list. List-shaped, unlike the scalar Result rows (see
    /// PerformanceValueSourceRows) - AttachmentRow.uxml is cloned once per entry into AttachmentRows
    /// and the whole list is rebuilt on add/remove (same idiom as PerformanceEditorPanel's
    /// WireLocalizedSection), since attachments are edited rarely enough that losing focus on
    /// add/remove doesn't matter the way it would for the Id TextField.
    /// </summary>
    public static class PerformanceAttachmentRows
    {
        public static void Wire(VisualElement root, TrainingPerformanceData performance, VisualTreeAsset rowTemplate, UnityEngine.Object dirtyTarget, Action onChanged)
        {
            VisualElement rowsContainer = root.Q<VisualElement>("AttachmentRows");

            void RebuildRows()
            {
                rowsContainer.Clear();

                for (int i = 0; i < performance.Attachments.Count; i++)
                {
                    int index = i;
                    PerformanceAttachmentSource attachment = performance.Attachments[index];

                    rowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    Toggle enabledToggle = row.Q<Toggle>("ToggleEnabled");
                    ObjectField sourceField = row.Q<ObjectField>("ObjectFieldSource");
                    DropdownField usageDropdown = row.Q<DropdownField>("DropdownUsageType");
                    Label pathLabel = row.Q<Label>("LabelPath");

                    ReflectedSourceField.Attach(sourceField, typeof(ReflectedAttachmentSourceSO));
                    enabledToggle.value = attachment.Enabled;
                    sourceField.value = attachment.ReflectedSource;

                    List<string> usageChoices = AttachmentUsages.All.Keys.ToList();
                    usageDropdown.choices = usageChoices;
                    usageDropdown.SetValueWithoutNotify(usageChoices.Contains(attachment.UsageTypeKey) ? attachment.UsageTypeKey : usageChoices.FirstOrDefault());

                    void RefreshPath()
                    {
                        if (attachment.ReflectedSource == null)
                        {
                            pathLabel.text = string.Empty;
                            return;
                        }

                        TrackableId target = ReflectedSourcePathUtility.FindTrackable(attachment.ReflectedSource.Data.TargetGuid);
                        ReflectedSourcePathUtility.CacheLastKnownLocation(attachment.ReflectedSource, attachment.ReflectedSource.Data, target);
                        pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(attachment.ReflectedSource.Data, target);
                    }

                    enabledToggle.RegisterValueChangedCallback(evt =>
                    {
                        attachment.Enabled = evt.newValue;
                        EditorUtility.SetDirty(dirtyTarget);
                        onChanged?.Invoke();
                    });

                    sourceField.RegisterValueChangedCallback(evt =>
                    {
                        attachment.ReflectedSource = (ReflectedAttachmentSourceSO)evt.newValue;
                        EditorUtility.SetDirty(dirtyTarget);
                        RefreshPath();
                        onChanged?.Invoke();
                    });

                    usageDropdown.RegisterValueChangedCallback(evt =>
                    {
                        attachment.UsageTypeKey = evt.newValue;
                        EditorUtility.SetDirty(dirtyTarget);
                    });

                    Button removeButton = row.Q<Button>("ButtonRemove");
                    removeButton.clicked += () =>
                    {
                        performance.Attachments.RemoveAt(index);
                        EditorUtility.SetDirty(dirtyTarget);
                        RebuildRows();
                        onChanged?.Invoke();
                    };

                    RefreshPath();
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>("ButtonAddAttachment");
            addButton.clicked += () =>
            {
                performance.Attachments.Add(new PerformanceAttachmentSource());
                EditorUtility.SetDirty(dirtyTarget);
                RebuildRows();
                onChanged?.Invoke();
            };
        }
    }
}
