using System;
using UnityEditor;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Binds a Performance entry's header Sync toggle and what it reveals: Apply (or "Read only" when
    /// Raw's reflected member can't be written) and the Send-on-close toggle.
    /// </summary>
    public static class PerformanceServerSyncControls
    {
        /// <summary>Returns a refresh to call whenever Raw's source changes.</summary>
        public static Action Wire(VisualElement root, TrainingPerformanceData performance, UnityEngine.Object dirtyTarget)
        {
            Toggle syncToggle = root.Q<Toggle>("ToggleSyncWithServer");
            Toggle applyToggle = root.Q<Toggle>("ToggleApplyServerValue");
            Label readOnlyLabel = root.Q<Label>("LabelReadOnly");
            Toggle sendOnCloseToggle = root.Q<Toggle>("ToggleSendOnClose");

            syncToggle.SetValueWithoutNotify(performance.SyncWithServer);
            applyToggle.SetValueWithoutNotify(performance.ApplyServerValue);
            sendOnCloseToggle.SetValueWithoutNotify(performance.SendOnClose);

            void Refresh()
            {
                IReflectedValueSource rawSource = performance.Raw.WritableReflectedSource;
                bool hasRawSource = performance.SyncWithServer && rawSource != null;
                bool writable = hasRawSource && ReflectedValueWriter.CanWrite(rawSource.Data);

                applyToggle.style.display = writable ? DisplayStyle.Flex : DisplayStyle.None;
                readOnlyLabel.style.display = hasRawSource && !writable ? DisplayStyle.Flex : DisplayStyle.None;
                sendOnCloseToggle.style.display = performance.SyncWithServer ? DisplayStyle.Flex : DisplayStyle.None;
            }

            syncToggle.RegisterValueChangedCallback(evt =>
            {
                performance.SyncWithServer = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
            });

            applyToggle.RegisterValueChangedCallback(evt =>
            {
                performance.ApplyServerValue = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
            });

            sendOnCloseToggle.RegisterValueChangedCallback(evt =>
            {
                performance.SendOnClose = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
            });

            Refresh();
            return Refresh;
        }
    }
}
