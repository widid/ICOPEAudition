using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Localization;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Single place to author a Training's Performance catalog end to end (see
    /// TrainingPerformanceData): UI Toolkit window (matches TrainingEditorWindow's convention -
    /// UXML skeleton + Packages/com.widid.immersiveapi/Editor/UI/Common.uss - rather than IMGUI), grouped
    /// by container (Simulation-scoped at the top, then each foldable Strategy's own Performances
    /// nested inside it, then each of its foldable Steps' own nested inside that) since scope is
    /// purely "which container this entry lives in" - see TrainingPerformanceData/TrainingStepData/
    /// TrainingStrategyData.
    ///
    /// One Performance entry's static layout lives in PerformanceEntry.uxml (cloned per entry, then
    /// wired up here) rather than being built as bare VisualElements in C# - same for each Name/
    /// Description language row (LanguageRow.uxml). Rebuild() does a full Clear()+rebuild of
    /// ContentScroll on any structural change (add/remove/move a Performance or language entry -
    /// mirrors TrainingEditorWindow.RefreshTrainingsList's same "clear and rebuild everything"
    /// idiom), but plain value edits (text fields, toggles, object fields) mutate the data directly
    /// with no rebuild, so typing never loses focus.
    /// </summary>
    public class PerformanceEditorPanel
    {
        TrainingSO training;
        ObjectField trainingField;
        ScrollView contentScroll;
        VisualTreeAsset entryTemplate;
        VisualTreeAsset languageRowTemplate;
        VisualTreeAsset attachmentRowTemplate;

        // Keyed by a stable string id (never by object reference - TrainingStrategyData/
        // TrainingStepData/TrainingPerformanceData/LanguageDictionary instances aren't guaranteed to
        // stay the same object across a Rebuild(), so an object-reference key can silently miss and
        // fall back to a collapsed default). Reused for Performance entries (default collapsed) and
        // Strategy/Step/Simulation section headers (default expanded).
        readonly Dictionary<string, bool> foldouts = new();

        // Tracked so RefreshDuplicateWarnings can update every entry's warning slot in place
        // whenever any Id field changes, without a full Rebuild() - rebuilding the tree the
        // TextField the user is actively typing into lives in would drop focus every keystroke.
        readonly List<(TrainingPerformanceData performance, VisualElement warningSlot)> duplicateWarningSlots = new();

        readonly TrainingValidationView validation = new();

        public VisualElement CreateView()
        {
            VisualElement root = new();

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.PerformanceEntry;
            languageRowTemplate = ImmersiveEditorUIConfigLoader.Assets.LanguageRow;
            attachmentRowTemplate = ImmersiveEditorUIConfigLoader.Assets.AttachmentRow;

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.PerformanceEditorWindow;
            visualTree.CloneTree(root);

            trainingField = root.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            contentScroll = root.Q<ScrollView>("ContentScroll");

            Rebuild();

            return root;
        }

        public void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            Rebuild();
        }

        void Rebuild()
        {
            if (contentScroll == null)
                return;

            contentScroll.Clear();
            duplicateWarningSlots.Clear();
            validation.Clear();

            if (training == null)
            {
                contentScroll.Add(new Label("Pick a Training to edit its Performance catalog.") { style = { opacity = 0.7f, marginTop = 8 } });
                return;
            }

            contentScroll.Add(BuildSimulationSection());

            RefreshDuplicateWarnings();
        }

        VisualElement BuildSimulationSection()
        {
            Foldout foldout = CreateFoldout($"simulation:{training.Data.Id}", $"Simulation: {training.Data.Id}", levelClass: "wid-foldout-level-simulation");
            foldout.Add(BuildPerformanceGroup(training.Data.GameFlow.Performances, 0));

            foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                foldout.Add(BuildStrategySection(strategy));

            // Markers propagate up every level rather than only marking the container an entry
            // literally lives in - a Strategy/Step is collapsed by default, so a problem inside one
            // would otherwise be invisible until it's opened.
            validation.AddSection(foldout, () => TrainingCatalogValidation.HasInvalidPerformances(training));

            return foldout;
        }

        VisualElement BuildStrategySection(TrainingStrategyData strategy)
        {
            Foldout foldout = CreateFoldout($"strategy:{strategy.Id}", $"Strategy: {strategy.Name.GetDisplayName("Strategy")}", defaultExpanded: false, levelClass: "wid-foldout-level-strategy");
            foldout.Add(BuildPerformanceGroup(strategy.Performances, 1));

            foreach (TrainingStepData step in strategy.Steps)
                foldout.Add(BuildStepSection(step));

            validation.AddSection(foldout, () => TrainingCatalogValidation.HasInvalidPerformances(strategy));

            return foldout;
        }

        VisualElement BuildStepSection(TrainingStepData step)
        {
            Foldout foldout = CreateFoldout($"step:{step.Id}", $"Step: {step.Name.GetDisplayName("Step")}", defaultExpanded: false, levelClass: "wid-foldout-level-step");
            foldout.Add(BuildPerformanceGroup(step.Performances, 2));

            validation.AddSection(foldout, () => TrainingCatalogValidation.HasInvalidPerformances(step.Performances));

            return foldout;
        }

        Foldout CreateFoldout(string key, string text, bool defaultExpanded = true, string levelClass = null)
        {
            bool expanded = foldouts.TryGetValue(key, out bool state) ? state : defaultExpanded;
            // viewDataKey (not just our own dictionary) needs to be unique per logical entity -
            // without it, UI Toolkit's own built-in Foldout state persistence can key off tree
            // position/name instead, and silently collide across sibling foldouts.
            Foldout foldout = new() { text = text, value = expanded, viewDataKey = key };
            foldout.AddToClassList("wid-foldout-spaced");

            if (levelClass != null)
                foldout.AddToClassList(levelClass);

            foldout.RegisterValueChangedCallback(evt => foldouts[key] = evt.newValue);
            return foldout;
        }

        IEnumerable<TrainingPerformanceData> CollectAllPerformances()
        {
            foreach (TrainingPerformanceData performance in training.Data.GameFlow.Performances)
                yield return performance;

            foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
            {
                foreach (TrainingPerformanceData performance in strategy.Performances)
                    yield return performance;

                foreach (TrainingStepData step in strategy.Steps)
                    foreach (TrainingPerformanceData performance in step.Performances)
                        yield return performance;
            }
        }

        // (label, container) for every valid scope a Performance can live in - used both to build
        // the "Move to" destination list and (indirectly, via CollectAllPerformances) the
        // duplicate-Id check.
        IEnumerable<(string label, List<TrainingPerformanceData> container)> CollectContainers()
        {
            yield return ("Simulation-scoped", training.Data.GameFlow.Performances);

            foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
            {
                string strategyLabel = strategy.Name.GetDisplayName("Strategy");
                yield return ($"Strategy: {strategyLabel}", strategy.Performances);

                foreach (TrainingStepData step in strategy.Steps)
                    yield return ($"Strategy: {strategyLabel} / Step: {step.Name.GetDisplayName("Step")}", step.Performances);
            }
        }

        VisualElement BuildPerformanceGroup(List<TrainingPerformanceData> performances, int depth)
        {
            VisualElement container = new();
            container.AddToClassList($"wid-depth-{Mathf.Min(depth, 3)}");

            foreach (TrainingPerformanceData performance in performances)
                container.Add(BuildPerformanceEntry(performance, performances, depth + 1));

            VisualElement addRow = new();
            addRow.AddToClassList("wid-button-center-row");
            Button addButton = new(() =>
            {
                TrainingPerformanceData newPerformance = new() { Id = Guid.NewGuid().ToString("N").Substring(0, 8) };
                performances.Add(newPerformance);
                foldouts[$"performance:{newPerformance.Id}"] = true;
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            })
            { text = "+ Add Performance" };
            addRow.Add(addButton);
            container.Add(addRow);

            return container;
        }

        VisualElement BuildPerformanceEntry(TrainingPerformanceData performance, List<TrainingPerformanceData> currentContainer, int depth)
        {
            string performanceFoldoutKey = $"performance:{performance.Id}";

            VisualElement wrapper = entryTemplate.CloneTree();
            wrapper.AddToClassList($"wid-depth-{Mathf.Min(depth, 3)}");

            Foldout foldout = wrapper.Q<Foldout>("FoldoutHeader");
            foldout.viewDataKey = performanceFoldoutKey;
            foldout.text = BuildHeaderText(performance);
            foldout.value = foldouts.TryGetValue(performanceFoldoutKey, out bool expanded) ? expanded : false;
            foldout.RegisterValueChangedCallback(evt => foldouts[performanceFoldoutKey] = evt.newValue);

            Label previewLabel = wrapper.Q<Label>("LabelPreview");
            previewLabel.text = PerformanceValuePreview.Build(performance) ?? string.Empty;

            validation.AddIndicator(wrapper.Q<VisualElement>("HeaderRow"), foldout, () => TrainingEntryValidator.Validate(performance));

            Button deleteButton = wrapper.Q<Button>("ButtonDelete");
            deleteButton.clicked += () =>
            {
                string idLabel = string.IsNullOrEmpty(performance.Id) ? "(no id)" : performance.Id;
                bool confirmed = EditorUtility.DisplayDialog("Delete Performance", $"Delete performance '{idLabel}'? This cannot be undone.", "Yes", "No");
                if (!confirmed)
                    return;

                currentContainer.Remove(performance);
                foldouts.Remove(performanceFoldoutKey);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            };

            duplicateWarningSlots.Add((performance, wrapper.Q<VisualElement>("DuplicateWarningSlot")));

            // TEMPORARY-STORED-PROGRESS
            Action refreshSyncControls = null;

            void RefreshHeader()
            {
                foldout.text = BuildHeaderText(performance);
                previewLabel.text = PerformanceValuePreview.Build(performance) ?? string.Empty;
                refreshSyncControls?.Invoke(); // TEMPORARY-STORED-PROGRESS
                validation.Refresh();
            }

            TextField idField = wrapper.Q<TextField>("FieldId");
            idField.value = performance.Id;
            idField.RegisterValueChangedCallback(evt =>
            {
                performance.Id = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshHeader();
                RefreshDuplicateWarnings();
            });

            TextField unitField = wrapper.Q<TextField>("FieldUnit");
            unitField.value = performance.Unit;
            unitField.RegisterValueChangedCallback(evt =>
            {
                performance.Unit = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshHeader();
            });

            WireLocalizedSection(wrapper, $"{performanceFoldoutKey}:name", "FoldoutName", "NameRows", "ButtonAddNameLanguage", performance.Name, RefreshHeader);
            WireLocalizedSection(wrapper, $"{performanceFoldoutKey}:description", "FoldoutDescription", "DescriptionRows", "ButtonAddDescriptionLanguage", performance.Description);

            // FoldoutResult (wraps the value-source rows below) was never wired to a stable key -
            // every cloned entry shares the same "FoldoutResult" name, so without this it's exactly
            // the kind of sibling collision that made unrelated foldouts collapse.
            Foldout resultFoldout = wrapper.Q<Foldout>("FoldoutResult");
            if (resultFoldout != null)
            {
                string resultFoldoutKey = $"{performanceFoldoutKey}:result";
                resultFoldout.viewDataKey = resultFoldoutKey;
                resultFoldout.value = foldouts.TryGetValue(resultFoldoutKey, out bool resultExpanded) ? resultExpanded : resultFoldout.value;
                resultFoldout.RegisterValueChangedCallback(evt => foldouts[resultFoldoutKey] = evt.newValue);
            }

            PerformanceValueSourceRows.WireFloat(wrapper, "Scaled", performance.Scaled, training, RefreshHeader);
            PerformanceValueSourceRows.WireInt(wrapper, "Raw", performance.Raw, training, RefreshHeader);
            PerformanceValueSourceRows.WireInt(wrapper, "Min", performance.Min, training, RefreshHeader);
            PerformanceValueSourceRows.WireInt(wrapper, "Max", performance.Max, training, RefreshHeader);
            PerformanceValueSourceRows.WireString(wrapper, "Response", performance.Response, training, RefreshHeader);

            // Same viewDataKey reasoning as FoldoutResult above.
            Foldout attachmentsFoldout = wrapper.Q<Foldout>("FoldoutAttachments");
            string attachmentsFoldoutKey = $"{performanceFoldoutKey}:attachments";
            attachmentsFoldout.viewDataKey = attachmentsFoldoutKey;
            attachmentsFoldout.value = foldouts.TryGetValue(attachmentsFoldoutKey, out bool attachmentsExpanded) ? attachmentsExpanded : attachmentsFoldout.value;
            attachmentsFoldout.RegisterValueChangedCallback(evt => foldouts[attachmentsFoldoutKey] = evt.newValue);

            PerformanceAttachmentRows.Wire(wrapper, performance, attachmentRowTemplate, training, RefreshHeader);

            // TEMPORARY-STORED-PROGRESS
            refreshSyncControls = PerformanceServerSyncControls.Wire(wrapper, performance, training);

            WireMoveControl(wrapper, performance, currentContainer);

            return wrapper;
        }

        // Recomputes duplicates across the whole catalog (every scope - Simulation/Strategy/Step
        // alike) and updates every already-built entry's warning slot in place - called after every
        // Id edit (not just on Rebuild(), which only happens on add/delete/move) so two entries
        // typed to match immediately both show the warning, and editing entry A's Id also refreshes
        // entry B's slot, not just its own.
        void RefreshDuplicateWarnings()
        {
            if (training == null)
                return;

            HashSet<string> duplicateIds = DuplicateIdFinder.Find(CollectAllPerformances(), performance => performance.Id);

            foreach ((TrainingPerformanceData performance, VisualElement warningSlot) in duplicateWarningSlots)
            {
                warningSlot.Clear();
                if (!string.IsNullOrEmpty(performance.Id) && duplicateIds.Contains(performance.Id))
                    warningSlot.Add(new HelpBox($"Duplicate Id '{performance.Id}' - each Performance needs a unique Id within this Training.", HelpBoxMessageType.Error));
            }
        }

        static string BuildHeaderText(TrainingPerformanceData performance)
        {
            string idLabel = string.IsNullOrEmpty(performance.Id) ? "(no id)" : performance.Id;
            string nameLabel = performance.Name.GetDisplayName("(no name)");
            return $"{idLabel} - {nameLabel}";
        }

        // Resets to "Move to..." afterward via the full Rebuild(), since this whole element is
        // recreated - the dropdown is a one-shot action, not a persistent representation of scope.
        void WireMoveControl(VisualElement root, TrainingPerformanceData performance, List<TrainingPerformanceData> currentContainer)
        {
            (string label, List<TrainingPerformanceData> container)[] destinations = CollectContainers()
                .Where(destination => destination.container != currentContainer)
                .ToArray();

            List<string> choices = new() { "Move to..." };
            choices.AddRange(destinations.Select(destination => destination.label));

            DropdownField dropdown = root.Q<DropdownField>("DropdownMoveTo");
            dropdown.choices = choices;
            dropdown.index = 0;
            dropdown.RegisterValueChangedCallback(evt =>
            {
                int index = choices.IndexOf(evt.newValue);
                if (index <= 0)
                    return;

                currentContainer.Remove(performance);
                destinations[index - 1].container.Add(performance);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            });
        }

        void WireLocalizedSection(VisualElement root, string foldoutKey, string foldoutName, string rowsContainerName, string addButtonName, LanguageDictionary dictionary, Action onChanged = null)
        {
            Foldout sectionFoldout = root.Q<Foldout>(foldoutName);
            sectionFoldout.viewDataKey = foldoutKey;
            sectionFoldout.value = foldouts.TryGetValue(foldoutKey, out bool expanded) ? expanded : sectionFoldout.value;
            sectionFoldout.RegisterValueChangedCallback(evt => foldouts[foldoutKey] = evt.newValue);

            VisualElement rowsContainer = root.Q<VisualElement>(rowsContainerName);

            void RebuildRows()
            {
                rowsContainer.Clear();
                LanguageDictionary.LanguageKey[] keys = dictionary.LanguageKeys;

                for (int i = 0; i < keys.Length; i++)
                {
                    int index = i;

                    languageRowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    DropdownField languagePopup = row.Q<DropdownField>("DropdownLanguageCode");
                    languagePopup.choices = LanguageDictionary.AvailableLanguages.ToList();
                    languagePopup.index = keys[index].localizationIndex;
                    languagePopup.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        int newLanguageIndex = Array.IndexOf(LanguageDictionary.AvailableLanguages, evt.newValue);
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = newLanguageIndex, value = current[index].value };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    TextField valueField = row.Q<TextField>("FieldLanguageValue");
                    valueField.value = keys[index].value;
                    valueField.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = current[index].localizationIndex, value = evt.newValue };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    Button removeButton = row.Q<Button>("ButtonRemoveLanguage");
                    removeButton.clicked += () =>
                    {
                        dictionary.LanguageKeys = dictionary.LanguageKeys.Where((_, keyIndex) => keyIndex != index).ToArray();
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                        RebuildRows();
                    };
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>(addButtonName);
            addButton.clicked += () =>
            {
                int nextLanguage = NextAvailableLanguageIndex(dictionary);
                dictionary.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = nextLanguage, value = string.Empty });
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
                RebuildRows();
            };
        }

        static int NextAvailableLanguageIndex(LanguageDictionary dictionary)
        {
            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (!dictionary.LanguageKeys.Any(key => key.localizationIndex == i))
                    return i;
            }

            return 0;
        }
    }
}
