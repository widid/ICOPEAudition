using System;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Performance
{
    /// <summary>
    /// Binds a Result row of PerformanceEntry.uxml (Toggle/ObjectField/fixed field/path label named
    /// after namePrefix) to a fixed-or-reflected value source.
    /// </summary>
    public static class PerformanceValueSourceRows
    {
        public static void WireFloat(VisualElement root, string namePrefix, PerformanceValueSource source, UnityEngine.Object dirtyTarget, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            FloatField fixedField = root.Q<FloatField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedFloatSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedFloatSourceSO)evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                onChanged?.Invoke();
            });

            Refresh();
        }

        public static void WireInt(VisualElement root, string namePrefix, PerformanceIntValueSource source, UnityEngine.Object dirtyTarget, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            IntegerField fixedField = root.Q<IntegerField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedIntSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedIntSourceSO)evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                onChanged?.Invoke();
            });

            Refresh();
        }

        public static void WireString(VisualElement root, string namePrefix, PerformanceStringValueSource source, UnityEngine.Object dirtyTarget, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            TextField fixedField = root.Q<TextField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedStringSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedStringSourceSO)evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(dirtyTarget);
                onChanged?.Invoke();
            });

            Refresh();
        }
    }
}
