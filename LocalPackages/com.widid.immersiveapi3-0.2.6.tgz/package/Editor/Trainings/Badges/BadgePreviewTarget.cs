using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Badges
{
    /// <summary>Previews the single `received` statement a Badge slot can send (see BadgeStatementFactory) - the same statement BadgeRecorder would send automatically once its UnlockCondition evaluates true.</summary>
    class BadgePreviewTarget : IStatementPreviewTarget
    {
        static readonly string[] VerbNames = { "Received" };

        readonly IReadOnlyList<string> pathSegments;
        readonly Simulation simulation;
        readonly TrainingBadgeData data;
        readonly int slotNumber;

        public BadgePreviewTarget(IReadOnlyList<string> pathSegments, Simulation simulation, TrainingBadgeData data, int slotNumber)
        {
            this.pathSegments = pathSegments;
            this.simulation = simulation;
            this.data = data;
            this.slotNumber = slotNumber;
        }

        public string FamilyName => "Badges";
        public IReadOnlyList<string> PathSegments => pathSegments;
        public IReadOnlyList<string> CompatibleVerbNames => VerbNames;

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return verbName switch
            {
                "Received" => (Verbs.Received, BadgeStatementFactory.Received(simulation, data, slotNumber)),
                _ => throw new ArgumentOutOfRangeException(nameof(verbName), verbName, null)
            };
        }
    }
}
