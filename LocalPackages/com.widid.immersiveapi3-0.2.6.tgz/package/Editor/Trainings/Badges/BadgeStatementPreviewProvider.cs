using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Badges
{
    /// <summary>
    /// Exposes every Badge slot in the project as a StatementPreviewWindow target, discovered
    /// automatically via IStatementPreviewProvider, same convention as
    /// GameFlowStatementPreviewProvider/PerformanceStatementPreviewProvider.
    /// </summary>
    public class BadgeStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);

                for (int i = 0; i < training.Data.GameFlow.Badges.Count; i++)
                {
                    int slotNumber = i + 1;
                    targets.Add(new BadgePreviewTarget(new[] { training.Data.Id, "Badges", $"Badge #{slotNumber}" }, simulation, training.Data.GameFlow.Badges[i], slotNumber));
                }
            }

            return targets;
        }
    }
}
