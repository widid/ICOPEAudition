using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Badges
{
    /// <summary>
    /// Authoring tool for a Training's Badge slots (see TrainingBadgeData/BadgeStatementFactory,
    /// xAPI-Statements/Badge/README.md) - always Simulation-scoped, capped at 3 entries (the
    /// dashboard only supports 3 badge slots per Simulation - see that README). Unlike Performance/
    /// Skill/Interaction, a Badge's Id isn't authored at all - it's just its 1-based position in
    /// TrainingGameFlowData.Badges, so there's no duplicate-Id concern and no Id field in the
    /// entry. Each entry's Unlock Condition (see ConditionChainEditor) is checked continuously at
    /// runtime by BadgeRecorder - the moment it evaluates true, the Received statement fires
    /// automatically, at most once per session; there's no manual trigger. UI Toolkit window
    /// (BadgeEditorWindow.uxml/BadgeEntry.uxml + shared Common.uss/LanguageRow.uxml), same
    /// conventions as PerformanceEditorWindow/SkillEditorWindow/InteractionEditorWindow.
    /// </summary>
    public class BadgeEditorPanel
    {
        const int MaxBadgeSlots = 3;

        TrainingSO training;
        ObjectField trainingField;
        ScrollView contentScroll;
        VisualTreeAsset entryTemplate;
        VisualTreeAsset languageRowTemplate;

        // Keyed by slot number, not a stable per-entry id (Badge has none) - deleting a badge
        // shifts every following slot's number down by one, so their foldout state naturally
        // follows whichever slot they land in rather than a stale one. Acceptable at only 3 slots.
        readonly Dictionary<string, bool> foldouts = new();

        readonly TrainingValidationView validation = new();

        public VisualElement CreateView()
        {
            VisualElement root = new();

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.BadgeEntry;
            languageRowTemplate = ImmersiveEditorUIConfigLoader.Assets.LanguageRow;

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.BadgeEditorWindow;
            visualTree.CloneTree(root);

            trainingField = root.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            contentScroll = root.Q<ScrollView>("ContentScroll");

            Rebuild();

            return root;
        }

        public void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            Rebuild();
        }

        void Rebuild()
        {
            if (contentScroll == null)
                return;

            contentScroll.Clear();
            validation.Clear();

            if (training == null)
            {
                contentScroll.Add(new Label("Pick a Training to edit its Badge slots.") { style = { opacity = 0.7f, marginTop = 8 } });
                return;
            }

            Foldout simulationFoldout = CreateFoldout($"simulation:{training.Data.Id}", $"Simulation: {training.Data.Id}");
            simulationFoldout.AddToClassList("wid-foldout-level-simulation");
            simulationFoldout.Add(BuildBadgeGroup(training.Data.GameFlow.Badges));
            validation.AddSection(simulationFoldout, () => TrainingCatalogValidation.HasInvalidBadges(training));
            contentScroll.Add(simulationFoldout);
        }

        Foldout CreateFoldout(string key, string text, bool defaultExpanded = true)
        {
            bool expanded = foldouts.TryGetValue(key, out bool state) ? state : defaultExpanded;
            Foldout foldout = new() { text = text, value = expanded, viewDataKey = key };
            foldout.AddToClassList("wid-foldout-spaced");
            foldout.RegisterValueChangedCallback(evt => foldouts[key] = evt.newValue);
            return foldout;
        }

        VisualElement BuildBadgeGroup(List<TrainingBadgeData> badges)
        {
            VisualElement container = new();
            container.AddToClassList("wid-depth-0");

            for (int i = 0; i < badges.Count; i++)
                container.Add(BuildBadgeEntry(badges, i));

            if (badges.Count < MaxBadgeSlots)
            {
                VisualElement addRow = new();
                addRow.AddToClassList("wid-button-center-row");
                Button addButton = new(() =>
                {
                    badges.Add(new TrainingBadgeData());
                    EditorUtility.SetDirty(training);
                    EditorApplication.delayCall += Rebuild;
                })
                { text = "+ Add Badge" };
                addRow.Add(addButton);
                container.Add(addRow);
            }
            else
            {
                container.Add(new Label($"All {MaxBadgeSlots} badge slots are used.") { style = { opacity = 0.7f, marginTop = 4, marginBottom = 4 } });
            }

            return container;
        }

        VisualElement BuildBadgeEntry(List<TrainingBadgeData> badges, int index)
        {
            TrainingBadgeData badge = badges[index];
            int slotNumber = index + 1;
            string badgeFoldoutKey = $"badge:{slotNumber}";

            VisualElement wrapper = entryTemplate.CloneTree();
            wrapper.AddToClassList("wid-depth-1");

            Foldout foldout = wrapper.Q<Foldout>("FoldoutHeader");
            foldout.viewDataKey = badgeFoldoutKey;
            foldout.text = BuildHeaderText(slotNumber, badge);
            foldout.value = foldouts.TryGetValue(badgeFoldoutKey, out bool expanded) ? expanded : false;
            foldout.RegisterValueChangedCallback(evt => foldouts[badgeFoldoutKey] = evt.newValue);

            Label previewLabel = wrapper.Q<Label>("LabelPreview");
            previewLabel.text = BuildValuePreview(badge);

            validation.AddIndicator(wrapper.Q<VisualElement>("HeaderRow"), foldout, () => TrainingEntryValidator.Validate(badge));

            Button deleteButton = wrapper.Q<Button>("ButtonDelete");
            deleteButton.clicked += () =>
            {
                bool confirmed = EditorUtility.DisplayDialog("Delete Badge", $"Delete badge slot #{slotNumber}? This cannot be undone.", "Yes", "No");
                if (!confirmed)
                    return;

                badges.RemoveAt(index);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            };

            void RefreshHeader()
            {
                foldout.text = BuildHeaderText(slotNumber, badge);
                previewLabel.text = BuildValuePreview(badge);
                validation.Refresh();
            }

            WireLocalizedSection(wrapper, $"{badgeFoldoutKey}:name", "FoldoutName", "NameRows", "ButtonAddNameLanguage", badge.Name, RefreshHeader);
            WireLocalizedSection(wrapper, $"{badgeFoldoutKey}:description", "FoldoutDescription", "DescriptionRows", "ButtonAddDescriptionLanguage", badge.Description);

            Foldout unlockConditionFoldout = wrapper.Q<Foldout>("FoldoutUnlockCondition");
            string unlockConditionFoldoutKey = $"{badgeFoldoutKey}:unlockCondition";
            unlockConditionFoldout.viewDataKey = unlockConditionFoldoutKey;
            unlockConditionFoldout.value = foldouts.TryGetValue(unlockConditionFoldoutKey, out bool unlockExpanded) ? unlockExpanded : unlockConditionFoldout.value;
            unlockConditionFoldout.RegisterValueChangedCallback(evt => foldouts[unlockConditionFoldoutKey] = evt.newValue);

            ConditionChainEditor.Bind(wrapper.Q<VisualElement>("UnlockConditionContainer"), badge.UnlockCondition, training, RefreshHeader);

            return wrapper;
        }

        static string BuildHeaderText(int slotNumber, TrainingBadgeData badge) => $"Badge #{slotNumber} - {badge.Name.GetDisplayName("(no name)")}";

        static string BuildValuePreview(TrainingBadgeData badge) => badge.UnlockCondition.Entries.Count > 0 ? "Auto-triggers when condition is met" : "Never triggers (no condition set)";

        void WireLocalizedSection(VisualElement root, string foldoutKey, string foldoutName, string rowsContainerName, string addButtonName, LanguageDictionary dictionary, Action onChanged = null)
        {
            Foldout sectionFoldout = root.Q<Foldout>(foldoutName);
            sectionFoldout.viewDataKey = foldoutKey;
            sectionFoldout.value = foldouts.TryGetValue(foldoutKey, out bool expanded) ? expanded : sectionFoldout.value;
            sectionFoldout.RegisterValueChangedCallback(evt => foldouts[foldoutKey] = evt.newValue);

            VisualElement rowsContainer = root.Q<VisualElement>(rowsContainerName);

            void RebuildRows()
            {
                rowsContainer.Clear();
                LanguageDictionary.LanguageKey[] keys = dictionary.LanguageKeys;

                for (int i = 0; i < keys.Length; i++)
                {
                    int index = i;

                    languageRowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    DropdownField languagePopup = row.Q<DropdownField>("DropdownLanguageCode");
                    languagePopup.choices = LanguageDictionary.AvailableLanguages.ToList();
                    languagePopup.index = keys[index].localizationIndex;
                    languagePopup.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        int newLanguageIndex = Array.IndexOf(LanguageDictionary.AvailableLanguages, evt.newValue);
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = newLanguageIndex, value = current[index].value };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    TextField valueField = row.Q<TextField>("FieldLanguageValue");
                    valueField.value = keys[index].value;
                    valueField.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = current[index].localizationIndex, value = evt.newValue };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    Button removeButton = row.Q<Button>("ButtonRemoveLanguage");
                    removeButton.clicked += () =>
                    {
                        dictionary.LanguageKeys = dictionary.LanguageKeys.Where((_, keyIndex) => keyIndex != index).ToArray();
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                        RebuildRows();
                    };
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>(addButtonName);
            addButton.clicked += () =>
            {
                int nextLanguage = NextAvailableLanguageIndex(dictionary);
                dictionary.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = nextLanguage, value = string.Empty });
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
                RebuildRows();
            };
        }

        static int NextAvailableLanguageIndex(LanguageDictionary dictionary)
        {
            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (!dictionary.LanguageKeys.Any(key => key.localizationIndex == i))
                    return i;
            }

            return 0;
        }
    }
}
