using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.Validation;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Localization;
using WiDiD.Reflection.Editors;
using WiDiD.Reflection.Tracking;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Interactions
{
    /// <summary>
    /// Authoring tool for a Training's Interaction catalog (see TrainingInteractionData/
    /// InteractionStatementFactory, xAPI-Statements/Interaction/README.md). Always Step-scoped -
    /// grouped by Simulation > Strategy > Step, same nesting PerformanceEditorWindow uses, minus the
    /// Simulation/Strategy-level groups Performance also supports (Interactions have none). Each
    /// entry's Result section (Scaled/Raw/Min/Max/Response) is wired exactly like
    /// PerformanceEditorWindow's own - fixed constant or live reflected source, float for Scaled,
    /// int for Raw/Min/Max (matching xAPI's Score.raw/min/max) - only success/severity/duration
    /// stay out, since those are supplied by host game code at trigger time (see
    /// TrainingRuntime.SendInteraction) rather than authored. UI Toolkit window
    /// (InteractionEditorWindow.uxml/InteractionEntry.uxml + shared Common.uss/LanguageRow.uxml),
    /// same conventions as PerformanceEditorWindow/SkillEditorWindow.
    /// </summary>
    public class InteractionEditorPanel
    {
        static readonly string[] KindChoices = { "Answered Question", "Interacted Interaction" };

        TrainingSO training;
        ObjectField trainingField;
        ScrollView contentScroll;
        VisualTreeAsset entryTemplate;
        VisualTreeAsset languageRowTemplate;

        // Keyed by a stable string id, same reasoning as PerformanceEditorWindow.foldouts.
        readonly Dictionary<string, bool> foldouts = new();

        readonly TrainingValidationView validation = new();

        public VisualElement CreateView()
        {
            VisualElement root = new();

            entryTemplate = ImmersiveEditorUIConfigLoader.Assets.InteractionEntry;
            languageRowTemplate = ImmersiveEditorUIConfigLoader.Assets.LanguageRow;

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.InteractionEditorWindow;
            visualTree.CloneTree(root);

            trainingField = root.Q<ObjectField>("ObjectFieldTraining");
            trainingField.objectType = typeof(TrainingSO);
            trainingField.value = training;
            trainingField.RegisterValueChangedCallback(evt => SetTraining((TrainingSO)evt.newValue));

            contentScroll = root.Q<ScrollView>("ContentScroll");

            Rebuild();

            return root;
        }

        public void SetTraining(TrainingSO newTraining)
        {
            training = newTraining;

            if (trainingField != null)
                trainingField.SetValueWithoutNotify(training);

            Rebuild();
        }

        void Rebuild()
        {
            if (contentScroll == null)
                return;

            contentScroll.Clear();
            validation.Clear();

            if (training == null)
            {
                contentScroll.Add(new Label("Pick a Training to edit its Interaction catalog.") { style = { opacity = 0.7f, marginTop = 8 } });
                return;
            }

            HashSet<string> duplicateIds = DuplicateIdFinder.Find(CollectAllInteractions(), interaction => interaction.Id);

            contentScroll.Add(BuildSimulationSection(duplicateIds));
        }

        VisualElement BuildSimulationSection(HashSet<string> duplicateIds)
        {
            Foldout foldout = CreateFoldout($"simulation:{training.Data.Id}", $"Simulation: {training.Data.Id}", levelClass: "wid-foldout-level-simulation");

            foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                foldout.Add(BuildStrategySection(strategy, duplicateIds));

            validation.AddSection(foldout, () => training.Data.GameFlow.Strategies.Any(strategy => TrainingCatalogValidation.HasInvalidInteractions(strategy)));

            return foldout;
        }

        VisualElement BuildStrategySection(TrainingStrategyData strategy, HashSet<string> duplicateIds)
        {
            Foldout foldout = CreateFoldout($"strategy:{strategy.Id}", $"Strategy: {strategy.Name.GetDisplayName("Strategy")}", defaultExpanded: false, levelClass: "wid-foldout-level-strategy");

            foreach (TrainingStepData step in strategy.Steps)
                foldout.Add(BuildStepSection(step, duplicateIds));

            validation.AddSection(foldout, () => TrainingCatalogValidation.HasInvalidInteractions(strategy));

            return foldout;
        }

        VisualElement BuildStepSection(TrainingStepData step, HashSet<string> duplicateIds)
        {
            Foldout foldout = CreateFoldout($"step:{step.Id}", $"Step: {step.Name.GetDisplayName("Step")}", defaultExpanded: false, levelClass: "wid-foldout-level-step");
            foldout.Add(BuildInteractionGroup(step.Interactions, duplicateIds, 1));

            validation.AddSection(foldout, () => TrainingCatalogValidation.HasInvalidInteractions(step));

            return foldout;
        }

        Foldout CreateFoldout(string key, string text, bool defaultExpanded = true, string levelClass = null)
        {
            bool expanded = foldouts.TryGetValue(key, out bool state) ? state : defaultExpanded;
            Foldout foldout = new() { text = text, value = expanded, viewDataKey = key };
            foldout.AddToClassList("wid-foldout-spaced");

            if (levelClass != null)
                foldout.AddToClassList(levelClass);

            foldout.RegisterValueChangedCallback(evt => foldouts[key] = evt.newValue);
            return foldout;
        }

        IEnumerable<TrainingInteractionData> CollectAllInteractions()
        {
            foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                foreach (TrainingStepData step in strategy.Steps)
                    foreach (TrainingInteractionData interaction in step.Interactions)
                        yield return interaction;
        }

        VisualElement BuildInteractionGroup(List<TrainingInteractionData> interactions, HashSet<string> duplicateIds, int depth)
        {
            VisualElement container = new();
            container.AddToClassList($"wid-depth-{Mathf.Min(depth, 3)}");

            foreach (TrainingInteractionData interaction in interactions)
                container.Add(BuildInteractionEntry(interaction, interactions, duplicateIds, depth + 1));

            VisualElement addRow = new();
            addRow.AddToClassList("wid-button-center-row");
            Button addButton = new(() =>
            {
                TrainingInteractionData newInteraction = new() { Id = Guid.NewGuid().ToString("N").Substring(0, 8) };
                interactions.Add(newInteraction);
                foldouts[$"interaction:{newInteraction.Id}"] = true;
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            })
            { text = "+ Add Interaction" };
            addRow.Add(addButton);
            container.Add(addRow);

            return container;
        }

        VisualElement BuildInteractionEntry(TrainingInteractionData interaction, List<TrainingInteractionData> currentContainer, HashSet<string> duplicateIds, int depth)
        {
            string interactionFoldoutKey = $"interaction:{interaction.Id}";

            VisualElement wrapper = entryTemplate.CloneTree();
            wrapper.AddToClassList($"wid-depth-{Mathf.Min(depth, 3)}");

            Foldout foldout = wrapper.Q<Foldout>("FoldoutHeader");
            foldout.viewDataKey = interactionFoldoutKey;
            foldout.text = BuildHeaderText(interaction);
            foldout.value = foldouts.TryGetValue(interactionFoldoutKey, out bool expanded) ? expanded : false;
            foldout.RegisterValueChangedCallback(evt => foldouts[interactionFoldoutKey] = evt.newValue);

            Label previewLabel = wrapper.Q<Label>("LabelPreview");
            previewLabel.text = BuildValuePreview(interaction);

            validation.AddIndicator(wrapper.Q<VisualElement>("HeaderRow"), foldout, () => TrainingEntryValidator.Validate(interaction));

            Button deleteButton = wrapper.Q<Button>("ButtonDelete");
            deleteButton.clicked += () =>
            {
                string idLabel = string.IsNullOrEmpty(interaction.Id) ? "(no id)" : interaction.Id;
                bool confirmed = EditorUtility.DisplayDialog("Delete Interaction", $"Delete interaction '{idLabel}'? This cannot be undone.", "Yes", "No");
                if (!confirmed)
                    return;

                currentContainer.Remove(interaction);
                foldouts.Remove(interactionFoldoutKey);
                EditorUtility.SetDirty(training);
                EditorApplication.delayCall += Rebuild;
            };

            if (!string.IsNullOrEmpty(interaction.Id) && duplicateIds.Contains(interaction.Id))
            {
                HelpBox duplicateWarning = new($"Duplicate Id '{interaction.Id}' - each Interaction needs a unique Id within this Training.", HelpBoxMessageType.Error);
                wrapper.Q<VisualElement>("DuplicateWarningSlot").Add(duplicateWarning);
            }

            void RefreshHeader()
            {
                foldout.text = BuildHeaderText(interaction);
                previewLabel.text = BuildValuePreview(interaction);
                validation.Refresh();
            }

            TextField idField = wrapper.Q<TextField>("FieldId");
            idField.value = interaction.Id;
            idField.RegisterValueChangedCallback(evt =>
            {
                interaction.Id = evt.newValue;
                EditorUtility.SetDirty(training);
                RefreshHeader();
            });

            WireLocalizedSection(wrapper, $"{interactionFoldoutKey}:name", "FoldoutName", "NameRows", "ButtonAddNameLanguage", interaction.Name, RefreshHeader);
            WireLocalizedSection(wrapper, $"{interactionFoldoutKey}:description", "FoldoutDescription", "DescriptionRows", "ButtonAddDescriptionLanguage", interaction.Description);

            WireKindDropdown(wrapper, interaction, RefreshHeader);
            WireInteractionTypeDropdown(wrapper, interaction, RefreshHeader);

            // Same reasoning as PerformanceEditorWindow.FoldoutResult - needs its own stable
            // viewDataKey, since every cloned entry otherwise shares the same "FoldoutResult" name.
            Foldout resultFoldout = wrapper.Q<Foldout>("FoldoutResult");
            string resultFoldoutKey = $"{interactionFoldoutKey}:result";
            resultFoldout.viewDataKey = resultFoldoutKey;
            resultFoldout.value = foldouts.TryGetValue(resultFoldoutKey, out bool resultExpanded) ? resultExpanded : resultFoldout.value;
            resultFoldout.RegisterValueChangedCallback(evt => foldouts[resultFoldoutKey] = evt.newValue);

            WireValueSourceRow(wrapper, "Scaled", interaction.Scaled, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Raw", interaction.Raw, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Min", interaction.Min, RefreshHeader);
            WireIntValueSourceRow(wrapper, "Max", interaction.Max, RefreshHeader);
            WireStringValueSourceRow(wrapper, "Response", interaction.Response, RefreshHeader);

            // Same viewDataKey reasoning as FoldoutResult above.
            Foldout successConditionFoldout = wrapper.Q<Foldout>("FoldoutSuccessCondition");
            string successConditionFoldoutKey = $"{interactionFoldoutKey}:successCondition";
            successConditionFoldout.viewDataKey = successConditionFoldoutKey;
            successConditionFoldout.value = foldouts.TryGetValue(successConditionFoldoutKey, out bool successConditionExpanded) ? successConditionExpanded : successConditionFoldout.value;
            successConditionFoldout.RegisterValueChangedCallback(evt => foldouts[successConditionFoldoutKey] = evt.newValue);

            ConditionChainEditor.Bind(wrapper.Q<VisualElement>("SuccessConditionContainer"), interaction.SuccessCondition, training, RefreshHeader);

            return wrapper;
        }

        void WireKindDropdown(VisualElement root, TrainingInteractionData interaction, Action onChanged)
        {
            DropdownField dropdown = root.Q<DropdownField>("DropdownKind");
            dropdown.choices = KindChoices.ToList();
            dropdown.SetValueWithoutNotify(KindChoices[(int)interaction.Kind]);
            dropdown.RegisterValueChangedCallback(evt =>
            {
                interaction.Kind = (InteractionKind)Array.IndexOf(KindChoices, evt.newValue);
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });
        }

        void WireInteractionTypeDropdown(VisualElement root, TrainingInteractionData interaction, Action onChanged)
        {
            List<string> choices = InteractionTypes.All.Keys.OrderBy(key => key).ToList();

            DropdownField dropdown = root.Q<DropdownField>("DropdownInteractionType");
            dropdown.choices = choices;
            dropdown.SetValueWithoutNotify(choices.Contains(interaction.InteractionTypeKey) ? interaction.InteractionTypeKey : choices.FirstOrDefault());
            dropdown.RegisterValueChangedCallback(evt =>
            {
                interaction.InteractionTypeKey = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });
        }

        static string BuildHeaderText(TrainingInteractionData interaction)
        {
            string idLabel = string.IsNullOrEmpty(interaction.Id) ? "(no id)" : interaction.Id;
            string nameLabel = interaction.Name.GetDisplayName("(no name)");
            return $"{idLabel} - {nameLabel}";
        }

        // Same priority as PerformanceEditorWindow.BuildValuePreview - Response (already a display
        // string) > Raw > Scaled - falling back to just Kind/InteractionType when none are set.
        static string BuildValuePreview(TrainingInteractionData interaction)
        {
            string kindAndType = $"{KindChoices[(int)interaction.Kind]} · {interaction.InteractionTypeKey}";

            string response = ResolvePreview(interaction.Response);
            if (!string.IsNullOrEmpty(response))
                return $"{kindAndType} · {response}";

            int? raw = ResolvePreview(interaction.Raw);
            if (raw.HasValue)
                return $"{kindAndType} · {raw.Value}";

            float? scaled = ResolvePreview(interaction.Scaled);
            if (scaled.HasValue)
                return $"{kindAndType} · {scaled.Value:0.##}";

            return kindAndType;
        }

        static float? ResolvePreview(PerformanceValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<float>(target, source.ReflectedSource.Data);
        }

        static int? ResolvePreview(PerformanceIntValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<int>(target, source.ReflectedSource.Data);
        }

        static string ResolvePreview(PerformanceStringValueSource source)
        {
            if (!source.Enabled)
                return null;

            if (source.ReflectedSource == null)
                return source.FixedValue;

            TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
            return ReflectedValueResolver.ResolveFrom<string>(target, source.ReflectedSource.Data);
        }

        void WireLocalizedSection(VisualElement root, string foldoutKey, string foldoutName, string rowsContainerName, string addButtonName, LanguageDictionary dictionary, Action onChanged = null)
        {
            Foldout sectionFoldout = root.Q<Foldout>(foldoutName);
            sectionFoldout.viewDataKey = foldoutKey;
            sectionFoldout.value = foldouts.TryGetValue(foldoutKey, out bool expanded) ? expanded : sectionFoldout.value;
            sectionFoldout.RegisterValueChangedCallback(evt => foldouts[foldoutKey] = evt.newValue);

            VisualElement rowsContainer = root.Q<VisualElement>(rowsContainerName);

            void RebuildRows()
            {
                rowsContainer.Clear();
                LanguageDictionary.LanguageKey[] keys = dictionary.LanguageKeys;

                for (int i = 0; i < keys.Length; i++)
                {
                    int index = i;

                    languageRowTemplate.CloneTree(rowsContainer);
                    VisualElement row = rowsContainer.Children().Last();

                    DropdownField languagePopup = row.Q<DropdownField>("DropdownLanguageCode");
                    languagePopup.choices = LanguageDictionary.AvailableLanguages.ToList();
                    languagePopup.index = keys[index].localizationIndex;
                    languagePopup.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        int newLanguageIndex = Array.IndexOf(LanguageDictionary.AvailableLanguages, evt.newValue);
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = newLanguageIndex, value = current[index].value };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    TextField valueField = row.Q<TextField>("FieldLanguageValue");
                    valueField.value = keys[index].value;
                    valueField.RegisterValueChangedCallback(evt =>
                    {
                        LanguageDictionary.LanguageKey[] current = dictionary.LanguageKeys;
                        current[index] = new LanguageDictionary.LanguageKey { localizationIndex = current[index].localizationIndex, value = evt.newValue };
                        dictionary.LanguageKeys = current;
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                    });

                    Button removeButton = row.Q<Button>("ButtonRemoveLanguage");
                    removeButton.clicked += () =>
                    {
                        dictionary.LanguageKeys = dictionary.LanguageKeys.Where((_, keyIndex) => keyIndex != index).ToArray();
                        EditorUtility.SetDirty(training);
                        onChanged?.Invoke();
                        RebuildRows();
                    };
                }
            }

            RebuildRows();

            Button addButton = root.Q<Button>(addButtonName);
            addButton.clicked += () =>
            {
                int nextLanguage = NextAvailableLanguageIndex(dictionary);
                dictionary.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = nextLanguage, value = string.Empty });
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
                RebuildRows();
            };
        }

        static int NextAvailableLanguageIndex(LanguageDictionary dictionary)
        {
            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (!dictionary.LanguageKeys.Any(key => key.localizationIndex == i))
                    return i;
            }

            return 0;
        }

        void WireValueSourceRow(VisualElement root, string namePrefix, PerformanceValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            FloatField fixedField = root.Q<FloatField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedFloatSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedFloatSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }

        void WireIntValueSourceRow(VisualElement root, string namePrefix, PerformanceIntValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            IntegerField fixedField = root.Q<IntegerField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedIntSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedIntSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }

        void WireStringValueSourceRow(VisualElement root, string namePrefix, PerformanceStringValueSource source, Action onChanged = null)
        {
            Toggle toggle = root.Q<Toggle>($"Toggle{namePrefix}Enabled");
            ObjectField objectField = root.Q<ObjectField>($"ObjectField{namePrefix}Source");
            TextField fixedField = root.Q<TextField>($"Field{namePrefix}Fixed");
            Label pathLabel = root.Q<Label>($"Label{namePrefix}Path");

            ReflectedSourceField.Attach(objectField, typeof(ReflectedStringSourceSO));
            toggle.value = source.Enabled;
            objectField.value = source.ReflectedSource;
            fixedField.value = source.FixedValue;

            void Refresh()
            {
                objectField.SetEnabled(source.Enabled);
                fixedField.SetEnabled(source.Enabled);

                bool showPath = source.Enabled && source.ReflectedSource != null;
                fixedField.style.display = showPath ? DisplayStyle.None : DisplayStyle.Flex;
                pathLabel.style.display = showPath ? DisplayStyle.Flex : DisplayStyle.None;

                if (showPath)
                {
                    TrackableId target = ReflectedSourcePathUtility.FindTrackable(source.ReflectedSource.Data.TargetGuid);
                    ReflectedSourcePathUtility.CacheLastKnownLocation(source.ReflectedSource, source.ReflectedSource.Data, target);
                    pathLabel.text = ReflectedSourcePathUtility.BuildFriendlyPath(source.ReflectedSource.Data, target);
                }
            }

            toggle.RegisterValueChangedCallback(evt =>
            {
                source.Enabled = evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            objectField.RegisterValueChangedCallback(evt =>
            {
                source.ReflectedSource = (ReflectedStringSourceSO)evt.newValue;
                EditorUtility.SetDirty(training);
                Refresh();
                onChanged?.Invoke();
            });

            fixedField.RegisterValueChangedCallback(evt =>
            {
                source.FixedValue = evt.newValue;
                EditorUtility.SetDirty(training);
                onChanged?.Invoke();
            });

            Refresh();
        }
    }
}
