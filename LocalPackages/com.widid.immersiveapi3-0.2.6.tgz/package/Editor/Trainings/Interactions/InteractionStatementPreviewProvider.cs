using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Interactions
{
    /// <summary>
    /// Exposes every Interaction in the project (always Step-scoped, see
    /// xAPI-Statements/Interaction/README.md) as a StatementPreviewWindow target, discovered
    /// automatically via IStatementPreviewProvider, same convention as
    /// GameFlowStatementPreviewProvider/PerformanceStatementPreviewProvider.
    /// </summary>
    public class InteractionStatementPreviewProvider : IStatementPreviewProvider
    {
        public IEnumerable<IStatementPreviewTarget> GetTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            UserSessionSO sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            string sessionTrainingId = sessionAsset != null ? sessionAsset.Data.TrainingId : string.Empty;

            foreach (string guid in AssetDatabase.FindAssets("t:TrainingSO"))
            {
                TrainingSO training = AssetDatabase.LoadAssetAtPath<TrainingSO>(AssetDatabase.GUIDToAssetPath(guid));
                if (training == null)
                    continue;

                Simulation simulation = SimulationStatementFactory.Initialized(training, sessionTrainingId);

                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    string strategyLabel = strategy.Name.GetDisplayName(strategy.Id);
                    Strategy parentStrategy = StrategyStatementFactory.Launched(simulation, strategy);

                    foreach (TrainingStepData step in strategy.Steps)
                    {
                        string stepLabel = step.Name.GetDisplayName(step.Id);
                        Step parentStep = StepStatementFactory.Launched(simulation, parentStrategy, step);

                        foreach (TrainingInteractionData interaction in step.Interactions)
                            targets.Add(new InteractionPreviewTarget(new[] { training.Data.Id, strategyLabel, stepLabel, "Interactions", interaction.Name.GetDisplayName(interaction.Id) }, simulation, parentStrategy, parentStep, interaction));
                    }
                }
            }

            return targets;
        }
    }
}
