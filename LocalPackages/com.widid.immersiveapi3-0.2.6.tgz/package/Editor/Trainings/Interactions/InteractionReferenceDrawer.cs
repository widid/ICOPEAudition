using System.Collections.Generic;
using UnityEditor;
using WiDiD.ImmersiveAPI.Editor.Trainings.GameFlow;
using WiDiD.ImmersiveAPI.Editor.Trainings.References;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Interactions
{
    /// <summary>
    /// Renders an InteractionReference field as a "Training/Strategy/Step/Name" dropdown instead of
    /// a raw id text field, scanning every TrainingSO asset in the project for its Interactions -
    /// same convention as StepReferenceDrawer/StrategyReferenceDrawer.
    /// </summary>
    [CustomPropertyDrawer(typeof(InteractionReference))]
    public class InteractionReferenceDrawer : ATrainingReferenceDrawer
    {
        protected override string ValuePropertyName => "interactionId";

        protected override List<TrainingReferenceOption> CollectOptions()
        {
            List<TrainingReferenceOption> results = new() { TrainingReferenceOption.None };

            foreach (TrainingSO training in TrainingAssetCatalog.LoadAll())
            {
                foreach (TrainingStrategyData strategy in training.Data.GameFlow.Strategies)
                {
                    string strategyLabel = strategy.Name.GetDisplayName("Strategy");
                    foreach (TrainingStepData step in strategy.Steps)
                    {
                        string stepLabel = step.Name.GetDisplayName("Step");
                        foreach (TrainingInteractionData interaction in step.Interactions)
                            results.Add(new TrainingReferenceOption(interaction.Id, $"{training.Data.Id}/{strategyLabel}/{stepLabel}/{interaction.Name.GetDisplayName(interaction.Id)}"));
                    }
                }
            }

            return results;
        }
    }
}
