using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.ImmersiveAPI.Editor.Statements;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Editor.Trainings.Interactions
{
    /// <summary>
    /// Previews the single statement a TrainingInteractionData sends (see
    /// InteractionStatementFactory) - which one depends on its own Kind. Score/Response come from
    /// the entry's own authored value sources (same as a real send); only success/duration/severity
    /// use placeholder values since those are supplied by host game code at trigger time (see
    /// TrainingRuntime.SendInteraction), not authored here.
    /// </summary>
    class InteractionPreviewTarget : IStatementPreviewTarget
    {
        readonly IReadOnlyList<string> pathSegments;
        readonly Simulation simulation;
        readonly Strategy parentStrategy;
        readonly Step parentStep;
        readonly TrainingInteractionData data;

        public InteractionPreviewTarget(IReadOnlyList<string> pathSegments, Simulation simulation, Strategy parentStrategy, Step parentStep, TrainingInteractionData data)
        {
            this.pathSegments = pathSegments;
            this.simulation = simulation;
            this.parentStrategy = parentStrategy;
            this.parentStep = parentStep;
            this.data = data;
        }

        public string FamilyName => "Interactions";
        public IReadOnlyList<string> PathSegments => pathSegments;
        public IReadOnlyList<string> CompatibleVerbNames => new[] { data.Kind == InteractionKind.AnsweredQuestion ? "Answered" : "Interacted" };

        public (Verb Verb, IStatementable Statementable) Build(string verbName)
        {
            return data.Kind switch
            {
                InteractionKind.AnsweredQuestion => (Verbs.Answered, InteractionStatementFactory.AnsweredQuestion(simulation, parentStrategy, parentStep, data, success: true, severity: SeverityLevel.Success)),
                InteractionKind.InteractedInteraction => (Verbs.Interacted, InteractionStatementFactory.InteractedInteraction(simulation, parentStrategy, parentStep, data, success: true, duration: TimeSpan.FromMinutes(5), severity: SeverityLevel.Success)),
                _ => throw new ArgumentOutOfRangeException(nameof(data.Kind), data.Kind, null)
            };
        }
    }
}
