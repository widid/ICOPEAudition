using System.Collections.Generic;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace WiDiD.ImmersiveAPI.Editor.Settings
{
    /// <summary>
    /// One place for every ImmersiveAPI setting and the package's current status. Settings are
    /// discovered from [ImmersiveSettings] rather than listed here (see ImmersiveSettingsRegistry),
    /// and each one is drawn with its own default Inspector, so adding a setting - or a field to an
    /// existing one - shows up here with no change to this window.
    ///
    /// Built in code rather than from a UXML asset like the other ImmersiveAPI windows: it has no
    /// fixed layout to author (its content is whatever settings exist), and this way the package
    /// carries no extra VisualTreeAsset reference to wire into ImmersiveEditorUIConfigSO.
    /// </summary>
    public class ImmersiveApiConfigWindow : EditorWindow
    {
        // Status is polled rather than event-driven: most of what it reports (session fields,
        // TrainingRuntime state) exposes no change notification - same reasoning as
        // SessionInfoPanelController's own refresh loop, just slower, since each pass re-reads the
        // Resources folder and nothing here changes fast enough to need sub-second updates.
        const int StatusRefreshMs = 1000;
        const int LabelWidth = 150;

        VisualElement settingsSection;
        VisualElement statusSection;

        // priority 0 so the package's entry point sits above the task-specific windows, which
        // all take the default.
        [MenuItem("WiDiD_API/ImmersiveAPI/Configuration", priority = 0)]
        public static void ShowWindow()
        {
            ImmersiveApiConfigWindow window = GetWindow<ImmersiveApiConfigWindow>();
            window.titleContent = new GUIContent("ImmersiveAPI Config");
            window.minSize = new Vector2(460, 360);
        }

        public void CreateGUI()
        {
            ScrollView scroll = new ScrollView();
            scroll.style.flexGrow = 1;
            scroll.contentContainer.style.paddingLeft = 8;
            scroll.contentContainer.style.paddingRight = 8;
            scroll.contentContainer.style.paddingTop = 6;
            rootVisualElement.Add(scroll);

            scroll.Add(new Button(() =>
            {
                RebuildSettings();
                RefreshStatus();
            })
            { text = "Refresh" });

            scroll.Add(SectionTitle("Settings"));
            settingsSection = new VisualElement();
            scroll.Add(settingsSection);

            scroll.Add(SectionTitle("Status"));
            statusSection = new VisualElement();
            scroll.Add(statusSection);

            RebuildSettings();
            RefreshStatus();
            rootVisualElement.schedule.Execute(RefreshStatus).Every(StatusRefreshMs);
        }

        void RebuildSettings()
        {
            List<ImmersiveSettingsEntry> entries = ImmersiveSettingsRegistry.Discover();
            settingsSection.Clear();

            if (entries.Count == 0)
            {
                settingsSection.Add(Hint("No setting declares [ImmersiveSettings] yet."));
                return;
            }

            foreach (ImmersiveSettingsEntry entry in entries)
                settingsSection.Add(BuildSetting(entry));
        }

        VisualElement BuildSetting(ImmersiveSettingsEntry entry)
        {
            Foldout foldout = new Foldout { text = entry.Meta.Title, value = true };
            foldout.style.marginBottom = 6;

            if (!string.IsNullOrEmpty(entry.Meta.Description))
                foldout.Add(Hint(entry.Meta.Description));

            if (!entry.Exists)
            {
                foldout.Add(Hint($"No asset at Resources/{entry.Meta.ResourcePath} - this setting is running on its defaults."));
                foldout.Add(new Button(() =>
                {
                    entry.Create();
                    RebuildSettings();
                })
                { text = "Create asset" });

                return foldout;
            }

            foldout.Add(new InspectorElement(entry.Asset));
            foldout.Add(new Button(() => EditorGUIUtility.PingObject(entry.Asset)) { text = "Show asset in Project" });

            return foldout;
        }

        void RefreshStatus()
        {
            statusSection.Clear();

            foreach (ImmersiveStatusLine line in ImmersiveStatusReport.Collect())
                statusSection.Add(StatusRow(line));
        }

        static VisualElement StatusRow(ImmersiveStatusLine line)
        {
            VisualElement row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;

            Label label = new Label(line.Label);
            label.style.width = LabelWidth;
            label.style.unityFontStyleAndWeight = FontStyle.Bold;

            Label value = new Label(line.Value);
            value.style.flexGrow = 1;
            value.style.whiteSpace = WhiteSpace.Normal;
            if (line.Ok.HasValue)
                value.style.color = line.Ok.Value ? new Color(0.45f, 0.8f, 0.45f) : new Color(0.9f, 0.45f, 0.45f);

            row.Add(label);
            row.Add(value);

            return row;
        }

        static Label SectionTitle(string text)
        {
            Label title = new Label(text);
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.fontSize = 14;
            title.style.marginTop = 10;
            title.style.marginBottom = 4;

            return title;
        }

        static Label Hint(string text)
        {
            Label hint = new Label(text);
            hint.style.whiteSpace = WhiteSpace.Normal;
            hint.style.opacity = 0.75f;
            hint.style.marginBottom = 4;

            return hint;
        }
    }
}
