using System;
using UnityEngine;
using WiDiD.ImmersiveAPI.Settings;

namespace WiDiD.ImmersiveAPI.Editor.Settings
{
    /// <summary>
    /// One discovered settings ScriptableObject: its attribute metadata plus the asset backing it,
    /// which is null until created - a setting with no asset isn't broken, it just runs on its own
    /// defaults, which is why the config window offers a Create button rather than creating one.
    /// </summary>
    public class ImmersiveSettingsEntry
    {
        public Type Type { get; }
        public ImmersiveSettingsAttribute Meta { get; }
        public ScriptableObject Asset { get; private set; }

        public string AssetPath => ImmersiveResourceAsset.ProjectPath(Meta.ResourcePath);
        public bool Exists => Asset != null;

        public ImmersiveSettingsEntry(Type type, ImmersiveSettingsAttribute meta)
        {
            Type = type;
            Meta = meta;
            Reload();
        }

        public void Reload()
        {
            Asset = ImmersiveResourceAsset.Load(Type, Meta.ResourcePath);
        }

        /// <summary>
        /// Creates the asset at the one path Resources.Load will find it at, so enabling a setting
        /// never means hand-placing a file in the right folder.
        /// </summary>
        public void Create()
        {
            Asset = ImmersiveResourceAsset.EnsureExists(Type, Meta.ResourcePath);
        }
    }
}
