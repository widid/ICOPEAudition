using System.Collections.Generic;
using UnityEngine;
using WiDiD.ImmersiveAPI.Authentication;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;
using WiDiD.ImmersiveAPI.Trainings;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;

namespace WiDiD.ImmersiveAPI.Editor.Settings
{
    /// <summary>
    /// Snapshot of what the ImmersiveAPI package currently has to work with: the assets it loads
    /// from Resources, the debug session filled in by ImmersiveDebugSessionWindow, and (in Play
    /// mode) TrainingRuntime's own state. Read-only by design - this panel answers "why isn't this
    /// working?", it doesn't change anything.
    /// </summary>
    public static class ImmersiveStatusReport
    {
        public static List<ImmersiveStatusLine> Collect()
        {
            List<ImmersiveStatusLine> lines = new List<ImmersiveStatusLine>();

            UserSessionSO session = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            lines.Add(new ImmersiveStatusLine("Session asset", session != null ? $"Resources/{UserSessionSO.ResourcePath}" : "Missing", session != null));

            if (session != null)
                AddSessionLines(lines, session.Data);

            TrainingSO[] trainings = Resources.LoadAll<TrainingSO>(TrainingSO.ResourcesFolder);
            lines.Add(new ImmersiveStatusLine("Trainings found", trainings.Length.ToString(), trainings.Length > 0));

            lines.Add(new ImmersiveStatusLine("Runtime ready", TrainingRuntime.IsReady ? "Yes" : "No - initializes in Play mode"));
            lines.Add(new ImmersiveStatusLine("Active training", TrainingRuntime.ActiveTraining != null ? TrainingRuntime.ActiveTraining.Data.Id : "(none)"));

            return lines;
        }

        static void AddSessionLines(List<ImmersiveStatusLine> lines, UserSessionData data)
        {
            bool signedIn = !string.IsNullOrEmpty(data.DecodedToken);
            lines.Add(new ImmersiveStatusLine("Signed in", signedIn ? "Yes" : "No - use the Debug Session window", signedIn));
            lines.Add(new ImmersiveStatusLine("Target url", Displayed(data.TargetUrl)));
            lines.Add(new ImmersiveStatusLine("Training id", Displayed(data.TrainingId)));
            lines.Add(new ImmersiveStatusLine("Module argument", Displayed(data.ModuleArgument)));
            lines.Add(new ImmersiveStatusLine("User id", Displayed(data.UserId)));
            lines.Add(new ImmersiveStatusLine("Launch time", LaunchTimeDisplay.Format(data.LaunchTime)));
            lines.Add(new ImmersiveStatusLine("User profile", DisplayedProfile(data.UserProfile?.Info)));
        }

        static string DisplayedProfile(ProfileInfo profile)
        {
            if (profile == null)
                return "Not fetched - the launcher passes no name, see UserProfileService";

            return $"{profile.FirstName} {profile.LastName}".Trim();
        }

        static string Displayed(string value) => string.IsNullOrEmpty(value) ? "(empty)" : value;
    }
}
