namespace WiDiD.ImmersiveAPI.Editor.Settings
{
    /// <summary>
    /// One row of the config window's status panel. Ok is null for a plain informational value -
    /// only something that can actually be right or wrong gets colored.
    /// </summary>
    public class ImmersiveStatusLine
    {
        public string Label { get; }
        public string Value { get; }
        public bool? Ok { get; }

        public ImmersiveStatusLine(string label, string value, bool? ok = null)
        {
            Label = label;
            Value = value;
            Ok = ok;
        }
    }
}
