using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using WiDiD.ImmersiveAPI.Settings;

namespace WiDiD.ImmersiveAPI.Editor.Settings
{
    /// <summary>
    /// Every [ImmersiveSettings] ScriptableObject in the project, in display order. Reflection over
    /// a maintained list on purpose: adding a setting shouldn't require editing the window.
    /// </summary>
    public static class ImmersiveSettingsRegistry
    {
        public static List<ImmersiveSettingsEntry> Discover()
        {
            return TypeCache.GetTypesWithAttribute<ImmersiveSettingsAttribute>()
                .Where(type => !type.IsAbstract && typeof(ScriptableObject).IsAssignableFrom(type))
                .Select(type => new ImmersiveSettingsEntry(type, (ImmersiveSettingsAttribute)Attribute.GetCustomAttribute(type, typeof(ImmersiveSettingsAttribute))))
                .OrderBy(entry => entry.Meta.Order)
                .ThenBy(entry => entry.Meta.Title)
                .ToList();
        }
    }
}
