using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Editor.Statements
{
    /// <summary>
    /// Contributes IStatementPreviewTargets to StatementPreviewWindow. Implement this anywhere in
    /// the project - one per family of trackable object (GameFlow, Performance, Skill, Points,
    /// ...) - and it's picked up automatically via TypeCache; the window never needs editing to
    /// support a new family.
    /// </summary>
    public interface IStatementPreviewProvider
    {
        IEnumerable<IStatementPreviewTarget> GetTargets();
    }
}
