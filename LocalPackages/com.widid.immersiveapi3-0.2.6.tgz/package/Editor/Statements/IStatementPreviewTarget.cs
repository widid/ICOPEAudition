using System.Collections.Generic;
using System.Threading.Tasks;
using TinCan;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Editor.Statements
{
    /// <summary>
    /// One previewable xAPI statement source for StatementPreviewWindow - a GameFlow Strategy/Step,
    /// a Performance/Skill/Interaction/Badge/Reward instance, or anything else IStatementable. The
    /// window only knows this interface, never the concrete kind behind it.
    /// </summary>
    public interface IStatementPreviewTarget
    {
        /// <summary>
        /// Coarse family this target belongs to (e.g. "GameFlow", "Performances", "Skills") - lets
        /// StatementPreviewWindow offer a Type filter before narrowing to one specific target,
        /// without the window ever needing to know the concrete IStatementPreviewTarget behind it.
        /// </summary>
        string FamilyName { get; }

        /// <summary>
        /// Where this target sits within its family, e.g. ["SPEECH", "Intro", "Answer the
        /// question"] - joined with "/" to build a human-readable breadcrumb once a family is
        /// selected. A leaf that also wants to represent "this level itself" (e.g. previewing a
        /// Strategy, not one of its Steps) should add a distinct trailing segment (e.g.
        /// "(Strategy)") rather than reusing its parent's path.
        /// </summary>
        IReadOnlyList<string> PathSegments { get; }

        IReadOnlyList<string> CompatibleVerbNames { get; }
        (Verb Verb, IStatementable Statementable) Build(string verbName);

        /// <summary>
        /// Same as Build(), but performs whatever real network side-effects (e.g. a Performance
        /// uploading its attachments - see PerformancePreviewTarget) are needed for the resulting
        /// statement to be genuinely sendable, not just previewable. Defaults to wrapping the
        /// synchronous Build() for every family that has no such side-effects, so this never needs
        /// implementing unless a family actually has something to upload first.
        /// </summary>
        Task<(Verb Verb, IStatementable Statementable)> BuildForSend(string verbName) => Task.FromResult(Build(verbName));
    }
}
