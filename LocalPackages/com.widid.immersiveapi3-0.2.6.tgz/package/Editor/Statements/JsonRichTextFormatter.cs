using System.Text;

namespace WiDiD.ImmersiveAPI.Editor.Statements
{
    /// <summary>
    /// Wraps a JSON string's keys/string values/numbers/keywords in UI Toolkit rich-text color
    /// tags, so a Label with richText enabled renders it with per-token-type color distinction.
    /// General-purpose - not tied to xAPI statements specifically, just JSON text.
    ///
    /// Leading indentation is left as plain spaces from Formatting.Indented - the Label
    /// displaying this text must use "white-space: pre" so those spaces aren't collapsed.
    /// </summary>
    public static class JsonRichTextFormatter
    {
        const string KeyColor = "#9CDCFE";
        const string StringColor = "#CE9178";
        const string NumberColor = "#B5CEA8";
        const string KeywordColor = "#569CD6";

        public static string Colorize(string json)
        {
            return ColorizeTokens(json);
        }

        static string ColorizeTokens(string json)
        {
            StringBuilder result = new(json.Length * 2);
            int i = 0;

            while (i < json.Length)
            {
                char c = json[i];

                if (c == '"')
                {
                    int start = i;
                    i++;
                    while (i < json.Length && (json[i] != '"' || json[i - 1] == '\\'))
                        i++;
                    i = System.Math.Min(i + 1, json.Length);

                    string token = json.Substring(start, i - start);
                    bool isKey = IsFollowedByColon(json, i);

                    result.Append("<color=").Append(isKey ? KeyColor : StringColor).Append('>').Append(token).Append("</color>");
                    continue;
                }

                if (char.IsDigit(c) || (c == '-' && i + 1 < json.Length && char.IsDigit(json[i + 1])))
                {
                    int start = i;
                    i++;
                    while (i < json.Length && (char.IsDigit(json[i]) || json[i] is '.' or 'e' or 'E' or '+' or '-'))
                        i++;

                    result.Append("<color=").Append(NumberColor).Append('>').Append(json, start, i - start).Append("</color>");
                    continue;
                }

                if (TryMatchKeyword(json, i, out string keyword))
                {
                    result.Append("<color=").Append(KeywordColor).Append('>').Append(keyword).Append("</color>");
                    i += keyword.Length;
                    continue;
                }

                result.Append(c);
                i++;
            }

            return result.ToString();
        }

        static bool IsFollowedByColon(string json, int index)
        {
            while (index < json.Length && char.IsWhiteSpace(json[index]))
                index++;

            return index < json.Length && json[index] == ':';
        }

        static bool TryMatchKeyword(string json, int index, out string keyword)
        {
            foreach (string candidate in new[] { "true", "false", "null" })
            {
                if (index + candidate.Length <= json.Length && string.CompareOrdinal(json, index, candidate, 0, candidate.Length) == 0)
                {
                    keyword = candidate;
                    return true;
                }
            }

            keyword = null;
            return false;
        }
    }
}
