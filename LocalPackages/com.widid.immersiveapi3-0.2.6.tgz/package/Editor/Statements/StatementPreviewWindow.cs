using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TinCan;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using WiDiD.ImmersiveAPI.Editor.UI;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Editor.Statements
{
    /// <summary>
    /// Lets you filter by statementable Type (GameFlow/Performances/Skills/Interactions/Badges/
    /// Rewards - see IStatementPreviewTarget.FamilyName), pick one specific Target of that type,
    /// then one of its compatible Verbs, and shows the resulting xAPI Statement JSON plus the Send
    /// Endpoint it'll actually be POSTed to (built from the signed-in UserSessionSO's TargetUrl via
    /// ImmersiveEndpoints, same as a real in-game send - not the Activity's own "object.id" URI,
    /// which is already visible inside the JSON itself) - a way to validate what a statement looks
    /// like, and optionally send it to the Immersive backend (same endpoint/auth as a real in-game
    /// send - see ImmersiveXapiEventSender/StatementSender), before wiring it into actual gameplay
    /// code.
    /// Targets are still contributed by IStatementPreviewProvider and discovered automatically via
    /// TypeCache - adding a new family only requires implementing that interface and giving its
    /// targets a FamilyName, no edits here.
    ///
    /// The JSON is shown in a rich-text Label (declared in the UXML) inside a ScrollView, colored
    /// per-token by JsonRichTextFormatter for readability - that formatter also swaps each line's
    /// leading indentation spaces for non-breaking spaces, since Label otherwise collapses runs of
    /// regular spaces the same way HTML does.
    /// </summary>
    public class StatementPreviewWindow : EditorWindow
    {
        // GameFlow/Performances/Skills/Interactions/Badges/Rewards first (matches TrainingCatalogTab's
        // ordering), then any other family alphabetically - so a new IStatementPreviewProvider still
        // shows up without needing this list updated.
        static readonly string[] KnownFamilyOrder = { "GameFlow", "Performances", "Skills", "Interactions", "Badges", "Rewards" };

        DropdownField typeDropdown;
        DropdownField targetDropdown;
        DropdownField verbDropdown;
        Label targetUrlLabel;
        Label statusLabel;
        Label jsonLabel;
        Button sendButton;
        Label sendStatusLabel;

        List<IStatementPreviewTarget> allTargets = new();
        List<IStatementPreviewTarget> targetsInFamily = new();
        string selectedFamily;
        IStatementPreviewTarget selectedTarget;

        UserSessionSO sessionAsset;
        readonly ImmersiveXapiEventSender statementSender = new();
        string lastRawJson;

        [MenuItem("WiDiD_API/ImmersiveAPI/Statement Preview")]
        public static void ShowWindow()
        {
            StatementPreviewWindow window = GetWindow<StatementPreviewWindow>();
            window.titleContent = new GUIContent("Statement Preview");
            window.minSize = new Vector2(420, 420);
        }

        public void CreateGUI()
        {
            sessionAsset = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);

            VisualTreeAsset visualTree = ImmersiveEditorUIConfigLoader.Assets.StatementPreviewWindow;
            visualTree.CloneTree(rootVisualElement);

            typeDropdown = rootVisualElement.Q<DropdownField>("DropdownType");
            targetDropdown = rootVisualElement.Q<DropdownField>("DropdownTarget");
            verbDropdown = rootVisualElement.Q<DropdownField>("DropdownVerb");
            targetUrlLabel = rootVisualElement.Q<Label>("LabelTargetUrl");
            statusLabel = rootVisualElement.Q<Label>("LabelStatus");
            jsonLabel = rootVisualElement.Q<Label>("LabelJson");
            jsonLabel.enableRichText = true;
            jsonLabel.selection.isSelectable = true;

            sendButton = rootVisualElement.Q<Button>("ButtonSendStatement");
            sendStatusLabel = rootVisualElement.Q<Label>("LabelSendStatus");

            typeDropdown.RegisterValueChangedCallback(evt =>
            {
                selectedFamily = evt.newValue;
                RefreshTargetsInFamily();
            });

            targetDropdown.RegisterValueChangedCallback(_ =>
            {
                int index = targetDropdown.index;
                selectedTarget = index >= 0 && index < targetsInFamily.Count ? targetsInFamily[index] : null;
                RefreshVerbs();
            });

            verbDropdown.RegisterValueChangedCallback(_ => RefreshJson());
            rootVisualElement.Q<Button>("ButtonRefresh").clicked += RefreshTargets;
            rootVisualElement.Q<Button>("ButtonSaveJson").clicked += SaveJson;
            sendButton.clicked += () => _ = SendStatementAsync();

            RefreshTargets();
        }

        void RefreshTargets()
        {
            allTargets = DiscoverTargets();

            List<string> familyNames = OrderFamilies(allTargets.Select(target => target.FamilyName).Distinct());
            typeDropdown.choices = familyNames;

            if (!familyNames.Contains(selectedFamily))
                selectedFamily = familyNames.FirstOrDefault();

            typeDropdown.SetValueWithoutNotify(selectedFamily);

            RefreshTargetsInFamily();
        }

        static List<string> OrderFamilies(IEnumerable<string> families)
        {
            List<string> familyList = families.ToList();
            List<string> ordered = KnownFamilyOrder.Where(familyList.Contains).ToList();
            ordered.AddRange(familyList.Except(KnownFamilyOrder).OrderBy(family => family));
            return ordered;
        }

        static List<IStatementPreviewTarget> DiscoverTargets()
        {
            List<IStatementPreviewTarget> targets = new();

            foreach (Type providerType in TypeCache.GetTypesDerivedFrom<IStatementPreviewProvider>())
            {
                if (providerType.IsAbstract || providerType.IsInterface)
                    continue;

                var provider = (IStatementPreviewProvider)Activator.CreateInstance(providerType);
                targets.AddRange(provider.GetTargets());
            }

            return targets;
        }

        void RefreshTargetsInFamily()
        {
            targetsInFamily = string.IsNullOrEmpty(selectedFamily)
                ? new List<IStatementPreviewTarget>()
                : allTargets.Where(target => target.FamilyName == selectedFamily).ToList();

            targetDropdown.choices = targetsInFamily.Select(target => string.Join(" / ", target.PathSegments)).ToList();

            int previousIndex = targetsInFamily.IndexOf(selectedTarget);
            int index = previousIndex >= 0 ? previousIndex : (targetsInFamily.Count > 0 ? 0 : -1);

            selectedTarget = index >= 0 ? targetsInFamily[index] : null;
            targetDropdown.SetValueWithoutNotify(index >= 0 ? targetDropdown.choices[index] : string.Empty);

            RefreshVerbs();
        }

        void RefreshVerbs()
        {
            verbDropdown.choices = selectedTarget != null ? selectedTarget.CompatibleVerbNames.ToList() : new List<string>();
            verbDropdown.index = verbDropdown.choices.Count > 0 ? 0 : -1;

            RefreshJson();
        }

        void RefreshJson()
        {
            lastRawJson = null;
            targetUrlLabel.text = string.Empty;
            sendStatusLabel.text = string.Empty;

            if (selectedTarget != null && verbDropdown.index >= 0)
            {
                if (sessionAsset == null)
                {
                    statusLabel.text = $"UserSessionSO asset could not be found at Resources/{UserSessionSO.ResourcePath}.";
                }
                else
                {
                    try
                    {
                        // Build(), not BuildForSend() - this is only ever a preview, so it must never
                        // trigger a real upload just from picking a target/verb in the dropdowns. A
                        // family with something to upload (see PerformancePreviewTarget) shows a
                        // realistic-but-unsent stand-in here instead (fake fileUrl, real everything
                        // else) - actually sending is what invokes BuildForSend, in SendStatementAsync.
                        (Verb verb, IStatementable statementable) = selectedTarget.Build(verbDropdown.value);

                        // The actual endpoint Send Statement will POST to (built from
                        // UserSession.TargetUrl, same as a real in-game send) - not the built
                        // Activity's own "object.id" URI (statementable.Uri), which is a fixed
                        // widid-immersive.fr/xapi/... identifier unrelated to which backend
                        // environment (Dev/Prod) is currently configured and already visible inside
                        // the JSON preview below regardless.
                        targetUrlLabel.text = new ImmersiveEndpoints(sessionAsset).XAPIPostAdress;

                        IStatementBuilderProfile profile = new RuntimeStatementBuilderProfile(sessionAsset.Data);
                        Statement statement = StatementBuilder.CreateFromProfile(profile, verb, statementable).Build();

                        object parsedJson = JsonConvert.DeserializeObject(statement.ToJSON(false));
                        lastRawJson = JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
                        statusLabel.text = string.Empty;
                    }
                    catch (Exception exception)
                    {
                        lastRawJson = null;
                        statusLabel.text = $"Failed to build statement: {exception.Message}";
                    }
                }
            }

            jsonLabel.text = !string.IsNullOrEmpty(lastRawJson) ? JsonRichTextFormatter.Colorize(lastRawJson) : string.Empty;
        }

        // Rebuilds via BuildForSend rather than reusing whatever RefreshJson last produced - for
        // most families that's identical to Build(), but for one with real upload side-effects (see
        // PerformancePreviewTarget) this is what actually performs them, right before sending, same
        // sequencing as a real in-game send (PerformanceRecorder). Also naturally picks up any field
        // edits made since the last Refresh instead of sending a possibly-stale preview.
        async Task SendStatementAsync()
        {
            if (selectedTarget == null || verbDropdown.index < 0)
            {
                sendStatusLabel.text = "Pick a target and verb first.";
                return;
            }

            if (sessionAsset == null || string.IsNullOrEmpty(sessionAsset.Data.DecodedToken))
            {
                sendStatusLabel.text = "Log in via the Debug Session window to send statements.";
                return;
            }

            sendButton.SetEnabled(false);
            sendStatusLabel.text = "Sending...";

            try
            {
                (Verb verb, IStatementable statementable) = await selectedTarget.BuildForSend(verbDropdown.value);

                IStatementBuilderProfile profile = new RuntimeStatementBuilderProfile(sessionAsset.Data);
                Statement statement = StatementBuilder.CreateFromProfile(profile, verb, statementable).Build();

                IImmersiveEndpoints endpoints = new ImmersiveEndpoints(sessionAsset);
                StatementSendResult result = await statementSender.SendAsync(statement, endpoints.XAPIPostAdress, sessionAsset.Data.DecodedToken);

                sendStatusLabel.text = result.Success ? "Sent successfully." : $"Failed ({result.StatusCode}): {result.Message}";
            }
            catch (Exception exception)
            {
                sendStatusLabel.text = $"Failed to build/send statement: {exception.Message}";
            }
            finally
            {
                sendButton.SetEnabled(true);
            }
        }

        void SaveJson()
        {
            if (string.IsNullOrEmpty(lastRawJson))
                return;

            string path = EditorUtility.SaveFilePanel("Save Statement JSON", Application.dataPath, "statement", "json");
            if (string.IsNullOrEmpty(path))
                return;

            File.WriteAllText(path, lastRawJson);

            if (path.StartsWith(Application.dataPath))
                AssetDatabase.Refresh();
        }
    }
}
