# WiDiD Immersive API

xAPI/TinCan statement authoring and delivery for Unity: training GameFlow authoring tools, the
Statementable object model, statement builders and LRS sending.

## Layout

| Folder | Assembly | Contents |
|---|---|---|
| `Runtime/` | `widid.immersiveapi3.runtime` | Actors, GameFlow, networking, settings, trainings |
| `Editor/` | `widid.immersiveapi3.editor` | Training/Skill/Performance/Interaction/Badge/Reward authoring windows, statement preview, debug session |
| `XAPI/` | `widid.immersiveapi3.xapi` | Statementables, builders, vocabulary libraries, `TinCan.dll` |

Authentication, launch validation (`SessionGate`) and the user session (`UserSessionSO`) live in
`com.widid.authentication`, so other packages can read the session without depending on this one.

Restoring previous sessions' progress (and the performance Sync / Apply / Send-on-close options) is a
temporary bridge until the backend exposes an LRS: see `Documentation~/StoredProgressBridge.md`.

`Runtime/Trainings/GameFlow/README.md` covers the two Runtime-side GameFlow tools in more depth:
building a flow from code instead of the nodal graph, and exporting any flow to the legacy
`gameflow.json` shape.

## Installing alongside an older ImmersiveAPI

Every assembly is namespaced under `widid.immersiveapi3.*`, so no assembly name clashes with the
`immersiveapi` package. Shared WiDiD libraries (`extension`, `graph-processor`, `launcharguments`,
`localization`, `reflection`, `authentication`) are regular package dependencies, shared with `immersiveapi` when
both are installed.

Every assembly here is **`autoReferenced: false`**. Code using this package has to live in an assembly
definition that references it explicitly - it will not resolve from a loose script in
`Assembly-CSharp`. `Assets/Scripts/Demo` in this repository is the worked example.

## Dependencies

Everything in `package.json` resolves automatically on import. Two things cannot:

**UniTask** is required by `com.widid.authentication` and must be added by hand (see that
package's README).

**Scoped registries** are never added by an imported package. The `com.widid` dependencies come
from the WiDiD registry, so consumers must add this to their `Packages/manifest.json` themselves:

```json
"scopedRegistries": [
  { "name": "WiDiD", "url": "https://npm.pkg.github.com/@widid", "scopes": ["com.widid"] }
]
```

## Assets the package needs

Nothing is written into a project on import. Each asset the package loads from a fixed Resources
path is offered where its absence actually shows up, so a new project is set up by clicking the
thing that is missing rather than by reading documentation.

`UserSessionSO` (from `com.widid.authentication`) holds the debug session and has no default to fall back on - SessionGate has
nowhere to put a launch result without it. **WiDiD_API > ImmersiveAPI > Debug Session** shows a
**Create Session Asset** button when none exists, and creates it at
`Assets/Resources/ImmersiveAPI/UserSessionSO.asset`.

`ActorIdentificationConfigSO` is a `[ImmersiveSettings]` asset, which does have a fallback: absent,
it runs on `ActorIdentificationData`'s own defaults, so absence is a valid state rather than a
misconfiguration. **WiDiD_API > ImmersiveAPI > Configuration** lists every setting with a Create
button for the ones with no asset yet.

Trainings are authored content rather than configuration: **Training Editor** creates
`Assets/Resources/ImmersiveAPI/Trainings/` the first time you add one.

## Where authored data lives

The Editor tooling writes to the consuming project, not into this package:

- Settings assets — `Assets/Resources/<ResourcePath>.asset`, so `Resources.Load` finds them
- Trainings — `Assets/Resources/ImmersiveAPI/Trainings/`
- Authoring graphs — `Assets/Editor/ImmersiveAPI/Trainings/`, mirroring the Training's folder with
  `Resources` swapped for `Editor` so graphs are never pulled into a player build
