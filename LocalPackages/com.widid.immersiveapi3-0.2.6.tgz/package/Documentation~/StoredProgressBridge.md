# Stored-progress bridge (temporary)

Everything described here is a **stopgap**. It exists only until the WiDiD Immersive backend
exposes an LRS that the package can query directly. Every piece carries the marker
`TEMPORARY-STORED-PROGRESS`, so one search lists all of it:

```
grep -rn "TEMPORARY-STORED-PROGRESS" Packages/com.widid.immersiveapi3 <demo>/Assets
```

## What it does today

At initialization, `TrainingRuntime` reads the signed-in user's previous progress from
`users/{userId}/stats/general?trainingId=…&lang=…` (not from the LRS). It then seeds the
recorders from that response:

| Statementable | Effect |
|---|---|
| Step / Strategy | Completion and best score restored, so unlock state survives restarts |
| Performance | Only when **Sync** is on: stored Raw is kept (`StatementableValues.GetPerformanceServerRaw`); written into Raw's reflected source when **Apply** is on; scored automatically before `terminated` when **Send on close** is on and it wasn't scored this session |
| Skill | Stored Scaled seeds the last known score (gates `progressed`) and is written into Scaled's reflected source |
| Reward | `totalPoint` is written into every reward's Raw reflected source |
| Badge | Slots already received are never sent again |

Send on close exists because the platform only displays a performance for the last session id.

## The three layers

1. **Backend adapter**: the only code that knows the stats endpoint and its JSON. *Replace it.*
   - `Runtime/Networking/Progression/` (all files: `UserStatsProgressSource`, `UserStatsStoredProgress`,
     `UserProgressionData`, `UserProgressionStat`, `ProgressionStatEntry`, `ProgressionJsonStep`,
     `ProgressionSession`, `ProgressionStep`)
   - `Runtime/Networking/IUserProgressionService.cs`, `UserProgressionService.cs`
   - `IImmersiveEndpoints.GetProgressionAdress` / `ImmersiveEndpoints.GetProgressionAdress`
   - `Runtime/Trainings/GameFlow/Progress/GameFlowProgressMapper.cs`
   - Demo: `Assets/Scripts/Demo/Debug/UserProgressionDebugTrigger.cs`

2. **Seam**: backend-agnostic and keyed by xAPI activity URI, so an LRS source can plug in. *Keep it if
   the LRS replacement still restores progress; delete it otherwise.*
   - `Runtime/Trainings/GameFlow/StoredProgress/IStoredProgress.cs`, `IStoredProgressSource.cs`,
     `ReflectedValueRestorer.cs`, `StoredProgressRestorer.cs`
   - `RestoreProgress` on `StepProgressController`, `StrategyProgressController`, `SkillRecorder`,
     `RewardRecorder`, `BadgeRecorder`
   - `Progress/StepProgressSnapshot.cs`
   - `WritableReflectedSource` on `PerformanceValueSource` / `PerformanceIntValueSource`

3. **Performance Sync / Apply / Send-on-close hack**: *Delete it.*
   - `Runtime/Trainings/GameFlow/StoredProgress/PerformanceServerSync.cs`, `IPerformanceServerValueLookup.cs`
   - `TrainingPerformanceData`: `SyncWithServer`, `ApplyServerValue`, `SendOnClose`, `SendsOnClose`,
     `AppliesServerValue`. Removing the serialized fields is safe; Unity drops them from assets on next save.
   - `StatementableValues.GetPerformanceServerRaw` and its `performanceServerValues` binding
   - `PerformanceRecorder.Scored` event (only `PerformanceServerSync` listens)
   - `IClosingStatementSource` and the closing-statement support in `SimulationTerminationFlusher`
     (constructor parameter, `StageClosingStatements`)
   - Editor: `PerformanceServerSyncControls.cs`, the two marked blocks in `PerformanceEntry.uxml`,
     the three marked lines in `PerformanceEditorPanel.cs`
   - Demo harness: `ValueSourceRowBinder.BindServerValue`, `LabelServer` in `ValueSourceRow.uxml`,
     the marked lines in `StatementableCatalogsController.cs`

All wiring lives in `TrainingRuntime.cs` (six marked spots: the `performanceServerSync` field, the
restore block in `HandleSessionReady`, the flusher argument, the `ClosingStatementsChanged`
subscription, `StatementableValues.Bind`, and the loop in `TerminateSimulation`).

## Replacing with the LRS

1. Implement `IStoredProgressSource` on top of an LRS statements query
   (`XAPI/XAPI/Builders/StatementQueryBuilder.cs` already builds a TinCan `StatementsQuery`), returning an
   `IStoredProgress` whose lookups are keyed by activity URI, the same ids the package sends.
2. In `TrainingRuntime.HandleSessionReady`, pass that source to `StoredProgressRestorer.Restore`
   instead of `UserStatsProgressSource`.
3. Delete layer 1.
4. Decide on layer 3 separately. Once every session's performance history is queryable from the LRS,
   Send on close has no purpose.

## Removing it entirely

1. Delete layers 1, 2 and 3 (files and members listed above).
2. In `TrainingRuntime.HandleSessionReady`, delete the marked restore block but keep
   `EnsureBadgeTicker().Recorder = badges;`. Drop the flusher argument and `StatementableValues`'s
   second `Bind` parameter.
3. Compile. Every remaining reference is one of the marked lines.

Not part of the bridge, so keep it: `ReflectionPathUtility.CanWrite` / `ReflectedValueWriter.CanWrite`
(com.widid.reflection), `PerformanceScopes`, `StatementableValues.GetPerformanceCurrentRaw`.
