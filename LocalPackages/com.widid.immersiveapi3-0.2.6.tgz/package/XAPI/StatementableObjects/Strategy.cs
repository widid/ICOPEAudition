using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Strategy : IStatementable
    {
        #region Fields
        private Uri uri;
        private string id;
        #endregion

        #region Accessors
        public Uri Uri => uri;
        public string UniqueId => id;

        #endregion

        public Strategy(string id, LanguageDictionary name, LanguageDictionary description, Simulation parentTraining, Course? parentCourse = null)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.parentTraining = parentTraining;
            this.parentCourse = parentCourse;
            if (parentCourse != null)
                this.parents = new IActivity[2] { parentCourse, parentTraining };
            else
                this.parents = new IActivity[1] { parentTraining };

            this.uri = XapiUriHelper.GetStatementableUri(this, ImmersiveAPI_Tests.StatementableUriConfig);
        }
    }
    public partial class Strategy : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Strategy(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
        public Activity Activity => new Activity() { definition = ActivityDefinition, id = uri.ToString() };
    }
    public partial class Strategy : ISimulationParentable
    {
        private Simulation parentTraining;
        public Simulation ParentSimulation => parentTraining;
    }
    public partial class Strategy : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse => parentCourse;
    }
    public partial class Strategy : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }
    public partial class Strategy : IResultable
    {
        public bool? Succeeded { get; set; }
        public bool? Completed { get; set; }
        public TimeSpan? Duration { get; set; }
        public Result GetResult()
        {
            Result result = new Result();
            result.success = Succeeded;
            result.completion = Completed;
            result.duration = Duration;
            result.score = GetScore();
            return result;
        }
    }
    public partial class Strategy : IScorable
    {
        public float? Score { get; set; }
        public Score GetScore()
        {
            if (Score == null) return null;
            return new Score() { scaled = Score };
        }
    }

}
