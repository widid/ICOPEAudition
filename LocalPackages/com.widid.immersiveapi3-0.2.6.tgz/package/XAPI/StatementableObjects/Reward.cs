using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Reward
    {
        public Reward(string id, LanguageDictionary name, LanguageDictionary description, Simulation parentSimulation, Course? parentCourse = null)
        {
            this.uniqueId = id;
            this.name = name;
            this.description = description;
            this.parentSimulation = parentSimulation;
            this.parentCourse = parentCourse;

            if (parentCourse != null)
                parents = new IActivity[2] { parentCourse, parentSimulation };
            else
                parents = new IActivity[1] { parentSimulation };

            uri = XapiUriHelper.GetStatementableUri(this, new StatementableUriConfig());
        }
    }

    public partial class Reward : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { id = Uri.ToString(), definition = ActivityDefinition };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Reward(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }

    public partial class Reward : IStatementable
    {
        private Uri uri;
        private string uniqueId;

        public Uri Uri => uri;
        public string UniqueId => uniqueId;
    }

    public partial class Reward : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse => parentCourse;
    }

    public partial class Reward : ISimulationParentable
    {
        private Simulation parentSimulation;
        public Simulation ParentSimulation => parentSimulation;
    }

    public partial class Reward : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }

    public partial class Reward : IResultable
    {
        public Result GetResult()
        {
            return new Result() { score = GetScore() };
        }
    }

    public partial class Reward : IScorable
    {
        public float? Score { get; set; }
        public int? ScoreRaw { get; set; }
        public int? MinScoreRaw { get; set; }
        public int? MaxScoreRaw { get; set; }
        public Score GetScore()
        {
            if (Score != null || ScoreRaw != null || MinScoreRaw != null || MaxScoreRaw != null)
                return new Score() { scaled = Score, raw = ScoreRaw, min = MinScoreRaw, max = MaxScoreRaw };
            return null;
        }
    }
}
