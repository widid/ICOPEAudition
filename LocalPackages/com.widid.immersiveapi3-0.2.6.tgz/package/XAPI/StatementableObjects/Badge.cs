using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Badge
    {
        public Badge(string id, LanguageDictionary name, LanguageDictionary description, Simulation parentSimulation, Course? parentCourse)
        {
            this.uniqueId = id;
            this.name = name;
            this.description = description;
            this.parentSimulation = parentSimulation;
            this.parentCourse = parentCourse;

            if (parentCourse != null)
                parents = new IActivity[2] { parentCourse, parentSimulation };
            else
                parents = new IActivity[1] { parentSimulation };

            uri = XapiUriHelper.GetStatementableUri(this, ImmersiveAPI_Tests.StatementableUriConfig);
        }
    }
    public partial class Badge : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;


        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { id = Uri.ToString(), definition = ActivityDefinition };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Badge(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }
    public partial class Badge : IStatementable
    {
        private Uri uri;
        private string uniqueId;

        public Uri Uri => uri;
        public string UniqueId => uniqueId;
    }

    public partial class Badge : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse => parentCourse;
    }
    public partial class Badge : ISimulationParentable
    {
        private Simulation parentSimulation;
        public Simulation ParentSimulation => parentSimulation;
    }

    public partial class Badge : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }
}