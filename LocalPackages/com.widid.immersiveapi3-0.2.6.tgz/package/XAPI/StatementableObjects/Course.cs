using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Course
    {
        public Course(string id, LanguageDictionary name, LanguageDictionary description)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.uri = XapiUriHelper.GetStatementableUri(this, ImmersiveAPI_Tests.StatementableUriConfig);
        }
    }
    public partial class Course : IStatementable
    {
        #region Fields
        private Uri uri;
        private string id;
        #endregion

        public Uri Uri => uri;
        public string UniqueId => id;

    }
    public partial class Course : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { definition = ActivityDefinition, id = uri.ToString() };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Course(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }
}