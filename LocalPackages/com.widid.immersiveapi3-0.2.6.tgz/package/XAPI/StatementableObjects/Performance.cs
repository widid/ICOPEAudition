using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Performance
    {
        public Performance(string id, LanguageDictionary name, LanguageDictionary description, Simulation parentSimulation, Step parentStep = null, Strategy parentStrategy = null, Course parentCourse = null)
        {
            this.id = id;
            this.name = name;
            this.description = description;

            this.parentSimulation = parentSimulation;

            this.parentStep = parentStep;
            this.parentStrategy = parentStrategy;
            this.parentCourse = parentCourse;

            uri = XapiUriHelper.GetStatementableUri(this, new StatementableUriConfig());

            List<IActivity> activities = new List<IActivity>();
            if (ParentCourse != null) activities.Add(ParentCourse);
            if (ParentSimulation != null) activities.Add(ParentSimulation);
            if (ParentStrategy != null) activities.Add(ParentStrategy);
            if (ParentStep != null) activities.Add(ParentStep);

            this.parents = activities.ToArray();
        }
    }

    public partial class Performance : IStatementable
    {
        private Uri uri;
        private string id;

        public Uri Uri => uri;
        public string UniqueId => id;
    }

    public partial class Performance : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { id = uri.ToString(), definition = ActivityDefinition };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Performance(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }

    public partial class Performance : IStepParentable
    {
        private Step parentStep = null;
        public Step ParentStep => parentStep;
    }

    public partial class Performance : IStrategyParentable
    {
        private Strategy parentStrategy = null;
        public Strategy ParentStrategy
        {
            get
            {
                if (parentStrategy == null)
                    if (parentStep != null)
                        return parentStep.ParentStrategy;

                return parentStrategy;
            }
        }
    }

    public partial class Performance : ISimulationParentable
    {
        private Simulation parentSimulation = null;
        public Simulation ParentSimulation
        {
            get
            {
                if (parentSimulation == null)
                {
                    if (parentStrategy != null)
                        return parentStrategy.ParentSimulation;
                    if (parentStep != null)
                        return parentStep.ParentStrategy.ParentSimulation;
                }
                return parentSimulation;
            }
        }
    }

    public partial class Performance : ICourseParentable
    {
        private Course parentCourse = null;
        public Course ParentCourse => parentCourse;
    }

    public partial class Performance : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }
    public partial class Performance : IResultable
    {
        public string? Response { get; set; }
        public TinCan.Extensions? Extensions { get; set; }
        public Result GetResult()
        {
            Result result = new Result();
            result.score = GetScore();
            result.response = Response;
            result.extensions = Extensions;
            return result;
        }
    }
    public partial class Performance : IScorable
    {
        public float? Score { get; set; }
        public int? ScoreRaw { get; set; }
        public int? MinScoreRaw { get; set; }
        public int? MaxScoreRaw { get; set; }
        public Score GetScore()
        {
            if (Score != null || ScoreRaw != null || MinScoreRaw != null || MaxScoreRaw != null)
                return new Score() { scaled = Score, raw = ScoreRaw, min = MinScoreRaw, max = MaxScoreRaw };
            return null;
        }
    }
    public partial class Performance : IAttachmentable
    {
        public List<Attachment> Attachments { get; set; }
        public List<Attachment> GetAttachments()
        {
            return Attachments;
        }
    }
}
