
using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Skill
    {
        public Skill(string id, LanguageDictionary name, LanguageDictionary description, SkillSubCategory skillSubCategory, Simulation parentSimulation, Course? parentCourse = null)
        {
            this.uniqueId = id;
            this.SkillSubCategory = skillSubCategory;
            this.name = name;
            this.description = description;
            this.parentSimulation = parentSimulation;
            this.parentCourse = parentCourse;

            if (parentCourse != null)
                parents = new IActivity[2] { parentCourse, parentSimulation };
            else
                parents = new IActivity[1] { parentSimulation };

            uri = XapiUriHelper.GetStatementableUri(this, new StatementableUriConfig());
        }
    }
    public partial class Skill : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { id = Uri.ToString(), definition = ActivityDefinition };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Skill(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }
    public partial class Skill : IStatementable
    {
        private Uri uri;
        private string uniqueId;

        public Uri Uri => uri;
        public string UniqueId => uniqueId;
    }

    public partial class Skill : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse => parentCourse;
    }

    public partial class Skill : ISimulationParentable
    {
        private Simulation parentSimulation;
        public Simulation ParentSimulation => parentSimulation;
    }

    public partial class Skill : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }

    public partial class Skill : IResultable
    {
        public Result GetResult()
        {
            return new Result() { score = GetScore() };
        }
    }

    public partial class Skill : IScorable
    {
        public float? Score { get; set; }
        public Score GetScore()
        {
            return new Score() { scaled = Score };
        }
    }
    public partial class Skill : ICategorisable
    {
        public SkillSubCategory SkillSubCategory { get; }

        public Activity[] GetCategories()
        {
            return new Activity[2] { SkillSubCategory.ParentCategory, SkillSubCategory.SubCategory };
        }
    }
}