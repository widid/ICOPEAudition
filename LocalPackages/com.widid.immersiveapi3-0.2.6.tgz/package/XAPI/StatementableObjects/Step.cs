using System;
using TinCan;
using UnityEngine;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Step
    {
        public Step(string id, LanguageDictionary name, LanguageDictionary description, Strategy parentSession, Simulation parentTraining, Course? parentCourse = null)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.parentSession = parentSession;
            this.parentTraining = parentTraining;
            this.parentCourse = parentCourse;

            if (parentCourse != null)
                this.parents = new IActivity[3] { parentCourse, parentTraining, parentSession };
            else
                this.parents = new IActivity[2] { parentTraining, parentSession };
            this.uri = XapiUriHelper.GetStatementableUri(this, ImmersiveAPI_Tests.StatementableUriConfig);
        }
    }
    public partial class Step : IStatementable
    {
        #region Fields
        [SerializeField] private Uri uri;
        [SerializeField] private string id;
        #endregion
        #region Accessors
        public Uri Uri => uri;
        public string UniqueId => id;
        #endregion
    }
    public partial class Step : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        #region Accessors
        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Step(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
        public Activity Activity => new Activity() { id = uri.ToString(), definition = ActivityDefinition };
        #endregion
    }

    public partial class Step : IStrategyParentable
    {
        private Strategy parentSession;
        public Strategy ParentStrategy => parentSession;
    }

    public partial class Step : ISimulationParentable
    {
        private Simulation parentTraining;
        public Simulation ParentSimulation { get => parentTraining; }
    }
    public partial class Step : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse { get => parentCourse; }
    }

    public partial class Step : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }

    public partial class Step : IScorable
    {
        public float? Score { get; set; }

        public Score GetScore()
        {
            if (Score == null) return null;
            return new Score() { scaled = Score };
        }
    }

    public partial class Step : IResultable
    {
        public bool? Succeeded { get; set; }
        public bool? Completed { get; set; }
        public TimeSpan? Duration { get; set; }

        public Result GetResult()
        {
            Result result = new Result();
            result.success = Succeeded;
            result.completion = Completed;
            result.duration = Duration;
            result.score = GetScore();

            return result;
        }
    }
}
