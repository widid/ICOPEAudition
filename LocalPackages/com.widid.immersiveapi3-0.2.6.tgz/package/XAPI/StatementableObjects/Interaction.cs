using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Interaction
    {
        public InteractionType InteractionType { get; set; }

        public Interaction(string id, LanguageDictionary name, LanguageDictionary description, Step parentStep, InteractionType interactionType, Strategy? parentStrategy = null, Simulation? parentSimulation = null, Course? parentCourse = null)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.parentStep = parentStep;
            this.InteractionType = interactionType;
            this.parentStrategy = parentStrategy;
            this.parentCourse = parentCourse;
            this.parentSimulation = parentSimulation;

            uri = XapiUriHelper.GetStatementableUri(this, new StatementableUriConfig());

            List<IActivity> activities = new List<IActivity>();
            if (ParentCourse != null) activities.Add(ParentCourse);
            if (ParentSimulation != null) activities.Add(ParentSimulation);
            if (ParentStrategy != null) activities.Add(ParentStrategy);
            if (ParentStep != null) activities.Add(ParentStep);

            parents = activities.ToArray();
        }
    }
    public partial class Interaction : IStatementable
    {
        #region Fields
        private Uri uri;
        private string id;
        #endregion
        #region Accessors
        public Uri Uri => uri;
        public string UniqueId => id;
        #endregion
    }
    public partial class Interaction : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;
        public LanguageDictionary Description => description;

        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Interaction(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap())) { interactionType = InteractionType };
        public Activity Activity => new Activity() { id = uri.ToString(), definition = ActivityDefinition };
    }
    public partial class Interaction : ICourseParentable
    {
        private Course parentCourse;
        public Course ParentCourse => parentCourse;
    }
    public partial class Interaction : ISimulationParentable
    {
        private Simulation parentSimulation = null;
        public Simulation ParentSimulation => parentSimulation == null ? ParentStep.ParentSimulation : parentSimulation;
    }
    public partial class Interaction : IStrategyParentable
    {
        private Strategy parentStrategy = null;
        public Strategy ParentStrategy => parentStrategy == null ? parentStep.ParentStrategy : parentStrategy;
    }
    public partial class Interaction : IStepParentable
    {
        private Step parentStep = null;
        public Step ParentStep => parentStep;
    }
    public partial class Interaction : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }
    public partial class Interaction : IResultable
    {
        public bool? Succeeded { get; set; }
        public TimeSpan? Duration { get; set; }
        public string? Response { get; set; }
        public TinCan.Extensions? Extensions { get; set; }
        public Result GetResult()
        {
            Result result = new Result();
            result.success = Succeeded;
            result.duration = Duration;
            result.response = Response;
            result.extensions = Extensions;
            result.score = GetScore();

            return result;
        }
    }
    public partial class Interaction : IScorable
    {
        public float? Score { get; set; }
        public int? ScoreRaw { get; set; }
        public int? MinScoreRaw { get; set; }
        public int? MaxScoreRaw { get; set; }

        public Score GetScore()
        {
            if (Score != null || ScoreRaw != null || MinScoreRaw != null || MaxScoreRaw != null)
                return new Score() { scaled = Score, raw = ScoreRaw, min = MinScoreRaw, max = MaxScoreRaw };

            return null;
        }
    }
}