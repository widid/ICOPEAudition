using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI.Statementables
{
    public partial class Simulation
    {
        public Simulation(string id, LanguageDictionary name, LanguageDictionary description, Course? parentCourse = null)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.uri = XapiUriHelper.GetStatementableUri(this, ImmersiveAPI_Tests.StatementableUriConfig);
            this.parentCourse = parentCourse;
            if (parentCourse != null)
                parents = new[] { parentCourse };
        }
    }
    [System.Serializable]
    public partial class Simulation : IStatementable
    {
        #region Fields
        private Uri uri;
        private string id;
        #endregion

        public Uri Uri => uri;
        public string UniqueId => id;
    }

    public partial class Simulation : IActivity
    {
        private LanguageDictionary name;
        private LanguageDictionary description;

        public LanguageDictionary Name => name;

        public LanguageDictionary Description => description;
        public Activity Activity => new Activity() { definition = ActivityDefinition, id = uri.ToString() };
        public ActivityDefinition ActivityDefinition => new ActivityDefinitions.Simulation(new LanguageMap(name.GetLanguageMap()), new LanguageMap(description.GetLanguageMap()));
    }

    public partial class Simulation : ICourseParentable
    {
        private Course? parentCourse;
        public Course ParentCourse => parentCourse;
    }

    public partial class Simulation : IParented
    {
        private IActivity[] parents;
        public IActivity[] Parents => parents;
    }
    public partial class Simulation : IResultable
    {
        public bool? Succeeded { get; set; }
        public bool? Completed { get; set; }
        public TimeSpan? Duration { get; set; }
        public Result GetResult()
        {
            Result result = new Result();
            result.success = Succeeded;
            result.completion = Completed;
            result.duration = Duration;
            result.score = GetScore();

            return result;
        }
    }
    public partial class Simulation : IScorable
    {
        public float? Progression { get; set; }
        public int? ScoreRaw { get; set; }
        public int? MinScoreRaw { get; set; }
        public int? MaxScoreRaw { get; set; }
        public Score GetScore()
        {
            if (Progression != null || ScoreRaw != null || MinScoreRaw != null || MaxScoreRaw != null)
                return new Score() { scaled = Progression, raw = ScoreRaw, min = MinScoreRaw, max = MaxScoreRaw };

            return null;
        }
    }
}
