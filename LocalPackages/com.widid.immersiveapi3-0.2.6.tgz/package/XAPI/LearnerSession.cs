using TinCan;

public class LearnerSession
{
    public Agent Agent { get; }
    public CourseRegistration CourseRegistration { get; }
    public LearnerSession(Agent learner, CourseRegistration? courseRegistration)
    {
        Agent = learner;
        CourseRegistration = courseRegistration;
    }
}
