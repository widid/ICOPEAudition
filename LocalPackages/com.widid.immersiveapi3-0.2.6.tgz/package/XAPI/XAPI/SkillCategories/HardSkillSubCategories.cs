using System;
using System.Collections.Generic;
using TinCan;
namespace WiDiD.XAPI
{

    public class HardSkillSubCategories
    {
        private static Uri subCategoryType = new Uri("http://id.tincanapi.com/activitytype/subcategory");
        public static SkillSubCategory ToolsMastery
        {
            get
            {
                return new SkillSubCategory(SkillCategories.HardSkill, ToolsMasteryActivity);
            }
        }
        public static SkillSubCategory GestureMastery
        {
            get
            {
                return new SkillSubCategory(SkillCategories.HardSkill, GesturesMasteryActivity);
            }
        }
        public static SkillSubCategory ProcessMastery
        {
            get
            {
                return new SkillSubCategory(SkillCategories.HardSkill, ProcessMasteryActivity);
            }
        }
        public static SkillSubCategory KnowledgesMastery
        {
            get
            {
                return new SkillSubCategory(SkillCategories.HardSkill, KnowledgesMasteryActivity);
            }
        }
        public static SkillSubCategory TaskMastery
        {
            get
            {
                return new SkillSubCategory(SkillCategories.HardSkill, TaskMasteryActivity);
            }
        }

        public static Dictionary<string, SkillSubCategory> All => new Dictionary<string, SkillSubCategory>
        {
            { nameof(ToolsMastery), ToolsMastery },
            { nameof(GestureMastery), GestureMastery },
            { nameof(ProcessMastery), ProcessMastery },
            { nameof(KnowledgesMastery), KnowledgesMastery },
            { nameof(TaskMastery), TaskMastery }
        };

        #region Private static sub skills activities
        private static Activity ToolsMasteryActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Tools mastery"},
                    {"fr-FR","Maitrise des outils"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to use and manipulate specific tools in the given activity"},
                    {"fr-FR","Capacité à utiliser et à manipuler des outils spécifiques dans l'activité donnée."}
                });

                return new Activity() { id = SkillCategories.HardSkill.id + "/0", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
        private static Activity GesturesMasteryActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Gestures mastery"},
                    {"fr-FR","Maitrise des gestes"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to execute precise and appropriate physical movements required in the given activity"},
                    {"fr-FR","Capacité à exécuter des mouvements physiques précis et appropriés requis dans l'activité donnée."}
                });

                return new Activity() { id = SkillCategories.HardSkill.id + "/1", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
        private static Activity ProcessMasteryActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Process mastery"},
                    {"fr-FR","Maitrise d'un procédé"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to understand and follow a specific set of steps or operations to complete an activity"},
                    {"fr-FR","Capacité à comprendre et à suivre un ensemble spécifique d'étapes ou d'opérations pour réaliser une activité."}
                });

                return new Activity() { id = SkillCategories.HardSkill.id + "/2", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
        private static Activity KnowledgesMasteryActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Knowledges mastery"},
                    {"fr-FR","Maitrise des savoirs"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to apply theoretical and factual knowledge relevant to the activity"},
                    {"fr-FR","Capacité à mobiliser des connaissances théoriques et factuelles pertinentes pour l'activité."}
                });

                return new Activity() { id = SkillCategories.HardSkill.id + "/3", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
        private static Activity TaskMasteryActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Task mastery"},
                    {"fr-FR","Maitrise d'une tâche"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to independently and efficiently perform a specific task within the activity"},
                    {"fr-FR","Capacité à exécuter de manière autonome et efficace une tâche spécifique dans l'activité."}
                });

                return new Activity() { id = SkillCategories.HardSkill.id + "/4", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
        #endregion
    }
}