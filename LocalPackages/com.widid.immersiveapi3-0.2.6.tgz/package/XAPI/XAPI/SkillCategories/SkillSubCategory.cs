using TinCan;

public class SkillSubCategory
{
    public Activity ParentCategory { get; }
    public Activity SubCategory { get; }

    public SkillSubCategory(Activity parentCategory, Activity subCategory)
    {
        ParentCategory = parentCategory;
        SubCategory = subCategory;
    }

}
