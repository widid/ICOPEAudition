using System;
using System.Collections.Generic;
using TinCan;
namespace WiDiD.XAPI
{

    public class SoftSkillSubCategories
    {

        private static Uri subCategoryType = new Uri("http://id.tincanapi.com/activitytype/subcategory");

        public static SkillSubCategory Communication
        {
            get
            {
                return new SkillSubCategory(SkillCategories.SoftSkill, CommunicationActivity);
            }
        }
        public static SkillSubCategory TeamSpirit
        {
            get
            {
                return new SkillSubCategory(SkillCategories.SoftSkill, TeamSpiritActivity);
            }
        }
        public static SkillSubCategory Autonomy
        {
            get
            {
                return new SkillSubCategory(SkillCategories.SoftSkill, AutonomyActivity);
            }
        }
        public static SkillSubCategory ProblemSolving
        {
            get
            {
                return new SkillSubCategory(SkillCategories.SoftSkill, ProblemSolvingActivity);
            }
        }
        public static SkillSubCategory StressManagement
        {
            get
            {
                return new SkillSubCategory(SkillCategories.SoftSkill, StressManagementActivity);
            }
        }

        public static Dictionary<string, SkillSubCategory> All => new Dictionary<string, SkillSubCategory>
        {
            { nameof(Communication), Communication },
            { nameof(TeamSpirit), TeamSpirit },
            { nameof(Autonomy), Autonomy },
            { nameof(ProblemSolving), ProblemSolving },
            { nameof(StressManagement), StressManagement }
        };

        private static Activity CommunicationActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Communication"},
                    {"fr-FR","Communication"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to clearly express ideas, actively listen, and adapt communication to different audiences and situations"},
                    {"fr-FR","Capacité à exprimer clairement des idées, à écouter activement et à adapter sa communication à différents publics et situations."}
                });

                return new Activity() { id = SkillCategories.SoftSkill.id + "/0", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }

        private static Activity TeamSpiritActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Team spirit"},
                    {"fr-FR","Esprit d'équipe"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to collaborate effectively with others to achieve shared goals."},
                    {"fr-FR","Capacité à collaborer efficacement avec les autres pour atteindre des objectifs communs."}
                });

                return new Activity() { id = SkillCategories.SoftSkill.id + "/1", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }

        private static Activity AutonomyActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Autonomy"},
                    {"fr-FR","Autonomie"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to perform tasks independently and take responsibility for one's decisions"},
                    {"fr-FR","Capacité à accomplir des tâches de manière autonome et à assumer la responsabilité de ses décisions."}
                });

                return new Activity() { id = SkillCategories.SoftSkill.id + "/2", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }

        private static Activity ProblemSolvingActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Problem solving"},
                    {"fr-FR","Résolution de problèmes"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to identify, analyze, and find solutions to problems in a logical and effective way"},
                    {"fr-FR","Capacité à identifier, analyser et résoudre des problèmes de manière logique et efficace."}
                });

                return new Activity() { id = SkillCategories.SoftSkill.id + "/3", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }

        private static Activity StressManagementActivity
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Stress management"},
                    {"fr-FR","Gestion du stress"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to stay calm, focused, and effective under pressure or in challenging situations"},
                    {"fr-FR","Capacité à rester calme, concentré et efficace sous pression ou dans des situations difficiles."}
                });

                return new Activity() { id = SkillCategories.SoftSkill.id + "/4", definition = new ActivityDefinition() { name = name, description = description, type = subCategoryType } };
            }
        }
    }
}