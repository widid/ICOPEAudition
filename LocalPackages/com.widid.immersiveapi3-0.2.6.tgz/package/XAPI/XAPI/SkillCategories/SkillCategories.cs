
using System;
using System.Collections.Generic;
using TinCan;
namespace WiDiD.XAPI
{

    public static class SkillCategories
    {
        private static Uri categoryType = new Uri("http://id.tincanapi.com/activitytype/category");

        public static Activity HardSkill
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Hard skill"},
                    {"fr-FR","Savoir faire"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Ability to solve practical problems; competence, experience in carrying out an activity."},
                    {"fr-FR","Habileté à résoudre les problèmes pratiques ; compétence, expérience dans l'exercice d'une activité."}
                });

                return new Activity() { id = ImmersiveAPI_Tests.StatementableUriConfig.XapiUri + "skillCategory/hard-skill", definition = new ActivityDefinition() { name = name, description = description, type = categoryType } };
            }
        }
        public static Activity SoftSkill
        {
            get
            {
                LanguageMap name = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Soft skill"},
                    {"fr-FR","Savoir être"}
                });

                LanguageMap description = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","Set of relational and behavioral qualities adapted to the business world."},
                    {"fr-FR","Ensemble des qualités relationnelles et comportementales adaptées au monde de l'entreprise."}
                });

                return new Activity() { id = ImmersiveAPI_Tests.StatementableUriConfig.XapiUri + "skillCategory/soft-skill", definition = new ActivityDefinition() { name = name, description = description, type = categoryType } };
            }
        }

        public static Dictionary<string, Activity> All => new Dictionary<string, Activity>
        {
            { nameof(HardSkill), HardSkill },
            { nameof(SoftSkill), SoftSkill }
        };
    }
}