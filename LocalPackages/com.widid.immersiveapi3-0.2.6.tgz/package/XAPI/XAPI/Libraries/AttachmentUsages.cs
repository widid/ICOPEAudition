using System;
using System.Collections.Generic;
using System.Reflection;

// Reflects over the static Uri properties below (stripping the "Uri" suffix for the key) so any
// usage type added here is automatically available to callers (e.g. a UI dropdown) without
// upkeep - the same convention as ActivityDefinitions.All/InteractionTypes.All.
public static class AttachmentUsages
{
    private static readonly IReadOnlyDictionary<string, Uri> all = BuildRegistry();

    public static IReadOnlyDictionary<string, Uri> All => all;

    public static Uri SupportingMediaUri => new Uri("http://id.tincanapi.com/attachment/supporting_media");
    public static Uri SignatureUri => new Uri("http://adlnet.gov/expapi/attachments/signature");
    public static Uri ContractUri => new Uri("http://id.tincanapi.com/attachment/contract");
    public static Uri CertificateOfCompletionUri => new Uri("http://id.tincanapi.com/attachment/certificate-of-completion");

    private static IReadOnlyDictionary<string, Uri> BuildRegistry()
    {
        Dictionary<string, Uri> registry = new Dictionary<string, Uri>();

        foreach (PropertyInfo property in typeof(AttachmentUsages).GetProperties(BindingFlags.Public | BindingFlags.Static))
        {
            if (property.PropertyType != typeof(Uri)) continue;

            string key = property.Name.EndsWith("Uri") ? property.Name.Substring(0, property.Name.Length - 3) : property.Name;
            registry[key] = (Uri)property.GetValue(null);
        }

        return registry;
    }
}
