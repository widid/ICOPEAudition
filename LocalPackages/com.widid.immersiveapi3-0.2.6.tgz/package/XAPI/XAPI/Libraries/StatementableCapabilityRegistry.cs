using System;
using System.Collections.Generic;
using WiDiD.XAPI.Statementables;

namespace WiDiD.XAPI
{
    // Reflects over the concrete StatementableObjects classes (Course/Simulation/Strategy/Step/
    // Interaction/Performance/Skill/Badge/Reward) so a demo Object's declared type-key (the same
    // string used as ActivityDefinitions.All's keys, e.g. "Simulation"/"Skill") resolves to that
    // real class's actual capabilities - no separate table to keep in sync by hand.
    public static class StatementableCapabilityRegistry
    {
        private static readonly IReadOnlyDictionary<string, StatementableCapabilities> byTypeKey = BuildRegistry();

        public static StatementableCapabilities Get(string typeKey)
        {
            if (!string.IsNullOrEmpty(typeKey) && byTypeKey.TryGetValue(typeKey, out StatementableCapabilities capabilities))
            {
                return capabilities;
            }

            return StatementableCapabilities.None;
        }

        private static IReadOnlyDictionary<string, StatementableCapabilities> BuildRegistry()
        {
            Dictionary<string, StatementableCapabilities> registry = new Dictionary<string, StatementableCapabilities>();

            foreach (Type type in typeof(Course).Assembly.GetTypes())
            {
                if (type.Namespace != typeof(Course).Namespace) continue;
                if (type.IsInterface) continue;

                registry[type.Name] = new StatementableCapabilities(type);
            }

            return registry;
        }
    }
}
