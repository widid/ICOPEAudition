using System.Collections.Generic;
using System.Reflection;
using TinCan;

namespace WiDiD.XAPI
{
    // TinCan.InteractionType is a sealed class with static readonly instances rather
    // than a C# enum, so this reflects over those fields for the same reason
    // ActivityDefinitions.All does - callers (e.g. a UI dropdown) get every known
    // interaction type without needing to duplicate the list by hand.
    public static class InteractionTypes
    {
        private static readonly IReadOnlyDictionary<string, InteractionType> all = BuildRegistry();

        public static IReadOnlyDictionary<string, InteractionType> All => all;

        private static IReadOnlyDictionary<string, InteractionType> BuildRegistry()
        {
            Dictionary<string, InteractionType> registry = new Dictionary<string, InteractionType>();

            foreach (FieldInfo field in typeof(InteractionType).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                if (field.FieldType == typeof(InteractionType))
                {
                    registry[field.Name] = (InteractionType)field.GetValue(null);
                }
            }

            return registry;
        }
    }
}
