using System;
using System.Collections.Generic;
using System.Linq;
using TinCan;

namespace WiDiD.XAPI
{
    public static class Verbs
    {
        private static Verb[] ResultTriggeringVerbs => new[] { Answered, Progressed, Failed, Passed, Mastered, Scored, Interacted, Exited, Completed, Terminated, Suspended };
        public static bool ShouldDisplayResult(Verb verb)
        {
            return ResultTriggeringVerbs.Contains(verb);
        }
        public static Verb GetVerbFromString(string verbId)
        {
            verbId = verbId.ToLower();

            switch (verbId)
            {
                case "answered": return Answered;
                case "initialized": return Initialized;
                case "launched": return Launched;
                case "progressed": return Progressed;
                case "failed": return Failed;
                case "suspended": return Suspended;
                case "passed": return Passed;
                case "exited": return Exited;
                case "mastered": return Mastered;
                case "scored": return Scored;
                case "interacted": return Interacted;
                case "terminated": return Terminated;
                case "completed": return Completed;
                case "received": return Received;

                default: return new Verb("default");
            }
        }

        #region Verb Fields
        public static readonly Verb Answered = AnsweredVerb;
        public static readonly Verb Initialized = InitializedVerb;
        public static readonly Verb Launched = LaunchedVerb;
        public static readonly Verb Progressed = ProgressedVerb;
        public static readonly Verb Failed = FailedVerb;
        public static readonly Verb Suspended = SuspendedVerb;
        public static readonly Verb Passed = PassedVerb;
        public static readonly Verb Exited = ExitedVerb;
        public static readonly Verb Mastered = MasteredVerb;
        public static readonly Verb Scored = ScoredVerb;
        public static readonly Verb Interacted = InteractedVerb;
        public static readonly Verb Terminated = TerminatedVerb;
        public static readonly Verb Completed = CompletedVerb;
        public static readonly Verb Received = ReceivedVerb;
        #endregion

        #region Verb Definitions
        private static Verb ReceivedVerb
        {
            get
            {
                Uri Id = new Uri("http://activitystrea.ms/schema/1.0/receive");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","received"},
                    {"fr-FR","a reçu"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }
        private static Verb AnsweredVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/answered");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","answered"},
                    {"fr-FR","a répondu"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb InitializedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/initialized");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","initialized"},
                    {"fr-FR","a démarré"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb LaunchedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/launched");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","launched"},
                    {"fr-FR","a lancé"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb ProgressedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/progressed");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","progressed"},
                    {"fr-FR","a progressé"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb FailedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/failed");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","failed"},
                    {"fr-FR","a échoué"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb SuspendedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/suspended");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","suspended"},
                    {"fr-FR","a suspendu"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb PassedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/passed");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","passed"},
                    {"fr-FR","a réussi"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb ExitedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/exited");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","exited"},
                    {"fr-FR","a quitté"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb MasteredVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/mastered");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","mastered"},
                    {"fr-FR","a maîtrisé"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb ScoredVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/scored");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","scored"},
                    {"fr-FR","a marqué"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb InteractedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/interacted");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","interacted"},
                    {"fr-FR","a intéragi"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb TerminatedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/terminated");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","terminated"},
                    {"fr-FR","a interrompu"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }

        private static Verb CompletedVerb
        {
            get
            {
                Uri Id = new Uri("http://adlnet.gov/expapi/verbs/completed");

                LanguageMap LanguageMap = new LanguageMap(new Dictionary<string, string>()
                {
                    {"en-US","completed"},
                    {"fr-FR","a terminé"}
                });
                return new Verb(Id) { display = LanguageMap };
            }
        }
        #endregion
    }

}