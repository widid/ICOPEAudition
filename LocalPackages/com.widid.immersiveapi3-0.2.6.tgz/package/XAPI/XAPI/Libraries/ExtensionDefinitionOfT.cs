using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace WiDiD.XAPI
{
    public class ExtensionDefinition<T> : ExtensionDefinition
    {
        private readonly Func<T, JToken> serialize;
        private readonly Action<T> validate;

        public ExtensionDefinition(Uri uri, string name, Func<T, JToken> serialize = null, Action<T> validate = null) : base(uri, name)
        {
            this.serialize = serialize ?? (value => JToken.FromObject(value));
            this.validate = validate;
        }

        public JToken Serialize(T value)
        {
            validate?.Invoke(value);
            return serialize(value);
        }

        public override JToken ToJToken(object value)
        {
            return Serialize((T)value);
        }

        public override IReadOnlyList<string> GetValueChoices()
        {
            if (!typeof(T).IsEnum) return null;

            return Enum.GetValues(typeof(T))
                .Cast<T>()
                .Select(enumValue => Serialize(enumValue).ToString())
                .ToList();
        }
    }
}
