namespace WiDiD.XAPI
{
    // Values match the only ones the Interaction statements' severity extension accepts (see
    // xAPI-Statements/Interaction/README.md) - serialized lowercase by ExtensionsLibrary.Severity.
    public enum SeverityLevel
    {
        Success,
        Info,
        Warning,
        Error,
        Critical
    }
}
