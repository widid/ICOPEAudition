using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace WiDiD.XAPI
{
    public abstract class ExtensionDefinition
    {
        public Uri Uri { get; }
        public string Name { get; }

        protected ExtensionDefinition(Uri uri, string name)
        {
            Uri = uri;
            Name = name;
        }

        public abstract JToken ToJToken(object value);

        // Plain-string form of a value, matching the tokens GetValueChoices returns. Lets callers
        // outside this assembly (e.g. the Demo's extension entry list) write a value without
        // needing a Newtonsoft.Json reference of their own.
        public string ToValueString(object value)
        {
            return ToJToken(value).ToString();
        }

        // Non-null only for value types with a fixed set of valid values (e.g. enums),
        // returned as their serialized string tokens so callers don't need to know T.
        public abstract IReadOnlyList<string> GetValueChoices();
    }
}
