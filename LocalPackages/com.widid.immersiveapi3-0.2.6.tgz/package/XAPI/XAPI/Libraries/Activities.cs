using TinCan;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace WiDiD.XAPI
{
    public class ActivityDefinitions
    {
        // Reflects over the nested types below so any ActivityDefinition added here
        // is automatically available to callers (e.g. a UI dropdown) without upkeep.
        private static readonly IReadOnlyDictionary<string, Uri> all = BuildRegistry();

        public static IReadOnlyDictionary<string, Uri> All => all;

        private static IReadOnlyDictionary<string, Uri> BuildRegistry()
        {
            Dictionary<string, Uri> registry = new Dictionary<string, Uri>();

            foreach (Type nestedType in typeof(ActivityDefinitions).GetNestedTypes())
            {
                FieldInfo typeField = nestedType.GetField("Type", BindingFlags.Public | BindingFlags.Static);
                if (typeField != null && typeField.FieldType == typeof(Uri))
                {
                    registry[nestedType.Name] = (Uri)typeField.GetValue(null);
                }
            }

            return registry;
        }

        public class Course : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://adlnet.gov/expapi/activities/course");
            public static readonly string DefaultName = "Course-DefaultName";
            public static readonly string DefaultDescription = "Course-DefaultDescription";
            public Course(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Simulation : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://adlnet.gov/expapi/activities/simulation");
            public static readonly string DefaultName = "Simulation-DefaultName";
            public static readonly string DefaultDescription = "Simulation-DefaultDescription";
            public Simulation(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Strategy : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://id.tincanapi.com/activitytype/strategy");
            public static readonly string DefaultName = "Strategy-DefaultName";
            public static readonly string DefaultDescription = "Strategy-DefaultDescription";
            public Strategy(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Step : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://id.tincanapi.com/activitytype/step");
            public static readonly string DefaultName = "Step-DefaultName";
            public static readonly string DefaultDescription = "Step-DefaultDescription";
            public Step(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }

        public class Performance : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://adlnet.gov/expapi/activities/performance");

            public Performance(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }

        public class Interaction : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://adlnet.gov/expapi/activities/cmi.interaction");
            public static readonly string DefaultName = "Interaction-DefaultName";
            public static readonly string DefaultDescription = "Interaction-DefaultDescription";
            public Interaction(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Skill : ActivityDefinition
        {

            public static readonly Uri Type = new Uri("http://adlnet.gov/expapi/activities/skill");
            public static readonly string DefaultName = "Skill-DefaultName";
            public static readonly string DefaultDescription = "Skill-DefaultDescription";
            public Skill(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Badge : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://activitystrea.ms/schema/1.0/badge");
            public static readonly string DefaultName = "Badge-DefaultName";
            public static readonly string DefaultDescription = "Badge-DefaultDescription";
            public Badge(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class Reward : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://id.tincanapi.com/activitytype/reward");
            public static readonly string DefaultName = "Points-DefaultName";
            public static readonly string DefaultDescription = "Points-DefaultDescription";
            public Reward(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }

        // Matches the type URIs SkillCategories/HardSkillSubCategories/SoftSkillSubCategories
        // already assign directly - registered here too so the generic ObjectConfigData ->
        // Activity conversion (BuildActivity) can resolve them like any other activity type.
        public class Category : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://id.tincanapi.com/activitytype/category");
            public Category(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
        public class SubCategory : ActivityDefinition
        {
            public static readonly Uri Type = new Uri("http://id.tincanapi.com/activitytype/subcategory");
            public SubCategory(LanguageMap name, LanguageMap description)
            {
                this.name = name;
                this.description = description;
                type = Type;
            }
        }
    }
}
