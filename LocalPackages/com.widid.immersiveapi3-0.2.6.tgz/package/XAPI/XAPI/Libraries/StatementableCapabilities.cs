using System;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI
{
    // Which of the StamentableInterfaces capability interfaces a given Statementable type
    // implements, resolved once via reflection (see StatementableCapabilityRegistry) so any
    // consumer - Context's parent-chain, Result/Score visibility, the Category picker - always
    // matches the real xAPI library's own interface implementations instead of duplicating a
    // hand-maintained rule table.
    public class StatementableCapabilities
    {
        public static readonly StatementableCapabilities None = new StatementableCapabilities(null);

        public bool CanParentCourse { get; }
        public bool CanParentSimulation { get; }
        public bool CanParentStrategy { get; }
        public bool CanParentStep { get; }
        public bool HasResult { get; }
        public bool HasScore { get; }
        public bool HasCategories { get; }
        public bool HasAttachments { get; }

        public StatementableCapabilities(Type statementableType)
        {
            CanParentCourse = Implements<ICourseParentable>(statementableType);
            CanParentSimulation = Implements<ISimulationParentable>(statementableType);
            CanParentStrategy = Implements<IStrategyParentable>(statementableType);
            CanParentStep = Implements<IStepParentable>(statementableType);
            HasResult = Implements<IResultable>(statementableType);
            HasScore = Implements<IScorable>(statementableType);
            HasCategories = Implements<ICategorisable>(statementableType);
            HasAttachments = Implements<IAttachmentable>(statementableType);
        }

        private static bool Implements<TInterface>(Type type)
        {
            return type != null && typeof(TInterface).IsAssignableFrom(type);
        }
    }
}
