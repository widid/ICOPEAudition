using System;

namespace WiDiD.XAPI
{
    public static class ExtensionsLibrary
    {
        public static readonly ExtensionDefinition<SeverityLevel> Severity = new ExtensionDefinition<SeverityLevel>(
            new Uri("http://id.tincanapi.com/extension/severity"),
            "Severity",
            serialize: value => value.ToString().ToLowerInvariant());

        public static readonly ExtensionDefinition<Guid> SessionId = new ExtensionDefinition<Guid>(
            new Uri("https://w3id.org/xapi/cmi5/context/extensions/sessionid"),
            "Session Id",
            serialize: value => value.ToString());

        public static readonly ExtensionDefinition<string> Measurement = new ExtensionDefinition<string>(
            new Uri("http://id.tincanapi.com/extension/measurement"),
            "Measurement");

        // The four device extensions describing where a statement was produced (see
        // xAPI-Statements/Statements_FromTrainings/DefaultObjects/Context.json). Only DeviceType is
        // required; the other three add precision when they're known - DeviceContextDetector
        // resolves all of them from the running platform.
        public static readonly ExtensionDefinition<DeviceKind> DeviceType = new ExtensionDefinition<DeviceKind>(
            new Uri("https://widid-immersive.fr/xapi/extensions/device-type"),
            "Device Type",
            serialize: value => value.ToString());

        public static readonly ExtensionDefinition<DeviceRuntime> Runtime = new ExtensionDefinition<DeviceRuntime>(
            new Uri("https://widid-immersive.fr/xapi/extensions/runtime"),
            "Runtime",
            serialize: value => value.ToString());

        public static readonly ExtensionDefinition<DeviceOperatingSystem> OperatingSystem = new ExtensionDefinition<DeviceOperatingSystem>(
            new Uri("https://widid-immersive.fr/xapi/extensions/operating-system"),
            "Operating System",
            serialize: value => value.ToString());

        public static readonly ExtensionDefinition<string> DeviceModel = new ExtensionDefinition<string>(
            new Uri("https://widid-immersive.fr/xapi/extensions/device-model"),
            "Device Model");


        public static readonly ExtensionDefinition[] All = { Severity, SessionId, Measurement, DeviceType, Runtime, OperatingSystem, DeviceModel };
    }
}
