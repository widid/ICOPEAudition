namespace WiDiD.XAPI
{
    /// <summary>
    /// The device a statement was produced on, carried by the four device context extensions
    /// (device-type, runtime, operating-system, device-model). OperatingSystem/Model are optional -
    /// the matching extension is omitted when they're absent.
    /// </summary>
    public class DeviceContext
    {
        public DeviceKind Kind { get; }
        public DeviceRuntime Runtime { get; }
        public DeviceOperatingSystem? OperatingSystem { get; }
        public string Model { get; }

        public DeviceContext(DeviceKind kind, DeviceRuntime runtime, DeviceOperatingSystem? operatingSystem = null, string model = null)
        {
            Kind = kind;
            Runtime = runtime;
            OperatingSystem = operatingSystem;
            Model = model;
        }
    }
}
