using UnityEngine;
using UnityEngine.XR;

namespace WiDiD.XAPI
{
    /// <summary>
    /// Resolves the DeviceContext of the machine currently running the app, from Unity's own
    /// platform/XR information.
    /// </summary>
    public static class DeviceContextDetector
    {
        private static DeviceContext current;

        // Cached: none of what it reports changes over an app run, and callers hit it as often as
        // once per built statement (the demo previews one every few hundred milliseconds).
        public static DeviceContext Current => current ??= Detect();

        public static DeviceContext Detect()
        {
            DeviceKind kind = DetectKind();
            return new DeviceContext(kind, DetectRuntime(), DetectOperatingSystem(kind), DetectModel());
        }

        private static DeviceKind DetectKind()
        {
            if (XRSettings.isDeviceActive) return DeviceKind.HMD;

            return SystemInfo.deviceType == UnityEngine.DeviceType.Handheld ? DeviceKind.Mobile : DeviceKind.Desktop;
        }

        private static DeviceRuntime DetectRuntime()
        {
            return Application.platform == RuntimePlatform.WebGLPlayer ? DeviceRuntime.Web : DeviceRuntime.Native;
        }

        private static DeviceOperatingSystem? DetectOperatingSystem(DeviceKind kind)
        {
            switch (Application.platform)
            {
                case RuntimePlatform.WindowsPlayer:
                case RuntimePlatform.WindowsEditor:
                    return DeviceOperatingSystem.Windows;
                case RuntimePlatform.OSXPlayer:
                case RuntimePlatform.OSXEditor:
                    return DeviceOperatingSystem.MacOS;
                case RuntimePlatform.LinuxPlayer:
                case RuntimePlatform.LinuxEditor:
                    return DeviceOperatingSystem.Linux;
                case RuntimePlatform.IPhonePlayer:
                    return DeviceOperatingSystem.iOS;
                case RuntimePlatform.Android:
                    // Standalone headsets (Quest and the like) run Horizon OS, itself an Android fork.
                    return kind == DeviceKind.HMD ? DeviceOperatingSystem.HorizonOS : DeviceOperatingSystem.Android;
                default:
                    // Covers WebGL, where the platform only says "browser" and the host OS has to
                    // come from SystemInfo instead. Consoles/visionOS report no family Unity can
                    // map here, so their extension is simply omitted.
                    return DetectOperatingSystemFamily();
            }
        }

        private static DeviceOperatingSystem? DetectOperatingSystemFamily()
        {
            switch (SystemInfo.operatingSystemFamily)
            {
                case OperatingSystemFamily.Windows:
                    return DeviceOperatingSystem.Windows;
                case OperatingSystemFamily.MacOSX:
                    return DeviceOperatingSystem.MacOS;
                case OperatingSystemFamily.Linux:
                    return DeviceOperatingSystem.Linux;
                default:
                    return null;
            }
        }

        // SystemInfo returns its unsupportedIdentifier placeholder rather than null when it has no
        // model to give, which would be noise in a statement - treated as absent.
        private static string DetectModel()
        {
            string model = SystemInfo.deviceModel;
            return string.IsNullOrEmpty(model) || model == SystemInfo.unsupportedIdentifier ? null : model;
        }
    }
}
