namespace WiDiD.XAPI
{
    // Values the device-type context extension accepts (see
    // xAPI-Statements/Statements_FromTrainings/README.md). Named Kind rather than Type to stay
    // unambiguous next to UnityEngine.DeviceType.
    public enum DeviceKind
    {
        Desktop,
        Mobile,
        HMD
    }
}
