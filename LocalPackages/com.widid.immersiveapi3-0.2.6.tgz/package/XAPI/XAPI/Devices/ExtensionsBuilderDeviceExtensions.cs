namespace WiDiD.XAPI
{
    /// <summary>
    /// Writes a DeviceContext into an ExtensionsBuilder as the four device context extensions, so
    /// every profile building a context does it identically instead of repeating the four keys.
    /// </summary>
    public static class ExtensionsBuilderDeviceExtensions
    {
        public static ExtensionsBuilder WithDeviceContext(this ExtensionsBuilder builder, DeviceContext device)
        {
            if (device == null) return builder;

            builder.WithExtension(ExtensionsLibrary.DeviceType, device.Kind);
            builder.WithExtension(ExtensionsLibrary.Runtime, device.Runtime);

            if (device.OperatingSystem.HasValue)
            {
                builder.WithExtension(ExtensionsLibrary.OperatingSystem, device.OperatingSystem.Value);
            }
            if (!string.IsNullOrEmpty(device.Model))
            {
                builder.WithExtension(ExtensionsLibrary.DeviceModel, device.Model);
            }

            return builder;
        }
    }
}
