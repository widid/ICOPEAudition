namespace WiDiD.XAPI
{
    // Values the runtime context extension accepts: a native build versus one running in a browser.
    public enum DeviceRuntime
    {
        Native,
        Web
    }
}
