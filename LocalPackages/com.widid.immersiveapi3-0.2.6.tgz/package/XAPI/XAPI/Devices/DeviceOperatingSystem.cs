namespace WiDiD.XAPI
{
    // Values the operating-system context extension accepts. Member names are serialized verbatim,
    // hence the vendor casing of visionOS/HorizonOS/PlayStationOS/XboxOS.
    public enum DeviceOperatingSystem
    {
        Windows,
        MacOS,
        Linux,
        Android,
        iOS,
        visionOS,
        HorizonOS,
        PlayStationOS,
        XboxOS
    }
}
