using TinCan;
using UnityEngine;
using WiDiD.XAPI;

public interface IStatementBuilderProfile
{
    public StatementBuilder CreateBuilderProfile(Verb verb, IStatementable statementable);
}
