using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace WiDiD.XAPI
{
    public class ExtensionsBuilder
    {
        private readonly Dictionary<Uri, JToken> extensions;

        public ExtensionsBuilder()
        {
            extensions = new Dictionary<Uri, JToken>();
        }

        public static ExtensionsBuilder Create()
        {
            return new ExtensionsBuilder();
        }

        public ExtensionsBuilder WithExtension<T>(ExtensionDefinition<T> definition, T value)
        {
            extensions[definition.Uri] = definition.Serialize(value);
            return this;
        }

        public ExtensionsBuilder WithRawExtension(Uri uri, JToken value)
        {
            extensions[uri] = value;
            return this;
        }

        // Plain-string overload so callers outside this assembly (e.g. the Demo layer)
        // don't need a Newtonsoft.Json reference just to add an ad-hoc extension.
        public ExtensionsBuilder WithRawExtension(Uri uri, string value)
        {
            extensions[uri] = value;
            return this;
        }

        public TinCan.Extensions Build()
        {
            JObject jObject = new JObject();
            foreach (KeyValuePair<Uri, JToken> extension in extensions)
            {
                jObject.Add(extension.Key.ToString(), extension.Value);
            }
            return new TinCan.Extensions(jObject);
        }
    }
}
