using System;
using TinCan;
using UnityEngine;

public class StatementQueryBuilder
{
    private StatementsQuery statementsQuery = null;
    public StatementQueryBuilder()
    {
        statementsQuery = new StatementsQuery();
    }
    public static StatementQueryBuilder Create()
    {
        return new StatementQueryBuilder();
    }

    public StatementQueryBuilder WithAgent(Agent agent)
    {
        statementsQuery.agent = agent;
        return this;
    }
    public StatementQueryBuilder WithActivityId(Uri activityId)
    {
        statementsQuery.activityId = activityId.ToString();
        return this;
    }
    public StatementQueryBuilder WithVerbId(Uri verbId)
    {
        statementsQuery.verbId = verbId;
        return this;
    }
    public StatementQueryBuilder WithRegistration(Guid registration)
    {
        statementsQuery.registration = registration;
        return this;
    }
    public StatementQueryBuilder WithCountLimit(int limit)
    {
        statementsQuery.limit = limit;
        return this;
    }
    public StatementQueryBuilder WithinTimeInterval(DateTime? since = null, DateTime? until = null)
    {
        statementsQuery.since = since;
        statementsQuery.until = until;
        return this;
    }
    public StatementQueryBuilder WithSortingSetting(bool ascending)
    {
        statementsQuery.ascending = ascending;
        return this;
    }

    public StatementsQuery Build()
    {
        return statementsQuery;
    }
}
