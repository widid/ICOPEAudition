using System;
using System.Collections.Generic;
using System.Linq;
using TinCan;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.XAPI
{
    public class DefaultStatementBuilderProfile : IStatementBuilderProfile
    {
        public StatementBuilder CreateBuilderProfile(Verb verb, IStatementable statementable)
        {
            Activity activity = new Activity();
            Context context = new Context();
            Result result = null;
            List<Attachment> attachments = null;

            if (statementable is IActivity act) { activity = act.Activity; }
            if (statementable is IAttachmentable attachmentable) { attachments = attachmentable.GetAttachments(); }
            context = BuildContext(statementable);

            if (Verbs.ShouldDisplayResult(verb))
            {
                result = BuildResult(statementable);
            }

            return StatementBuilder.Create()
                .WithActor(ImmersiveAPI_Tests.UserIdentity)
                .WithVerb(verb)
                .WithObject(activity)
                .WithContext(context)
                .WithResult(result)
                .WithAttachments(attachments);
        }

        private List<Activity> GetParentContextActivities(IParented parented)
        {
            return parented.Parents.Select(activityDef => activityDef.Activity).ToList();
        }

        private Result BuildResult(IStatementable statementable)
        {
            Result result = null;
            if (statementable is IResultable resultable)
            {
                result = resultable.GetResult();
            }
            else if (statementable is IScorable scorable)
            {
                result = new Result();
                result.score = scorable.GetScore();
            }
            return result;
        }

        private Context BuildContext(IStatementable statementable)
        {
            Context context = new Context();
            context.platform = "WiDiD Immersive";
            context.registration = ImmersiveAPI_Tests.UserRegistration;
            context.language = "en-US";

            context.extensions = ExtensionsBuilder.Create()
                .WithExtension(ExtensionsLibrary.SessionId, ImmersiveAPI_Tests.SessionId)
                .WithDeviceContext(ImmersiveAPI_Tests.DeviceContext)
                .Build();

            if (statementable is IParented parented)
            {
                if (context.contextActivities == null) context.contextActivities = new ContextActivities();
                context.contextActivities.parent = GetParentContextActivities(parented);
            }
            if (statementable is ICategorisable categorisable)
            {
                if (context.contextActivities == null) context.contextActivities = new ContextActivities();
                context.contextActivities.category = categorisable.GetCategories().ToList();
            }

            return context;
        }

    }
}
