using UnityEngine;
using TinCan;
using System;
using WiDiD.Localization;
public class AttachmentBuilder
{
    private Attachment attachment;

    public AttachmentBuilder(Uri fileUrl, string contentType)
    {
        attachment = new Attachment();
        attachment.fileUrl = fileUrl;
        attachment.contentType = contentType;
        attachment.sha2 = "";
    }
    public static AttachmentBuilder Create(Uri fileUrl, string contentType)
    {
        return new AttachmentBuilder(fileUrl, contentType);
    }

    public AttachmentBuilder WithDisplay(LanguageDictionary display)
    {
        attachment.display = new LanguageMap(display.GetLanguageMap());
        return this;
    }
    public AttachmentBuilder WithDescription(LanguageDictionary description)
    {
        attachment.description = new LanguageMap(description.GetLanguageMap());
        return this;
    }
    public AttachmentBuilder WithLength(long length)
    {
        attachment.length = length;
        return this;
    }
    public AttachmentBuilder WithUsageType(Uri usageType)
    {
        attachment.usageType = usageType;
        return this;
    }
    public AttachmentBuilder WithSha2(string sha2)
    {
        attachment.sha2 = sha2;
        return this;
    }
    public AttachmentBuilder WithLanguage(string languageCode)
    {
        attachment.language = languageCode;
        return this;
    }

    public Attachment Build()
    {
        return attachment;
    }
}
