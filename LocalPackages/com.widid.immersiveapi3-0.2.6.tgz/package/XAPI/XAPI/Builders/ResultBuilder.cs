using UnityEngine;
using TinCan;
using System;


namespace WiDiD.XAPI
{
    public class ResultBuilder
    {
        private Result result;

        public ResultBuilder()
        {
            result = new Result();
        }

        public static ResultBuilder Create()
        {
            return new ResultBuilder();
        }

        public ResultBuilder WithScore(float? scaled = null, int? raw = null, int? minimumScore = null, int? maximumScore = null)
        {
            result.score = new Score() { scaled = scaled, raw = raw, min = minimumScore, max = maximumScore };
            return this;
        }
        public ResultBuilder WithSuccess(bool success)
        {
            result.success = success;
            return this;
        }
        public ResultBuilder WithCompletion(bool completion)
        {
            result.completion = completion;
            return this;
        }
        public ResultBuilder WithResponse(string response)
        {
            result.response = response;
            return this;
        }
        public ResultBuilder WithDuration(TimeSpan duration)
        {
            result.duration = duration;
            return this;
        }
        public Result Build()
        {
            return result;
        }
    }
}
