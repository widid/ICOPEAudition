using System;
using TinCan;
using UnityEngine;
namespace WiDiD.XAPI
{
    public class ActivityBuilder
    {
        private Activity activity;

        public ActivityBuilder()
        {
            activity = new Activity();
        }
        public static ActivityBuilder Create()
        {
            return new ActivityBuilder();
        }
        public ActivityBuilder WithId(Uri id)
        {
            activity.id = id.ToString();
            return this;
        }
        public ActivityBuilder WithDefinition(ActivityDefinition activityDefinition)
        {
            activity.definition = activityDefinition;
            return this;
        }
        public Activity Build()
        {
            return activity;
        }
    }
}
