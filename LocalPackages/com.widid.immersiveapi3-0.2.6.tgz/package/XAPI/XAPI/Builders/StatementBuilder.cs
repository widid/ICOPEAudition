using System.Collections.Generic;
using TinCan;
#nullable enable
namespace WiDiD.XAPI
{
    public class StatementBuilder
    {
        private Statement statement;

        private StatementBuilder()
        {
            statement = new Statement();
            statement.timestamp = System.DateTime.Now;
        }
        public static StatementBuilder Create()
        {
            return new StatementBuilder().WithActor(ImmersiveAPI_Tests.UserIdentity);
        }
        public static StatementBuilder CreateFromProfile(IStatementBuilderProfile profile, Verb verb, IStatementable statementable)
        {
            return profile.CreateBuilderProfile(verb, statementable);
        }

        public StatementBuilder WithActor(Agent agent)
        {
            statement.actor = agent;
            return this;
        }
        public StatementBuilder WithVerb(Verb verb)
        {
            statement.verb = verb;
            return this;
        }

        public StatementBuilder WithObject(Activity activity)
        {
            statement.target = activity;
            return this;
        }
        public StatementBuilder WithContext(Context context)
        {
            statement.context = context;
            return this;
        }
        public StatementBuilder WithResult(Result result)
        {
            statement.result = result;
            return this;
        }
        public StatementBuilder WithAttachments(List<Attachment> attachments)
        {
            statement.attachments = attachments;
            return this;
        }
        public Statement Build()
        {
            return statement;
        }
    }
}