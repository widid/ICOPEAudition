using UnityEngine;
using TinCan;
using System;

namespace WiDiD.XAPI
{
    public class ContextBuilder
    {
        private Context context;

        public ContextBuilder()
        {
            context = new Context();
        }

        public static ContextBuilder Create()
        {
            return new ContextBuilder();
        }

        public ContextBuilder WithRegistration(Guid registration)
        {
            context.registration = registration;
            return this;
        }
        public ContextBuilder WithInstructor(Agent instructor)
        {
            context.instructor = instructor;
            return this;
        }
        public ContextBuilder WithParentActivity(Activity parentActivity)
        {
            context.contextActivities.parent.Add(parentActivity);
            return this;
        }
        public Context Build()
        {
            return context;
        }
    }
}
