using System;
using TinCan;
using WiDiD.XAPI.Statementables;

public record CourseRegistration
{
    public Course Course { get; }
    public Agent Instructor { get; }
    public Guid Registration { get; }
    public Group? Group { get; }
}
