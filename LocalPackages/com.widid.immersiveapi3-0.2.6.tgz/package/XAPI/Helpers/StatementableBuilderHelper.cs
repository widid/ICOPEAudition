using System;
using TinCan;
using WiDiD.Localization;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;
#nullable enable
public static class StatementableBuilderHelper
{
    public static Agent DefaultAgent = new Agent { mbox = "mailto:johndoe@example.com", name = "John Doe" };
    public static Guid DefaultRegistration => Guid.Parse("0f134eb4-4c55-49d6-acbe-76ceef25fb94");
    public static Guid DefaultSessionId => Guid.Parse("60b60f72-0cf9-4a1f-ac4f-b30a67f2fdc9");

    // Fixed rather than detected from the running machine, so the device context extensions match
    // the expected statements' own values (xAPI-Statements/Statements_FromTrainings/DefaultObjects/Context.json).
    public static DeviceContext DefaultDeviceContext => new DeviceContext(DeviceKind.HMD, DeviceRuntime.Native, DeviceOperatingSystem.Android, "Quest3");


    public static Course BuildCourse(string id = "{Course_Id}")
    {
        var name = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Course.DefaultName } },
            new[] { 0 });

        var description = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Course.DefaultDescription } },
            new[] { 0 });

        return new Course(id, name, description);
    }

    /// <summary>
    /// Default build of simulation
    /// </summary>
    public static Simulation BuildSimulation(string id = "{Simulation_Id}", Course? parentCourse = null)
    {
        var name = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Simulation.DefaultName } },
            new[] { 0 });

        var description = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Simulation.DefaultDescription } },
            new[] { 0 });

        return new Simulation(id, name, description, parentCourse);
    }
    public static Strategy BuildStrategy(Simulation parentSimulation, string id = "{Strategy_Id}", Course? parentCourse = null)
    {
        var name = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Strategy.DefaultName } },
            new[] { 0 });

        var description = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Strategy.DefaultDescription } },
            new[] { 0 });

        return new Strategy(id, name, description, parentSimulation, parentCourse);
    }

    public static Step BuildStep(Simulation parentSimulation, Strategy parentStrategy, string id = "{Step_Id}", Course? parentCourse = null)
    {
        var name = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Step.DefaultName } },
            new[] { 0 });

        var description = new LanguageDictionary(
            new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = ActivityDefinitions.Step.DefaultDescription } },
            new[] { 0 });

        return new Step(id, name, description, parentStrategy, parentSimulation, parentCourse);
    }

    /// <summary>
    /// Default building of step
    /// </summary>
    /// <returns></returns>
    public static Step BuildStep()
    {
        Course parentCourse = StatementableBuilderHelper.BuildCourse();
        Strategy parentStrategy = BuildStrategy(StatementableBuilderHelper.BuildSimulation(id: "{Simulation_Id}", parentCourse));
        Step step = BuildStep(parentStrategy.ParentSimulation, parentStrategy, "{Step_Id}", parentCourse);
        return step;
    }
    /// <summary>
    /// Default build of strategy
    /// </summary>
    /// <returns></returns>
    public static Strategy BuildStrategy()
    {
        Course parentCourse = StatementableBuilderHelper.BuildCourse();
        Simulation simulation = StatementableBuilderHelper.BuildSimulation("{Simulation_Id}", parentCourse);
        Strategy strategy = BuildStrategy(simulation, "{Strategy_Id}", parentCourse);
        return strategy;
    }

}
