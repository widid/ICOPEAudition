using System;

namespace WiDiD.XAPI.Statementables
{
    public static class XapiUriHelper
    {
        public static Uri GetStatementableUri(IStatementable statementable, StatementableUriConfig uriConfig)
        {
            if (statementable is Course course)
            {
                return GetCourseUri(course, uriConfig);
            }
            if (statementable is Simulation training)
            {
                return GetTrainingUri(training, uriConfig);
            }
            if (statementable is Strategy session)
            {
                return GetSessionUri(session, uriConfig);
            }
            if (statementable is Step step)
            {
                return GetStepUri(step, uriConfig);
            }
            if (statementable is Interaction interaction)
            {
                return GetInteractionUri(interaction, uriConfig);
            }
            if (statementable is Performance performance)
            {
                return GetPerformanceUri(performance, uriConfig);
            }
            if (statementable is Skill skill)
            {
                return GetSkillUri(skill, uriConfig);
            }
            if (statementable is Badge badge)
            {
                return GetBadgeUri(badge, uriConfig);
            }
            if (statementable is Reward reward)
            {
                return GetRewardUri(reward, uriConfig);
            }
            return uriConfig.XapiUri;
        }
        private static Uri GetCourseUri(Course course, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.CoursePath + course.UniqueId);
        }
        private static Uri GetTrainingUri(Simulation training, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + training.UniqueId);
        }
        private static Uri GetSessionUri(Strategy session, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + session.ParentSimulation.UniqueId + '/' + uriConfig.StrategyPath + session.UniqueId);
        }
        private static Uri GetStepUri(Step step, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + step.ParentSimulation.UniqueId + '/' + uriConfig.StrategyPath + step.ParentStrategy.UniqueId + '/' + uriConfig.StepPath + step.UniqueId);
        }
        private static Uri GetInteractionUri(Interaction interaction, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + interaction.ParentSimulation.UniqueId + '/' + uriConfig.StrategyPath + interaction.ParentStrategy.UniqueId + '/' + uriConfig.StepPath + interaction.ParentStep.UniqueId + '/' + uriConfig.InteractionPath + interaction.UniqueId);
        }
        private static Uri GetPerformanceUri(Performance performance, StatementableUriConfig uriConfig)
        {
            string uri = uriConfig.XapiUri + uriConfig.SimulationPath + performance.ParentSimulation.UniqueId;
            if (performance.ParentStrategy == null)
            {
                if (performance.ParentStep != null)
                {
                    uri += '/' + uriConfig.StrategyPath + performance.ParentStrategy.UniqueId + '/' + uriConfig.StepPath + performance.ParentStep.UniqueId;
                }
            }
            else
            {
                uri += '/' + uriConfig.StrategyPath + performance.ParentStrategy.UniqueId;
                if (performance.ParentStep != null)
                {
                    uri += '/' + uriConfig.StepPath + performance.ParentStep.UniqueId;
                }
            }


            uri += '/' + uriConfig.PerformancePath + performance.UniqueId;

            return new Uri(uri);
        }

        private static Uri GetSkillUri(Skill skill, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + skill.ParentSimulation.UniqueId + '/' + uriConfig.SkillPath + skill.UniqueId);
        }
        private static Uri GetBadgeUri(Badge badge, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + badge.ParentSimulation.UniqueId + '/' + uriConfig.BadgePath + badge.UniqueId);
        }
        private static Uri GetRewardUri(Reward reward, StatementableUriConfig uriConfig)
        {
            return new Uri(uriConfig.XapiUri + uriConfig.SimulationPath + reward.ParentSimulation.UniqueId + '/' + uriConfig.RewardPath + reward.UniqueId);
        }
    }
}
