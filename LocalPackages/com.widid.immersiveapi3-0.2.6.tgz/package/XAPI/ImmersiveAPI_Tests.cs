using System;
using TinCan;

namespace WiDiD.XAPI
{
    public class ImmersiveAPI_Tests
    {
        public static readonly Agent UserIdentity = StatementableBuilderHelper.DefaultAgent;
        public static StatementableUriConfig StatementableUriConfig => new StatementableUriConfig();
        public static Guid UserRegistration = StatementableBuilderHelper.DefaultRegistration;
        public static Guid SessionId = StatementableBuilderHelper.DefaultSessionId;
        public static DeviceContext DeviceContext = StatementableBuilderHelper.DefaultDeviceContext;
    }
}
