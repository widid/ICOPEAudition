
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface ICourseParentable
    {
        public Course ParentCourse { get; }
    }
}