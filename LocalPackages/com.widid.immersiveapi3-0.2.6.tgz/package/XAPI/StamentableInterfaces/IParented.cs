
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface IParented
    {
        public IActivity[] Parents { get; }
    }
}