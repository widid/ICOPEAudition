using TinCan;
public interface ICategorisable
{
    public Activity[] GetCategories();
}
