using System;

namespace WiDiD.XAPI
{
    public interface IStatementable
    {
        public Uri Uri { get; }
        /// <summary>
        /// Must be unique for a given implementation of this interface 
        /// For example, all steps should not share the same id, but could share ids with sessions
        /// </summary>
        public string UniqueId { get; }
    }
}
