using TinCan;
using WiDiD.Localization;
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface IActivity
    {
        public LanguageDictionary Name { get; }
        public LanguageDictionary Description { get; }
        public Activity Activity { get; }
        public ActivityDefinition ActivityDefinition { get; }
    }
}