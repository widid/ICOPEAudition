using TinCan;
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface IScorable
    {
        public Score GetScore();
    }
}