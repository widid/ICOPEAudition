namespace WiDiD.XAPI.Statementables.Interfaces
{

    /// <summary>
    /// Must be implemented to datas linked to a specific session
    /// </summary>
    public interface IStepParentable
    {
        /// <summary>
        /// If null, doesn't add session ID to generated statement
        /// </summary>
        public Step ParentStep { get; }
    }
}