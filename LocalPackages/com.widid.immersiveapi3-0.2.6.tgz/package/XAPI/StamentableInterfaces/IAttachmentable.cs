using System.Collections.Generic;
using TinCan;
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface IAttachmentable
    {
        public List<Attachment> GetAttachments();
    }
}