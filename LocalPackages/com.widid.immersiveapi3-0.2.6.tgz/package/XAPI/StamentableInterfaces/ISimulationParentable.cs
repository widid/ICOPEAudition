namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface ISimulationParentable
    {
        public Simulation ParentSimulation { get; }
    }
}
