using TinCan;
namespace WiDiD.XAPI.Statementables.Interfaces
{
    public interface IResultable
    {
        public Result GetResult();
    }
}