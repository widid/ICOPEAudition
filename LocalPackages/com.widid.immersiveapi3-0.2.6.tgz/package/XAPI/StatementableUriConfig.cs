using System;
namespace WiDiD.XAPI
{
    public class StatementableUriConfig
    {
        public Uri XapiUri { get; }
        public string CoursePath { get; }
        public string SimulationPath { get; }
        public string StrategyPath { get; }
        public string StepPath { get; }
        public string InteractionPath { get; }
        public string PerformancePath { get; }
        public string SkillPath { get; }
        public string BadgePath { get; }
        public string RewardPath { get; }

        //Default constructor
        public StatementableUriConfig()
        {
            XapiUri = new Uri("https://widid-immersive.fr/xapi/");
            CoursePath = "courses/";
            SimulationPath = "simulations/";
            StrategyPath = "strategies/";
            StepPath = "steps/";
            InteractionPath = "interactions/";
            PerformancePath = "performances/";
            SkillPath = "skills/";
            BadgePath = "badges/";
            RewardPath = "points/";
        }

        public StatementableUriConfig(Uri xapiUri, string coursePath, string trainingPath, string sessionPath, string stepPath, string interactionPath, string performancePath, string skillPath, string badgePath, string rewardPath)
        {
            XapiUri = xapiUri;
            CoursePath = coursePath;
            SimulationPath = trainingPath;
            StrategyPath = sessionPath;
            StepPath = stepPath;
            InteractionPath = interactionPath;
            PerformancePath = performancePath;
            SkillPath = skillPath;
            BadgePath = badgePath;
            RewardPath = rewardPath;
        }
    }
}