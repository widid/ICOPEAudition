using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    /// <summary>
    /// A session/step display name translated into each language the training scenario supports,
    /// as returned by the trainings/{id}/json-step endpoint's "name" object
    /// ({ en, fr, it, es, de, pt }).
    /// </summary>
    [Serializable]
    public class LocalizedName
    {
        [field: SerializeField] public string En { get; set; }
        [field: SerializeField] public string Fr { get; set; }
        [field: SerializeField] public string It { get; set; }
        [field: SerializeField] public string Es { get; set; }
        [field: SerializeField] public string De { get; set; }
        [field: SerializeField] public string Pt { get; set; }

        /// <summary>
        /// Returns the value for the given BCP-47/base language code, falling back to English
        /// then to whatever's available.
        /// </summary>
        public string Get(string languageCode)
        {
            return languageCode?.ToLowerInvariant() switch
            {
                "en" => En,
                "fr" => Fr,
                "it" => It,
                "es" => Es,
                "de" => De,
                "pt" => Pt,
                _ => null,
            } ?? En ?? Fr ?? It ?? Es ?? De ?? Pt;
        }

        /// <summary>
        /// Converts every non-empty language into a LanguageDictionary, matching the format
        /// ObjectConfigData.Definition.NameTranslations expects.
        /// </summary>
        public LanguageDictionary ToLanguageDictionary()
        {
            List<LanguageDictionary.LanguageKey> keys = new();
            AddIfPresent(keys, 0, En);
            AddIfPresent(keys, 1, Fr);
            AddIfPresent(keys, 2, It);
            AddIfPresent(keys, 3, Es);
            AddIfPresent(keys, 4, De);
            AddIfPresent(keys, 5, Pt);
            return new LanguageDictionary(keys.ToArray(), new[] { 0, 1 });
        }

        private static void AddIfPresent(List<LanguageDictionary.LanguageKey> keys, int localizationIndex, string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                keys.Add(new LanguageDictionary.LanguageKey { localizationIndex = localizationIndex, value = value });
            }
        }
    }
}
