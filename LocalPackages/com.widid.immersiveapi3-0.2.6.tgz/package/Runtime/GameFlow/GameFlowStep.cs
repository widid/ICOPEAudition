using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    [Serializable]
    public class GameFlowStep : GameFlowNode
    {
        [field: SerializeField] public bool Succeeded { get; set; }
        [field: SerializeField] public float Score { get; set; }
        [field: SerializeField] public float Highscore { get; set; }
        [field: SerializeField] public bool IsPercent { get; set; }
    }
}
