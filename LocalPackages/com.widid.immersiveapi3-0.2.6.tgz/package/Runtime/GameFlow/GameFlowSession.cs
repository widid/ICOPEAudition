using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    [Serializable]
    public class GameFlowSession : GameFlowNode
    {
        [field: SerializeField] public List<GameFlowStep> Steps { get; set; } = new List<GameFlowStep>();
    }
}
