using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    // Sessions and Steps are both nodes in the same kind of graph: each one carries its own
    // id ("current"), the id(s) of the node(s) that precede it ("previous"), and a name
    // translated into every supported language. Modeling that shared shape once here is what
    // lets a session or a step be walked the same way regardless of which level of the flow it
    // belongs to.
    //
    // Current/Previous are strings rather than Guid: Unity's Inspector/serializer doesn't
    // support System.Guid, so a Guid field would deserialize from JSON fine but show up
    // blank (and fail to persist) in the Inspector.
    [Serializable]
    public abstract class GameFlowNode
    {
        [field: SerializeField] public string Current { get; set; }
        [field: SerializeField] public List<string> Previous { get; set; } = new List<string>();
        [field: SerializeField] public LocalizedName Name { get; set; }
    }
}
