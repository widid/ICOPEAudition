namespace WiDiD.ImmersiveAPI.GameFlow
{
    public interface IGameFlowDataProvider
    {
        GameFlowData Data { get; }
    }
}
