using System.Threading.Tasks;
using Newtonsoft.Json;
using WiDiD.ImmersiveAPI.Networking;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    public class GameFlowService : IGameFlowService
    {
        private readonly IImmersiveEndpoints endpoints;
        private readonly ILogger logger;

        public GameFlowService(IImmersiveEndpoints endpoints, ILogger logger)
        {
            this.endpoints = endpoints;
            this.logger = logger;
        }

        public async Task<GameFlowData> FetchProgression()
        {
            WebRequestResult result = await WebRequestUtility.GetAsync(endpoints.JsonStepAdress, endpoints.UserSession.DecodedToken);

            if (!result.Success)
            {
                logger.Log($"Failed to fetch training scenario ({result.StatusCode}): {result.Error}");
                return null;
            }

            return JsonConvert.DeserializeObject<GameFlowData>(result.Text);
        }
    }
}
