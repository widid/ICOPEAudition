using UnityEngine;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    [CreateAssetMenu(fileName = "NewGameFlowDataSO", menuName = "Data/GameFlow Data")]
    public class GameFlowDataSO : ScriptableObject, IGameFlowDataProvider
    {
        [field: SerializeField]
        public GameFlowData Data { get; private set; }

        public void SetData(GameFlowData data)
        {
            Data = data;
        }

        private void OnEnable()
        {
            // Progression is session-scoped: even though GameFlowData is now properly
            // serialized (so its content stays visible/persisted in the Inspector like any
            // other config asset), it shouldn't carry over between Play sessions - force a
            // clean slate on every load.
            Data = null;
        }
    }
}
