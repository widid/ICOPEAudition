using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    // Maps to the trainings/{id}/json-step response: { sessions }.
    [Serializable]
    public class GameFlowData
    {
        [field: SerializeField] public List<GameFlowSession> Sessions { get; set; } = new List<GameFlowSession>();
    }
}
