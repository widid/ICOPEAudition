using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.GameFlow
{
    public interface IGameFlowService
    {
        Task<GameFlowData> FetchProgression();
    }
}
