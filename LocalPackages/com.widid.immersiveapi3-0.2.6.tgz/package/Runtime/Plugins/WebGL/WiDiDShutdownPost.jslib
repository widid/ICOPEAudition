mergeInto(LibraryManager.library, {

    // Marshals the staged payload out to WiDiDShutdownPost.jspre, which owns the unload listeners
    // and the sending (see WebGlShutdownStatementPoster for why the browser side owns all of it,
    // and why nothing here ever calls back into managed code).
    WiDiD_StageShutdownStatements: function (urlPtr, tokenPtr, bodiesPtr) {
        window.wididShutdownStage(UTF8ToString(urlPtr), UTF8ToString(tokenPtr), UTF8ToString(bodiesPtr));
    },

    // Posts the staged statements immediately, for the deliberate exit that knows the app is
    // ending before the browser does. Shares the one-shot guard with the unload listeners.
    WiDiD_PostStagedNow: function () {
        window.wididShutdownPostNow();
    }

});
