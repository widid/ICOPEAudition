// Holds the statements the runtime says would have to be sent if the app died right now, and
// posts them when the page actually goes away (see WebGlShutdownStatementPoster). Loaded before
// the Unity module starts, so the two entry points below always exist by the time
// WiDiDShutdownPost.jslib reaches for them.
//
// The payload - including the session's bearer token - stays in this closure rather than on
// window, so other scripts on the hosting page cannot read it back out. Only the two functions
// are exposed, because a .jslib cannot see a .jspre's locals any other way.
(function () {

    var state = { url: '', token: '', bodies: [], posted: false, listening: false };

    // Every request is fired here and now, in one turn of the event loop, because a browser gives
    // an unload handler no further turns: anything deferred to a .then() or a timer would simply
    // never run, so the requests cannot be chained one-after-another. keepalive is what lets each
    // one finish after the page is gone, and each statement's own xAPI timestamp - stamped when it
    // was built, so terminated's is always the latest - is what keeps them ordered on arrival.
    //
    // keepalive caps a body at 64KB, which a single statement is nowhere near. navigator.sendBeacon
    // would be the more obvious unload transport but cannot carry an Authorization header, which
    // this endpoint requires.
    //
    // One-shot: pagehide and visibilitychange can both fire for a single teardown, and a deliberate
    // exit posts through here too, so terminated must not go out twice.
    function post() {
        if (state.posted || state.bodies.length === 0) {
            return;
        }
        state.posted = true;

        var headers = { 'Content-Type': 'application/json' };
        if (state.token) {
            headers['Authorization'] = 'Bearer ' + state.token;
        }

        for (var i = 0; i < state.bodies.length; i++) {
            try {
                fetch(state.url, {
                    method: 'POST',
                    headers: headers,
                    body: state.bodies[i],
                    keepalive: true,
                    mode: 'cors'
                }).catch(function (error) {
                    console.error('[xAPI] Shutdown post failed: ' + error);
                });
            } catch (error) {
                console.error('[xAPI] Shutdown post could not be started: ' + error);
            }
        }
    }

    // pagehide covers tab close, reload and navigation - including the deliberate exit in
    // AppTermination.Terminate(). visibilitychange covers mobile Safari, which routinely discards
    // a backgrounded tab without ever firing pagehide.
    function listen() {
        if (state.listening) {
            return;
        }
        state.listening = true;

        window.addEventListener('pagehide', post);
        window.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'hidden') {
                post();
            }
        });
    }

    window.wididShutdownStage = function (url, token, bodiesJson) {
        state.url = url;
        state.token = token;

        try {
            state.bodies = JSON.parse(bodiesJson) || [];
        } catch (error) {
            console.error('[xAPI] Could not read the staged shutdown statements: ' + error);
            state.bodies = [];
        }

        listen();
    };

    window.wididShutdownPostNow = post;

})();
