using System;

namespace WiDiD.ImmersiveAPI.Settings
{
    /// <summary>
    /// Marks a ScriptableObject as an ImmersiveAPI setting, so the config window (WiDiD_API >
    /// ImmersiveAPI > Configuration) lists and edits it. Discovery is by attribute rather than by a
    /// registry the window owns: a new setting is a new ScriptableObject carrying this, with
    /// nothing anywhere else to keep in sync.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    public class ImmersiveSettingsAttribute : Attribute
    {
        public string Title { get; }

        /// <summary>
        /// Path this setting is loaded from at runtime (Resources.Load, so no "Assets/Resources"
        /// prefix and no extension) - also where the config window creates the asset, so the two
        /// can't disagree.
        /// </summary>
        public string ResourcePath { get; }

        /// <summary>One line on what the setting controls, shown above its fields.</summary>
        public string Description { get; set; }

        /// <summary>Ascending sort position in the window; ties fall back to Title.</summary>
        public int Order { get; set; }

        public ImmersiveSettingsAttribute(string title, string resourcePath)
        {
            Title = title;
            ResourcePath = resourcePath;
        }
    }
}
