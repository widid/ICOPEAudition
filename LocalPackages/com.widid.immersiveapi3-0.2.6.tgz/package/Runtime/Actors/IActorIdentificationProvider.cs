namespace WiDiD.ImmersiveAPI.Actors
{
    public interface IActorIdentificationProvider
    {
        ActorIdentificationData Data { get; }
    }
}
