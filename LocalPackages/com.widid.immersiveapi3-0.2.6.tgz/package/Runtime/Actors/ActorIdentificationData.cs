using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Actors
{
    [Serializable]
    public class ActorIdentificationData
    {
        // The actor is always identified by account (backend url + launcher user id) - that's the
        // only identifier the launch arguments actually provide. This adds the user's real name
        // alongside it as a display value, which costs one user profile request on launch (see
        // UserProfileService) since the launcher never passes a name.
        [field: SerializeField] public bool IncludeDisplayName { get; private set; } = true;
    }
}
