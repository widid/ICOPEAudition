using UnityEngine;

namespace WiDiD.ImmersiveAPI.Actors
{
    /// <summary>
    /// Reads the actor identification setting, defaulting to a fresh ActorIdentificationData (i.e.
    /// account identification) when no asset exists at ActorIdentificationConfigSO.ResourcePath -
    /// the setting is opt-in, its absence is not a misconfiguration.
    /// </summary>
    public static class ActorIdentificationConfigLoader
    {
        public static ActorIdentificationData Load()
        {
            ActorIdentificationConfigSO asset = Resources.Load<ActorIdentificationConfigSO>(ActorIdentificationConfigSO.ResourcePath);

            return asset != null ? asset.Data : new ActorIdentificationData();
        }
    }
}
