using System;
using TinCan;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Actors
{
    /// <summary>
    /// Builds the xAPI Agent every statement is attributed to: an account identifier (backend url +
    /// launcher user id), optionally carrying the user's real name as a display value (see
    /// ActorIdentificationConfigSO). Account is the identifier rather than mbox because launching
    /// through WiDiD Immersive only yields a user id - the name itself comes from the user profile
    /// endpoint (see UserProfileService) and is not an identifier.
    /// </summary>
    public static class ActorFactory
    {
        // Only reached when the session carries no usable TargetUrl - an account identifier without
        // a homePage isn't a valid identifier at all, so the canonical host stands in.
        static readonly Uri FallbackHomePage = new Uri("https://widid-immersive.fr/");

        /// <summary>
        /// Actor from what the session already knows, with no network call - the display name is
        /// only present if something already fetched a profile (the email/password login path, see
        /// LoginManagerRuntimeController). For the real runtime actor, fetch the profile first and
        /// call Build.
        /// </summary>
        public static Agent FromLocalSession(UserSessionData sessionData)
        {
            return Build(sessionData, ActorIdentificationConfigLoader.Load(), sessionData.UserProfile?.Info);
        }

        public static Agent Build(UserSessionData sessionData, ActorIdentificationData config, ProfileInfo profile)
        {
            Agent actor = new Agent
            {
                account = new AgentAccount
                {
                    name = sessionData.UserId,
                    homePage = ResolveHomePage(sessionData.TargetUrl)
                }
            };

            if (config == null || config.IncludeDisplayName)
                actor.name = ResolveDisplayName(profile);

            return actor;
        }

        static string ResolveDisplayName(ProfileInfo profile)
        {
            if (profile == null)
                return null;

            string displayName = $"{profile.FirstName} {profile.LastName}".Trim();

            return string.IsNullOrEmpty(displayName) ? null : displayName;
        }

        static Uri ResolveHomePage(string targetUrl)
        {
            return Uri.TryCreate(targetUrl, UriKind.Absolute, out Uri homePage) ? homePage : FallbackHomePage;
        }
    }
}
