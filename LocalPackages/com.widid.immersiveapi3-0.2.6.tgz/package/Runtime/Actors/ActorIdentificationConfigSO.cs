using UnityEngine;
using WiDiD.ImmersiveAPI.Settings;

namespace WiDiD.ImmersiveAPI.Actors
{
    [ImmersiveSettings("Actor Identification", ActorIdentificationConfigSO.ResourcePath,
        Description = "How statements identify the learner. The account identifier (backend url + launcher user id) is always sent; the display name is read from the user profile endpoint.",
        Order = 0)]
    [CreateAssetMenu(fileName = "NewActorIdentificationConfigSO", menuName = "Data/Actor Identification Config")]
    public class ActorIdentificationConfigSO : ScriptableObject, IActorIdentificationProvider
    {
        // Same "found via Resources.Load, no Inspector wiring" rule as UserSessionSO - the actor is
        // resolved from static code paths (TrainingRuntime, the Editor statement preview) that have
        // nowhere to serialize a reference.
        public const string ResourcePath = "ImmersiveAPI/ActorIdentificationConfigSO";

        [field: SerializeField] public ActorIdentificationData Data { get; private set; } = new ActorIdentificationData();
    }
}
