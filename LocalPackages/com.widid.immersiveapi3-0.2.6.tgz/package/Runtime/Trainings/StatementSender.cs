using System.Threading.Tasks;
using TinCan;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings
{
    /// <summary>
    /// Builds a statement via the signed-in-user profile and posts it to the Immersive backend.
    ///
    /// Every send this runtime makes passes through here, the automatic ones included (see
    /// StrategyProgressController/SimulationProgressController/SkillRecorder/BadgeRecorder, none of
    /// which go through TrainingRuntime's own methods), so this is where a refused or unreachable
    /// send is reported (StatementFailureLog) rather than left to whichever caller may or may not
    /// inspect the result. Rejections never reach here - TrainingRuntime reports those itself.
    ///
    /// The statement is built the moment Send is called, but posted through PendingQueue, which
    /// serializes every send so they reach the backend in the order the game raised them - see
    /// StatementSendQueue for why that matters and what it costs. Building up front is what keeps
    /// each statement's xAPI timestamp honest despite the wait.
    /// </summary>
    public class StatementSender : IStatementSender
    {
        readonly IStatementBuilderProfile profile;
        readonly IImmersiveEndpoints endpoints;
        readonly string bearerToken;
        readonly ImmersiveXapiEventSender eventSender;

        /// <summary>
        /// Exposed for the app-teardown path, which needs to pull the not-yet-posted backlog out
        /// and re-send it over a transport that survives shutdown (see
        /// SimulationTerminationFlusher). Nothing else should reach into it - ordinary sends go
        /// through Send.
        /// </summary>
        public StatementSendQueue PendingQueue { get; }

        public StatementSender(IStatementBuilderProfile profile, IImmersiveEndpoints endpoints, string bearerToken, ImmersiveXapiEventSender eventSender)
        {
            this.profile = profile;
            this.endpoints = endpoints;
            this.bearerToken = bearerToken;
            this.eventSender = eventSender;

            PendingQueue = new StatementSendQueue(Post);
        }

        public Task<StatementSendResult> Send(Verb verb, IStatementable statementable)
        {
            Statement statement = StatementBuilder.CreateFromProfile(profile, verb, statementable).Build();
            string context = $"{verb.id} {statementable.GetType().Name} '{statementable.UniqueId}'";

            return PendingQueue.Enqueue(new PendingStatement(verb, statement, context));
        }

        /// <summary>
        /// Builds a statement without sending it, for the teardown path that has to serialize
        /// terminated ahead of time rather than post it through the queue (see
        /// SimulationTerminationFlusher).
        /// </summary>
        public Statement Build(Verb verb, IStatementable statementable)
        {
            return StatementBuilder.CreateFromProfile(profile, verb, statementable).Build();
        }

        async Task<StatementSendResult> Post(PendingStatement pending)
        {
            StatementSendResult result = await eventSender.SendAsync(pending.Statement, endpoints.XAPIPostAdress, bearerToken);

            if (result.Success)
                Debug.Log($"[xAPI] {pending.Context} -> OK ({result.StatusCode})");
            else
                StatementFailureLog.Report(pending.Context, result);

            StatementSendLog.Raise(pending.Verb, pending.Statement, result);
            return result;
        }
    }
}
