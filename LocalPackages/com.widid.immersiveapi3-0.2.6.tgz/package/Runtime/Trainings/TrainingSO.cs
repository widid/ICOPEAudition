using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings
{
    /// <summary>
    /// A local, editor-authored training (the "Formation" equivalent from the old ImmersiveAPI
    /// system) - distinct from <see cref="Remote.TrainingDTO"/>, which is the backend's catalog
    /// data. A TrainingSO can know about a remote TrainingDTO (e.g. to bind itself to a specific
    /// backend training), never the other way around. Holds a GameFlow (Strategies/Steps), see
    /// TrainingData.GameFlow, tracked at runtime by TrainingRuntime.
    /// </summary>
    [CreateAssetMenu(fileName = "NewTrainingSO", menuName = "Data/Training")]
    public class TrainingSO : ScriptableObject
    {
        // Single source of truth for where these assets live, so TrainingRuntime can find them
        // via Resources.LoadAll with no Inspector wiring - see TrainingEditorWindow, which uses
        // this to derive its own Assets/Resources/... folder path.
        public const string ResourcesFolder = "ImmersiveAPI/Trainings";

        [field: SerializeField] public TrainingData Data { get; private set; } = new TrainingData();
    }
}
