using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TinCan;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking;

namespace WiDiD.ImmersiveAPI.Trainings
{
    /// <summary>
    /// Posts statements strictly one at a time, in the order they were handed over.
    ///
    /// Everything in this runtime sends fire-and-forget from void Unity callbacks, and several
    /// senders are automatic and concurrent by nature (StrategyProgressController and
    /// SimulationProgressController both react to the same step completion, SkillRecorder and
    /// BadgeRecorder to the same score). Left unserialized, those requests race, and a Simulation's
    /// terminated - which has to be the session's last statement - can overtake a progressed that
    /// was raised before it. This queue is what makes "last" mean anything.
    ///
    /// The cost is real and intended: a statement raised while another is still in the air waits
    /// for it, so a burst of sends is spread over consecutive round-trips rather than overlapped.
    /// Correct ordering is worth more here than throughput; nothing in a Training sends at a rate
    /// where that is noticeable.
    ///
    /// TakeWaiting is how the app-teardown path gets the backlog out (see
    /// SimulationTerminationFlusher): whatever is still queued has provably not been posted, so it
    /// can be re-sent through a transport that survives shutdown with no risk of duplicating it.
    /// The one statement that cannot be recovered that way is the one already in flight - it has
    /// been posted, it carries no xAPI id for an LRS to de-duplicate on, and re-posting it would
    /// be as likely to double-count as to save it. InFlightCount reports it so the loss is at
    /// least visible in the log rather than silent.
    /// </summary>
    public class StatementSendQueue
    {
        readonly Queue<PendingStatement> waiting = new Queue<PendingStatement>();
        readonly Func<PendingStatement, Task<StatementSendResult>> post;

        // Held outside the queue while it is being posted, so WaitingCount and TakeWaiting mean
        // strictly "not yet posted" - a statement already in the air must never be handed to the
        // teardown poster.
        PendingStatement inFlight;

        public StatementSendQueue(Func<PendingStatement, Task<StatementSendResult>> post)
        {
            this.post = post;
        }

        public int WaitingCount => waiting.Count;

        /// <summary>Always 0 or 1 - this queue posts one statement at a time by design.</summary>
        public int InFlightCount => inFlight != null ? 1 : 0;

        public Task<StatementSendResult> Enqueue(PendingStatement pending)
        {
            waiting.Enqueue(pending);
            Pump();
            return pending.Completion;
        }

        /// <summary>
        /// Removes every statement that has not been posted yet and hands them back in order.
        /// Their callers' Tasks complete as deferred - not sent by this queue, and now the
        /// teardown path's to deliver.
        /// </summary>
        public List<Statement> TakeWaiting()
        {
            List<Statement> taken = new List<Statement>(waiting.Count);

            while (waiting.Count > 0)
            {
                PendingStatement pending = waiting.Dequeue();
                taken.Add(pending.Statement);
                pending.Complete(StatementSendResult.Deferred($"{pending.Context} was handed to the app-teardown poster instead of being sent normally."));
            }

            return taken;
        }

        // async void rather than a chained Task: nothing awaits the pump itself, and every
        // per-statement outcome is delivered through its own PendingStatement.Completion. Exits
        // only when the queue is empty, so Enqueue never has to know whether a pump is already
        // running - it just calls this and the inFlight guard sorts it out.
        async void Pump()
        {
            if (inFlight != null)
                return;

            try
            {
                while (waiting.Count > 0)
                {
                    inFlight = waiting.Dequeue();
                    StatementSendResult result;

                    try
                    {
                        result = await post(inFlight);
                    }
                    catch (Exception exception)
                    {
                        result = StatementSendResult.Failed($"{inFlight.Context} threw while being posted: {exception.Message}");
                        Debug.LogError($"[xAPI] {result.Message}");
                    }

                    inFlight.Complete(result);
                }
            }
            finally
            {
                inFlight = null;
            }
        }
    }
}
