# GameFlow: code authoring and JSON export

Covers the two Runtime-side tools in this folder:

- **`Building/`** — build a `TrainingGameFlowData` (Strategies and Steps) from code, without the
  nodal graph.
- **`Json/`** — serialize any `TrainingGameFlowData` to the old ImmersiveAPI system's
  `gameflow.json` shape.

Both live in `widid.immersiveapi3.runtime`, so they work in a shipped player, not just the Editor.
Everything else in this folder — `TrainingRuntime`, the progress controllers, the recorders — is
documented in its own XML docs; start with `TrainingRuntime`.

Consuming code needs an assembly definition that references the package explicitly. It will not
resolve from a loose script in `Assembly-CSharp` (see the package README, *Installing alongside an
older ImmersiveAPI*).

## Two authoring paths, one data model

| | Nodal graph (`Editor/Trainings/GameFlow/`) | Builder (`Building/`) |
|---|---|---|
| Runs in | Editor only | Editor and player |
| Authored by | Dragging nodes, saved into the `TrainingSO` asset | Code |
| Node identity | GraphProcessor's `NodeGuid`, `Id` separately editable | `NodeGuid` mirrors `Id` |
| Validation | No structural checks — the graph accepts what you draw | `IGameFlowValidator`, before `Build()` returns |
| Writes | The asset, via `GameFlowGraph.Sync()` | Nothing, until you install it |

Both produce the same `TrainingGameFlowData`, so `TrainingRuntime` cannot tell them apart. Pick the
graph for hand-authored trainings; pick the builder for flows generated from data (a CSV, a backend
payload, a procedural scenario) or for tests.

Terminology: a **Strategy** is what the old ImmersiveAPI system called a *session*. The builder uses
`Strategy` to match `TrainingStrategyData`; the JSON export writes `sessions` to match the legacy
file.

## Quick start

```csharp
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Building;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Json;

GameFlowBuildResult result = GameFlowBuilderService.Create()
    .SimulationPassingScore(0.6f)
    .Strategy("intro", s => s
        .Named("en", "Introduction")
        .Named("fr", "Présentation")
        .PassingScore(0.5f)
        .Step("welcome", st => st.Named("en", "Welcome"))
        .Step("briefing", st => st
            .After("welcome")
            .CompletesStrategy()))
    .Strategy("mission", s => s
        .After("intro")
        .RequirePreviousPassed()
        .CompletesSimulation()
        .Step("act", st => st.CompletesStrategy()))
    .Build();

if (!result)
{
    Debug.LogError(result);   // ToString() lists every issue
    return;
}

foreach (GameFlowBuildIssue warning in result.Warnings)
    Debug.LogWarning(warning);

new GameFlowInstaller().Install(training, result.GameFlow);   // hand it to TrainingRuntime
string json = result.ToJson();                               // or export it
```

Steps are configured inside a callback while `Step()` returns the *strategy* builder, so siblings
chain and there is never a question about which strategy a step belongs to.

## Builder API

`IGameFlowBuilderService` — `GameFlowBuilderService.Create()`, or `Create(IGameFlowValidator)` to
substitute the rules.

| Method | Effect |
|---|---|
| `SimulationPassingScore(float)` | Threshold the average of every completed Strategy is compared against when the Simulation ends. Unset keeps `TrainingGameFlowData`'s own default (`0.5`) |
| `Strategy(string id, Action<IStrategyBuilder>)` | Declares a Strategy. Call once per id — a second call with the same id is an error, not a re-open |
| `Build()` | Assembles, validates, returns a `GameFlowBuildResult` |

`IStrategyBuilder` and `IStepBuilder` share most of their surface:

| Method | Strategy | Step | Effect |
|---|---|---|---|
| `Named(string language, string value)` | ✓ | ✓ | Adds or replaces one language's display name |
| `Named(LanguageDictionary)` | ✓ | ✓ | Replaces the whole dictionary |
| `Described(...)` | ✓ | ✓ | Same two overloads, for the description |
| `After(params string[])` | ✓ | ✓ | Ids that must precede this node |
| `RequirePreviousCompleted(bool = true)` | ✓ | ✓ | Gate on every `After` node being Completed. Default `true` |
| `RequirePreviousPassed(bool = true)` | ✓ | ✓ | Gate on every `After` node having met *its own* `PassingScore`. Default `false` |
| `PassingScore(float)` | ✓ | ✓ | Pass threshold in `[0,1]`. Default `0.5` |
| `CompletesSimulation(bool = true)` | ✓ | | This Strategy's completion ends the Simulation |
| `CompletesStrategy(bool = true)` | | ✓ | This Step's completion ends its Strategy |
| `Step(string id, Action<IStepBuilder>)` | ✓ | | Declares a Step of this Strategy |

Language codes are the six `LanguageDictionary.AvailableLanguages` support: `en`, `fr`, `it`, `es`,
`de`, `pt`. Anything else is a build error rather than a silent drop, since the value would
otherwise vanish before validation could see it.

A node with no `After` is an entry point. `RequirePreviousCompleted`/`RequirePreviousPassed` are
ignored on one, matching `GameFlowUnlockEvaluator`.

### Ids and references

`NodeGuid` is set to the authored `Id`. The graph keeps the two separate because
`StrategyNode.customId` can be renamed behind a `StrategyReference`'s back; a code-authored id is
fixed at its call site, so it is already the stable identity `NodeGuid` needs to be.

The practical consequence: a `StrategyReference`/`StepReference` picked in an Inspector stores a
`NodeGuid`, so it resolves against a code-built flow only if that flow uses the same ids. For a flow
built at runtime, address strategies and steps by their string ids
(`TrainingRuntime.LaunchStep("welcome")`) rather than through the reference pickers.

## Build results

`GameFlowBuildResult` converts implicitly to `bool`, so `if (result)` reads naturally.

| Member | |
|---|---|
| `Succeeded` | False when any issue is an `Error` |
| `GameFlow` | The built flow, or **null** when `Succeeded` is false — a flow that cannot work is never returned half-built |
| `Issues` | Every issue, errors and warnings |
| `Errors` / `Warnings` | Filtered views |
| `ToString()` | All issues, one per line — safe to pass straight to `Debug.LogError` |

Each `GameFlowBuildIssue` carries `Severity`, `Message`, and the `NodeId` it concerns (null for
flow-wide issues).

### Errors

An error means the flow could not work at runtime, so `Build()` returns no `GameFlow`.

| Rule | Why |
|---|---|
| Strategy/step id empty, or declared twice | Ids are the only handle the runtime has |
| Step id reused across strategies | `StepProgressController` keys progress and strategy-ownership by step id **flat across every Strategy**, so two steps sharing one would collapse into a single progress entry |
| Duplicate strategy id | Lookups resolve by id |
| `PassingScore` or `SimulationPassingScore` outside `[0,1]` | Scaled scores are compared against it directly |
| A node lists itself in `After` | Never unlocks |
| `After` names a strategy that is not in the flow | Dangling reference |
| `After` names a step that is not in the *same* Strategy | A step's unlock is only ever evaluated against its own Strategy's steps |
| A `Previous` cycle among strategies, or among a Strategy's steps | Nothing in the cycle ever unlocks |
| No entry point — every strategy, or every step of a strategy, has an `After` | Nothing ever unlocks |
| A Strategy declares no step | Strategies are step-driven, so it could never complete |
| The flow declares no strategy | Nothing to run |
| An unsupported language code | The value would be dropped silently |

### Warnings

A warning means the flow is usable but probably not what you meant. `Build()` still returns it.

| Rule | Consequence |
|---|---|
| No step in a Strategy is marked `CompletesStrategy` | That Strategy never auto-completes, so nothing downstream of it unlocks |
| No Strategy is marked `CompletesSimulation` | The Simulation never ends and sends no Passed/Failed/Completed |
| `CompletesStrategy` on a step another step lists in `After` | Never fires — only a leaf triggers completion |
| `CompletesSimulation` on a Strategy another Strategy lists in `After` | Same, one level up |

The two "never fires" rules come from `StrategyProgressController.EndsStrategy` and
`SimulationProgressController`, where the leaf check is part of the trigger.

## Installing into a Training

```csharp
GameFlowCheck installed = new GameFlowInstaller().Install(training, result.GameFlow);
if (!installed)
    Debug.LogError(installed.Reason);
```

`Install` mutates the loaded `TrainingSO` in memory and never writes the asset, so it behaves
identically in a player and in the Editor. It replaces `Strategies` and `SimulationPassingScore`
only — the same fields `GameFlowGraph.Sync()` owns.

Each Strategy's and Step's existing `Performances`, and each Step's `Interactions`, are **carried
forward by id** from whatever was already on the Training. The builder authors structure only, so
without that carry-forward, installing would silently wipe everything the Performance and
Interaction editor windows own. Top-level `Performances`, `Skills`, `Badges` and `Rewards` are left
untouched.

Install **before the session starts**. It is rejected once `TrainingRuntime.IsReady`, because the
progress controllers are configured once against the flow they find, and swapping it underneath them
would desync their progress dictionaries.

## JSON export

```csharp
string json    = result.ToJson();                      // null if the build failed
string json    = training.Data.GameFlow.ToJson();      // straight off any flow
string compact = gameFlow.ToJson(indented: false);
```

`ToJson` is sugar over `IGameFlowJsonExporter`; inject that instead when the exporter needs to be
substituted. It also offers `ToDto()`, which returns the `GameFlowJsonRoot` object graph for
embedding in a larger payload rather than serializing straight to a string.

Output is byte-identical to what the Editor's graph exporter produced, which is what the Inspector
preview and **Save JSON...** on a `TrainingSO` now use:

```json
{
  "sessions": [
    {
      "current": "intro",
      "previous": [],
      "name": {
        "en": "Introduction",
        "fr": "Présentation"
      },
      "steps": [
        {
          "current": "welcome",
          "previous": [],
          "name": {
            "en": "Welcome"
          },
          "succeeded": false,
          "score": 0.0,
          "highscore": 0.0
        },
        {
          "current": "briefing",
          "previous": [
            "welcome"
          ],
          "name": {
            "en": "Briefing"
          },
          "succeeded": false,
          "score": 0.0,
          "highscore": 0.0
        }
      ]
    }
  ]
}
```

Writing it to disk is the caller's job — the exporter only returns a string:

```csharp
File.WriteAllText(Path.Combine(Application.persistentDataPath, "gameflow.json"), json);
```

### What the export does not carry

This is a **handoff format for tools that consume the old `gameflow.json`, not a round-trip of an
authored flow.** The legacy shape has nowhere to put most of what a Strategy or Step holds, so the
export drops it:

- `SimulationPassingScore`, `PassingScore`
- `Description`
- `RequireAllPreviousCompleted`, `RequireAllPreviousPassed`
- `CompleteSimulation`, `TriggersStrategyCompletion`
- `Performances`, `Interactions`, and the flow's `Skills`/`Badges`/`Rewards`
- `NodeGuid`

Saving and reloading a built flow needs a separate serializer over `TrainingGameFlowData` itself.

`succeeded`, `score` and `highscore` are always `false`/`0`/`0`. This system does not persist
progress this way — `TrainingNodeProgress` is in-memory only — and keeping the export derived from
the authored flow alone makes it reproducible. Exporting a real play-through's progress would mean
passing `StepProgressController`'s state in, which is deliberately not wired up.

## Extending

- **Performances and Interactions** are not authorable from the builder; they stay owned by their
  editor windows and survive install. Adding `.Performance(...)`/`.Interaction(...)` to
  `IStepBuilder` is the natural next increment.
- **Custom rules**: implement `IGameFlowValidator` and pass it to
  `GameFlowBuilderService.Create(validator)`. `GameFlowValidator` is the default; validation is
  deliberately separate from the builders so the same rules can be run against a graph-authored
  flow too.
- **`NodeCycleDetector`** and **`LocalizedTextFactory`** are public and reusable — cycle detection
  over any id-to-previous map, and add-or-replace on a `LanguageDictionary` keyed by language code
  (`LanguageDictionary.TryAddLanguage` refuses to overwrite an existing entry).
