using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Automatically sends a Received Badge statement for each of a Simulation's badge slots (see
    /// TrainingGameFlowData.Badges/xAPI-Statements/Badge/README.md) the moment its own
    /// UnlockCondition first evaluates true - checked every frame via BadgeConditionTicker.Tick(),
    /// since a condition's reflected values can change at any time with no lifecycle event to
    /// piggyback on (unlike Performance/Strategy/Step). Each slot fires at most once, and never for a
    /// slot already received in a previous session (see RestoreProgress).
    /// </summary>
    public class BadgeRecorder
    {
        readonly IStatementSender sender;
        readonly HashSet<int> receivedSlots = new();

        List<TrainingBadgeData> badges;
        Simulation simulation;

        public BadgeRecorder(IStatementSender sender)
        {
            this.sender = sender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            badges = gameFlow.Badges;
            this.simulation = simulation;
        }

        /// <summary>TEMPORARY-STORED-PROGRESS: Marks slots already received as such so they never fire again. Returns how many were found.</summary>
        public int RestoreProgress(IStoredProgress progress)
        {
            int restored = 0;

            for (int i = 0; i < badges.Count; i++)
            {
                if (progress.HasReceivedBadge(i + 1) && receivedSlots.Add(i + 1))
                    restored++;
            }

            return restored;
        }

        public void Tick()
        {
            if (badges == null || receivedSlots.Count >= badges.Count)
                return;

            for (int i = 0; i < badges.Count; i++)
            {
                int slotNumber = i + 1;
                if (receivedSlots.Contains(slotNumber))
                    continue;

                if (badges[i].UnlockCondition.Evaluate() != true)
                    continue;

                receivedSlots.Add(slotNumber);
                SendReceived(slotNumber, badges[i]);
            }
        }

        async void SendReceived(int slotNumber, TrainingBadgeData data)
        {
            try
            {
                await sender.Send(Verbs.Received, BadgeStatementFactory.Received(simulation, data, slotNumber));
            }
            catch (Exception exception)
            {
                Debug.LogError($"[BadgeRecorder] Failed to record badge slot #{slotNumber}: {exception}");
            }
        }
    }
}
