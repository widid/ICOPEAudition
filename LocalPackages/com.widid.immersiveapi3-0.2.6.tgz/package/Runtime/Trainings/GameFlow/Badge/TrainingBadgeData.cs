using System;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one of a Simulation's (up to three) badge slots (see
    /// xAPI-Statements/Badge/README.md) - living in TrainingGameFlowData.Badges. Unlike Performance/
    /// Skill/Interaction, there's no authored Id: a Badge's xAPI id is just its 1-based position in
    /// that list (see BadgeStatementFactory.Received), matching the spec's "ids are from left to
    /// right: 1, 2, 3". UnlockCondition is checked continuously at runtime by BadgeRecorder - the
    /// moment it evaluates true, the Received statement fires automatically (see ConditionChain);
    /// leaving it empty means this slot never triggers on its own.
    /// </summary>
    [Serializable]
    public class TrainingBadgeData
    {
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public ConditionChain UnlockCondition { get; set; } = new ConditionChain();
    }
}
