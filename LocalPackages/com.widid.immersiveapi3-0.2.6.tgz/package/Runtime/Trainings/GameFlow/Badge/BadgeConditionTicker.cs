using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// The one unavoidable MonoBehaviour behind Badge's automatic triggering - Unity's engine loop
    /// has no pure-C# per-frame hook, so this exists purely to forward Update() into
    /// BadgeRecorder.Tick(), which owns all the actual condition-evaluation/sending logic.
    /// TrainingRuntime creates and owns the single instance of this at runtime (see
    /// HandleSessionReady) - never placed in a scene manually.
    /// </summary>
    class BadgeConditionTicker : MonoBehaviour
    {
        public BadgeRecorder Recorder { get; set; }

        void Update() => Recorder?.Tick();
    }
}
