using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the single xAPI Badge statementable Badge supports - verb `received`, no lifecycle,
    /// no result (see xAPI-Statements/Badge/README.md). slotNumber is the Badge's 1-based position
    /// among TrainingGameFlowData.Badges (see TrainingBadgeData), which becomes its Id/Uri tail
    /// directly, matching the spec's "ids are from left to right: 1, 2, 3". parentCourse is always
    /// null here - there's no Course concept anywhere else in ImmersiveAPI yet.
    /// </summary>
    public static class BadgeStatementFactory
    {
        public static Badge Received(Simulation simulation, TrainingBadgeData data, int slotNumber)
        {
            return new Badge(slotNumber.ToString(), data.Name, data.Description, simulation, parentCourse: null);
        }
    }
}
