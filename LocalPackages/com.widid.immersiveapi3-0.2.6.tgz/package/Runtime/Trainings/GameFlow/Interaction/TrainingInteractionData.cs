using System;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one Interaction a Step can send (see xAPI-Statements/Interaction/README.md) -
    /// always Step-scoped, living in TrainingStepData.Interactions. Score/Response are authored the
    /// same way as Performance's - fixed constant or live reflected source, float for Scaled (see
    /// PerformanceValueSource/ReflectedFloatSourceSO), int for Raw/Min/Max (see
    /// PerformanceIntValueSource/ReflectedIntSourceSO, matching xAPI's int-only Score.raw/min/max) -
    /// resolved at trigger time by InteractionStatementFactory. Severity/duration stay out of this -
    /// those are inherently one-off decisions from host game code, supplied directly to
    /// TrainingRuntime.SendInteraction instead. Success can be authored the same way
    /// via SuccessCondition (see ConditionChain) - if it has at least one entry, its evaluated
    /// result wins over whatever the caller passed at trigger time; otherwise the caller's value is
    /// used as before (see InteractionStatementFactory.New).
    /// </summary>
    [Serializable]
    public class TrainingInteractionData
    {
        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public InteractionKind Kind { get; set; } = InteractionKind.AnsweredQuestion;

        // Key into InteractionTypes.All (a TinCan.InteractionType field name, e.g. "LongFillIn") -
        // not the raw wire string, so the editor dropdown and InteractionStatementFactory both
        // resolve through the same registry.
        [field: SerializeField] public string InteractionTypeKey { get; set; } = "Other";

        [field: SerializeField] public PerformanceValueSource Scaled { get; set; } = new PerformanceValueSource();
        [field: SerializeField] public PerformanceIntValueSource Raw { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Min { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Max { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceStringValueSource Response { get; set; } = new PerformanceStringValueSource();
        [field: SerializeField] public ConditionChain SuccessCondition { get; set; } = new ConditionChain();
    }
}
