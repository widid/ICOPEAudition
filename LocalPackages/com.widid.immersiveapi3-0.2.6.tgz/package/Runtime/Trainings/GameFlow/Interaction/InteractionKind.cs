namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    // Which of the two Interaction statements (see xAPI-Statements/Interaction/README.md) a
    // TrainingInteractionData represents - adding a third kind later means adding a value here plus
    // a matching case in InteractionStatementFactory/InteractionRecorder/InteractionEditorWindow,
    // the same small diff shape Performance/Skill's own scope extensions already went through.
    public enum InteractionKind
    {
        AnsweredQuestion,
        InteractedInteraction
    }
}
