using System;
using System.Linq;
using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Developer-triggered sender for a Training's authored Interactions (see
    /// TrainingInteractionData) - nothing here fires automatically: host game code decides exactly
    /// when a question was answered or an interaction happened (see
    /// TrainingRuntime.SendInteraction). Only an interactionId is needed - Interaction Ids are
    /// unique across the whole Training (see DuplicateIdFinder/InteractionEditorWindow), so its
    /// owning Step/Strategy is found from that alone, no separate Step id/reference required.
    ///
    /// One Send method covers both Interaction statements, dispatching on the entry's own authored
    /// TrainingInteractionData.Kind rather than on which method the caller picked - the kind is
    /// authored data, so letting a call disagree with it could only ever send the wrong verb for
    /// what the Training declares.
    /// </summary>
    public class InteractionRecorder
    {
        readonly IStatementSender sender;

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        public InteractionRecorder(IStatementSender sender)
        {
            this.sender = sender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
        }

        /// <summary>
        /// Sends whichever of the two Interaction statements this entry is authored as. Duration
        /// only applies to an InteractedInteraction - an AnsweredQuestion carries no duration at
        /// all (see InteractionStatementFactory), so it is ignored for those.
        /// </summary>
        public async Task<StatementSendResult> Send(string interactionId, bool? success = null, TimeSpan? duration = null, SeverityLevel? severity = null)
        {
            if (!TryGet(interactionId, out TrainingStrategyData owningStrategy, out TrainingStepData step, out TrainingInteractionData interaction, out StatementSendResult error))
                return error;

            Strategy parentStrategy = StrategyStatementFactory.New(simulation, owningStrategy);
            Step parentStep = StepStatementFactory.New(simulation, parentStrategy, step);

            if (interaction.Kind == InteractionKind.AnsweredQuestion)
                return await sender.Send(Verbs.Answered, InteractionStatementFactory.AnsweredQuestion(simulation, parentStrategy, parentStep, interaction, success, severity));

            return await sender.Send(Verbs.Interacted, InteractionStatementFactory.InteractedInteraction(simulation, parentStrategy, parentStep, interaction, success, duration, severity));
        }

        bool TryGet(string interactionId, out TrainingStrategyData owningStrategy, out TrainingStepData step, out TrainingInteractionData interaction, out StatementSendResult error)
        {
            owningStrategy = null;
            step = null;
            interaction = null;
            error = null;

            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
            {
                foreach (TrainingStepData candidateStep in strategy.Steps)
                {
                    TrainingInteractionData match = candidateStep.Interactions.FirstOrDefault(i => i.Id == interactionId);
                    if (match == null)
                        continue;

                    owningStrategy = strategy;
                    step = candidateStep;
                    interaction = match;
                    return true;
                }
            }

            error = StatementSendResult.Rejection($"Unknown interaction '{interactionId}'.");
            return false;
        }
    }
}
