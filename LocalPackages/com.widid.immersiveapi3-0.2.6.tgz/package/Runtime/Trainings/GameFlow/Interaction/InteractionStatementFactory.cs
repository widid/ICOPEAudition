using System;
using TinCan;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    using Interaction = WiDiD.XAPI.Statementables.Interaction;

    /// <summary>
    /// Builds the two xAPI Interaction statementables Interaction supports (see
    /// xAPI-Statements/Interaction/README.md) - `answered` for a graded question (carries
    /// response/score/success) and `interacted` for any other tracked interaction (carries
    /// score/success/duration). Both are entirely developer-triggered (see InteractionRecorder/
    /// TrainingRuntime.SendInteraction), but Score/Response are read from
    /// TrainingInteractionData itself - fixed constant or live reflected source, same as
    /// PerformanceStatementFactory (float for Scaled, int for Raw/Min/Max, matching xAPI's
    /// Score.raw/min/max). Success works the same way if authored (data.SuccessCondition has at
    /// least one entry) - its evaluated result wins; otherwise the caller-supplied success param is
    /// used as before. severity/duration stay caller-supplied either way.
    /// </summary>
    public static class InteractionStatementFactory
    {
        public static Interaction AnsweredQuestion(Simulation simulation, Strategy parentStrategy, Step parentStep, TrainingInteractionData data, bool? success = null, SeverityLevel? severity = null)
        {
            Interaction interaction = New(simulation, parentStrategy, parentStep, data, success);
            ApplySeverity(interaction, severity);
            return interaction;
        }

        public static Interaction InteractedInteraction(Simulation simulation, Strategy parentStrategy, Step parentStep, TrainingInteractionData data, bool? success = null, TimeSpan? duration = null, SeverityLevel? severity = null)
        {
            Interaction interaction = New(simulation, parentStrategy, parentStep, data, success);
            interaction.Duration = duration;
            ApplySeverity(interaction, severity);
            return interaction;
        }

        static void ApplySeverity(Interaction interaction, SeverityLevel? severity)
        {
            if (severity.HasValue)
                interaction.Extensions = ExtensionsBuilder.Create().WithExtension(ExtensionsLibrary.Severity, severity.Value).Build();
        }

        static Interaction New(Simulation simulation, Strategy parentStrategy, Step parentStep, TrainingInteractionData data, bool? callerSuccess)
        {
            InteractionType interactionType = InteractionTypes.All.TryGetValue(data.InteractionTypeKey, out InteractionType type) ? type : InteractionType.Other;
            Interaction interaction = new(data.Id, data.Name, data.Description, parentStep, interactionType, parentStrategy: parentStrategy, parentSimulation: simulation);

            interaction.Score = data.Scaled.Resolve();
            interaction.ScoreRaw = data.Raw.Resolve();
            interaction.MinScoreRaw = data.Min.Resolve();
            interaction.MaxScoreRaw = data.Max.Resolve();
            interaction.Response = data.Response.Resolve();
            interaction.Succeeded = data.SuccessCondition.Evaluate() ?? callerSuccess;

            return interaction;
        }
    }
}
