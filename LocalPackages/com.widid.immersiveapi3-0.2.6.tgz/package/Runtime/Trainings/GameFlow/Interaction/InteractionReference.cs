using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick an Interaction by name (via
    /// InteractionReferenceDrawer, Editor-only) instead of hand-typing its raw GUID id. Resolves to
    /// that id at runtime for TrainingRuntime.SendInteraction.
    /// </summary>
    [Serializable]
    public class InteractionReference
    {
        [SerializeField] private string interactionId = string.Empty;
        public string InteractionId => interactionId;
    }
}
