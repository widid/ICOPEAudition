using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick a strategy by name (via
    /// StrategyReferenceDrawer, Editor-only) instead of hand-typing its raw id. Stores the
    /// strategy's stable GraphProcessor NodeGuid rather than its authored Id (see
    /// TrainingStrategyData.NodeGuid/StrategyNode.customId) - the Id can be edited after this
    /// reference is set, so resolving by NodeGuid (via TrainingRuntime, which does the actual
    /// NodeGuid -> current Id lookup) keeps this reference pointing at the right strategy even
    /// across a rename, instead of silently going stale.
    /// </summary>
    [Serializable]
    public class StrategyReference
    {
        [SerializeField] private string strategyNodeGuid = string.Empty;
        public string StrategyNodeGuid => strategyNodeGuid;
    }
}
