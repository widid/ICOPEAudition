using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one strategy (xAPI Strategy - a "session" in the old ImmersiveAPI system's
    /// terms, renamed to match the actual xAPI vocabulary this maps to), authored via the nodal
    /// strategy-graph editor. Steps are nested directly inside their owning strategy, matching the
    /// old ImmersiveAPI system's Formation/Session/Step parenting.
    /// </summary>
    [Serializable]
    public class TrainingStrategyData
    {
        // GraphProcessor's own BaseNode.GUID - stable for the node's whole lifetime, unlike Id
        // below (which defaults to this same value but can be overridden). Purely an internal
        // correlation key so GameFlowGraph.Sync() can still find "this same node's previous data"
        // to carry forward (e.g. Performances) even after Id has been edited to something else -
        // never shown in any UI, never used for xAPI/statement purposes.
        [field: SerializeField] public string NodeGuid { get; set; } = string.Empty;

        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public List<string> Previous { get; set; } = new List<string>();
        [field: SerializeField] public List<TrainingStepData> Steps { get; set; } = new List<TrainingStepData>();

        // Unlock conditions, evaluated against Previous strategies' runtime progress - see
        // TrainingRuntime. Both default to "no extra requirement" so a strategy with no Previous is
        // always unlocked, matching the old ImmersiveAPI system's default behavior.
        // RequireAllPreviousPassed gates on each Previous strategy's own Score having met that
        // strategy's own PassingScore (TrainingNodeProgress.Passed), not just Completed.
        [field: SerializeField] public bool RequireAllPreviousCompleted { get; set; } = true;
        [field: SerializeField] public bool RequireAllPreviousPassed { get; set; } = false;

        // Threshold the average of this strategy's completed steps' scores is compared against
        // once every step is done, to decide whether StrategyProgressController auto-sends a
        // Passed or Failed statement for the strategy - see StrategyProgressController.
        [field: SerializeField] public float PassingScore { get; set; } = 0.5f;

        // Only meaningful on a strategy with no Next connection (nothing else in the GameFlow lists
        // it as Previous) - same "leaf + toggle" shape as TrainingStepData.TriggersStrategyCompletion,
        // one level up. When this strategy Completes, SimulationProgressController ends the whole
        // Simulation: a final Progressed(1) is sent, then the average score of every completed
        // Strategy decides Passed_Simulation vs Failed_Simulation.
        [field: SerializeField] public bool CompleteSimulation { get; set; } = false;

        // Performances scoped to this Strategy (see TrainingPerformanceData/PerformanceEditorWindow).
        // Unlike every field above, this has no matching representation on StrategyNode, so
        // GameFlowGraph.Sync() must carry it forward by Id when it rebuilds this object from the
        // graph, or it would be silently wiped on the next graph edit.
        [field: SerializeField] public List<TrainingPerformanceData> Performances { get; set; } = new List<TrainingPerformanceData>();
    }
}
