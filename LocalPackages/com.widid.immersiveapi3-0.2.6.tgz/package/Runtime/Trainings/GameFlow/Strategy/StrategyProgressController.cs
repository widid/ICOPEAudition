using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Owns strategy-level progress/unlock state. Launch's own precondition lives in CanLaunch,
    /// which TrainingRuntime.CanLaunchStrategy exposes verbatim, so host game code can ask whether
    /// a strategy is startable instead of learning the rule from a rejected call.
    /// Only Launched/Exited are developer-driven -
    /// Progressed, Passed/Failed and Completed are automatic, recomputed from the owning
    /// StepProgressController every time one of the strategy's steps completes (see
    /// HandleStepCompleted): Progressed = completed step count / total step count, sent on every
    /// step completion. The strategy itself doesn't need every step done to finish - it ends the
    /// moment a completed step both has no Next connection (nothing else in the strategy lists it
    /// as Previous) and has TrainingStepData.TriggersStrategyCompletion set. At that point the
    /// average score of the strategy's completed steps is compared against
    /// TrainingStrategyData.PassingScore to decide Passed vs Failed (falling back to 1/0 when no
    /// step actually recorded a score, so Failed/Passed always carries a real scaled score rather
    /// than sometimes reporting 0 for what was just called a pass), then Completed is sent with
    /// that same score. Only Completed marks the strategy Completed and re-evaluates strategy
    /// unlocks. Every statement but Launched also carries a duration: elapsed wall-clock time since
    /// this strategy's own Launched (see DurationSinceLaunched/TrainingNodeProgress.LaunchedAt).
    ///
    /// Note: a strategy with no step marked TriggersStrategyCompletion has nothing to trigger this
    /// and will never auto-complete - not handled yet, revisit if that turns out to be a real
    /// authoring case.
    /// </summary>
    public class StrategyProgressController
    {
        // Fired once a strategy actually finishes (see AutomateStrategy) - lets
        // SimulationProgressController aggregate Simulation-level progress the same way it does for
        // Step-scoped completions via StepProgressController.StepCompleted.
        public event Action<TrainingStrategyData> Completed;

        public TrainingStrategyData Current { get; private set; }

        readonly Dictionary<string, TrainingNodeProgress> progress = new();

        // Steps completed since each strategy's last Launch. An open attempt is automated even when
        // the strategy was already completed (this session or a restored one), so a replay sends its
        // own Progressed/Passed-or-Failed/Completed and is scored on the replayed steps only.
        readonly Dictionary<string, HashSet<string>> attempts = new();
        readonly IStatementSender sender;
        readonly StepProgressController steps;

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        public StrategyProgressController(IStatementSender sender, StepProgressController steps)
        {
            this.sender = sender;
            this.steps = steps;
            steps.StepCompleted += HandleStepCompleted;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
            Current = null;

            progress.Clear();
            attempts.Clear();
            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
                progress[strategy.Id] = new TrainingNodeProgress { PassingScore = strategy.PassingScore };

            RecomputeUnlocks();
        }

        public bool IsUnlocked(string strategyId) => progress.TryGetValue(strategyId, out TrainingNodeProgress nodeProgress) && nodeProgress.Unlocked;
        public bool IsCompleted(string strategyId) => progress.TryGetValue(strategyId, out TrainingNodeProgress nodeProgress) && nodeProgress.Completed;
        public float? GetScore(string strategyId) => progress.TryGetValue(strategyId, out TrainingNodeProgress nodeProgress) ? nodeProgress.Score : null;
        public float? GetBestScore(string strategyId) => progress.TryGetValue(strategyId, out TrainingNodeProgress nodeProgress) ? nodeProgress.BestScore : null;

        /// <summary>
        /// Every precondition Launch enforces, as a question rather than a rejection. Single source
        /// of truth - Launch itself calls this rather than repeating the rules.
        /// </summary>
        public GameFlowCheck CanLaunch(string strategyId)
        {
            if (!progress.ContainsKey(strategyId))
                return GameFlowCheck.No($"Unknown strategy '{strategyId}'.");

            if (!progress[strategyId].Unlocked)
                return GameFlowCheck.No($"Strategy '{strategyId}' is locked.");

            return GameFlowCheck.Ok();
        }

        public async Task<StatementSendResult> Launch(string strategyId)
        {
            if (!TryGet(strategyId, out TrainingStrategyData strategy, out StatementSendResult error))
                return error;

            GameFlowCheck check = CanLaunch(strategyId);
            if (!check)
                return StatementSendResult.Rejection(check.Reason);

            Current = strategy;
            progress[strategyId].LaunchedAt = DateTime.UtcNow;
            attempts[strategyId] = new HashSet<string>();

            return await sender.Send(Verbs.Launched, StrategyStatementFactory.Launched(simulation, strategy));
        }

        public async Task<StatementSendResult> Exit(string strategyId)
        {
            if (!TryGet(strategyId, out TrainingStrategyData strategy, out StatementSendResult error))
                return error;

            return await sender.Send(Verbs.Exited, StrategyStatementFactory.Exited(simulation, strategy, DurationSinceLaunched(strategyId)));
        }

        async void HandleStepCompleted(TrainingStrategyData owningStrategy, TrainingStepData completedStep)
        {
            try
            {
                await AutomateStrategy(owningStrategy, completedStep);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[StrategyProgressController] Failed to automate strategy '{owningStrategy.Id}' after step '{completedStep.Id}' completed: {exception}");
            }
        }

        async Task AutomateStrategy(TrainingStrategyData strategy, TrainingStepData completedStep)
        {
            bool inAttempt = attempts.TryGetValue(strategy.Id, out HashSet<string> attemptSteps);

            if (inAttempt)
                attemptSteps.Add(completedStep.Id);
            else if (progress[strategy.Id].Completed)
                return; // Already finished and not relaunched - nothing left to automate.

            int totalSteps = strategy.Steps.Count;
            int completedSteps = inAttempt ? attemptSteps.Count : strategy.Steps.Count(step => steps.IsCompleted(step.Id));
            float progressFraction = totalSteps == 0 ? 0f : (float)completedSteps / totalSteps;

            await sender.Send(Verbs.Progressed, StrategyStatementFactory.Progressed(simulation, strategy, progressFraction, DurationSinceLaunched(strategy.Id)));

            if (!EndsStrategy(strategy, completedStep))
                return;

            attempts.Remove(strategy.Id);

            float resolvedScore = ResolveCompletionScore(strategy, inAttempt ? attemptSteps : null);
            bool passed = resolvedScore >= strategy.PassingScore;

            TimeSpan? duration = DurationSinceLaunched(strategy.Id);

            await sender.Send(passed ? Verbs.Passed : Verbs.Failed, passed
                ? StrategyStatementFactory.Passed(simulation, strategy, resolvedScore, duration)
                : StrategyStatementFactory.Failed(simulation, strategy, resolvedScore, duration));

            progress[strategy.Id].Completed = true;
            progress[strategy.Id].RecordScore(resolvedScore);
            RecomputeUnlocks();

            await sender.Send(Verbs.Completed, StrategyStatementFactory.Completed(simulation, strategy, resolvedScore, duration));
            Completed?.Invoke(strategy);
        }

        /// <summary>
        /// TEMPORARY-STORED-PROGRESS.
        /// Recomputes strategy-level state from the step progress that was just restored (see
        /// StepProgressController.RestoreProgress), applying the same rules AutomateStrategy would
        /// have: a strategy counts as completed once its own ending step is completed, scored by
        /// the average of its completed steps. Local state only - no statement is sent, and
        /// Completed deliberately does not fire.
        /// </summary>
        public void RestoreProgress()
        {
            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
            {
                if (!strategy.Steps.Any(step => steps.IsCompleted(step.Id) && EndsStrategy(strategy, step)))
                    continue;

                progress[strategy.Id].Completed = true;
                progress[strategy.Id].RecordScore(ResolveCompletionScore(strategy, null));
            }

            RecomputeUnlocks();
        }

        // Average of every completed step's recorded score. No step recorded a score at all (e.g.
        // every step in this strategy was completed without one) - falls back to 1/0 based on the
        // pass/fail decision itself (made using 0 as a neutral placeholder) rather than always
        // reporting 0, which would contradict a statement that just said "Passed".
        // Restricted to attemptSteps when given, so a replay is scored on what was replayed.
        float ResolveCompletionScore(TrainingStrategyData strategy, HashSet<string> attemptSteps)
        {
            float[] scores = strategy.Steps
                .Where(step => attemptSteps?.Contains(step.Id) ?? steps.IsCompleted(step.Id))
                .Select(step => steps.GetScore(step.Id))
                .Where(score => score.HasValue)
                .Select(score => score.Value)
                .ToArray();

            if (scores.Length > 0)
                return scores.Average();

            return 0f >= strategy.PassingScore ? 1f : 0f;
        }

        // The completed step ends its strategy if it has no Next connection (nothing else in the
        // strategy lists it as Previous) and was authored to trigger completion.
        static bool EndsStrategy(TrainingStrategyData strategy, TrainingStepData completedStep)
        {
            if (!completedStep.TriggersStrategyCompletion)
                return false;

            return !strategy.Steps.Any(step => step.Previous.Contains(completedStep.Id));
        }

        TimeSpan? DurationSinceLaunched(string strategyId) => progress[strategyId].LaunchedAt.HasValue ? DateTime.UtcNow - progress[strategyId].LaunchedAt.Value : null;

        bool TryGet(string strategyId, out TrainingStrategyData strategy, out StatementSendResult error)
        {
            strategy = gameFlow.Strategies.FirstOrDefault(s => s.Id == strategyId);
            error = strategy == null ? StatementSendResult.Rejection($"Unknown strategy '{strategyId}'.") : null;
            return strategy != null;
        }

        void RecomputeUnlocks()
        {
            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
                progress[strategy.Id].Unlocked = GameFlowUnlockEvaluator.Evaluate(strategy.Previous, strategy.RequireAllPreviousCompleted, strategy.RequireAllPreviousPassed, progress);
        }
    }
}
