using System;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the six xAPI Strategy statementables used to track a strategy's lifecycle. Every verb
    /// but Launched takes a duration (elapsed time since this strategy's own Launched - see
    /// StrategyProgressController, which tracks that per strategy). Failed/Passed always carry a
    /// scaled score - callers resolve their own default (0/1) before calling, so this always
    /// reports a real number rather than sometimes omitting result.score entirely. Otherwise each
    /// method only sets the Result properties that verb is actually reporting (e.g. Completed only
    /// sets Completed) rather than redundantly restating state already covered by a separate
    /// statement.
    /// </summary>
    public static class StrategyStatementFactory
    {
        public static Strategy Launched(Simulation simulation, TrainingStrategyData data) => New(simulation, data);

        public static Strategy Progressed(Simulation simulation, TrainingStrategyData data, float progress, TimeSpan? duration = null)
        {
            Strategy strategy = New(simulation, data);
            strategy.Score = progress;
            strategy.Duration = duration;
            return strategy;
        }

        public static Strategy Failed(Simulation simulation, TrainingStrategyData data, float score, TimeSpan? duration = null)
        {
            Strategy strategy = New(simulation, data);
            strategy.Succeeded = false;
            strategy.Score = score;
            strategy.Duration = duration;
            return strategy;
        }

        public static Strategy Passed(Simulation simulation, TrainingStrategyData data, float score, TimeSpan? duration = null)
        {
            Strategy strategy = New(simulation, data);
            strategy.Succeeded = true;
            strategy.Score = score;
            strategy.Duration = duration;
            return strategy;
        }

        public static Strategy Completed(Simulation simulation, TrainingStrategyData data, float? score = null, TimeSpan? duration = null)
        {
            Strategy strategy = New(simulation, data);
            strategy.Completed = true;
            strategy.Score = score;
            strategy.Duration = duration;
            return strategy;
        }

        public static Strategy Exited(Simulation simulation, TrainingStrategyData data, TimeSpan? duration = null)
        {
            Strategy strategy = New(simulation, data);
            strategy.Duration = duration;
            return strategy;
        }

        // Internal (not private): StepProgressController also needs a bare parent Strategy
        // reference when building Step statementables, without that itself constituting a
        // "Launched" event.
        internal static Strategy New(Simulation simulation, TrainingStrategyData data) => new(data.Id, data.Name, data.Description, simulation);
    }
}
