#if UNITY_EDITOR
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Starts TrainingRuntime in Editor play mode from the UserSessionSO filled by the Debug Session
    /// window and the Training Editor's "Set Active", since SessionGate skips validation in the Editor.
    /// </summary>
    public static class EditorSessionBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Initialize()
        {
            UserSessionSO session = Resources.Load<UserSessionSO>(UserSessionSO.ResourcePath);
            if (session == null || string.IsNullOrEmpty(session.Data.DecodedToken))
            {
                Debug.LogWarning("[EditorSessionBootstrap] No debug session found: sign in via WiDiD_API > ImmersiveAPI > Debug Session.");
                return;
            }

            TrainingRuntime.HandleSessionReady(session);
        }
    }
}
#endif
