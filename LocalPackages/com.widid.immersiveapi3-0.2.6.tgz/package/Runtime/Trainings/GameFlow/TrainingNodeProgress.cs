using System;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Runtime-only progress for one strategy or step (this play-through) - strategies and steps
    /// track exactly the same things, so one shared shape covers both rather than two
    /// near-duplicate classes. Never serialized; rebuilt fresh by TrainingRuntime each time the
    /// app initializes. Distinct from TrainingStrategyData/TrainingStepData, which are the
    /// authored, unchanging structure (name/topology/unlock conditions) - PassingScore is copied
    /// from there once at configure time purely so Passed can be computed without a second lookup.
    /// </summary>
    public class TrainingNodeProgress
    {
        public bool Unlocked { get; set; }
        public bool Completed { get; set; }
        public float? Score { get; set; }

        /// <summary>Highest Score ever recorded for this node, restored progress included (see RecordScore).</summary>
        public float? BestScore { get; private set; }

        public float PassingScore { get; set; }

        // Set the moment Launched is sent - every other statement for this node (Progressed/Failed/
        // Passed/Completed/Exited) reports elapsed wall-clock time since then as its own duration
        // (see StepProgressController/StrategyProgressController). DateTime.UtcNow, not Time.time,
        // so it keeps counting through any pause/background time regardless of timeScale - same
        // reasoning as TrainingRuntime's own Simulation duration tracking.
        public DateTime? LaunchedAt { get; set; }

        /// <summary>Whether this node's own recorded Score met its own PassingScore - used by GameFlowUnlockEvaluator's RequireAllPreviousPassed check.</summary>
        public bool Passed => Completed && Score.HasValue && Score.Value >= PassingScore;

        /// <summary>Sets Score and raises BestScore when the new score beats it.</summary>
        public void RecordScore(float score)
        {
            Score = score;

            if (!BestScore.HasValue || score > BestScore.Value)
                BestScore = score;
        }
    }
}
