using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Subscribes SimulationTerminationFlusher to whatever this platform actually offers as "the
    /// app is ending". The one place in the termination path that branches per platform, because
    /// the signals genuinely have nothing in common - the flusher below it stays platform-free.
    ///
    /// Standalone and the Editor get Application.quitting, which is raised after the last frame
    /// and is enough here only because the flusher posts over blocking sockets rather than
    /// UnityWebRequest (see BlockingShutdownStatementPoster). The Editor is included on purpose,
    /// unlike before: exiting Play mode now sends Terminated_Simulation just as a built player
    /// would, which is the only way to exercise this path without producing a build. It stays
    /// harmless when no session was ever confirmed, since TrainingRuntime only installs these
    /// hooks once one was.
    ///
    /// Android and iOS also get OnApplicationPause, and terminate on it. The OS can kill a
    /// backgrounded app without ever raising Application.quitting, so waiting for a quit that may
    /// not come would routinely lose the statement outright. The cost of that choice is real and
    /// worth knowing: backgrounding the app - even briefly, to take a call - ends the xAPI session,
    /// and coming back does not start a new one. An early terminated beats a missing one, but if a
    /// Training legitimately spans app switches this is the line to revisit.
    ///
    /// WebGL gets neither. Application.quitting is never raised in a browser and
    /// Application.Quit() is a no-op, so nothing in managed code learns that a tab is closing;
    /// the JS side owns the unload listeners instead and posts what was staged for it (see
    /// WiDiDShutdownPost.jslib). All this installs there is the periodic re-stage that keeps that
    /// payload current, plus - via AppTermination - the deliberate-exit path, which does know in
    /// advance. Note that OnApplicationPause fires on mere tab-focus loss in a browser, which is
    /// exactly why TerminatesOnPause is not set there.
    /// </summary>
    public static class SimulationTerminationHooks
    {
        /// <summary>
        /// How long the blocking poster may hold up a quit. Long enough for one round-trip on a
        /// slow connection, short enough that a user closing the app does not think it hung.
        /// </summary>
        public static readonly TimeSpan QuitTimeout = TimeSpan.FromSeconds(3);

        /// <summary>
        /// Shorter than QuitTimeout: on mobile the app is being backgrounded, not closed, and the
        /// OS gives a pause callback far less room than a quit.
        /// </summary>
        public static readonly TimeSpan PauseTimeout = TimeSpan.FromSeconds(2);

        /// <summary>
        /// Seconds between re-staged payloads on platforms that must have one ready in advance.
        /// Also the accuracy of the terminated statement's duration there.
        /// </summary>
        const float WebGlRefreshInterval = 1f;

        static SimulationTerminationFlusher installed;
        static AppLifecycleRelay relay;
        static bool hooked;

        public static void Install(SimulationTerminationFlusher flusher)
        {
            // Always re-pointed at the newest flusher, so a second session (a re-login, see
            // TrainingRuntime.HandleSessionReady) terminates its own Simulation rather than the
            // previous one's. The hooks themselves are wired once and go on serving whatever this
            // points at.
            installed = flusher;

            if (!hooked)
            {
                hooked = true;

                AppTermination.OnTerminating += HandleDeliberateExit;

#if UNITY_WEBGL && !UNITY_EDITOR
                EnsureRelay(WebGlRefreshInterval, terminatesOnPause: false);
#elif UNITY_ANDROID || UNITY_IOS
                EnsureRelay(refreshInterval: 0f, terminatesOnPause: true);
                Application.quitting += HandleQuitting;
#else
                Application.quitting += HandleQuitting;
#endif
            }

            if (relay != null)
                relay.Flusher = flusher;

            // Staged straight away rather than only on the first tick, so a teardown in the first
            // moments of a session still has a terminated to send.
            flusher.Refresh();
        }

        static void EnsureRelay(float refreshInterval, bool terminatesOnPause)
        {
            GameObject host = new GameObject("[TrainingRuntime] AppLifecycleRelay") { hideFlags = HideFlags.HideInHierarchy };
            UnityEngine.Object.DontDestroyOnLoad(host);

            relay = host.AddComponent<AppLifecycleRelay>();
            relay.RefreshInterval = refreshInterval;
            relay.TerminatesOnPause = terminatesOnPause;
        }

        static void HandleQuitting() => installed?.Flush(QuitTimeout);

        // The app deciding to close itself, which is the only teardown a browser build can see
        // coming - and on every other platform simply arrives before Application.quitting would.
        // One-shot either way (see SimulationTerminationFlusher.Flush).
        static void HandleDeliberateExit() => installed?.Flush(QuitTimeout);
    }
}
