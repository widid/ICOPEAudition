using System;
using System.Collections.Generic;
using TinCan;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking.Shutdown;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Gets Terminated_Simulation out as the session's genuinely last statement while the app is
    /// ending, on every platform.
    ///
    /// The problem this exists to solve is that the ordinary send path cannot run during teardown
    /// at all. StatementSender posts over UnityWebRequest, which only completes when Unity raises
    /// AsyncOperation.completed from the player loop, and every "the app is ending" signal arrives
    /// after the last frame has been pumped - so the await behind an ordinary send would simply
    /// never resume, on standalone as much as on WebGL. Sending from here therefore means handing
    /// serialized statements to a transport that needs no player loop (see
    /// IShutdownStatementPoster) rather than calling TrainingRuntime's own send methods.
    ///
    /// Building the payload is the other half, and it has to happen before it is needed, because
    /// neither poster can await anything. That splits into two methods for the two shapes the
    /// platforms have. Flush is for a teardown managed code is told about in time to act on it
    /// (Application.quitting, a mobile pause, a deliberate exit): it takes the send queue's
    /// not-yet-posted backlog, appends a freshly built terminated, and posts the lot on the spot.
    /// Refresh is for the teardown nothing is told about - a browser tab closing - and only stages
    /// the closing statements and terminated, on a timer, so the JS side always has a current
    /// payload to send.
    ///
    /// Refresh deliberately leaves the backlog alone. Taking statements out of a queue that is
    /// about to post them normally would strand them, and staging a copy the queue then posts
    /// anyway would duplicate them; neither is worth risking for a backlog that is normally empty
    /// and never more than a round-trip old. An abrupt tab close therefore sends terminated and
    /// may lose a statement queued in the last instant - the trade is deliberate.
    ///
    /// Terminated is last in whatever gets staged, and its xAPI timestamp is later than every
    /// statement in front of it, so it reads as last either way: by arrival on standalone and
    /// mobile, where the poster blocks on each request in turn, and by timestamp alone on WebGL,
    /// where a browser will not give an unload handler the turns of the event loop that ordering
    /// requests one after another would need. Duration is wall-clock time since Initialized went
    /// out, so on WebGL it is accurate to the refresh interval rather than to the millisecond -
    /// immaterial on a session-length measure.
    ///
    /// TEMPORARY-STORED-PROGRESS: whatever closingStatements still owes (see IClosingStatementSource) is staged right before
    /// terminated, in both Refresh and Flush, so it is sent with it and timestamped ahead of it.
    ///
    /// Flush is one-shot, and MarkFlushed shares that flag. Several teardown signals can fire for
    /// one teardown (pagehide and visibilitychange in a browser, pause then quit on mobile), and
    /// terminated must go out exactly once.
    /// </summary>
    public class SimulationTerminationFlusher
    {
        readonly IShutdownStatementPoster poster;
        readonly StatementSender sender;
        readonly Func<IStatementable> buildTerminated;
        readonly IClosingStatementSource closingStatements; // TEMPORARY-STORED-PROGRESS
        readonly string url;
        readonly string bearerToken;

        readonly List<string> staged = new List<string>();

        public bool HasFlushed { get; private set; }

        public SimulationTerminationFlusher(IShutdownStatementPoster poster, StatementSender sender, Func<IStatementable> buildTerminated, IClosingStatementSource closingStatements, string url, string bearerToken)
        {
            this.poster = poster;
            this.sender = sender;
            this.buildTerminated = buildTerminated;
            this.closingStatements = closingStatements;
            this.url = url;
            this.bearerToken = bearerToken;
        }

        /// <summary>
        /// Re-stages the closing statements and a freshly built terminated, so a teardown that gives
        /// managed code no notice still has a current payload to send. Safe to call on a timer, and
        /// deliberately limited to those: it must not touch the send queue's backlog, since taking statements out of
        /// a queue that is about to post them normally would strand them, and staging a copy that
        /// the queue then posts successfully would duplicate them. The backlog is only ever taken
        /// once the app really is going away - see Flush.
        /// </summary>
        public void Refresh()
        {
            if (HasFlushed || poster == null)
                return;

            staged.Clear();
            StageClosingStatements();

            if (!TryStageTerminated())
                return;

            poster.Stage(staged, url, bearerToken);
        }

        /// <summary>
        /// Sends the not-yet-posted backlog and then terminated, last, and refuses to do so twice.
        /// Called from whichever teardown signal this platform actually gets - and on WebGL, only
        /// from the deliberate exit that knows before the browser does (see AppTermination), since
        /// an abrupt tab close never reaches managed code and gets whatever Refresh last staged
        /// instead.
        /// </summary>
        public void Flush(TimeSpan timeout)
        {
            if (HasFlushed || poster == null)
                return;

            HasFlushed = true;
            staged.Clear();

            // Only statements the queue has provably not posted yet, so re-sending them here
            // cannot duplicate anything (see StatementSendQueue.TakeWaiting).
            foreach (Statement backlog in sender.PendingQueue.TakeWaiting())
                staged.Add(backlog.ToJSON(false));

            StageClosingStatements();

            if (!TryStageTerminated())
                return;

            int inFlight = sender.PendingQueue.InFlightCount;
            if (inFlight > 0)
                Debug.LogWarning($"[TrainingRuntime] {inFlight} statement(s) were already in flight when the app started closing and cannot be recovered - they carry no xAPI id to de-duplicate a re-send on.");

            if (!poster.PreservesArrivalOrder && staged.Count > 1)
                Debug.LogWarning($"[TrainingRuntime] {staged.Count} statements are being posted at once on this platform - they arrive in no guaranteed order, and only their xAPI timestamps place Terminated_Simulation last.");

            poster.Stage(staged, url, bearerToken);
            poster.PostStaged(timeout);
        }

        /// <summary>
        /// Records that terminated has gone out by some other route, so no teardown signal sends a
        /// second one - specifically TrainingRuntime.TerminateSimulation, which ends a session
        /// while the app is still running and can therefore use the ordinary send path. Also drops
        /// whatever was staged, since staging is only ever a payload for a terminated still owed.
        /// </summary>
        public void MarkFlushed()
        {
            HasFlushed = true;
            staged.Clear();
            poster?.Stage(staged, url, bearerToken);
        }

        // TEMPORARY-STORED-PROGRESS. A closing statement that fails to build must never cost the session its terminated.
        void StageClosingStatements()
        {
            if (closingStatements == null)
                return;

            try
            {
                foreach ((Verb verb, IStatementable statementable) in closingStatements.BuildClosingStatements())
                    staged.Add(sender.Build(verb, statementable).ToJSON(false));
            }
            catch (Exception exception)
            {
                Debug.LogError($"[TrainingRuntime] A closing statement could not be built for the app-teardown poster: {exception}");
            }
        }

        bool TryStageTerminated()
        {
            try
            {
                staged.Add(sender.Build(Verbs.Terminated, buildTerminated()).ToJSON(false));
                return true;
            }
            catch (Exception exception)
            {
                Debug.LogError($"[TrainingRuntime] Terminated_Simulation could not be built for the app-teardown poster: {exception}");
                return false;
            }
        }
    }
}
