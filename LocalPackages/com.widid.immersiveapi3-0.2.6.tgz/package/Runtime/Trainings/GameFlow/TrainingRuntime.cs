using System;
using System.Linq;
using System.Threading.Tasks;
using TinCan;
using UnityEngine;
using WiDiD.ImmersiveAPI.Actors;
using WiDiD.ImmersiveAPI.Authentication;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Networking.Authentification;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;
using WiDiD.ImmersiveAPI.Networking.Progression;
using WiDiD.ImmersiveAPI.Networking.Shutdown;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Developer-facing API for tracking a player's progress through a Training's GameFlow while
    /// sending the matching xAPI statements. "Initialized" fires automatically the moment
    /// SessionGate confirms a real session and resolves which Training to track - nothing to call
    /// for that.
    ///
    /// This class itself only bootstraps the session and orchestrates the collaborators that own
    /// all the actual progress/unlock state and statement sending: StrategyProgressController,
    /// StepProgressController, and InteractionRecorder (see those for the real logic) - all take
    /// a matching XReference overload too (StrategyReference/StepReference/InteractionReference),
    /// so a MonoBehaviour/ScriptableObject field can be wired via the custom Inspector picker
    /// instead of hand-typing a raw id. SendInteraction only needs the interaction's own
    /// id/reference - no separate Step id, since Interaction Ids are unique across the whole
    /// Training (see InteractionRecorder.TryGet).
    ///
    /// Every send method is named for the xAPI verb it sends - Launch/Progress/Fail/Pass/Complete/
    /// Exit/Score/Terminate produce launched/progressed/failed/passed/completed/exited/scored/
    /// terminated. SendInteraction is the one exception, because it is the one method that picks
    /// its verb rather than naming it: an Interaction is authored as either a question or a plain
    /// interaction (TrainingInteractionData.Kind), and SendInteraction sends whichever that says,
    /// so a call can never disagree with the authored data.
    ///
    /// StrategyReference/StepReference are the odd ones out among the Xreference types: they store
    /// a stable NodeGuid rather than the strategy/step's own authored Id (see StrategyNode.customId/
    /// StepNode.customId - both editable, unlike GraphProcessor's own node GUID), so
    /// ResolveStrategyId/ResolveStepId resolve NodeGuid -> current Id against ActiveTraining right
    /// before every call, instead of baking in a specific Id that a later rename could invalidate.
    ///
    /// Strategies are step-driven: call LaunchStrategy to begin one, then LaunchStep/ProgressStep/
    /// FailStep/PassStep/CompleteStep/ExitStep for its steps as normal - the strategy's own
    /// Progressed/Passed-or-Failed/Completed statements are sent automatically once its steps are
    /// done (see StrategyProgressController), so there's no manual equivalent for those on a
    /// strategy. ExitStrategy stays manual, since leaving isn't derivable from step state.
    ///
    /// Launching has real sequencing rules - a strategy must be unlocked, and a step must be
    /// unlocked *and* belong to the strategy that is currently launched. CanLaunchStrategy/
    /// CanLaunchStep answer both up front (see GameFlowCheck), reusing the very checks
    /// LaunchStrategy/LaunchStep enforce, so host game code can gate a button on them instead of
    /// finding out from a rejected send. Nothing is auto-started on your behalf: LaunchStep will
    /// not quietly launch the owning strategy, since that would send a Strategy statement the game
    /// never asked for.
    ///
    /// Calling a send method before initialization has finished no longer throws the statement
    /// away: while a session is still being set up the call waits for it (see WhenReady) and then
    /// proceeds, and only a call made with no session at all - or after initialization actually
    /// failed - comes back rejected. Await WhenReady directly to sequence your own setup after the
    /// runtime's.
    ///
    /// Every method returns Task&lt;StatementSendResult&gt;, and host game code realistically
    /// discards it - a fire-and-forget call from a void Unity callback draws no compiler warning.
    /// So no failure depends on the caller inspecting the result: rejections are reported here and
    /// send failures in StatementSender, both through StatementFailureLog, which logs an error and
    /// raises OnStatementFailed for anything that wants to observe it.
    ///
    /// Progress is seeded once at initialization from previous sessions (TEMPORARY-STORED-PROGRESS,
    /// see StoredProgressRestorer), then lives in memory and only moves forward through the send methods.
    ///
    /// Badges are the odd one out: BadgeRecorder has no manual trigger API at all - each slot's
    /// UnlockCondition (see TrainingBadgeData/ConditionChain) is checked every frame via
    /// BadgeConditionTicker and fires automatically the moment it evaluates true.
    ///
    /// ScoreReward is manual, like SendInteraction - host game code decides exactly when points are
    /// awarded, and the same reward Id can legitimately be sent many times over a session (see
    /// xAPI-Statements/Reward's dashboard aggregation rule).
    ///
    /// ScoreSkill is manual too, but only for Scored - Progressed/Mastered are derived
    /// automatically from each Score call by comparing the newly resolved Scaled value against
    /// that skill's own last known score (see SkillRecorder). Host game code never calls Progressed
    /// or Mastered directly.
    ///
    /// ScorePerformance is manual as well, and sends a single Performance regardless of which
    /// container (Simulation/Strategy/Step) it's scoped to (see PerformanceReference/
    /// PerformanceRecorder.Score). Only a SendsOnClose performance left unscored is sent on its
    /// own, right before Terminated_Simulation.
    ///
    /// Statements go out strictly in the order they are raised, one at a time (see
    /// StatementSendQueue) - so a burst of sends is spread over consecutive round-trips rather
    /// than overlapped, and Initialized/Terminated genuinely bookend a session.
    ///
    /// Terminated_Simulation is automatic and needs nothing from host game code: it is sent as the
    /// app closes, on every platform, including a browser tab simply being closed. That cannot go
    /// through any of the send methods here, because none of them can complete once the last frame
    /// has been pumped - see SimulationTerminationFlusher for how it is actually done, and
    /// SimulationTerminationHooks for what each platform gives us to hang it on. TerminateSimulation
    /// remains for host code that ends a session while the app keeps running, and marks the session
    /// terminated so the automatic one does not follow it.
    ///
    /// HandleSessionReady is public so Editor-only tooling can call it directly instead of going
    /// through SessionGate, which never runs in the Editor at all (see EditorSessionBootstrap).
    /// </summary>
    public static class TrainingRuntime
    {
        public static bool IsReady { get; private set; }
        public static TrainingSO ActiveTraining { get; private set; }
        public static TrainingStrategyData CurrentStrategy => strategies?.Current;
        public static TrainingStepData CurrentStep => steps?.Current;

        /// <summary>
        /// Completes once initialization has finished, whether it succeeded or not - check IsReady
        /// after awaiting to tell which. Never faults, so it is safe to await unguarded. The send
        /// methods await this themselves; this is for host code that wants to sequence its own
        /// setup after the runtime's.
        /// </summary>
        public static Task WhenReady => readySignal.Task;

        static StepProgressController steps;
        static StrategyProgressController strategies;
        static SimulationProgressController simulationProgress;
        static PerformanceRecorder performances;
        static InteractionRecorder interactions;
        static BadgeRecorder badges;
        static BadgeConditionTicker badgeTicker;
        static RewardRecorder rewards;
        static SkillRecorder skills;
        static PerformanceServerSync performanceServerSync; // TEMPORARY-STORED-PROGRESS

        // Kept around (not just HandleSessionReady locals) so the termination path can still build
        // and send Terminated after that method has long since returned.
        static StatementSender sender;
        static SimulationTerminationFlusher termination;
        static string sessionTrainingId;
        static DateTime initializedAt;

        // IsReady alone can't guard against a second HandleSessionReady call anymore: restoring
        // progression awaits a network round-trip before IsReady is set, leaving a window a second
        // caller (SessionGate and EditorSessionBootstrap both call it) would otherwise slip through.
        static bool initializing;

        // RunContinuationsAsynchronously so completing this can't synchronously run a waiting
        // caller's deferred send in the middle of HandleSessionReady - each await still resumes on
        // Unity's main-thread context as usual, just not inline.
        static TaskCompletionSource<bool> readySignal = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);

        const string UnresolvedStrategy = "StrategyReference is not set or no longer resolves to a Strategy.";
        const string UnresolvedStep = "StepReference is not set or no longer resolves to a Step.";
        const string NoSession = "TrainingRuntime is not ready - no session has been confirmed yet.";

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Bootstrap()
        {
            SessionGate.OnSessionReady += HandleSessionReady;
        }

        // Public (not just SessionGate.OnSessionReady's private subscriber) so Editor-only tooling
        // that can't rely on SessionGate - it deliberately never runs in the Editor, see this class's
        // own doc comment - can feed TrainingRuntime a manually-populated UserSessionSO instead (e.g.
        // EditorSessionBootstrap, using the same session the Debug Session window/Training
        // Editor's "Set Active" already fill in). Guarded against double-init since it's now callable
        // from more than one place.
        public static async void HandleSessionReady(UserSessionSO session)
        {
            if (IsReady || initializing)
                return;

            initializing = true;

            // An earlier attempt that failed left the signal completed - a fresh attempt needs a
            // fresh one, or everything awaiting readiness this time is handed that old failure
            // immediately instead of waiting for this run.
            if (readySignal.Task.IsCompleted)
                readySignal = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);

            ActiveTraining = ResolveActiveTraining(session.Data);
            if (ActiveTraining == null)
            {
                Debug.LogError($"[TrainingRuntime] No Training asset found under Resources/{TrainingSO.ResourcesFolder} to initialize.");
                FinishInitializing(false);
                return;
            }

            sessionTrainingId = session.Data.TrainingId;
            Simulation simulation = SimulationStatementFactory.Initialized(ActiveTraining, sessionTrainingId);

            IImmersiveEndpoints endpoints = new ImmersiveEndpoints(session);
            Agent actor = await ResolveActor(session.Data, endpoints);

            sender = new StatementSender(
                new RuntimeStatementBuilderProfile(session.Data, actor),
                endpoints,
                session.Data.DecodedToken,
                new ImmersiveXapiEventSender());

            steps = new StepProgressController(sender);
            strategies = new StrategyProgressController(sender, steps);
            simulationProgress = new SimulationProgressController(sender, steps, strategies);
            performances = new PerformanceRecorder(sender, endpoints, session.Data.DecodedToken, new ImmersiveImageSender());
            interactions = new InteractionRecorder(sender);
            badges = new BadgeRecorder(sender);
            rewards = new RewardRecorder(sender);
            skills = new SkillRecorder(sender);

            steps.Configure(ActiveTraining.Data.GameFlow, simulation);
            strategies.Configure(ActiveTraining.Data.GameFlow, simulation);
            simulationProgress.Configure(ActiveTraining, sessionTrainingId, ActiveTraining.Data.GameFlow);
            performances.Configure(ActiveTraining.Data.GameFlow, simulation);
            interactions.Configure(ActiveTraining.Data.GameFlow, simulation);
            badges.Configure(ActiveTraining.Data.GameFlow, simulation);
            rewards.Configure(ActiveTraining.Data.GameFlow, simulation);
            skills.Configure(ActiveTraining.Data.GameFlow, simulation);

            // TEMPORARY-STORED-PROGRESS: replace the source with the LRS one, or delete this block (see Documentation~/StoredProgressBridge.md).
            performanceServerSync = new PerformanceServerSync();
            performanceServerSync.Configure(ActiveTraining.Data.GameFlow, simulation);
            performances.Scored += performanceServerSync.MarkScored;
            await new StoredProgressRestorer(steps, strategies, performanceServerSync, skills, rewards, badges)
                .Restore(new UserStatsProgressSource(new UserProgressionService(endpoints, new ImmersiveLogger()), session.Data));

            // Armed only after restoring, so a badge received in a previous session is never re-sent.
            EnsureBadgeTicker().Recorder = badges;

            initializedAt = DateTime.UtcNow;

            // Initialized_Simulation must be the first statement of the session (see
            // xAPI-Statements/Simulation/README.md), so readiness is only announced once it has
            // actually gone out - any send that was deferred waiting for WhenReady would otherwise
            // be free to overtake it. A failed Initialized still counts as ready: the session is
            // live either way, and refusing every later statement over it would lose far more.
            await sender.Send(Verbs.Initialized, simulation);

            // Armed only now, after Initialized: terminated is the bookend to that statement, and
            // staging one before the session has actually opened would let a teardown mid-startup
            // terminate a Simulation that was never initialized.
            termination = new SimulationTerminationFlusher(
                ShutdownStatementPosterFactory.Create(),
                sender,
                () => SimulationStatementFactory.Terminated(ActiveTraining, sessionTrainingId, DateTime.UtcNow - initializedAt),
                performanceServerSync, // TEMPORARY-STORED-PROGRESS
                endpoints.XAPIPostAdress,
                session.Data.DecodedToken);

            // TEMPORARY-STORED-PROGRESS: re-staged at once so an abrupt teardown never re-sends a performance just scored.
            performanceServerSync.ClosingStatementsChanged += termination.Refresh;

            SimulationTerminationHooks.Install(termination);

            StatementableValues.Bind(performances, performanceServerSync);
            FinishInitializing(true);
        }

        static void FinishInitializing(bool ready)
        {
            IsReady = ready;
            initializing = false;
            readySignal.TrySetResult(ready);
        }

        // Builds the actor every statement is attributed to (see ActorFactory). The profile endpoint
        // is only called when the actor is configured to carry a display name and nothing already
        // fetched one, so turning that setting off leaves initialization request-free.
        static async Task<Agent> ResolveActor(UserSessionData sessionData, IImmersiveEndpoints endpoints)
        {
            ActorIdentificationData actorConfig = ActorIdentificationConfigLoader.Load();
            ProfileInfo profile = sessionData.UserProfile?.Info;

            if (profile == null && actorConfig.IncludeDisplayName)
                profile = await new UserProfileService(endpoints, new ImmersiveLogger()).FetchProfile();

            return ActorFactory.Build(sessionData, actorConfig, profile);
        }

        /// <summary>
        /// Sends Terminated_Simulation through the ordinary send path, for host code or tooling
        /// that ends a session while the app carries on running (e.g. RuntimeHarness's Session Info
        /// popup, to verify the statement without quitting). Duration is wall-clock time since
        /// Initialized was sent (DateTime.UtcNow, not Time.time - it must keep counting through any
        /// pause/background time too, unaffected by timeScale).
        ///
        /// Not what runs when the app is closing. That path cannot use this method at all: it goes
        /// through SimulationTerminationFlusher, over a transport that does not need Unity's player
        /// loop, because the await inside this one would never resume once the last frame has been
        /// pumped. Calling this does mark the session terminated, so the teardown path will not
        /// send a second terminated afterwards.
        ///
        /// TEMPORARY-STORED-PROGRESS: performances still owed on close (PerformanceServerSync) are queued first.
        ///
        /// Unlike the other send methods this will not wait for initialization: a session that has
        /// not opened has no initialized Simulation to terminate.
        /// </summary>
        public static Task<StatementSendResult> TerminateSimulation()
        {
            if (!IsReady)
                return Task.FromResult(Reject(nameof(TerminateSimulation), "TrainingRuntime is not ready - there is no initialized Simulation to terminate."));

            if (termination != null && termination.HasFlushed)
                return Task.FromResult(Reject(nameof(TerminateSimulation), "Terminated_Simulation has already been sent for this session."));

            termination?.MarkFlushed();

            foreach ((Verb verb, IStatementable statementable) in performanceServerSync.BuildClosingStatements().ToList())
                _ = sender.Send(verb, statementable);

            return sender.Send(Verbs.Terminated, SimulationStatementFactory.Terminated(ActiveTraining, sessionTrainingId, DateTime.UtcNow - initializedAt));
        }

        public static bool IsStrategyUnlocked(string strategyId) => IsReady && strategies.IsUnlocked(strategyId);
        public static bool IsStrategyCompleted(string strategyId) => IsReady && strategies.IsCompleted(strategyId);
        public static bool IsStepUnlocked(string stepId) => IsReady && steps.IsUnlocked(stepId);
        public static bool IsStepCompleted(string stepId) => IsReady && steps.IsCompleted(stepId);

        /// <summary>
        /// Whether LaunchStrategy would be accepted right now, and if not, why (see GameFlowCheck) -
        /// runs the same check LaunchStrategy itself enforces, so the two can't disagree.
        /// </summary>
        public static GameFlowCheck CanLaunchStrategy(StrategyReference strategy) => IsReady ? WithResolvedStrategy(strategy, strategies.CanLaunch) : GameFlowCheck.No(NotReadyReason());
        public static GameFlowCheck CanLaunchStrategy(string strategyId) => IsReady ? strategies.CanLaunch(strategyId) : GameFlowCheck.No(NotReadyReason());

        /// <summary>
        /// Whether LaunchStep would be accepted right now, and if not, why (see GameFlowCheck) -
        /// runs the same check LaunchStep itself enforces, covering both the step's own unlock state
        /// and whether its owning strategy is the one currently launched.
        /// </summary>
        public static GameFlowCheck CanLaunchStep(StepReference step) => IsReady ? WithResolvedStep(step, stepId => steps.CanLaunch(stepId, strategies.Current)) : GameFlowCheck.No(NotReadyReason());
        public static GameFlowCheck CanLaunchStep(string stepId) => IsReady ? steps.CanLaunch(stepId, strategies.Current) : GameFlowCheck.No(NotReadyReason());

        public static Task<StatementSendResult> LaunchStrategy(StrategyReference strategy) => Send(nameof(LaunchStrategy), () => WithResolvedStrategy(strategy, strategies.Launch));
        public static Task<StatementSendResult> LaunchStrategy(string strategyId) => Send(nameof(LaunchStrategy), () => strategies.Launch(strategyId));

        public static Task<StatementSendResult> ExitStrategy(StrategyReference strategy) => Send(nameof(ExitStrategy), () => WithResolvedStrategy(strategy, strategies.Exit));
        public static Task<StatementSendResult> ExitStrategy(string strategyId) => Send(nameof(ExitStrategy), () => strategies.Exit(strategyId));

        public static Task<StatementSendResult> LaunchStep(StepReference step) => Send(nameof(LaunchStep), () => WithResolvedStep(step, stepId => steps.Launch(stepId, strategies.Current)));
        public static Task<StatementSendResult> LaunchStep(string stepId) => Send(nameof(LaunchStep), () => steps.Launch(stepId, strategies.Current));

        public static Task<StatementSendResult> ProgressStep(StepReference step, float progress) => Send(nameof(ProgressStep), () => WithResolvedStep(step, stepId => steps.Progress(stepId, progress)));
        public static Task<StatementSendResult> ProgressStep(string stepId, float progress) => Send(nameof(ProgressStep), () => steps.Progress(stepId, progress));

        public static Task<StatementSendResult> FailStep(StepReference step, float? score = null) => Send(nameof(FailStep), () => WithResolvedStep(step, stepId => steps.Fail(stepId, score)));
        public static Task<StatementSendResult> FailStep(string stepId, float? score = null) => Send(nameof(FailStep), () => steps.Fail(stepId, score));

        public static Task<StatementSendResult> PassStep(StepReference step, float? score = null) => Send(nameof(PassStep), () => WithResolvedStep(step, stepId => steps.Pass(stepId, score)));
        public static Task<StatementSendResult> PassStep(string stepId, float? score = null) => Send(nameof(PassStep), () => steps.Pass(stepId, score));

        public static Task<StatementSendResult> CompleteStep(StepReference step, float? score = null) => Send(nameof(CompleteStep), () => WithResolvedStep(step, stepId => steps.Complete(stepId, score)));
        public static Task<StatementSendResult> CompleteStep(string stepId, float? score = null) => Send(nameof(CompleteStep), () => steps.Complete(stepId, score));

        public static Task<StatementSendResult> ExitStep(StepReference step) => Send(nameof(ExitStep), () => WithResolvedStep(step, steps.Exit));
        public static Task<StatementSendResult> ExitStep(string stepId) => Send(nameof(ExitStep), () => steps.Exit(stepId));

        /// <summary>
        /// Sends whichever Interaction statement this entry is authored as - answered for a
        /// question, interacted otherwise (see TrainingInteractionData.Kind/InteractionRecorder.Send).
        /// Duration only applies to the latter; a question carries none.
        /// </summary>
        public static Task<StatementSendResult> SendInteraction(InteractionReference interaction, bool? success = null, TimeSpan? duration = null, SeverityLevel? severity = null) => SendInteraction(interaction.InteractionId, success, duration, severity);
        public static Task<StatementSendResult> SendInteraction(string interactionId, bool? success = null, TimeSpan? duration = null, SeverityLevel? severity = null) => Send(nameof(SendInteraction), () => interactions.Send(interactionId, success, duration, severity));

        public static Task<StatementSendResult> ScorePerformance(PerformanceReference performance) => ScorePerformance(performance.PerformanceId);
        public static Task<StatementSendResult> ScorePerformance(string performanceId) => Send(nameof(ScorePerformance), () => performances.Score(performanceId));

        public static Task<StatementSendResult> ScoreReward(RewardReference reward) => ScoreReward(reward.RewardId);
        public static Task<StatementSendResult> ScoreReward(string rewardId) => Send(nameof(ScoreReward), () => rewards.Score(rewardId));

        public static Task<StatementSendResult> ScoreSkill(SkillReference skill) => ScoreSkill(skill.SkillId);
        public static Task<StatementSendResult> ScoreSkill(string skillId) => Send(nameof(ScoreSkill), () => skills.Score(skillId));

        /// <summary>
        /// The one path every send method takes, so none of them has to repeat the readiness
        /// handling or remember to report its own rejection.
        ///
        /// A call made while a session is still initializing waits for it rather than being thrown
        /// away - that window is a network round-trip wide (see StoredProgressRestorer), far too wide
        /// for host game code to reliably stay out of. Only a call with no session at all, or one
        /// made after initialization actually failed, is rejected.
        /// </summary>
        static async Task<StatementSendResult> Send(string context, Func<Task<StatementSendResult>> call)
        {
            if (!IsReady)
            {
                if (!initializing)
                    return Reject(context, NoSession);

                await WhenReady;

                if (!IsReady)
                    return Reject(context, "TrainingRuntime failed to initialize - see the earlier error for why.");
            }

            StatementSendResult result = await call();

            // Rejections only: a statement that was actually posted and refused was already
            // reported by StatementSender, which sees the verb and statementable this doesn't.
            if (result.Rejected)
                StatementFailureLog.Report(context, result);

            return result;
        }

        static StatementSendResult Reject(string context, string reason)
        {
            StatementSendResult rejection = StatementSendResult.Rejection(reason);
            StatementFailureLog.Report(context, rejection);
            return rejection;
        }

        static string NotReadyReason() => initializing ? "TrainingRuntime is still initializing." : NoSession;

        // StrategyReference/StepReference store a stable NodeGuid, not the authored Id (see those
        // classes) - resolved here, at the moment of use, against ActiveTraining's current data, so
        // a reference set up before a rename (see StrategyNode.customId/StepNode.customId) still
        // finds the right strategy/step afterward instead of silently failing.
        static string ResolveStrategyId(StrategyReference strategy) => ActiveTraining?.Data.GameFlow.Strategies.FirstOrDefault(s => s.NodeGuid == strategy.StrategyNodeGuid)?.Id;

        static string ResolveStepId(StepReference step) => ActiveTraining?.Data.GameFlow.Strategies.SelectMany(s => s.Steps).FirstOrDefault(s => s.NodeGuid == step.StepNodeGuid)?.Id;

        static Task<StatementSendResult> WithResolvedStrategy(StrategyReference strategy, Func<string, Task<StatementSendResult>> call)
        {
            string strategyId = ResolveStrategyId(strategy);

            return strategyId == null
                ? Task.FromResult(StatementSendResult.Rejection(UnresolvedStrategy))
                : call(strategyId);
        }

        static Task<StatementSendResult> WithResolvedStep(StepReference step, Func<string, Task<StatementSendResult>> call)
        {
            string stepId = ResolveStepId(step);

            return stepId == null
                ? Task.FromResult(StatementSendResult.Rejection(UnresolvedStep))
                : call(stepId);
        }

        static GameFlowCheck WithResolvedStrategy(StrategyReference strategy, Func<string, GameFlowCheck> check)
        {
            string strategyId = ResolveStrategyId(strategy);
            return strategyId == null ? GameFlowCheck.No(UnresolvedStrategy) : check(strategyId);
        }

        static GameFlowCheck WithResolvedStep(StepReference step, Func<string, GameFlowCheck> check)
        {
            string stepId = ResolveStepId(step);
            return stepId == null ? GameFlowCheck.No(UnresolvedStep) : check(stepId);
        }

        // Badge's auto-triggering needs a per-frame tick (see BadgeConditionTicker) that a plain
        // static class can't provide on its own - lazily creates the one hidden, DontDestroyOnLoad
        // GameObject that hosts it, so a re-login (HandleSessionReady firing again) reuses it
        // instead of leaking a duplicate.
        static BadgeConditionTicker EnsureBadgeTicker()
        {
            if (badgeTicker == null)
            {
                GameObject tickerObject = new GameObject("[TrainingRuntime] BadgeConditionTicker") { hideFlags = HideFlags.HideInHierarchy };
                UnityEngine.Object.DontDestroyOnLoad(tickerObject);
                badgeTicker = tickerObject.AddComponent<BadgeConditionTicker>();
            }

            return badgeTicker;
        }

        static TrainingSO ResolveActiveTraining(UserSessionData sessionData)
        {
            TrainingSO[] trainings = Resources.LoadAll<TrainingSO>(TrainingSO.ResourcesFolder);
            if (trainings.Length == 0)
                return null;

            TrainingSO matched = trainings.FirstOrDefault(t => !string.IsNullOrEmpty(t.Data.ModuleId) && t.Data.ModuleId == sessionData.ModuleArgument);
            return matched != null ? matched : trainings[0];
        }
    }
}
