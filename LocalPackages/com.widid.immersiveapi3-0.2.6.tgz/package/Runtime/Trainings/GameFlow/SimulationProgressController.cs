using System;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Owns Simulation-level Progressed/Passed/Failed - entirely automatic, mirroring
    /// StrategyProgressController's own step-driven automation one level up. Progressed is sent on
    /// every Step completion anywhere in the Training (scaled = completed step count / total step
    /// count across every Strategy, not just one - the Simulation is the whole Training, unlike a
    /// Strategy's own Progressed which only counts its own Steps).
    ///
    /// The Simulation ends the moment a Strategy both has no Next connection (nothing else in the
    /// GameFlow lists it as Previous) and has TrainingStrategyData.CompleteSimulation set - the same
    /// "leaf + toggle" shape StrategyProgressController itself uses to decide when a Strategy ends
    /// from its own Steps, just one level up. At that point a final Progressed(1) is sent, then the
    /// average score of every completed Strategy is compared against
    /// TrainingGameFlowData.SimulationPassingScore to decide Passed vs Failed, then Completed is
    /// sent with that same average - same three-statement shape as
    /// StrategyProgressController.AutomateStrategy. Initialized/Terminated are TrainingRuntime's own
    /// concern (session start/app quit), not this controller's - it only reacts to GameFlow progress.
    /// </summary>
    public class SimulationProgressController
    {
        readonly IStatementSender sender;
        readonly StepProgressController steps;
        readonly StrategyProgressController strategies;

        TrainingSO training;
        TrainingGameFlowData gameFlow;
        string sessionTrainingId;
        bool completed;

        public SimulationProgressController(IStatementSender sender, StepProgressController steps, StrategyProgressController strategies)
        {
            this.sender = sender;
            this.steps = steps;
            this.strategies = strategies;

            steps.StepCompleted += HandleStepCompleted;
            strategies.Completed += HandleStrategyCompleted;
        }

        public void Configure(TrainingSO training, string sessionTrainingId, TrainingGameFlowData gameFlow)
        {
            this.training = training;
            this.sessionTrainingId = sessionTrainingId;
            this.gameFlow = gameFlow;
            completed = false;
        }

        async void HandleStepCompleted(TrainingStrategyData owningStrategy, TrainingStepData completedStep)
        {
            try
            {
                if (completed)
                    return;

                int totalSteps = steps.TotalStepCount;
                float progressFraction = totalSteps == 0 ? 0f : (float)steps.CompletedStepCount / totalSteps;

                await sender.Send(Verbs.Progressed, SimulationStatementFactory.Progressed(training, sessionTrainingId, progressFraction));
            }
            catch (Exception exception)
            {
                Debug.LogError($"[SimulationProgressController] Failed to send Simulation Progressed after a step completed: {exception}");
            }
        }

        async void HandleStrategyCompleted(TrainingStrategyData strategy)
        {
            try
            {
                await AutomateSimulation(strategy);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[SimulationProgressController] Failed to automate Simulation completion after strategy '{strategy.Id}' completed: {exception}");
            }
        }

        async Task AutomateSimulation(TrainingStrategyData strategy)
        {
            if (completed || !EndsSimulation(strategy))
                return;

            await sender.Send(Verbs.Progressed, SimulationStatementFactory.Progressed(training, sessionTrainingId, 1f));

            float[] scores = gameFlow.Strategies
                .Where(s => strategies.IsCompleted(s.Id))
                .Select(s => strategies.GetScore(s.Id))
                .Where(score => score.HasValue)
                .Select(score => score.Value)
                .ToArray();

            // No strategy recorded a score at all - falls back to 1/0 based on the pass/fail
            // decision itself (made using 0 as a neutral placeholder) rather than always reporting
            // 0, which would contradict a statement that just said "Passed" - same reasoning as
            // StrategyProgressController.AutomateStrategy's own fallback, one level up.
            float? averageScore = scores.Length == 0 ? null : scores.Average();
            bool passed = (averageScore ?? 0f) >= gameFlow.SimulationPassingScore;
            float resolvedScore = averageScore ?? (passed ? 1f : 0f);

            completed = true;

            await sender.Send(passed ? Verbs.Passed : Verbs.Failed, passed
                ? SimulationStatementFactory.Passed(training, sessionTrainingId, resolvedScore)
                : SimulationStatementFactory.Failed(training, sessionTrainingId, resolvedScore));

            await sender.Send(Verbs.Completed, SimulationStatementFactory.Completed(training, sessionTrainingId, resolvedScore));
        }

        // The completed strategy ends the Simulation if it has no Next connection (nothing else in
        // the GameFlow lists it as Previous) and was authored to complete the Simulation - same
        // check as StrategyProgressController.EndsStrategy, one level up.
        bool EndsSimulation(TrainingStrategyData strategy)
        {
            if (!strategy.CompleteSimulation)
                return false;

            return !gameFlow.Strategies.Any(s => s.Previous.Contains(strategy.Id));
        }
    }
}
