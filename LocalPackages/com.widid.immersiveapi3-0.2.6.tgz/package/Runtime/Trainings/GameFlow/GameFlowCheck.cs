namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Whether a GameFlow call is allowed right now, and if not, why - so host game code can ask
    /// before calling (see TrainingRuntime.CanLaunchStrategy/CanLaunchStep) instead of discovering
    /// a sequencing rule from a rejected send after the fact. Converts implicitly to bool, so
    /// `if (TrainingRuntime.CanLaunchStep(step))` reads naturally while Reason stays available for
    /// a message.
    ///
    /// The same checks are what StrategyProgressController.Launch/StepProgressController.Launch
    /// themselves run, so a passing check and a successful call can't disagree.
    /// </summary>
    public readonly struct GameFlowCheck
    {
        public bool Allowed { get; }

        /// <summary>Why the call would be rejected. Null when Allowed.</summary>
        public string Reason { get; }

        GameFlowCheck(bool allowed, string reason)
        {
            Allowed = allowed;
            Reason = reason;
        }

        public static GameFlowCheck Ok() => new GameFlowCheck(true, null);
        public static GameFlowCheck No(string reason) => new GameFlowCheck(false, reason);

        public static implicit operator bool(GameFlowCheck check) => check.Allowed;
    }
}
