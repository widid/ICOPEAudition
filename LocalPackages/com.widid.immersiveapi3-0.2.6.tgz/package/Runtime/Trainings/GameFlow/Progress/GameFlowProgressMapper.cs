using System.Collections.Generic;
using WiDiD.ImmersiveAPI.Networking.Progression;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Turns the backend's stored jsonStep into per-step snapshots the runtime can seed itself
    /// with. "succeeded" is the backend's "was this step ever completed" flag, so it maps straight
    /// onto Completed; the pass/fail distinction is left to TrainingNodeProgress.Passed, which
    /// compares the restored Score against the step's own authored PassingScore - i.e. completed +
    /// highscore >= PassingScore reads as passed, completed + highscore below it as
    /// attempted-but-failed.
    ///
    /// Highscore, not Score: Score is the last attempt's result, Highscore the best one ever
    /// reached, and unlock state should reflect the best run rather than the most recent.
    /// </summary>
    public static class GameFlowProgressMapper
    {
        public static List<StepProgressSnapshot> ToStepSnapshots(ProgressionJsonStep jsonStep)
        {
            List<StepProgressSnapshot> snapshots = new List<StepProgressSnapshot>();

            if (jsonStep?.Sessions == null)
                return snapshots;

            foreach (ProgressionSession session in jsonStep.Sessions)
            {
                if (session?.Steps == null)
                    continue;

                foreach (ProgressionStep step in session.Steps)
                {
                    if (string.IsNullOrEmpty(step?.Current))
                        continue;

                    snapshots.Add(new StepProgressSnapshot(step.Current, step.Succeeded, step.Succeeded ? ScaledHighscore(step) : null));
                }
            }

            return snapshots;
        }

        // PassingScore is a 0..1 scaled threshold, so a step scored on a 0-100 percent scale has to
        // be brought back into that range before the two can be compared.
        static float ScaledHighscore(ProgressionStep step) => step.IsPercent ? step.Highscore / 100f : step.Highscore;
    }
}
