namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// One step's previously-stored state, as read back from the backend and handed to
    /// StepProgressController.RestoreProgress. Score is null when the step was never completed.
    /// </summary>
    public class StepProgressSnapshot
    {
        public string StepId { get; }
        public bool Completed { get; }
        public float? Score { get; }

        public StepProgressSnapshot(string stepId, bool completed, float? score)
        {
            StepId = stepId;
            Completed = completed;
            Score = score;
        }
    }
}
