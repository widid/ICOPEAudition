using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Developer-triggered sender for a Training's authored Skills (see TrainingSkillData) - host
    /// game code only ever calls Score (see TrainingRuntime.ScoreSkill); Progressed/Mastered are
    /// derived automatically from that same call:
    /// - Progressed fires whenever the newly resolved Scaled score is greater than this skill's
    ///   last known score (0 if it's never been scored before this call).
    /// - Mastered fires on every call where the newly resolved Scaled score is &gt;= 1 - not just the
    ///   first time it crosses that line, so calling Score again while already mastered sends
    ///   another Mastered statement each time.
    /// lastKnownScores is seeded from stored progress (see RestoreProgress), so Progressed only fires
    /// once a score beats what the user already reached in a previous session.
    /// </summary>
    public class SkillRecorder
    {
        readonly IStatementSender sender;
        readonly Dictionary<string, float> lastKnownScores = new();

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        public SkillRecorder(IStatementSender sender)
        {
            this.sender = sender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
        }

        /// <summary>TEMPORARY-STORED-PROGRESS: Seeds each skill's last known score and writes it back into its Scaled reflected source. Returns how many were found.</summary>
        public int RestoreProgress(IStoredProgress progress, ReflectedValueRestorer restorer)
        {
            int restored = 0;

            foreach (TrainingSkillData skill in gameFlow.Skills)
            {
                if (!progress.TryGetSkillScaled(SkillStatementFactory.Scored(simulation, skill).Uri, out float scaled))
                    continue;

                lastKnownScores[skill.Id] = scaled;
                restorer.Restore(skill.Scaled.WritableReflectedSource, scaled);
                restored++;
            }

            return restored;
        }

        public async Task<StatementSendResult> Score(string skillId)
        {
            TrainingSkillData skill = gameFlow.Skills.FirstOrDefault(s => s.Id == skillId);
            if (skill == null)
                return StatementSendResult.Rejection($"Unknown skill '{skillId}'.");

            StatementSendResult result = await sender.Send(Verbs.Scored, SkillStatementFactory.Scored(simulation, skill));

            float? newScore = skill.Scaled.Resolve();
            if (newScore.HasValue)
            {
                float previousScore = lastKnownScores.TryGetValue(skillId, out float stored) ? stored : 0f;

                if (newScore.Value > previousScore)
                {
                    try
                    {
                        await sender.Send(Verbs.Progressed, SkillStatementFactory.Progressed(simulation, skill));
                    }
                    catch (Exception exception)
                    {
                        Debug.LogError($"[SkillRecorder] Failed to auto-send Progressed for skill '{skillId}': {exception}");
                    }
                }

                if (newScore.Value >= 1f)
                {
                    try
                    {
                        await sender.Send(Verbs.Mastered, SkillStatementFactory.Mastered(simulation, skill));
                    }
                    catch (Exception exception)
                    {
                        Debug.LogError($"[SkillRecorder] Failed to auto-send Mastered for skill '{skillId}': {exception}");
                    }
                }

                lastKnownScores[skillId] = newScore.Value;
            }

            return result;
        }
    }
}
