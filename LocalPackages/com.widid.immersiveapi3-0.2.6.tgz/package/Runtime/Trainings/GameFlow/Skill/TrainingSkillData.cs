using System;
using UnityEngine;
using WiDiD.Localization;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one measurable Skill a Training reports (see
    /// xAPI-Statements/Skill/README.md) - Simulation-scoped only for now, living in the flat
    /// TrainingGameFlowData.Skills list. Extending to Strategy/Step scope later is the same small
    /// diff TrainingPerformanceData already went through: add a List&lt;TrainingSkillData&gt; Skills
    /// field to TrainingStrategyData/TrainingStepData and a matching editor section - nothing about
    /// this class itself needs to change for that.
    ///
    /// Categorization is two-tiered per spec: MainCategoryKey picks one of SkillCategories.All's
    /// predefined main categories (Hard skill/Soft skill - there's no wider library yet). The
    /// sub-category has no fixed catalog in WiDiD_XAPI at all, so it's authored freely here and
    /// turned into its own Activity by SkillStatementFactory.
    /// </summary>
    [Serializable]
    public class TrainingSkillData
    {
        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        [field: SerializeField] public string MainCategoryKey { get; set; } = nameof(SkillCategories.SoftSkill);

        [field: SerializeField] public string SubCategoryId { get; set; } = "1";
        [field: SerializeField] public LanguageDictionary SubCategoryName { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary SubCategoryDescription { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        [field: SerializeField] public PerformanceValueSource Scaled { get; set; } = new PerformanceValueSource();
    }
}
