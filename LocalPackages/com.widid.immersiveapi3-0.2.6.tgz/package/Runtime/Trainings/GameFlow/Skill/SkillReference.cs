using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick a Skill by name (via
    /// SkillReferenceDrawer, Editor-only) instead of hand-typing its raw GUID id.
    /// </summary>
    [Serializable]
    public class SkillReference
    {
        [SerializeField] private string skillId = string.Empty;
        public string SkillId => skillId;
    }
}
