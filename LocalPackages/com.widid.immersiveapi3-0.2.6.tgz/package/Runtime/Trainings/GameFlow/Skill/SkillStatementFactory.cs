using System;
using TinCan;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the xAPI Skill statementable Skill supports (see xAPI-Statements/Skill/README.md) -
    /// `progressed`/`scored`/`mastered` all carry the same data (Score/categories), just sent under
    /// a different verb depending on which moment triggers it; no lifecycle beyond that (unlike
    /// Step/Strategy). Host game code only ever asks for Scored - Progressed/Mastered are derived
    /// automatically from that call by SkillRecorder, never triggered directly.
    /// </summary>
    public static class SkillStatementFactory
    {
        // Matches SkillCategories' own (private) categoryType - xAPI's generic "category" activity
        // type, used for both the predefined main category and the freely-authored sub-category.
        static readonly Uri CategoryType = new("http://id.tincanapi.com/activitytype/category");

        public static Skill Progressed(Simulation simulation, TrainingSkillData data) => New(simulation, data);
        public static Skill Scored(Simulation simulation, TrainingSkillData data) => New(simulation, data);
        public static Skill Mastered(Simulation simulation, TrainingSkillData data) => New(simulation, data);

        static Skill New(Simulation simulation, TrainingSkillData data)
        {
            SkillSubCategory subCategory = new(ResolveMainCategory(data.MainCategoryKey), BuildSubCategoryActivity(data));
            Skill skill = new(data.Id, data.Name, data.Description, subCategory, simulation);
            skill.Score = data.Scaled.Resolve();
            return skill;
        }

        static Activity ResolveMainCategory(string key)
        {
            return SkillCategories.All.TryGetValue(key, out Activity category) ? category : SkillCategories.SoftSkill;
        }

        static Activity BuildSubCategoryActivity(TrainingSkillData data)
        {
            return new Activity
            {
                id = ImmersiveAPI_Tests.StatementableUriConfig.XapiUri + $"skillSubCategory/{data.SubCategoryId}",
                definition = new ActivityDefinition
                {
                    name = new LanguageMap(data.SubCategoryName.GetLanguageMap()),
                    description = new LanguageMap(data.SubCategoryDescription.GetLanguageMap()),
                    type = CategoryType
                }
            };
        }
    }
}
