using System;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the six xAPI Step statementables used to track a step's lifecycle - same shape and
    /// Result semantics as StrategyStatementFactory, just parented to a Strategy as well. Every
    /// verb but Launched takes a duration (elapsed time since this step's own Launched - see
    /// StepProgressController, which tracks that per step). Failed/Passed always carry a scaled
    /// score - callers resolve their own default (0/1) before calling, same as
    /// StrategyStatementFactory, so this always reports a real number rather than sometimes
    /// omitting result.score entirely.
    /// </summary>
    public static class StepStatementFactory
    {
        public static Step Launched(Simulation simulation, Strategy parentStrategy, TrainingStepData data) => New(simulation, parentStrategy, data);

        public static Step Progressed(Simulation simulation, Strategy parentStrategy, TrainingStepData data, float progress, TimeSpan? duration = null)
        {
            Step step = New(simulation, parentStrategy, data);
            step.Score = progress;
            step.Duration = duration;
            return step;
        }

        public static Step Failed(Simulation simulation, Strategy parentStrategy, TrainingStepData data, float score, TimeSpan? duration = null)
        {
            Step step = New(simulation, parentStrategy, data);
            step.Succeeded = false;
            step.Score = score;
            step.Duration = duration;
            return step;
        }

        public static Step Passed(Simulation simulation, Strategy parentStrategy, TrainingStepData data, float score, TimeSpan? duration = null)
        {
            Step step = New(simulation, parentStrategy, data);
            step.Succeeded = true;
            step.Score = score;
            step.Duration = duration;
            return step;
        }

        public static Step Completed(Simulation simulation, Strategy parentStrategy, TrainingStepData data, float? score = null, TimeSpan? duration = null)
        {
            Step step = New(simulation, parentStrategy, data);
            step.Completed = true;
            step.Score = score;
            step.Duration = duration;
            return step;
        }

        public static Step Exited(Simulation simulation, Strategy parentStrategy, TrainingStepData data, TimeSpan? duration = null)
        {
            Step step = New(simulation, parentStrategy, data);
            step.Duration = duration;
            return step;
        }

        // internal (not private): PerformanceRecorder also needs a bare parent Step reference when
        // building a Step-scoped Performance statementable, without that itself being a "Launched" event.
        internal static Step New(Simulation simulation, Strategy parentStrategy, TrainingStepData data) => new(data.Id, data.Name, data.Description, parentStrategy, simulation);
    }
}
