using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Owns step-level progress/unlock state and sends the six Step statements. Launch's own
    /// preconditions live in CanLaunch, which TrainingRuntime.CanLaunchStep exposes verbatim, so
    /// host game code can ask whether a step is startable instead of learning the rule from a
    /// rejected call. Only Complete marks
    /// a step Completed and re-evaluates step unlocks - Progressed/Exited never touch progress at
    /// all, and Failed/Passed only record Score (for reporting/aggregation) without completing the
    /// step or affecting unlocks. Fires StepCompleted so StrategyProgressController can aggregate
    /// the owning strategy's progress.
    ///
    /// Fail/Pass default their optional score to 0/1 respectively when the caller doesn't supply
    /// one, so Failed/Passed always carries a real scaled score rather than sometimes omitting
    /// result.score entirely - still fully overridable via the score parameter. Every statement but
    /// Launched also carries a duration: elapsed wall-clock time since this step's own Launched
    /// (see DurationSinceLaunched/TrainingNodeProgress.LaunchedAt).
    /// </summary>
    public class StepProgressController
    {
        public event Action<TrainingStrategyData, TrainingStepData> StepCompleted;

        public TrainingStepData Current { get; private set; }

        readonly Dictionary<string, TrainingNodeProgress> progress = new();
        readonly Dictionary<string, string> owningStrategyId = new();
        readonly IStatementSender sender;

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        public StepProgressController(IStatementSender sender)
        {
            this.sender = sender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
            Current = null;

            progress.Clear();
            owningStrategyId.Clear();

            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
            {
                foreach (TrainingStepData step in strategy.Steps)
                {
                    progress[step.Id] = new TrainingNodeProgress { PassingScore = step.PassingScore };
                    owningStrategyId[step.Id] = strategy.Id;
                }
            }

            RecomputeUnlocks();
        }

        /// <summary>
        /// TEMPORARY-STORED-PROGRESS.
        /// Seeds this play-through's progress with what the user already did in previous sessions
        /// (see GameFlowProgressMapper) - purely local state, no statement is sent for restored
        /// progress and StepCompleted deliberately does not fire, so nothing downstream mistakes a
        /// restored step for one that was just completed. Snapshots for steps that are no longer in
        /// the authored GameFlow are skipped; the returned count is how many actually matched a
        /// step, so a wholesale id mismatch between the two doesn't pass unnoticed.
        /// </summary>
        public int RestoreProgress(IReadOnlyList<StepProgressSnapshot> snapshots)
        {
            int restored = 0;

            foreach (StepProgressSnapshot snapshot in snapshots)
            {
                if (!progress.TryGetValue(snapshot.StepId, out TrainingNodeProgress nodeProgress))
                    continue;

                nodeProgress.Completed = snapshot.Completed;
                nodeProgress.Score = snapshot.Score;
                restored++;
            }

            RecomputeUnlocks();

            return restored;
        }

        public bool IsUnlocked(string stepId) => progress.TryGetValue(stepId, out TrainingNodeProgress nodeProgress) && nodeProgress.Unlocked;
        public bool IsCompleted(string stepId) => progress.TryGetValue(stepId, out TrainingNodeProgress nodeProgress) && nodeProgress.Completed;
        public float? GetScore(string stepId) => progress.TryGetValue(stepId, out TrainingNodeProgress nodeProgress) ? nodeProgress.Score : null;

        // Flat across every Strategy - Simulation-level progress (see SimulationProgressController)
        // needs the whole Training's step count, not just one strategy's own.
        public int TotalStepCount => progress.Count;
        public int CompletedStepCount => progress.Values.Count(nodeProgress => nodeProgress.Completed);

        /// <summary>
        /// Every precondition Launch enforces, as a question rather than a rejection. Single source
        /// of truth - Launch itself calls this rather than repeating the rules.
        /// </summary>
        public GameFlowCheck CanLaunch(string stepId, TrainingStrategyData currentStrategy)
        {
            if (!owningStrategyId.TryGetValue(stepId, out string strategyId))
                return GameFlowCheck.No($"Unknown step '{stepId}'.");

            if (currentStrategy == null || currentStrategy.Id != strategyId)
                return GameFlowCheck.No($"Launch strategy '{strategyId}' before launching step '{stepId}'.");

            if (!progress[stepId].Unlocked)
                return GameFlowCheck.No($"Step '{stepId}' is locked.");

            return GameFlowCheck.Ok();
        }

        public async Task<StatementSendResult> Launch(string stepId, TrainingStrategyData currentStrategy)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            GameFlowCheck check = CanLaunch(stepId, currentStrategy);
            if (!check)
                return StatementSendResult.Rejection(check.Reason);

            Current = step;
            progress[stepId].LaunchedAt = DateTime.UtcNow;

            return await sender.Send(Verbs.Launched, StepStatementFactory.Launched(simulation, ParentStrategy(owningStrategy), step));
        }

        public async Task<StatementSendResult> Progress(string stepId, float stepProgress)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            return await sender.Send(Verbs.Progressed, StepStatementFactory.Progressed(simulation, ParentStrategy(owningStrategy), step, stepProgress, DurationSinceLaunched(stepId)));
        }

        public async Task<StatementSendResult> Fail(string stepId, float? score = null)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            float resolvedScore = score ?? 0f;
            RecordScore(stepId, resolvedScore);

            return await sender.Send(Verbs.Failed, StepStatementFactory.Failed(simulation, ParentStrategy(owningStrategy), step, resolvedScore, DurationSinceLaunched(stepId)));
        }

        public async Task<StatementSendResult> Pass(string stepId, float? score = null)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            float resolvedScore = score ?? 1f;
            RecordScore(stepId, resolvedScore);

            return await sender.Send(Verbs.Passed, StepStatementFactory.Passed(simulation, ParentStrategy(owningStrategy), step, resolvedScore, DurationSinceLaunched(stepId)));
        }

        public async Task<StatementSendResult> Complete(string stepId, float? score = null)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            RecordScore(stepId, score);
            progress[stepId].Completed = true;
            RecomputeUnlocks();

            StatementSendResult result = await sender.Send(Verbs.Completed, StepStatementFactory.Completed(simulation, ParentStrategy(owningStrategy), step, score, DurationSinceLaunched(stepId)));
            StepCompleted?.Invoke(owningStrategy, step);
            return result;
        }

        public async Task<StatementSendResult> Exit(string stepId)
        {
            if (!TryGet(stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error))
                return error;

            return await sender.Send(Verbs.Exited, StepStatementFactory.Exited(simulation, ParentStrategy(owningStrategy), step, DurationSinceLaunched(stepId)));
        }

        void RecordScore(string stepId, float? score)
        {
            if (score.HasValue)
                progress[stepId].Score = score;
        }

        TimeSpan? DurationSinceLaunched(string stepId) => progress[stepId].LaunchedAt.HasValue ? DateTime.UtcNow - progress[stepId].LaunchedAt.Value : null;

        Strategy ParentStrategy(TrainingStrategyData owningStrategy) => StrategyStatementFactory.New(simulation, owningStrategy);

        bool TryGet(string stepId, out TrainingStepData step, out TrainingStrategyData owningStrategy, out StatementSendResult error)
        {
            step = null;
            owningStrategy = null;
            error = null;

            if (!owningStrategyId.TryGetValue(stepId, out string strategyId))
            {
                error = StatementSendResult.Rejection($"Unknown step '{stepId}'.");
                return false;
            }

            owningStrategy = gameFlow.Strategies.First(s => s.Id == strategyId);
            step = owningStrategy.Steps.First(s => s.Id == stepId);
            return true;
        }

        void RecomputeUnlocks()
        {
            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
            {
                foreach (TrainingStepData step in strategy.Steps)
                    progress[step.Id].Unlocked = GameFlowUnlockEvaluator.Evaluate(step.Previous, step.RequireAllPreviousCompleted, step.RequireAllPreviousPassed, progress);
            }
        }
    }
}
