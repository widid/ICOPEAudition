using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick a step by name (via
    /// StepReferenceDrawer, Editor-only) instead of hand-typing its raw id. Stores the step's
    /// stable GraphProcessor NodeGuid rather than its authored Id (see TrainingStepData.NodeGuid/
    /// StepNode.customId) - the Id can be edited after this reference is set, so resolving by
    /// NodeGuid (via TrainingRuntime, which does the actual NodeGuid -> current Id lookup) keeps
    /// this reference pointing at the right step even across a rename, instead of silently going
    /// stale.
    /// </summary>
    [Serializable]
    public class StepReference
    {
        [SerializeField] private string stepNodeGuid = string.Empty;
        public string StepNodeGuid => stepNodeGuid;
    }
}
