using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one step, authored via the nodal step-graph editor but never itself
    /// depending on it - see GameFlowGraph/StepGraph in the Editor assembly, which write into
    /// this shape rather than being it.
    /// </summary>
    [Serializable]
    public class TrainingStepData
    {
        // GraphProcessor's own BaseNode.GUID - see TrainingStrategyData.NodeGuid for why this is
        // kept separate from the editable Id below.
        [field: SerializeField] public string NodeGuid { get; set; } = string.Empty;

        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public List<string> Previous { get; set; } = new List<string>();

        // Same RequireAllPreviousCompleted shape as TrainingStrategyData - see the comment there.
        // RequireAllPreviousPassed is Step-only: gates on each Previous step's own Score having
        // met that step's own PassingScore (TrainingNodeProgress.Passed), not just Completed.
        [field: SerializeField] public bool RequireAllPreviousCompleted { get; set; } = true;
        [field: SerializeField] public bool RequireAllPreviousPassed { get; set; } = false;

        // Threshold this step's own recorded Score is compared against to decide Passed (see
        // TrainingNodeProgress.Passed) - used by downstream steps' RequireAllPreviousPassed check.
        [field: SerializeField] public float PassingScore { get; set; } = 0.5f;

        // When this step (only meaningful on one with no Next connection - see
        // StrategyProgressController) gets Completed, that ends its owning strategy: Passed/Failed
        // (average score of the strategy's completed steps) then Completed are sent for it,
        // regardless of whether every other step in the strategy is done.
        [field: SerializeField] public bool TriggersStrategyCompletion { get; set; } = false;

        // Performances scoped to this Step (see TrainingPerformanceData/PerformanceEditorWindow).
        // Unlike every field above, this has no matching representation on StepNode, so
        // StepGraph.Sync()/GameFlowGraph.Sync() must carry it forward by Id when they rebuild this
        // object from the graph, or it would be silently wiped on the next graph edit.
        [field: SerializeField] public List<TrainingPerformanceData> Performances { get; set; } = new List<TrainingPerformanceData>();

        // Interactions scoped to this Step (see TrainingInteractionData/InteractionEditorWindow) -
        // always developer-triggered via TrainingRuntime, never sent automatically. Same carry-
        // forward requirement as Performances above - StepGraph.Sync() must preserve it by Id.
        [field: SerializeField] public List<TrainingInteractionData> Interactions { get; set; } = new List<TrainingInteractionData>();
    }
}
