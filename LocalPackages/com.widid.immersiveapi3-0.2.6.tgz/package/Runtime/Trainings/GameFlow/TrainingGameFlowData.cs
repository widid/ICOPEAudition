using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Root of a Training's authored GameFlow (Strategies/Steps). Purely data - this is what the
    /// nodal graph editor (GameFlowGraph/StepGraph, Editor-only) writes into, never the other
    /// way around, so nothing at runtime ever needs to know the graph tooling exists.
    /// </summary>
    [Serializable]
    public class TrainingGameFlowData
    {
        [field: SerializeField] public List<TrainingStrategyData> Strategies { get; set; } = new List<TrainingStrategyData>();

        // Threshold the average score of every completed Strategy is compared against, once the
        // Simulation ends (see TrainingStrategyData.CompleteSimulation/SimulationProgressController),
        // to decide Passed_Simulation vs Failed_Simulation. Left visible in the default Inspector -
        // unlike Performances/Skills/Badges/Rewards below, it's a single scalar with no dedicated
        // editor window to justify hiding it.
        [field: SerializeField] public float SimulationPassingScore { get; set; } = 0.5f;

        // Hidden from the default Inspector - PerformanceEditorWindow is the only intended way to
        // edit this list (opened via TrainingSOEditor/TrainingEditorWindow).
        [field: SerializeField, HideInInspector] public List<TrainingPerformanceData> Performances { get; set; } = new List<TrainingPerformanceData>();

        // Hidden from the default Inspector - SkillEditorWindow is the only intended way to edit
        // this list (opened via TrainingSOEditor/TrainingEditorWindow).
        [field: SerializeField, HideInInspector] public List<TrainingSkillData> Skills { get; set; } = new List<TrainingSkillData>();

        // Hidden from the default Inspector - BadgeEditorWindow is the only intended way to edit
        // this list (opened via TrainingSOEditor/TrainingEditorWindow). Capped at 3 entries by that
        // window (see xAPI-Statements/Badge/README.md) - a Badge's Id is just its position here,
        // not authored, so there's nothing else to validate.
        [field: SerializeField, HideInInspector] public List<TrainingBadgeData> Badges { get; set; } = new List<TrainingBadgeData>();

        // Hidden from the default Inspector - RewardEditorWindow is the only intended way to edit
        // this list (opened via TrainingSOEditor/TrainingEditorWindow).
        [field: SerializeField, HideInInspector] public List<TrainingRewardData> Rewards { get; set; } = new List<TrainingRewardData>();
    }
}
