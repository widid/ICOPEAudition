namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    public interface IPerformanceValueLookup
    {
        /// <summary>The Raw value the next score would send, or null for an unknown performance or a disabled Raw.</summary>
        int? GetCurrentRaw(string performanceId);
    }
}
