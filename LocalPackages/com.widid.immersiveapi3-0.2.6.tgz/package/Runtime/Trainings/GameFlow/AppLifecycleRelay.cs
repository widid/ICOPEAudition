using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Forwards the two engine callbacks the termination path needs and a plain static class cannot
    /// have - a per-frame tick and OnApplicationPause - into SimulationTerminationFlusher, which
    /// owns all the actual logic. Same shape and reason as BadgeConditionTicker.
    /// SimulationTerminationHooks creates and owns the single instance; never placed in a scene.
    ///
    /// TerminatesOnPause is off unless the platform really needs it (see
    /// SimulationTerminationHooks for which do and why) - on desktop and in a browser, losing focus
    /// raises this same callback and must not end the session.
    /// </summary>
    class AppLifecycleRelay : MonoBehaviour
    {
        public SimulationTerminationFlusher Flusher { get; set; }

        /// <summary>Seconds between re-staged payloads; 0 or less never ticks.</summary>
        public float RefreshInterval { get; set; }

        public bool TerminatesOnPause { get; set; }

        float nextRefresh;

        void Update()
        {
            if (Flusher == null || RefreshInterval <= 0f || Time.unscaledTime < nextRefresh)
                return;

            nextRefresh = Time.unscaledTime + RefreshInterval;
            Flusher.Refresh();
        }

        void OnApplicationPause(bool paused)
        {
            if (paused && TerminatesOnPause)
                Flusher?.Flush(SimulationTerminationHooks.PauseTimeout);
        }
    }
}
