using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Read-only value lookups for a Training's statementables, for host code that needs to inspect
    /// values without sending anything. Every lookup returns null until TrainingRuntime is ready.
    /// </summary>
    public static class StatementableValues
    {
        static IPerformanceValueLookup performances;
        static IPerformanceServerValueLookup performanceServerValues; // TEMPORARY-STORED-PROGRESS

        internal static void Bind(IPerformanceValueLookup performanceLookup, IPerformanceServerValueLookup performanceServerLookup)
        {
            performances = performanceLookup;
            performanceServerValues = performanceServerLookup;
        }

        /// <summary>Raw value the next ScorePerformance would send; null when not ready, unknown or Raw is disabled.</summary>
        public static int? GetPerformanceCurrentRaw(PerformanceReference performance) => GetPerformanceCurrentRaw(performance.PerformanceId);
        public static int? GetPerformanceCurrentRaw(string performanceId) => performances?.GetCurrentRaw(performanceId);

        /// <summary>
        /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
        /// Raw value stored by previous sessions; null when not ready, not synced (TrainingPerformanceData.SyncWithServer) or none is stored.
        /// </summary>
        public static int? GetPerformanceServerRaw(PerformanceReference performance) => GetPerformanceServerRaw(performance.PerformanceId);
        public static int? GetPerformanceServerRaw(string performanceId) => performanceServerValues?.GetServerRaw(performanceId);
    }
}
