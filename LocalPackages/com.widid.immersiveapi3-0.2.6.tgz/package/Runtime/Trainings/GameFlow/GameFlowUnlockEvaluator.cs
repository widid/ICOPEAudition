using System.Collections.Generic;
using System.Linq;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Shared unlock-condition check, used identically by StrategyProgressController and
    /// StepProgressController - a node with no Previous is always unlocked; otherwise it depends
    /// on its own RequireAllPreviousCompleted/requireAllPassed settings against its Previous
    /// nodes' current progress. "Passed" means a previous node's own recorded Score met its own
    /// PassingScore (TrainingNodeProgress.Passed) - there's no separate minimum-score threshold
    /// authored on the downstream node anymore.
    /// </summary>
    public static class GameFlowUnlockEvaluator
    {
        public static bool Evaluate(List<string> previousIds, bool requireAllCompleted, bool requireAllPassed, Dictionary<string, TrainingNodeProgress> progress)
        {
            if (previousIds == null || previousIds.Count == 0)
                return true;

            List<TrainingNodeProgress> previousStates = previousIds
                .Where(progress.ContainsKey)
                .Select(id => progress[id])
                .ToList();

            if (requireAllCompleted && previousStates.Any(state => !state.Completed))
                return false;

            if (requireAllPassed && previousStates.Any(state => !state.Passed))
                return false;

            return true;
        }
    }
}
