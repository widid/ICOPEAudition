using System.Collections.Generic;
using TinCan;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Statements owed before Terminated_Simulation (see SimulationTerminationFlusher). Building them
    /// must not change any state, since the flusher may rebuild them many times before sending once.
    /// </summary>
    public interface IClosingStatementSource
    {
        IEnumerable<(Verb Verb, IStatementable Statementable)> BuildClosingStatements();
    }
}
