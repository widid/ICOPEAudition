using WiDiD.ImmersiveAPI.Trainings.GameFlow.Building;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// ToJson() sugar over <see cref="IGameFlowJsonExporter"/>, for the common case of exporting
    /// straight off a flow or a build result. Inject the interface instead when the exporter needs
    /// to be substituted.
    /// </summary>
    public static class GameFlowJsonExtensions
    {
        // Stateless, so one instance serves every call.
        static readonly IGameFlowJsonExporter Exporter = new GameFlowJsonExporter();

        public static string ToJson(this TrainingGameFlowData gameFlow, bool indented = true)
            => Exporter.Export(gameFlow, indented);

        /// <summary>
        /// Exports the built flow, or returns null when the build failed - a failed
        /// GameFlowBuildResult carries no GameFlow to export.
        /// </summary>
        public static string ToJson(this GameFlowBuildResult result, bool indented = true)
            => result.Succeeded ? Exporter.Export(result.GameFlow, indented) : null;
    }
}
