using System.Collections.Generic;
using Newtonsoft.Json;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// Root of the exported gameflow.json: { sessions }. Same shape the trainings/{id}/json-step
    /// endpoint returns, so an export can be handed to anything that already consumes that.
    /// </summary>
    public class GameFlowJsonRoot
    {
        [JsonProperty("sessions")] public List<GameFlowJsonSession> Sessions { get; set; } = new List<GameFlowJsonSession>();
    }
}
