using System.Collections.Generic;
using Newtonsoft.Json;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// One step in the exported gameflow.json. Property names are mapped explicitly rather than
    /// relying on Newtonsoft's default casing, so the emitted keys stay locked to the shape the
    /// old ImmersiveAPI system expects regardless of any serializer settings the host app sets.
    /// </summary>
    public class GameFlowJsonStep
    {
        [JsonProperty("current")] public string Current { get; set; }

        [JsonProperty("previous")] public List<string> Previous { get; set; } = new List<string>();

        [JsonProperty("name")] public Dictionary<string, string> Name { get; set; } = new Dictionary<string, string>();

        [JsonProperty("succeeded")] public bool Succeeded { get; set; }

        [JsonProperty("score")] public float Score { get; set; }

        [JsonProperty("highscore")] public float Highscore { get; set; }
    }
}
