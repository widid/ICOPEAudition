namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// Serializes a TrainingGameFlowData to the old ImmersiveAPI system's gameflow.json shape
    /// (sessions/steps keyed by current/previous). Lives in the Runtime assembly so a shipped
    /// player can export, not just the Editor inspector.
    /// </summary>
    public interface IGameFlowJsonExporter
    {
        /// <summary>Exported JSON. Returns null when there is no flow to export.</summary>
        string Export(TrainingGameFlowData gameFlow, bool indented = true);

        /// <summary>
        /// The same export as an object graph, for embedding in a larger payload instead of
        /// serializing it straight to a string.
        /// </summary>
        GameFlowJsonRoot ToDto(TrainingGameFlowData gameFlow);
    }
}
