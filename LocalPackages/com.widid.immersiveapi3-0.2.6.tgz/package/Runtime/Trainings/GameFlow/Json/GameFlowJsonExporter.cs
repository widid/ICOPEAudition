using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// The shape is the old ImmersiveAPI system's gameflow.json - sessions/steps keyed by
    /// current/previous, name as a flat language-code map, plus succeeded/score/highscore - kept
    /// because other tools still consume it. A Strategy is a "session" there (see
    /// TrainingStrategyData).
    ///
    /// Exports the AUTHORED Strategy/Step structure only: succeeded/score/highscore are always
    /// false/0/0, since this system doesn't persist progress this way (see TrainingNodeProgress,
    /// in-memory only). Feeding a play-through's real progress back into those fields would need
    /// StepProgressController's state passed in - deliberately not done here, so an export stays
    /// reproducible from the flow alone.
    /// </summary>
    public class GameFlowJsonExporter : IGameFlowJsonExporter
    {
        public string Export(TrainingGameFlowData gameFlow, bool indented = true)
        {
            if (gameFlow == null)
                return null;

            return JsonConvert.SerializeObject(ToDto(gameFlow), indented ? Formatting.Indented : Formatting.None);
        }

        public GameFlowJsonRoot ToDto(TrainingGameFlowData gameFlow)
        {
            return new GameFlowJsonRoot
            {
                Sessions = gameFlow == null
                    ? new List<GameFlowJsonSession>()
                    : gameFlow.Strategies.Select(ToSession).ToList()
            };
        }

        static GameFlowJsonSession ToSession(TrainingStrategyData strategy)
        {
            return new GameFlowJsonSession
            {
                Current = strategy.Id,
                Previous = Copy(strategy.Previous),
                Name = LanguageMap(strategy.Name),
                Steps = strategy.Steps == null
                    ? new List<GameFlowJsonStep>()
                    : strategy.Steps.Select(ToStep).ToList()
            };
        }

        static GameFlowJsonStep ToStep(TrainingStepData step)
        {
            return new GameFlowJsonStep
            {
                Current = step.Id,
                Previous = Copy(step.Previous),
                Name = LanguageMap(step.Name),
                Succeeded = false,
                Score = 0f,
                Highscore = 0f
            };
        }

        // Copied rather than referenced so a caller mutating the export can't reach back into the
        // TrainingGameFlowData it came from.
        static List<string> Copy(List<string> ids) => ids == null ? new List<string>() : new List<string>(ids);

        static Dictionary<string, string> LanguageMap(LanguageDictionary name)
            => name?.GetLanguageMap() ?? new Dictionary<string, string>();
    }
}
