using System.Collections.Generic;
using Newtonsoft.Json;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Json
{
    /// <summary>
    /// One session in the exported gameflow.json - a Strategy, under the old ImmersiveAPI system's
    /// name for it (see TrainingStrategyData).
    /// </summary>
    public class GameFlowJsonSession
    {
        [JsonProperty("current")] public string Current { get; set; }

        [JsonProperty("previous")] public List<string> Previous { get; set; } = new List<string>();

        [JsonProperty("name")] public Dictionary<string, string> Name { get; set; } = new Dictionary<string, string>();

        [JsonProperty("steps")] public List<GameFlowJsonStep> Steps { get; set; } = new List<GameFlowJsonStep>();
    }
}
