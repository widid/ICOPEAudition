using System;
using System.Collections.Generic;
using System.Linq;
using TinCan;
using WiDiD.ImmersiveAPI.Actors;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables.Interfaces;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds statements using the real signed-in user as actor. DefaultStatementBuilderProfile
    /// (WiDiD.XAPI) hardcodes a fake demo agent (ImmersiveAPI_Tests.UserIdentity, "John Doe") -
    /// this mirrors its context/result-building logic exactly, just sourced from a real session
    /// instead. How that actor is identified isn't decided here: it's built by ActorFactory from a
    /// setting and passed in ready-made. xapiSessionId is generated fresh per app run (one "attempt"
    /// of the Training) - not to be confused with a GameFlow Session. registration is NOT generated
    /// - nothing populates UserSessionData.Registration yet, so it's simply omitted from every
    /// statement until something does (same "parse or omit" rule DemoStatementFactory already uses
    /// for its own Registration field) - no statement should carry a made-up registration value.
    /// </summary>
    public class RuntimeStatementBuilderProfile : IStatementBuilderProfile
    {
        readonly Agent actor;
        readonly Guid? registration;
        readonly Guid xapiSessionId;

        /// <summary>Actor resolved from local session data only - no profile fetch (see ActorFactory.FromLocalSession).</summary>
        public RuntimeStatementBuilderProfile(UserSessionData sessionData)
            : this(sessionData, ActorFactory.FromLocalSession(sessionData))
        {
        }

        public RuntimeStatementBuilderProfile(UserSessionData sessionData, Agent actor)
        {
            this.actor = actor;
            registration = Guid.TryParse(sessionData.Registration, out Guid parsedRegistration) ? parsedRegistration : null;
            xapiSessionId = Guid.NewGuid();
        }

        public StatementBuilder CreateBuilderProfile(Verb verb, IStatementable statementable)
        {
            Activity activity = statementable is IActivity act ? act.Activity : new Activity();
            List<Attachment> attachments = statementable is IAttachmentable attachmentable ? attachmentable.GetAttachments() : null;
            Context context = BuildContext(statementable);
            Result result = Verbs.ShouldDisplayResult(verb) ? BuildResult(statementable) : null;

            return StatementBuilder.Create()
                .WithActor(actor)
                .WithVerb(verb)
                .WithObject(activity)
                .WithContext(context)
                .WithResult(result)
                .WithAttachments(attachments);
        }

        Context BuildContext(IStatementable statementable)
        {
            Context context = new()
            {
                platform = "WiDiD Immersive",
                registration = registration,
                language = "en-US",
                extensions = ExtensionsBuilder.Create()
                    .WithExtension(ExtensionsLibrary.SessionId, xapiSessionId)
                    .WithDeviceContext(DeviceContextDetector.Current)
                    .Build()
            };

            if (statementable is IParented parented && parented.Parents != null)
            {
                context.contextActivities ??= new ContextActivities();
                context.contextActivities.parent = parented.Parents.Select(p => p.Activity).ToList();
            }

            if (statementable is ICategorisable categorisable)
            {
                context.contextActivities ??= new ContextActivities();
                context.contextActivities.category = categorisable.GetCategories().ToList();
            }

            return context;
        }

        static Result BuildResult(IStatementable statementable)
        {
            if (statementable is IResultable resultable)
                return resultable.GetResult();

            if (statementable is IScorable scorable)
                return new Result { score = scorable.GetScore() };

            return null;
        }
    }
}
