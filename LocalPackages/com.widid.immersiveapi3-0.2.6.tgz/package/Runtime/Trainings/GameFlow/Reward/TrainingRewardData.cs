using System;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one measurable Reward a Training reports (see
    /// xAPI-Statements/Reward/README.md) - Simulation-scoped, living in
    /// TrainingGameFlowData.Rewards. Score is authored the same way as Performance's - fixed
    /// constant or live reflected source, float for Scaled (see PerformanceValueSource/
    /// ReflectedFloatSourceSO), int for Raw/Min/Max (see PerformanceIntValueSource/
    /// ReflectedIntSourceSO, matching xAPI's int-only Score.raw/min/max) - resolved at trigger time
    /// by RewardStatementFactory. Unlike Performance, nothing auto-triggers this: host game code
    /// calls TrainingRuntime.ScoreReward whenever points are actually awarded (see
    /// xAPI-Statements/Reward's "in any context within a Simulation"), which is why the same Id can
    /// legitimately be scored many times over a session (see that README's dashboard aggregation
    /// rule) rather than just once.
    /// </summary>
    [Serializable]
    public class TrainingRewardData
    {
        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        [field: SerializeField] public PerformanceValueSource Scaled { get; set; } = new PerformanceValueSource();
        [field: SerializeField] public PerformanceIntValueSource Raw { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Min { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Max { get; set; } = new PerformanceIntValueSource();
    }
}
