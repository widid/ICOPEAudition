using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick a Reward by name (via
    /// RewardReferenceDrawer, Editor-only) instead of hand-typing its raw GUID id. Resolves to that
    /// id at runtime for TrainingRuntime.ScoreReward.
    /// </summary>
    [Serializable]
    public class RewardReference
    {
        [SerializeField] private string rewardId = string.Empty;
        public string RewardId => rewardId;
    }
}
