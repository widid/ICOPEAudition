using System.Linq;
using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Developer-triggered sender for a Training's authored Rewards (see TrainingRewardData) -
    /// nothing here fires automatically: host game code decides exactly when points are awarded
    /// (see TrainingRuntime.ScoreReward), same convention as InteractionRecorder. The same reward Id
    /// can legitimately be sent many times over a session - each Score call reflects whatever
    /// Scaled/Raw/Min/Max currently resolve to (fixed or live reflected value).
    /// </summary>
    public class RewardRecorder
    {
        readonly IStatementSender sender;

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        public RewardRecorder(IStatementSender sender)
        {
            this.sender = sender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
        }

        /// <summary>TEMPORARY-STORED-PROGRESS: Writes each stored total into its reward's RestoreTarget. Returns how many were found.</summary>
        public int RestoreProgress(IStoredProgress progress, ReflectedValueRestorer restorer)
        {
            int restored = 0;

            foreach (TrainingRewardData reward in gameFlow.Rewards)
            {
                if (!progress.TryGetRewardRaw(RewardStatementFactory.Scored(simulation, reward).Uri, out int raw))
                    continue;

                restorer.Restore(reward.RestoreTarget, raw);
                restored++;
            }

            return restored;
        }

        public async Task<StatementSendResult> Score(string rewardId)
        {
            TrainingRewardData reward = gameFlow.Rewards.FirstOrDefault(r => r.Id == rewardId);
            if (reward == null)
                return StatementSendResult.Rejection($"Unknown reward '{rewardId}'.");

            return await sender.Send(Verbs.Scored, RewardStatementFactory.Scored(simulation, reward));
        }
    }
}
