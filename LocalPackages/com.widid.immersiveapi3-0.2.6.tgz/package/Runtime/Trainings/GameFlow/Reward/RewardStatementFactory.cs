using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the single xAPI Reward statementable Reward supports - verb `scored`, no lifecycle
    /// (see xAPI-Statements/Reward/README.md). Simulation-scoped only - Reward has no Strategy/Step
    /// parenting, unlike Performance.
    /// </summary>
    public static class RewardStatementFactory
    {
        public static Reward Scored(Simulation simulation, TrainingRewardData data)
        {
            Reward reward = new(data.Id, data.Name, data.Description, simulation);

            reward.Score = data.Scaled.Resolve();
            reward.ScoreRaw = data.Raw.Resolve();
            reward.MinScoreRaw = data.Min.Resolve();
            reward.MaxScoreRaw = data.Max.Resolve();

            return reward;
        }
    }
}
