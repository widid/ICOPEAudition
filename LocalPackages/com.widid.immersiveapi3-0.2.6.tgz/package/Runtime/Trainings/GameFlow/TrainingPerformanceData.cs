using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Plain data for one measurable Performance a Training reports. A flat entry rather than a
    /// graph node - Performance has no topology (see xAPI-Statements/Performance/README.md). Scope
    /// comes purely from which container an entry lives in (TrainingStepData.Performances,
    /// TrainingStrategyData.Performances, or the top-level TrainingGameFlowData.Performances for
    /// Simulation-scoped/global ones) rather than a self-referential id, so there's no way for an
    /// entry to point at a scope it doesn't actually live under. Scaled/Raw/Min/Max/Response are
    /// each independently optional and independently either a fixed authored constant or a live
    /// reflected source - Scaled is float (see PerformanceValueSource/ReflectedFloatSourceSO, xAPI's
    /// Score.scaled is a float), Raw/Min/Max are int (see PerformanceIntValueSource/
    /// ReflectedIntSourceSO, matching Score.raw/min/max) - read by PerformanceRecorder at trigger
    /// time, no manual call from host game code.
    /// </summary>
    [Serializable]
    public class TrainingPerformanceData
    {
        [field: SerializeField] public string Id { get; set; } = string.Empty;
        [field: SerializeField] public LanguageDictionary Name { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary Description { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public string Unit { get; set; } = string.Empty;

        // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md): SyncWithServer through AppliesServerValue.
        /// <summary>Whether the Raw value stored by previous sessions is read when the session starts (see StatementableValues.GetPerformanceServerRaw).</summary>
        [field: SerializeField] public bool SyncWithServer { get; set; }

        /// <summary>Whether that stored Raw value is also written into Raw's reflected source.</summary>
        [field: SerializeField] public bool ApplyServerValue { get; set; }

        /// <summary>Whether this performance is scored automatically before the session terminates if it wasn't scored during it.</summary>
        [field: SerializeField] public bool SendOnClose { get; set; }

        public bool SendsOnClose => SyncWithServer && SendOnClose;
        public bool AppliesServerValue => SyncWithServer && ApplyServerValue;

        [field: SerializeField] public PerformanceValueSource Scaled { get; set; } = new PerformanceValueSource();
        [field: SerializeField] public PerformanceIntValueSource Raw { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Min { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceIntValueSource Max { get; set; } = new PerformanceIntValueSource();
        [field: SerializeField] public PerformanceStringValueSource Response { get; set; } = new PerformanceStringValueSource();

        [field: SerializeField] public List<PerformanceAttachmentSource> Attachments { get; set; } = new List<PerformanceAttachmentSource>();
    }
}
