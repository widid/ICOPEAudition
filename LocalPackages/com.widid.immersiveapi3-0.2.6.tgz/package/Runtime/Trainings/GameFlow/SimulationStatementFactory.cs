using System;
using WiDiD.Localization;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the Simulation statementable for a Training - see TrainingRuntime/
    /// SimulationProgressController for when each of these actually gets sent. Mirrors
    /// StrategyStatementFactory/StepStatementFactory's shape, using Simulation's own Progression
    /// (IScorable) in place of Score, since Simulation has no plain Score property. Failed/Passed
    /// always carry a scaled score - callers resolve their own default (0/1) before calling, same
    /// as StrategyStatementFactory/StepStatementFactory.
    ///
    /// The Simulation's id is the backend's numeric training id (UserSessionData.TrainingId, e.g.
    /// via TrainingRuntime), not the local TrainingSO's own Id - it needs to match whatever the
    /// statement actually gets posted against remotely. Falls back to the local Id if no session
    /// training id is available yet (e.g. previewing before ever logging in/linking a training).
    /// Name/Description come from TrainingData.LocalizedName/LocalizedDescription (see
    /// TrainingLocalizationService, cached by TrainingEditorWindow) - falling back to a plain
    /// single-language name built from the local Id, and an empty description, if never fetched.
    /// </summary>
    public static class SimulationStatementFactory
    {
        public static Simulation Initialized(TrainingSO training, string sessionTrainingId) => New(training, sessionTrainingId);

        public static Simulation Progressed(TrainingSO training, string sessionTrainingId, float progress)
        {
            Simulation simulation = New(training, sessionTrainingId);
            simulation.Progression = progress;
            return simulation;
        }

        public static Simulation Failed(TrainingSO training, string sessionTrainingId, float score)
        {
            Simulation simulation = New(training, sessionTrainingId);
            simulation.Succeeded = false;
            simulation.Progression = score;
            return simulation;
        }

        public static Simulation Passed(TrainingSO training, string sessionTrainingId, float score)
        {
            Simulation simulation = New(training, sessionTrainingId);
            simulation.Succeeded = true;
            simulation.Progression = score;
            return simulation;
        }

        public static Simulation Completed(TrainingSO training, string sessionTrainingId, float? score = null)
        {
            Simulation simulation = New(training, sessionTrainingId);
            simulation.Completed = true;
            simulation.Progression = score;
            return simulation;
        }

        public static Simulation Exited(TrainingSO training, string sessionTrainingId) => New(training, sessionTrainingId);

        public static Simulation Terminated(TrainingSO training, string sessionTrainingId, TimeSpan? duration = null)
        {
            Simulation simulation = New(training, sessionTrainingId);
            simulation.Duration = duration;
            return simulation;
        }

        static Simulation New(TrainingSO training, string sessionTrainingId)
        {
            string id = !string.IsNullOrEmpty(sessionTrainingId) ? sessionTrainingId : training.Data.Id;
            return new Simulation(id, ResolveName(training), ResolveDescription(training));
        }

        static LanguageDictionary ResolveName(TrainingSO training)
        {
            return HasAnyTranslation(training.Data.LocalizedName) ? training.Data.LocalizedName : BuildName(training.Data.Id);
        }

        static LanguageDictionary ResolveDescription(TrainingSO training)
        {
            return HasAnyTranslation(training.Data.LocalizedDescription) ? training.Data.LocalizedDescription : EmptyDescription();
        }

        static bool HasAnyTranslation(LanguageDictionary dictionary) => dictionary.GetLanguageMap().Count > 0;

        static LanguageDictionary BuildName(string text)
        {
            return new LanguageDictionary(
                new[] { new LanguageDictionary.LanguageKey { localizationIndex = 0, value = text } },
                new[] { 0 });
        }

        static LanguageDictionary EmptyDescription() => new(Array.Empty<LanguageDictionary.LanguageKey>(), Array.Empty<int>());
    }
}
