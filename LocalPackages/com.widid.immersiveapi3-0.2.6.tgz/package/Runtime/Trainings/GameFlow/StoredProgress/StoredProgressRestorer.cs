using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Seeds every recorder from previous sessions' progress at initialization. Best-effort: a failed
    /// fetch leaves the GameFlow as authored.
    /// </summary>
    public class StoredProgressRestorer
    {
        readonly StepProgressController steps;
        readonly StrategyProgressController strategies;
        readonly PerformanceServerSync performances;
        readonly SkillRecorder skills;
        readonly RewardRecorder rewards;
        readonly BadgeRecorder badges;

        public StoredProgressRestorer(StepProgressController steps, StrategyProgressController strategies, PerformanceServerSync performances, SkillRecorder skills, RewardRecorder rewards, BadgeRecorder badges)
        {
            this.steps = steps;
            this.strategies = strategies;
            this.performances = performances;
            this.skills = skills;
            this.rewards = rewards;
            this.badges = badges;
        }

        public async Task Restore(IStoredProgressSource source)
        {
            IStoredProgress progress = await source.Fetch();

            if (progress == null)
            {
                Debug.LogWarning("[TrainingRuntime] No stored progression could be read - starting from the authored GameFlow state.");
                return;
            }

            int restoredSteps = steps.RestoreProgress(progress.Steps);
            strategies.RestoreProgress();

            ReflectedValueRestorer restorer = new ReflectedValueRestorer();
            int restoredPerformances = performances.RestoreProgress(progress, restorer);
            int restoredSkills = skills.RestoreProgress(progress, restorer);
            int restoredRewards = rewards.RestoreProgress(progress, restorer);
            int restoredBadges = badges.RestoreProgress(progress);

            Debug.Log($"[TrainingRuntime] Restored {restoredSteps}/{progress.Steps.Count} step(s) ({progress.Steps.Count(snapshot => snapshot.Completed)} completed), {restoredPerformances} performance(s), {restoredSkills} skill(s), {restoredRewards} reward(s), {restoredBadges} badge(s).");
        }
    }
}
