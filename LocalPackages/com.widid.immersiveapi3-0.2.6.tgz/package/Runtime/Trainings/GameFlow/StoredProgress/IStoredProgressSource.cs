using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md). Where previous sessions' progress is read from.</summary>
    public interface IStoredProgressSource
    {
        /// <summary>Returns null when no stored progress could be read.</summary>
        Task<IStoredProgress> Fetch();
    }
}
