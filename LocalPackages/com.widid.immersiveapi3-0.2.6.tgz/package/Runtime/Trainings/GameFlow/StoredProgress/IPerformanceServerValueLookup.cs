namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).</summary>
    public interface IPerformanceServerValueLookup
    {
        /// <summary>The Raw value stored by previous sessions, or null when the performance isn't synced or has none.</summary>
        int? GetServerRaw(string performanceId);
    }
}
