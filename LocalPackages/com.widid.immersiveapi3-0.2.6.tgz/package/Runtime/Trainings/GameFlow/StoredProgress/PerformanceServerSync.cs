using System;
using System.Collections.Generic;
using TinCan;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// The per-performance Sync / Apply / Send-on-close behaviour (TrainingPerformanceData.SyncWithServer,
    /// ApplyServerValue, SendOnClose): keeps each synced performance's stored Raw value, optionally
    /// writes it into Raw's reflected source, and owes a scored statement before Terminated_Simulation
    /// for every SendsOnClose performance not scored this session. Closing statements are built at
    /// teardown, when nothing can be uploaded, so they carry no attachments.
    /// </summary>
    public class PerformanceServerSync : IClosingStatementSource, IPerformanceServerValueLookup
    {
        readonly HashSet<string> scoredThisSession = new();
        readonly Dictionary<string, int> serverRawValues = new();

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        /// <summary>Raised whenever the set of statements BuildClosingStatements returns changes.</summary>
        public event Action ClosingStatementsChanged;

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
        }

        /// <summary>Hooked to PerformanceRecorder.Scored.</summary>
        public void MarkScored(string performanceId)
        {
            if (scoredThisSession.Add(performanceId))
                ClosingStatementsChanged?.Invoke();
        }

        /// <summary>Keeps every synced performance's stored Raw value and applies it where asked. Returns how many were found.</summary>
        public int RestoreProgress(IStoredProgress progress, ReflectedValueRestorer restorer)
        {
            int restored = 0;

            foreach ((TrainingPerformanceData performance, Step parentStep, Strategy parentStrategy) in PerformanceScopes.Enumerate(gameFlow, simulation))
            {
                if (!performance.SyncWithServer)
                    continue;

                Uri uri = PerformanceStatementFactory.Scored(simulation, performance, parentStep: parentStep, parentStrategy: parentStrategy).Uri;
                if (!progress.TryGetPerformanceRaw(uri, out int raw))
                    continue;

                serverRawValues[performance.Id] = raw;

                if (performance.AppliesServerValue)
                    restorer.Restore(performance.Raw.WritableReflectedSource, raw);

                restored++;
            }

            return restored;
        }

        public int? GetServerRaw(string performanceId) => serverRawValues.TryGetValue(performanceId, out int raw) ? raw : null;

        public IEnumerable<(Verb Verb, IStatementable Statementable)> BuildClosingStatements()
        {
            foreach ((TrainingPerformanceData performance, Step parentStep, Strategy parentStrategy) in PerformanceScopes.Enumerate(gameFlow, simulation))
            {
                if (performance.SendsOnClose && !scoredThisSession.Contains(performance.Id))
                    yield return (Verbs.Scored, PerformanceStatementFactory.Scored(simulation, performance, parentStep: parentStep, parentStrategy: parentStrategy));
            }
        }
    }
}
