using System;
using System.Collections.Generic;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// What this user already achieved in previous sessions, looked up by each statementable's xAPI
    /// activity URI (see XapiUriHelper) so the recorders stay independent of where it was read from.
    /// </summary>
    public interface IStoredProgress
    {
        IReadOnlyList<StepProgressSnapshot> Steps { get; }

        bool TryGetPerformanceRaw(Uri performanceUri, out int raw);
        bool TryGetSkillScaled(Uri skillUri, out float scaled);
        bool TryGetRewardRaw(Uri rewardUri, out int raw);
        bool HasReceivedBadge(int slotNumber);
    }
}
