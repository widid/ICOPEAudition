using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Writes restored values into reflected sources. A write whose scene target isn't loaded yet is
    /// kept and retried on every scene load until it lands; a read-only member is skipped.
    /// </summary>
    public class ReflectedValueRestorer
    {
        readonly List<(ReflectedValueSourceData Data, object Value)> pending = new();

        public void Restore(IReflectedValueSource source, object value)
        {
            if (source == null)
                return;

            if (!ReflectedValueWriter.CanWrite(source.Data))
            {
                Debug.LogWarning($"[ReflectedValueRestorer] '{source.Data.MemberPath}' is read-only - the restored value is not applied.");
                return;
            }

            if (TryWrite(source.Data, value))
                return;

            if (pending.Count == 0)
                SceneManager.sceneLoaded += HandleSceneLoaded;

            pending.Add((source.Data, value));
        }

        void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            pending.RemoveAll(write => TryWrite(write.Data, write.Value));

            if (pending.Count == 0)
                SceneManager.sceneLoaded -= HandleSceneLoaded;
        }

        // A write that throws is misconfigured (e.g. a type mismatch) and is dropped rather than retried.
        static bool TryWrite(ReflectedValueSourceData data, object value)
        {
            try
            {
                return ReflectedValueWriter.TrySetValue(data, value);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[ReflectedValueRestorer] Failed to restore '{data.MemberPath}': {exception}");
                return true;
            }
        }
    }
}
