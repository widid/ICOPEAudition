using System.Collections.Generic;
using System.Linq;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Installs a built flow the same way GameFlowGraph.Sync() does on the Editor side: only
    /// Strategies and SimulationPassingScore are replaced, and each strategy's/step's
    /// Performances and Interactions are carried forward by id from whatever was already on the
    /// training. The builder authors structure only, so without that carry-forward a code-built
    /// flow would silently wipe everything the Performance/Interaction editor windows own.
    /// </summary>
    public class GameFlowInstaller : IGameFlowInstaller
    {
        public GameFlowCheck Install(TrainingSO training, TrainingGameFlowData gameFlow)
        {
            if (training == null)
                return GameFlowCheck.No("No TrainingSO to install into.");

            if (gameFlow == null)
                return GameFlowCheck.No("No GameFlow to install - check GameFlowBuildResult.Succeeded first.");

            if (TrainingRuntime.IsReady)
                return GameFlowCheck.No("TrainingRuntime is already tracking a GameFlow. Install before the session starts, since its controllers are configured once against the flow they find.");

            TrainingGameFlowData target = training.Data.GameFlow;

            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
                CarryForward(strategy, target.Strategies.FirstOrDefault(existing => existing.Id == strategy.Id));

            target.Strategies = gameFlow.Strategies;
            target.SimulationPassingScore = gameFlow.SimulationPassingScore;

            return GameFlowCheck.Ok();
        }

        static void CarryForward(TrainingStrategyData strategy, TrainingStrategyData existing)
        {
            if (existing == null)
                return;

            strategy.Performances = existing.Performances ?? new List<TrainingPerformanceData>();

            foreach (TrainingStepData step in strategy.Steps)
            {
                TrainingStepData existingStep = existing.Steps?.FirstOrDefault(other => other.Id == step.Id);
                if (existingStep == null)
                    continue;

                step.Performances = existingStep.Performances ?? new List<TrainingPerformanceData>();
                step.Interactions = existingStep.Interactions ?? new List<TrainingInteractionData>();
            }
        }
    }
}
