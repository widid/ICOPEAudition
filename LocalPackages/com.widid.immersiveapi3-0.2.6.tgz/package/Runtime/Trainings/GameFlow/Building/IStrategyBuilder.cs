using System;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Fluent authoring surface for one strategy (the "session" of the old ImmersiveAPI system -
    /// see TrainingStrategyData) and its steps. Step returns this same builder so sibling steps
    /// chain, while each step's own settings are configured inside its callback - that keeps which
    /// strategy a step belongs to unambiguous, unlike a flat chain.
    /// </summary>
    public interface IStrategyBuilder
    {
        /// <summary>Adds or replaces the display name for one language code (en/fr/it/es/de/pt).</summary>
        IStrategyBuilder Named(string language, string value);

        IStrategyBuilder Named(LanguageDictionary name);

        IStrategyBuilder Described(string language, string value);

        IStrategyBuilder Described(LanguageDictionary description);

        /// <summary>Ids of the strategies that must precede this one.</summary>
        IStrategyBuilder After(params string[] previousStrategyIds);

        IStrategyBuilder RequirePreviousCompleted(bool require = true);

        IStrategyBuilder RequirePreviousPassed(bool require = true);

        /// <summary>
        /// Threshold in [0,1] the average of this strategy's completed steps' scores is compared
        /// against to decide Passed vs Failed.
        /// </summary>
        IStrategyBuilder PassingScore(float passingScore);

        /// <summary>
        /// Marks this strategy as the one whose completion ends the whole Simulation. Only fires on
        /// a strategy no other strategy lists as Previous.
        /// </summary>
        IStrategyBuilder CompletesSimulation(bool completes = true);

        /// <summary>Declares a step of this strategy. Step ids must be unique across the whole Training.</summary>
        IStrategyBuilder Step(string id, Action<IStepBuilder> configure = null);
    }
}
