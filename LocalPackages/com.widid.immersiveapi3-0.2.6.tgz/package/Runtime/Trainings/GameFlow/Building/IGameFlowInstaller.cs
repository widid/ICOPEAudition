namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Applies a built GameFlow onto a TrainingSO so TrainingRuntime tracks it. In-memory only -
    /// it mutates the loaded ScriptableObject instance and never writes the asset, so the same call
    /// behaves identically in a player and in the Editor.
    /// </summary>
    public interface IGameFlowInstaller
    {
        /// <summary>
        /// Replaces the training's Strategies and SimulationPassingScore. Rejected once
        /// TrainingRuntime is ready, since its controllers have already been configured against
        /// the previous flow - install before the session starts.
        /// </summary>
        GameFlowCheck Install(TrainingSO training, TrainingGameFlowData gameFlow);
    }
}
