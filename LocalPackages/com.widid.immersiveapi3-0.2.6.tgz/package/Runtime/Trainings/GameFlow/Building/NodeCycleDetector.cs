using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Finds Previous cycles in a flat id -> previous-ids map. Used for both the strategy graph and
    /// each strategy's step graph, since the two are walked the same way (see
    /// GameFlowUnlockEvaluator) and a cycle in either means neither node ever unlocks.
    /// </summary>
    public static class NodeCycleDetector
    {
        /// <summary>Ids taking part in at least one cycle. Empty when the graph is acyclic.</summary>
        public static IReadOnlyList<string> FindCycles(IReadOnlyDictionary<string, List<string>> previousById)
        {
            List<string> cyclic = new List<string>();
            if (previousById == null)
                return cyclic;

            HashSet<string> onCurrentPath = new HashSet<string>();
            HashSet<string> settled = new HashSet<string>();

            foreach (string id in previousById.Keys)
                Visit(id, previousById, onCurrentPath, settled, cyclic);

            return cyclic;
        }

        static void Visit(string id, IReadOnlyDictionary<string, List<string>> previousById, HashSet<string> onCurrentPath, HashSet<string> settled, List<string> cyclic)
        {
            if (settled.Contains(id) || !onCurrentPath.Add(id))
                return;

            if (previousById.TryGetValue(id, out List<string> previous) && previous != null)
            {
                foreach (string previousId in previous)
                {
                    // Ids with no entry of their own are dangling references, reported separately
                    // by GameFlowValidator - skip them rather than counting them as cycles here.
                    if (!previousById.ContainsKey(previousId))
                        continue;

                    // Reaching a node still on the current path closes a loop - record both ends so
                    // the reported ids point at the actual edge, not just the entry point.
                    if (onCurrentPath.Contains(previousId))
                    {
                        AddOnce(cyclic, previousId);
                        AddOnce(cyclic, id);
                        continue;
                    }

                    Visit(previousId, previousById, onCurrentPath, settled, cyclic);

                    if (cyclic.Contains(previousId))
                        AddOnce(cyclic, id);
                }
            }

            onCurrentPath.Remove(id);
            settled.Add(id);
        }

        static void AddOnce(List<string> ids, string id)
        {
            if (!ids.Contains(id))
                ids.Add(id);
        }
    }
}
