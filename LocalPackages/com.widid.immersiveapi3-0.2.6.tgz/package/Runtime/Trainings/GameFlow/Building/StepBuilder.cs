using System.Collections.Generic;
using System.Linq;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Accumulates one TrainingStepData. Holds no validation of its own beyond rejecting an
    /// unsupported language code, which would otherwise be silently dropped by the time
    /// GameFlowValidator sees the built data - everything structural is checked there instead.
    /// </summary>
    public class StepBuilder : IStepBuilder
    {
        readonly TrainingStepData data;
        readonly List<GameFlowBuildIssue> issues;

        public StepBuilder(string id, List<GameFlowBuildIssue> issues)
        {
            this.issues = issues;

            // A code-authored step has no graph node to take a GUID from, and its Id is fixed at
            // the call site rather than editable behind a StepReference's back (unlike
            // StepNode.customId), so the Id is already the stable identity NodeGuid needs to be.
            data = new TrainingStepData
            {
                Id = id,
                NodeGuid = id,
                Name = LocalizedTextFactory.Empty(),
                Description = LocalizedTextFactory.Empty()
            };
        }

        public TrainingStepData Data => data;

        public IStepBuilder Named(string language, string value)
        {
            Set(data.Name, language, value, nameof(Named));
            return this;
        }

        public IStepBuilder Named(LanguageDictionary name)
        {
            data.Name = name ?? LocalizedTextFactory.Empty();
            return this;
        }

        public IStepBuilder Described(string language, string value)
        {
            Set(data.Description, language, value, nameof(Described));
            return this;
        }

        public IStepBuilder Described(LanguageDictionary description)
        {
            data.Description = description ?? LocalizedTextFactory.Empty();
            return this;
        }

        public IStepBuilder After(params string[] previousStepIds)
        {
            data.Previous = previousStepIds == null
                ? new List<string>()
                : previousStepIds.Where(id => !string.IsNullOrEmpty(id)).Distinct().ToList();

            return this;
        }

        public IStepBuilder RequirePreviousCompleted(bool require = true)
        {
            data.RequireAllPreviousCompleted = require;
            return this;
        }

        public IStepBuilder RequirePreviousPassed(bool require = true)
        {
            data.RequireAllPreviousPassed = require;
            return this;
        }

        public IStepBuilder PassingScore(float passingScore)
        {
            data.PassingScore = passingScore;
            return this;
        }

        public IStepBuilder CompletesStrategy(bool completes = true)
        {
            data.TriggersStrategyCompletion = completes;
            return this;
        }

        void Set(LanguageDictionary dictionary, string language, string value, string caller)
        {
            if (!LocalizedTextFactory.Set(dictionary, language, value))
            {
                issues.Add(GameFlowBuildIssue.Error(
                    $"{caller}('{language}', ...) uses a language code that isn't one of {string.Join("/", LanguageDictionary.AvailableLanguages)}.",
                    data.Id));
            }
        }
    }
}
