using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Checks an assembled TrainingGameFlowData against the structural rules the runtime
    /// controllers assume. Kept separate from the builders so the same rules apply to a flow from
    /// any source, including one authored by the nodal graph.
    /// </summary>
    public interface IGameFlowValidator
    {
        IReadOnlyList<GameFlowBuildIssue> Validate(TrainingGameFlowData gameFlow);
    }
}
