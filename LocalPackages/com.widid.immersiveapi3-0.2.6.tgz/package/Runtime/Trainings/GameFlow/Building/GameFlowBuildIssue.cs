namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// One problem found while building or validating a GameFlow, scoped to the strategy/step it
    /// concerns when it has one.
    /// </summary>
    public readonly struct GameFlowBuildIssue
    {
        public GameFlowBuildIssueSeverity Severity { get; }

        /// <summary>Id of the strategy or step this concerns. Null for flow-wide issues.</summary>
        public string NodeId { get; }

        public string Message { get; }

        GameFlowBuildIssue(GameFlowBuildIssueSeverity severity, string message, string nodeId)
        {
            Severity = severity;
            Message = message;
            NodeId = nodeId;
        }

        public static GameFlowBuildIssue Error(string message, string nodeId = null)
            => new GameFlowBuildIssue(GameFlowBuildIssueSeverity.Error, message, nodeId);

        public static GameFlowBuildIssue Warning(string message, string nodeId = null)
            => new GameFlowBuildIssue(GameFlowBuildIssueSeverity.Warning, message, nodeId);

        public override string ToString()
            => string.IsNullOrEmpty(NodeId) ? $"[{Severity}] {Message}" : $"[{Severity}] '{NodeId}': {Message}";
    }
}
