using System;
using System.Collections.Generic;
using System.Linq;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Single entry point for code-authored GameFlows: collects StrategyBuilders, assembles their
    /// data, then hands the result to an <see cref="IGameFlowValidator"/> before returning it.
    /// Validation is injected rather than hardcoded so a project can tighten or relax the rules
    /// without touching the builders.
    /// </summary>
    public class GameFlowBuilderService : IGameFlowBuilderService
    {
        readonly IGameFlowValidator validator;
        readonly List<StrategyBuilder> strategies = new List<StrategyBuilder>();

        // Issues the builders themselves raise while being configured (an unsupported language
        // code, a duplicate declaration) - merged with the validator's before the result is built.
        readonly List<GameFlowBuildIssue> authoringIssues = new List<GameFlowBuildIssue>();

        // Left unset unless SimulationPassingScore() is called, so an unspecified threshold keeps
        // whatever default TrainingGameFlowData itself declares rather than a copy of it.
        float? simulationPassingScore;

        public GameFlowBuilderService() : this(new GameFlowValidator())
        {
        }

        public GameFlowBuilderService(IGameFlowValidator validator)
        {
            this.validator = validator ?? new GameFlowValidator();
        }

        public static IGameFlowBuilderService Create() => new GameFlowBuilderService();

        public static IGameFlowBuilderService Create(IGameFlowValidator validator) => new GameFlowBuilderService(validator);

        public IGameFlowBuilderService SimulationPassingScore(float passingScore)
        {
            simulationPassingScore = passingScore;
            return this;
        }

        public IGameFlowBuilderService Strategy(string id, Action<IStrategyBuilder> configure = null)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                authoringIssues.Add(GameFlowBuildIssue.Error("Strategy was declared with an empty id."));
                return this;
            }

            // Caught here rather than left to the validator: a second Strategy() call with the same
            // id would otherwise silently configure a separate builder whose settings are lost.
            if (strategies.Any(strategy => strategy.Id == id))
            {
                authoringIssues.Add(GameFlowBuildIssue.Error("Strategy is declared twice. Call Strategy() once per id.", id));
                return this;
            }

            StrategyBuilder builder = new StrategyBuilder(id, authoringIssues);
            strategies.Add(builder);
            configure?.Invoke(builder);

            return this;
        }

        public GameFlowBuildResult Build()
        {
            TrainingGameFlowData gameFlow = new TrainingGameFlowData
            {
                Strategies = strategies.Select(strategy => strategy.Build()).ToList()
            };

            if (simulationPassingScore.HasValue)
                gameFlow.SimulationPassingScore = simulationPassingScore.Value;

            List<GameFlowBuildIssue> issues = new List<GameFlowBuildIssue>(authoringIssues);
            issues.AddRange(validator.Validate(gameFlow));

            return issues.Any(issue => issue.Severity == GameFlowBuildIssueSeverity.Error)
                ? GameFlowBuildResult.Failed(issues)
                : GameFlowBuildResult.Ok(gameFlow, issues);
        }
    }
}
