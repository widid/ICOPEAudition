using System;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Builds a TrainingGameFlowData from code - the non-graph counterpart to the Editor-only
    /// nodal GameFlowGraph, which is otherwise the only way to author a flow. Pure and in-memory:
    /// nothing here touches assets, so it works at runtime and in tests alike. Use
    /// <see cref="IGameFlowInstaller"/> to hand a built flow to a TrainingSO for TrainingRuntime
    /// to track.
    ///
    /// Builds only the authored Strategy/Step structure. Performances/Interactions/Skills/Badges/
    /// Rewards stay owned by their own editor windows and are preserved on install, matching how
    /// GameFlowGraph.Sync() leaves them alone.
    /// </summary>
    public interface IGameFlowBuilderService
    {
        /// <summary>
        /// Threshold in [0,1] the average score of every completed strategy is compared against
        /// once the Simulation ends. Defaults to TrainingGameFlowData's own 0.5.
        /// </summary>
        IGameFlowBuilderService SimulationPassingScore(float passingScore);

        /// <summary>Declares a strategy. Ids must be unique within the flow.</summary>
        IGameFlowBuilderService Strategy(string id, Action<IStrategyBuilder> configure = null);

        /// <summary>
        /// Assembles and validates the flow. The result carries no GameFlow when validation found
        /// an error - see <see cref="GameFlowBuildResult"/>.
        /// </summary>
        GameFlowBuildResult Build();
    }
}
