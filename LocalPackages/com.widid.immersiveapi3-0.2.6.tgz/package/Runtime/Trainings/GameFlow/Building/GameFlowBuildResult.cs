using System.Collections.Generic;
using System.Linq;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Outcome of <see cref="IGameFlowBuilderService.Build"/>. Converts implicitly to bool, so
    /// `if (result)` reads naturally while Issues stays available for reporting. GameFlow is only
    /// non-null when no Error-severity issue was found - a flow that can't work is never handed
    /// back half-built.
    /// </summary>
    public readonly struct GameFlowBuildResult
    {
        public bool Succeeded { get; }

        /// <summary>The built flow. Null when Succeeded is false.</summary>
        public TrainingGameFlowData GameFlow { get; }

        public IReadOnlyList<GameFlowBuildIssue> Issues { get; }

        GameFlowBuildResult(bool succeeded, TrainingGameFlowData gameFlow, IReadOnlyList<GameFlowBuildIssue> issues)
        {
            Succeeded = succeeded;
            GameFlow = gameFlow;
            Issues = issues ?? new List<GameFlowBuildIssue>();
        }

        public IEnumerable<GameFlowBuildIssue> Errors
            => Issues.Where(issue => issue.Severity == GameFlowBuildIssueSeverity.Error);

        public IEnumerable<GameFlowBuildIssue> Warnings
            => Issues.Where(issue => issue.Severity == GameFlowBuildIssueSeverity.Warning);

        public static GameFlowBuildResult Ok(TrainingGameFlowData gameFlow, IReadOnlyList<GameFlowBuildIssue> issues)
            => new GameFlowBuildResult(true, gameFlow, issues);

        public static GameFlowBuildResult Failed(IReadOnlyList<GameFlowBuildIssue> issues)
            => new GameFlowBuildResult(false, null, issues);

        public static implicit operator bool(GameFlowBuildResult result) => result.Succeeded;

        public override string ToString()
            => Issues.Count == 0
                ? (Succeeded ? "GameFlow built." : "GameFlow build failed.")
                : (Succeeded ? "GameFlow built with issues:\n" : "GameFlow build failed:\n") + string.Join("\n", Issues);
    }
}
