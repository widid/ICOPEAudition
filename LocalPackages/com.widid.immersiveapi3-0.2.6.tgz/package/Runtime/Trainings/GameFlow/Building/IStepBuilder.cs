using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Fluent authoring surface for one step of a strategy. Every method is optional - a step
    /// declared with nothing but an id is valid and carries TrainingStepData's own defaults.
    /// </summary>
    public interface IStepBuilder
    {
        /// <summary>Adds or replaces the display name for one language code (en/fr/it/es/de/pt).</summary>
        IStepBuilder Named(string language, string value);

        IStepBuilder Named(LanguageDictionary name);

        IStepBuilder Described(string language, string value);

        IStepBuilder Described(LanguageDictionary description);

        /// <summary>
        /// Ids of the steps that must precede this one. They must belong to the same strategy -
        /// a step's Previous is only ever evaluated against its own strategy's steps.
        /// </summary>
        IStepBuilder After(params string[] previousStepIds);

        IStepBuilder RequirePreviousCompleted(bool require = true);

        IStepBuilder RequirePreviousPassed(bool require = true);

        /// <summary>Threshold in [0,1] this step's own recorded score is compared against.</summary>
        IStepBuilder PassingScore(float passingScore);

        /// <summary>
        /// Marks this step as the one whose completion ends the owning strategy. Only fires on a
        /// step no other step in the strategy lists as Previous.
        /// </summary>
        IStepBuilder CompletesStrategy(bool completes = true);
    }
}
