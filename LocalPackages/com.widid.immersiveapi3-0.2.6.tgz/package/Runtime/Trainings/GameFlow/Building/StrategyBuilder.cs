using System;
using System.Collections.Generic;
using System.Linq;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Accumulates one TrainingStrategyData and the StepBuilders for its steps. Steps are built
    /// lazily on <see cref="Build"/> so a step's callback can run in declaration order while the
    /// resulting list stays in that same order.
    /// </summary>
    public class StrategyBuilder : IStrategyBuilder
    {
        readonly TrainingStrategyData data;
        readonly List<StepBuilder> steps = new List<StepBuilder>();
        readonly List<GameFlowBuildIssue> issues;

        public StrategyBuilder(string id, List<GameFlowBuildIssue> issues)
        {
            this.issues = issues;

            // See StepBuilder's constructor for why NodeGuid mirrors the authored Id here.
            data = new TrainingStrategyData
            {
                Id = id,
                NodeGuid = id,
                Name = LocalizedTextFactory.Empty(),
                Description = LocalizedTextFactory.Empty()
            };
        }

        public string Id => data.Id;

        public IStrategyBuilder Named(string language, string value)
        {
            Set(data.Name, language, value, nameof(Named));
            return this;
        }

        public IStrategyBuilder Named(LanguageDictionary name)
        {
            data.Name = name ?? LocalizedTextFactory.Empty();
            return this;
        }

        public IStrategyBuilder Described(string language, string value)
        {
            Set(data.Description, language, value, nameof(Described));
            return this;
        }

        public IStrategyBuilder Described(LanguageDictionary description)
        {
            data.Description = description ?? LocalizedTextFactory.Empty();
            return this;
        }

        public IStrategyBuilder After(params string[] previousStrategyIds)
        {
            data.Previous = previousStrategyIds == null
                ? new List<string>()
                : previousStrategyIds.Where(id => !string.IsNullOrEmpty(id)).Distinct().ToList();

            return this;
        }

        public IStrategyBuilder RequirePreviousCompleted(bool require = true)
        {
            data.RequireAllPreviousCompleted = require;
            return this;
        }

        public IStrategyBuilder RequirePreviousPassed(bool require = true)
        {
            data.RequireAllPreviousPassed = require;
            return this;
        }

        public IStrategyBuilder PassingScore(float passingScore)
        {
            data.PassingScore = passingScore;
            return this;
        }

        public IStrategyBuilder CompletesSimulation(bool completes = true)
        {
            data.CompleteSimulation = completes;
            return this;
        }

        public IStrategyBuilder Step(string id, Action<IStepBuilder> configure = null)
        {
            StepBuilder step = new StepBuilder(id, issues);
            steps.Add(step);
            configure?.Invoke(step);

            return this;
        }

        public TrainingStrategyData Build()
        {
            data.Steps = steps.Select(step => step.Data).ToList();
            return data;
        }

        void Set(LanguageDictionary dictionary, string language, string value, string caller)
        {
            if (!LocalizedTextFactory.Set(dictionary, language, value))
            {
                issues.Add(GameFlowBuildIssue.Error(
                    $"{caller}('{language}', ...) uses a language code that isn't one of {string.Join("/", LanguageDictionary.AvailableLanguages)}.",
                    data.Id));
            }
        }
    }
}
