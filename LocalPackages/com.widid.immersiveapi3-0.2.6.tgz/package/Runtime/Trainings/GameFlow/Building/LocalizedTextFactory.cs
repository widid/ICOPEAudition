using System;
using System.Collections.Generic;
using System.Linq;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Creates and fills the LanguageDictionary instances the GameFlow data types expect, keyed by
    /// BCP-47 base language code instead of the raw localization index those types store.
    /// LanguageDictionary.TryAddLanguage refuses to overwrite an existing entry, so Set does the
    /// add-or-replace the builders need.
    /// </summary>
    public static class LocalizedTextFactory
    {
        // Same mandatory en/fr pair every authored LanguageDictionary in the package defaults to.
        static readonly int[] MandatoryLanguages = { 0, 1 };

        public static LanguageDictionary Empty()
            => new LanguageDictionary(new LanguageDictionary.LanguageKey[0], MandatoryLanguages);

        public static bool IsSupportedLanguage(string language) => TryResolveIndex(language, out _);

        /// <summary>
        /// Adds or replaces the entry for one language. Returns false when the code isn't one of
        /// LanguageDictionary.AvailableLanguages, leaving the dictionary untouched.
        /// </summary>
        public static bool Set(LanguageDictionary dictionary, string language, string value)
        {
            if (dictionary == null || !TryResolveIndex(language, out int index))
                return false;

            List<LanguageDictionary.LanguageKey> keys = dictionary.LanguageKeys.ToList();
            keys.RemoveAll(key => key.localizationIndex == index);
            keys.Add(new LanguageDictionary.LanguageKey { localizationIndex = index, value = value });
            dictionary.LanguageKeys = keys.ToArray();

            return true;
        }

        static bool TryResolveIndex(string language, out int index)
        {
            index = language == null
                ? -1
                : Array.IndexOf(LanguageDictionary.AvailableLanguages, language.Trim().ToLowerInvariant());

            return index >= 0;
        }
    }
}
