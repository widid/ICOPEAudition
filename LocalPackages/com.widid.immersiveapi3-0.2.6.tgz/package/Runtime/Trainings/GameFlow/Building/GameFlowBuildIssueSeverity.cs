namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    public enum GameFlowBuildIssueSeverity
    {
        /// <summary>Authoring smell that still produces a usable GameFlow.</summary>
        Warning,

        /// <summary>Broken structure - Build() returns no GameFlow at all.</summary>
        Error
    }
}
