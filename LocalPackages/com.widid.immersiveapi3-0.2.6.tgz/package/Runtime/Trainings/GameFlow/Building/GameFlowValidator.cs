using System.Collections.Generic;
using System.Linq;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow.Building
{
    /// <summary>
    /// Default rules, each one derived from something a runtime collaborator actually assumes:
    /// step ids are unique across the whole Training because StepProgressController keys its
    /// progress/ownership dictionaries by step id flat across every strategy; a step's Previous
    /// must name a step of the same strategy because that's the only set its unlock is evaluated
    /// against; a strategy needs a step marked CompletesStrategy and the Simulation needs a
    /// strategy marked CompletesSimulation, since those leaf flags are the only completion
    /// triggers (see StrategyProgressController.EndsStrategy/SimulationProgressController).
    /// </summary>
    public class GameFlowValidator : IGameFlowValidator
    {
        public IReadOnlyList<GameFlowBuildIssue> Validate(TrainingGameFlowData gameFlow)
        {
            List<GameFlowBuildIssue> issues = new List<GameFlowBuildIssue>();

            if (gameFlow == null)
            {
                issues.Add(GameFlowBuildIssue.Error("There is no GameFlow to validate."));
                return issues;
            }

            ValidateFlow(gameFlow, issues);

            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
                ValidateStrategy(gameFlow, strategy, issues);

            ValidateStepIdsAreGloballyUnique(gameFlow, issues);

            return issues;
        }

        static void ValidateFlow(TrainingGameFlowData gameFlow, List<GameFlowBuildIssue> issues)
        {
            if (!IsNormalizedScore(gameFlow.SimulationPassingScore))
                issues.Add(GameFlowBuildIssue.Error($"SimulationPassingScore must be within [0,1], was {gameFlow.SimulationPassingScore}."));

            if (gameFlow.Strategies.Count == 0)
            {
                issues.Add(GameFlowBuildIssue.Error("The GameFlow declares no strategy."));
                return;
            }

            foreach (string duplicate in Duplicates(gameFlow.Strategies.Select(strategy => strategy.Id)))
                issues.Add(GameFlowBuildIssue.Error("Duplicate strategy id - strategy ids must be unique within the GameFlow.", duplicate));

            if (gameFlow.Strategies.All(strategy => strategy.Previous.Count > 0))
                issues.Add(GameFlowBuildIssue.Error("No strategy is an entry point: every strategy declares a Previous, so none is ever unlocked."));

            if (!gameFlow.Strategies.Any(strategy => strategy.CompleteSimulation))
                issues.Add(GameFlowBuildIssue.Warning("No strategy is marked CompletesSimulation, so the Simulation never ends and no Passed/Failed/Completed is sent for it."));

            Dictionary<string, List<string>> strategyGraph = gameFlow.Strategies
                .GroupBy(strategy => strategy.Id)
                .ToDictionary(group => group.Key, group => group.First().Previous);

            foreach (string id in NodeCycleDetector.FindCycles(strategyGraph))
                issues.Add(GameFlowBuildIssue.Error("Strategy takes part in a Previous cycle, so it is never unlocked.", id));
        }

        static void ValidateStrategy(TrainingGameFlowData gameFlow, TrainingStrategyData strategy, List<GameFlowBuildIssue> issues)
        {
            if (string.IsNullOrWhiteSpace(strategy.Id))
            {
                issues.Add(GameFlowBuildIssue.Error("A strategy has an empty id."));
                return;
            }

            if (!IsNormalizedScore(strategy.PassingScore))
                issues.Add(GameFlowBuildIssue.Error($"PassingScore must be within [0,1], was {strategy.PassingScore}.", strategy.Id));

            HashSet<string> knownStrategyIds = new HashSet<string>(gameFlow.Strategies.Select(other => other.Id));

            foreach (string previousId in strategy.Previous)
            {
                if (previousId == strategy.Id)
                    issues.Add(GameFlowBuildIssue.Error("Strategy lists itself as Previous.", strategy.Id));
                else if (!knownStrategyIds.Contains(previousId))
                    issues.Add(GameFlowBuildIssue.Error($"Previous references '{previousId}', which is not a strategy of this GameFlow.", strategy.Id));
            }

            bool isLeaf = !gameFlow.Strategies.Any(other => other.Previous.Contains(strategy.Id));

            if (strategy.CompleteSimulation && !isLeaf)
                issues.Add(GameFlowBuildIssue.Warning("CompletesSimulation is set but another strategy lists this one as Previous, so it never fires.", strategy.Id));

            ValidateSteps(strategy, issues);
        }

        static void ValidateSteps(TrainingStrategyData strategy, List<GameFlowBuildIssue> issues)
        {
            if (strategy.Steps.Count == 0)
            {
                issues.Add(GameFlowBuildIssue.Error("Strategy declares no step. Strategies are step-driven, so it could never complete.", strategy.Id));
                return;
            }

            HashSet<string> ownStepIds = new HashSet<string>(strategy.Steps.Select(step => step.Id));

            foreach (TrainingStepData step in strategy.Steps)
            {
                if (string.IsNullOrWhiteSpace(step.Id))
                {
                    issues.Add(GameFlowBuildIssue.Error("A step has an empty id.", strategy.Id));
                    continue;
                }

                if (!IsNormalizedScore(step.PassingScore))
                    issues.Add(GameFlowBuildIssue.Error($"PassingScore must be within [0,1], was {step.PassingScore}.", step.Id));

                foreach (string previousId in step.Previous)
                {
                    if (previousId == step.Id)
                        issues.Add(GameFlowBuildIssue.Error("Step lists itself as Previous.", step.Id));
                    else if (!ownStepIds.Contains(previousId))
                        issues.Add(GameFlowBuildIssue.Error($"Previous references '{previousId}', which is not a step of strategy '{strategy.Id}'. A step's Previous is only evaluated against its own strategy's steps.", step.Id));
                }

                bool isLeaf = !strategy.Steps.Any(other => other.Previous.Contains(step.Id));

                if (step.TriggersStrategyCompletion && !isLeaf)
                    issues.Add(GameFlowBuildIssue.Warning("CompletesStrategy is set but another step of the same strategy lists this one as Previous, so it never fires.", step.Id));
            }

            foreach (string duplicate in Duplicates(strategy.Steps.Select(step => step.Id)))
                issues.Add(GameFlowBuildIssue.Error($"Duplicate step id within strategy '{strategy.Id}'.", duplicate));

            if (strategy.Steps.All(step => step.Previous.Count > 0))
                issues.Add(GameFlowBuildIssue.Error("No step is an entry point: every step declares a Previous, so none is ever unlocked.", strategy.Id));

            if (!strategy.Steps.Any(step => step.TriggersStrategyCompletion))
                issues.Add(GameFlowBuildIssue.Warning("No step is marked CompletesStrategy, so this strategy never auto-completes and nothing downstream of it unlocks.", strategy.Id));

            Dictionary<string, List<string>> stepGraph = strategy.Steps
                .GroupBy(step => step.Id)
                .ToDictionary(group => group.Key, group => group.First().Previous);

            foreach (string id in NodeCycleDetector.FindCycles(stepGraph))
                issues.Add(GameFlowBuildIssue.Error("Step takes part in a Previous cycle, so it is never unlocked.", id));
        }

        // StepProgressController keys progress and strategy-ownership by step id flat across every
        // strategy, so two strategies reusing an id would collapse into one progress entry.
        static void ValidateStepIdsAreGloballyUnique(TrainingGameFlowData gameFlow, List<GameFlowBuildIssue> issues)
        {
            IEnumerable<IGrouping<string, string>> collisions = gameFlow.Strategies
                .SelectMany(strategy => strategy.Steps.Select(step => new { StepId = step.Id, StrategyId = strategy.Id }))
                .Where(entry => !string.IsNullOrWhiteSpace(entry.StepId))
                .GroupBy(entry => entry.StepId, entry => entry.StrategyId)
                .Where(group => group.Distinct().Count() > 1);

            foreach (IGrouping<string, string> collision in collisions)
            {
                string owners = string.Join("', '", collision.Distinct());
                issues.Add(GameFlowBuildIssue.Error($"Step id is reused by strategies '{owners}'. Step ids must be unique across the whole Training.", collision.Key));
            }
        }

        static IEnumerable<string> Duplicates(IEnumerable<string> ids)
        {
            return ids
                .Where(id => !string.IsNullOrWhiteSpace(id))
                .GroupBy(id => id)
                .Where(group => group.Count() > 1)
                .Select(group => group.Key);
        }

        static bool IsNormalizedScore(float score) => score >= 0f && score <= 1f;
    }
}
