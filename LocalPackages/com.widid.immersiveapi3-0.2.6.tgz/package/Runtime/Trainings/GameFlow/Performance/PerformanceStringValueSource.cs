using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// String counterpart of PerformanceValueSource - used for Performance's Response field. Kept
    /// as its own concrete class rather than a generic PerformanceValueSource&lt;T&gt; to avoid
    /// relying on Unity serializing a generic type directly (see DataReference&lt;T&gt;'s concrete
    /// Boolean/Numeric/StringDataReference subclasses for the same reasoning elsewhere in this repo).
    /// </summary>
    [Serializable]
    public class PerformanceStringValueSource
    {
        [field: SerializeField] public bool Enabled { get; set; }
        [field: SerializeField] public string FixedValue { get; set; } = string.Empty;
        [field: SerializeField] public ReflectedStringSourceSO ReflectedSource { get; set; }

        public string Resolve()
        {
            if (!Enabled)
                return null;

            return ReflectedSource != null ? ReflectedSource.Value : FixedValue;
        }
    }
}
