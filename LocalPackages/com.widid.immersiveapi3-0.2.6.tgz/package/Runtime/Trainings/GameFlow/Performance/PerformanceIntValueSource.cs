using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Int counterpart of PerformanceValueSource, used for Raw/Min/Max on both Performance and
    /// Interaction - xAPI's Score.raw/min/max are int-only, unlike Score.scaled (float), so these
    /// no longer round a float reflected value at send time; the reflected source itself is already
    /// an int (see ReflectedIntSourceSO). Kept as its own concrete class rather than a generic
    /// PerformanceValueSource&lt;T&gt; for the same reason PerformanceStringValueSource is - Unity
    /// can't serialize a generic type directly.
    /// </summary>
    [Serializable]
    public class PerformanceIntValueSource
    {
        [field: SerializeField] public bool Enabled { get; set; }
        [field: SerializeField] public int FixedValue { get; set; }
        [field: SerializeField] public ReflectedIntSourceSO ReflectedSource { get; set; }

        // TEMPORARY-STORED-PROGRESS
        public IReflectedValueSource WritableReflectedSource => Enabled && ReflectedSource != null ? ReflectedSource : null;

        public int? Resolve()
        {
            if (!Enabled)
                return null;

            return ReflectedSource != null ? ReflectedSource.Value : FixedValue;
        }
    }
}
