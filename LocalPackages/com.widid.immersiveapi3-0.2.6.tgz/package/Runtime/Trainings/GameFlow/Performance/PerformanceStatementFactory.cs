using System.Collections.Generic;
using TinCan;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Builds the single xAPI Performance statementable Performance supports - verb `scored`, no
    /// lifecycle (see xAPI-Statements/Performance/README.md). parentStrategy/parentStep are mutually
    /// exclusive: pass parentStep for a Step-scoped performance (Performance's own ParentStrategy/
    /// ParentSimulation fallbacks resolve the rest, see Performance.cs), parentStrategy alone for a
    /// Strategy-scoped one, or neither for a Simulation-scoped (global) one.
    ///
    /// attachments is already-built (uploaded fileUrl and all - see PerformanceAttachmentFactory,
    /// which needs network access to upload each entry's captured bytes first) rather than resolved
    /// from data.Attachments here, since every other member of this factory is synchronous.
    /// </summary>
    public static class PerformanceStatementFactory
    {
        public static Performance Scored(Simulation simulation, TrainingPerformanceData data, Step parentStep = null, Strategy parentStrategy = null, List<Attachment> attachments = null)
        {
            Performance performance = new(data.Id, data.Name, data.Description, simulation, parentStep, parentStrategy);

            performance.Score = data.Scaled.Resolve();
            performance.ScoreRaw = data.Raw.Resolve();
            performance.MinScoreRaw = data.Min.Resolve();
            performance.MaxScoreRaw = data.Max.Resolve();
            performance.Response = data.Response.Resolve();
            performance.Attachments = attachments;

            if (!string.IsNullOrEmpty(data.Unit))
                performance.Extensions = ExtensionsBuilder.Create().WithExtension(ExtensionsLibrary.Measurement, data.Unit).Build();

            return performance;
        }
    }
}
