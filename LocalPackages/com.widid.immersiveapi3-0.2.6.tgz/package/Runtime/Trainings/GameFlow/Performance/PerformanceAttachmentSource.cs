using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// One attachment a Performance can send, sourced from a live ReflectedAttachmentSourceSO (e.g.
    /// a CameraAttachmentProvider) - no fixed-value fallback, unlike PerformanceValueSource, since
    /// there's no meaningful "fixed" attachment to author in its place. UsageTypeKey is a key into
    /// AttachmentUsages.All, matching how SkillEditorPanel picks SkillCategories.All by key.
    /// </summary>
    [Serializable]
    public class PerformanceAttachmentSource
    {
        [field: SerializeField] public bool Enabled { get; set; }
        [field: SerializeField] public ReflectedAttachmentSourceSO ReflectedSource { get; set; }
        [field: SerializeField] public string UsageTypeKey { get; set; } = "SupportingMedia";

        public AttachmentCapture? Resolve()
        {
            if (!Enabled || ReflectedSource == null)
                return null;

            return ReflectedSource.Capture();
        }

        public Uri UsageType => AttachmentUsages.All.TryGetValue(UsageTypeKey, out Uri usageType) ? usageType : AttachmentUsages.SupportingMediaUri;
    }
}
