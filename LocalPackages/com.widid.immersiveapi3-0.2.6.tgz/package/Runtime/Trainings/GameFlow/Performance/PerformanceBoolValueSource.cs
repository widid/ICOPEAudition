using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Bool counterpart of PerformanceValueSource/PerformanceIntValueSource/
    /// PerformanceStringValueSource - fixed constant or live ReflectedBoolSourceSO. Used as a
    /// Condition's operand (see Conditions/Condition.cs) as well as anywhere else a fixed-or-
    /// reflected bool is needed. Kept as its own concrete class for the same reason the others are -
    /// Unity can't serialize a generic type directly.
    /// </summary>
    [Serializable]
    public class PerformanceBoolValueSource
    {
        [field: SerializeField] public bool Enabled { get; set; }
        [field: SerializeField] public bool FixedValue { get; set; }
        [field: SerializeField] public ReflectedBoolSourceSO ReflectedSource { get; set; }

        public bool? Resolve()
        {
            if (!Enabled)
                return null;

            return ReflectedSource != null ? ReflectedSource.Value : FixedValue;
        }
    }
}
