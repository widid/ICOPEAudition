using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TinCan;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Developer-triggered sender for a Training's authored Performances - like InteractionRecorder
    /// and RewardRecorder, nothing here fires automatically: host game code decides exactly when a
    /// Performance is scored, whatever container (Simulation/Strategy/Step) it's scoped to (see
    /// PerformanceReference/TrainingRuntime.ScorePerformance). Only a performanceId is needed - its
    /// owning Step/Strategy, if any, is found from that alone (see TryFindPerformance). Stateless
    /// beyond the Simulation/TrainingGameFlowData it's Configure()'d with - Performance has no
    /// unlock/progress state of its own to track. Reads each entry's Scaled/Raw/Min/Max/Response
    /// through the shared WiDiD.Reflection tracking system (or a fixed authored constant, see
    /// PerformanceValueSource/PerformanceStringValueSource). Attachments (see
    /// PerformanceAttachmentFactory) are captured and uploaded the same way, using the same
    /// endpoints/bearerToken the sender itself was built with.
    /// </summary>
    public class PerformanceRecorder : IPerformanceValueLookup
    {
        readonly IStatementSender sender;
        readonly IImmersiveEndpoints endpoints;
        readonly string bearerToken;
        readonly ImmersiveImageSender imageSender;

        TrainingGameFlowData gameFlow;
        Simulation simulation;

        /// <summary>Raised with the performance id each time a known performance is scored. TEMPORARY-STORED-PROGRESS: only PerformanceServerSync listens.</summary>
        public event Action<string> Scored;

        public PerformanceRecorder(IStatementSender sender, IImmersiveEndpoints endpoints, string bearerToken, ImmersiveImageSender imageSender)
        {
            this.sender = sender;
            this.endpoints = endpoints;
            this.bearerToken = bearerToken;
            this.imageSender = imageSender;
        }

        public void Configure(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            this.gameFlow = gameFlow;
            this.simulation = simulation;
        }

        public async Task<StatementSendResult> Score(string performanceId)
        {
            if (!TryFindPerformance(performanceId, out TrainingPerformanceData performance, out Step parentStep, out Strategy parentStrategy))
                return StatementSendResult.Rejection($"Unknown performance '{performanceId}'.");

            Scored?.Invoke(performanceId);

            List<Attachment> attachments = await PerformanceAttachmentFactory.BuildAsync(performance, endpoints, bearerToken, imageSender);
            return await sender.Send(Verbs.Scored, PerformanceStatementFactory.Scored(simulation, performance, parentStep: parentStep, parentStrategy: parentStrategy, attachments: attachments));
        }

        public int? GetCurrentRaw(string performanceId) => TryFindPerformance(performanceId, out TrainingPerformanceData performance, out _, out _) ? performance.Raw.Resolve() : null;

        bool TryFindPerformance(string performanceId, out TrainingPerformanceData performance, out Step parentStep, out Strategy parentStrategy)
        {
            foreach ((TrainingPerformanceData candidate, Step candidateStep, Strategy candidateStrategy) in PerformanceScopes.Enumerate(gameFlow, simulation))
            {
                if (candidate.Id != performanceId)
                    continue;

                performance = candidate;
                parentStep = candidateStep;
                parentStrategy = candidateStrategy;
                return true;
            }

            performance = null;
            parentStep = null;
            parentStrategy = null;
            return false;
        }
    }
}
