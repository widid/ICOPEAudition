using System.Collections.Generic;
using WiDiD.XAPI.Statementables;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    public static class PerformanceScopes
    {
        /// <summary>
        /// Every authored performance with the parent its statement is built with - none for
        /// Simulation scope, the Strategy for Strategy scope, the Step alone for Step scope.
        /// </summary>
        public static IEnumerable<(TrainingPerformanceData Performance, Step ParentStep, Strategy ParentStrategy)> Enumerate(TrainingGameFlowData gameFlow, Simulation simulation)
        {
            foreach (TrainingPerformanceData performance in gameFlow.Performances)
                yield return (performance, null, null);

            foreach (TrainingStrategyData strategy in gameFlow.Strategies)
            {
                Strategy parentStrategy = StrategyStatementFactory.New(simulation, strategy);

                foreach (TrainingPerformanceData performance in strategy.Performances)
                    yield return (performance, null, parentStrategy);

                foreach (TrainingStepData step in strategy.Steps)
                {
                    Step parentStep = StepStatementFactory.New(simulation, parentStrategy, step);

                    foreach (TrainingPerformanceData performance in step.Performances)
                        yield return (performance, parentStep, null);
                }
            }
        }
    }
}
