using System;
using UnityEngine;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// One component of a Performance's Score (scaled/raw/min/max - see TrainingPerformanceData),
    /// either a fixed authored constant or a live ReflectedFloatSourceSO - useful since min/max are
    /// often fixed bounds while scaled/raw are usually tracked live. Enabled distinguishes "not
    /// provided at all" from a legitimately authored 0, matching Performance.cs's own nullable
    /// Score/ScoreRaw/MinScoreRaw/MaxScoreRaw fields.
    /// </summary>
    [Serializable]
    public class PerformanceValueSource
    {
        [field: SerializeField] public bool Enabled { get; set; }
        [field: SerializeField] public float FixedValue { get; set; }
        [field: SerializeField] public ReflectedFloatSourceSO ReflectedSource { get; set; }

        // TEMPORARY-STORED-PROGRESS
        public IReflectedValueSource WritableReflectedSource => Enabled && ReflectedSource != null ? ReflectedSource : null;

        public float? Resolve()
        {
            if (!Enabled)
                return null;

            return ReflectedSource != null ? ReflectedSource.Value : FixedValue;
        }
    }
}
