using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Drop this on a MonoBehaviour/ScriptableObject field to pick a Performance by name (via
    /// PerformanceReferenceDrawer, Editor-only) instead of hand-typing its raw GUID id - regardless
    /// of which container (Simulation/Strategy/Step) it's actually scoped to.
    /// </summary>
    [Serializable]
    public class PerformanceReference
    {
        [SerializeField] private string performanceId = string.Empty;
        public string PerformanceId => performanceId;
    }
}
