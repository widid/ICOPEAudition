using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TinCan;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.Reflection.Tracking;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// Captures and uploads every enabled PerformanceAttachmentSource on a TrainingPerformanceData,
    /// building the resulting fileUrl-bearing xAPI Attachments - kept out of PerformanceStatementFactory
    /// since uploading needs network access (ImmersiveImageSender.SendAsync) and every other member
    /// that factory resolves is synchronous. An entry whose capture or upload fails is skipped rather
    /// than failing the whole statement.
    /// </summary>
    public static class PerformanceAttachmentFactory
    {
        public static async Task<List<Attachment>> BuildAsync(TrainingPerformanceData data, IImmersiveEndpoints endpoints, string bearerToken, ImmersiveImageSender imageSender)
        {
            if (data.Attachments == null || data.Attachments.Count == 0)
                return null;

            List<Attachment> attachments = new();

            foreach (PerformanceAttachmentSource source in data.Attachments)
            {
                AttachmentCapture? capture = source.Resolve();
                if (capture == null)
                    continue;

                ImageSendResult uploadResult = await imageSender.SendAsync(capture.Value.Bytes, capture.Value.FileName, capture.Value.ContentType, endpoints.FileSendingAdress, bearerToken);
                if (!uploadResult.Success)
                    continue;

                attachments.Add(AttachmentBuilder.Create(new Uri(uploadResult.Url), capture.Value.ContentType)
                    .WithLength(capture.Value.Bytes.Length)
                    .WithUsageType(source.UsageType)
                    .Build());
            }

            return attachments.Count > 0 ? attachments : null;
        }

        // Synchronous, no-network counterpart used by PerformancePreviewTarget.Build - captures the
        // same bytes as BuildAsync but skips the upload, so the Statement Preview window's JSON can
        // still show a realistic attachment (contentType/length/usageType) before ever actually
        // sending anything. fileUrl can't be omitted (AttachmentBuilder requires one), so it's a
        // clearly-fake placeholder rather than a real stored url.
        public static List<Attachment> BuildPreviewAttachments(TrainingPerformanceData data)
        {
            if (data.Attachments == null || data.Attachments.Count == 0)
                return null;

            List<Attachment> attachments = new();

            foreach (PerformanceAttachmentSource source in data.Attachments)
            {
                AttachmentCapture? capture = source.Resolve();
                if (capture == null)
                    continue;

                attachments.Add(AttachmentBuilder.Create(new Uri("attachment-preview:not-uploaded-yet"), capture.Value.ContentType)
                    .WithLength(capture.Value.Bytes.Length)
                    .WithUsageType(source.UsageType)
                    .Build());
            }

            return attachments.Count > 0 ? attachments : null;
        }
    }
}
