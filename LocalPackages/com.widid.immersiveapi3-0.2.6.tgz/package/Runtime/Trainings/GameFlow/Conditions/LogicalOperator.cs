namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    public enum LogicalOperator
    {
        And,
        Or
    }
}
