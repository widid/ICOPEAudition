namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    // GreaterThan/GreaterOrEqual/LessThan/LessOrEqual only apply to Float/Int - for String they
    // compare ordinally, for Bool they're meaningless (see Condition.Evaluate).
    public enum ComparisonOperator
    {
        Equals,
        NotEquals,
        GreaterThan,
        GreaterOrEqual,
        LessThan,
        LessOrEqual
    }
}
