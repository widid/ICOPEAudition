using System;
using System.Collections.Generic;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// A sequential chain of entries combined left-to-right with each entry's own And/Or
    /// Combinator - no operator precedence, since each entry can itself be a parenthesized group
    /// (see ConditionChainEntry.IsGroup/Group) wherever explicit grouping is needed, e.g.
    /// "(x AND y) OR a OR b" is authored as a 3-entry chain: a group {x AND y}, then Or a, then Or
    /// b. Meant to be embedded as a field anywhere a general-purpose authored bool is useful -
    /// resolving a Success/Enabled-style field, gating whether something should trigger, etc. - see
    /// ConditionChainEditor for the shared Editor UI that authors one.
    /// </summary>
    [Serializable]
    public class ConditionChain
    {
        [field: SerializeField] public List<ConditionChainEntry> Entries { get; set; } = new List<ConditionChainEntry>();

        // Null means "not configured" (no entries authored yet) - distinct from a legitimately
        // authored false. Any single entry that can't resolve (see ConditionChainEntry.Evaluate) is
        // folded in as false rather than propagating null through the whole chain, so one
        // unresolved reflected source (or an empty nested group) doesn't make an otherwise-
        // configured chain silently unevaluatable.
        public bool? Evaluate()
        {
            if (Entries.Count == 0)
                return null;

            bool result = Entries[0].Evaluate() ?? false;

            for (int i = 1; i < Entries.Count; i++)
            {
                bool next = Entries[i].Evaluate() ?? false;
                result = Entries[i].Combinator == LogicalOperator.And ? result && next : result || next;
            }

            return result;
        }
    }
}
