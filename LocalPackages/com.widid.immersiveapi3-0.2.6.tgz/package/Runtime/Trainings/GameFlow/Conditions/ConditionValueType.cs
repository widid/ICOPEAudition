namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    public enum ConditionValueType
    {
        Float,
        Int,
        String,
        Bool
    }
}
