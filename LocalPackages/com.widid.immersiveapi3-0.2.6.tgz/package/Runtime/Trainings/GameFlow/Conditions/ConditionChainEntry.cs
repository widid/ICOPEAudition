using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// One link in a ConditionChain - Combinator says how this entry's result combines with the
    /// running result of every entry before it (ignored on the first entry, which simply seeds the
    /// running result). IsGroup picks whether this entry is a single Condition or a fully nested
    /// ConditionChain of its own - i.e. a parenthesized group, e.g. "(x AND y) OR z" is a chain of
    /// two entries: a group {x AND y} combined via Or with a plain condition z. Set once at
    /// creation (see ConditionChainEditor's "+ Add Condition"/"+ Add Group" buttons) and never
    /// toggled afterward - a group's own entries can themselves be groups, so nesting is unbounded.
    /// </summary>
    [Serializable]
    public class ConditionChainEntry
    {
        [field: SerializeField] public LogicalOperator Combinator { get; set; } = LogicalOperator.And;
        [field: SerializeField] public bool IsGroup { get; set; }
        [field: SerializeField] public Condition Condition { get; set; } = new Condition();

        // Serialized as a managed reference rather than inline: a ConditionChain holds entries and
        // an entry can hold a chain of its own, and Unity serializes an inline object graph only to
        // a fixed depth, which a self-nesting type exhausts after a single level of grouping.
        // Managed references are stored flat, so a group nests as deeply as it is authored.
        //
        // Left null on a leaf entry - only a group owns a chain - so it is allocated at creation
        // (see ConditionChainEditor's "+ Add Group") instead of by a field initializer.
        [field: SerializeReference] public ConditionChain Group { get; set; }

        public bool? Evaluate() => IsGroup ? Group?.Evaluate() : Condition.Evaluate();
    }
}
