using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Trainings.GameFlow
{
    /// <summary>
    /// One typed comparison between two operands - each operand is itself a fixed-or-reflected
    /// value source (PerformanceValueSource/PerformanceIntValueSource/PerformanceStringValueSource/
    /// PerformanceBoolValueSource), so either side can be a live reflected value, a fixed authored
    /// constant, or unset. ValueType picks which of the four Left/Right pairs is actually in use -
    /// the other three sit unused, same convention as TrainingInteractionData.Kind picking between
    /// AnsweredQuestion/InteractedInteraction fields. See ConditionChain for combining several of
    /// these with And/Or.
    /// </summary>
    [Serializable]
    public class Condition
    {
        [field: SerializeField] public ConditionValueType ValueType { get; set; }
        [field: SerializeField] public ComparisonOperator Operator { get; set; } = ComparisonOperator.Equals;

        // Enabled is always true here - unlike Performance/Interaction's own optional fields, a
        // condition operand isn't meaningfully "off": comparing anything requires both sides to
        // have a value, so ConditionChainEditor never exposes a toggle for these and just forces
        // Enabled on whenever it wires one up (see ConditionChainEditor.WireXRow).
        [field: SerializeField] public PerformanceValueSource FloatLeft { get; set; } = new PerformanceValueSource { Enabled = true };
        [field: SerializeField] public PerformanceValueSource FloatRight { get; set; } = new PerformanceValueSource { Enabled = true };

        [field: SerializeField] public PerformanceIntValueSource IntLeft { get; set; } = new PerformanceIntValueSource { Enabled = true };
        [field: SerializeField] public PerformanceIntValueSource IntRight { get; set; } = new PerformanceIntValueSource { Enabled = true };

        [field: SerializeField] public PerformanceStringValueSource StringLeft { get; set; } = new PerformanceStringValueSource { Enabled = true };
        [field: SerializeField] public PerformanceStringValueSource StringRight { get; set; } = new PerformanceStringValueSource { Enabled = true };

        [field: SerializeField] public PerformanceBoolValueSource BoolLeft { get; set; } = new PerformanceBoolValueSource { Enabled = true };
        [field: SerializeField] public PerformanceBoolValueSource BoolRight { get; set; } = new PerformanceBoolValueSource { Enabled = true };

        // Null means "can't tell" - either operand didn't resolve (disabled, or a reflected source
        // with no live target), not the same as a legitimately authored false/0/empty comparison.
        public bool? Evaluate()
        {
            return ValueType switch
            {
                ConditionValueType.Float => CompareNumeric(FloatLeft.Resolve(), FloatRight.Resolve()),
                ConditionValueType.Int => CompareNumeric(IntLeft.Resolve(), IntRight.Resolve()),
                ConditionValueType.String => CompareString(StringLeft.Resolve(), StringRight.Resolve()),
                ConditionValueType.Bool => CompareBool(BoolLeft.Resolve(), BoolRight.Resolve()),
                _ => null
            };
        }

        bool? CompareNumeric(float? left, float? right)
        {
            if (!left.HasValue || !right.HasValue)
                return null;

            return Operator switch
            {
                ComparisonOperator.Equals => left.Value == right.Value,
                ComparisonOperator.NotEquals => left.Value != right.Value,
                ComparisonOperator.GreaterThan => left.Value > right.Value,
                ComparisonOperator.GreaterOrEqual => left.Value >= right.Value,
                ComparisonOperator.LessThan => left.Value < right.Value,
                ComparisonOperator.LessOrEqual => left.Value <= right.Value,
                _ => null
            };
        }

        bool? CompareString(string left, string right)
        {
            if (left == null || right == null)
                return null;

            int comparison = string.CompareOrdinal(left, right);

            return Operator switch
            {
                ComparisonOperator.Equals => comparison == 0,
                ComparisonOperator.NotEquals => comparison != 0,
                ComparisonOperator.GreaterThan => comparison > 0,
                ComparisonOperator.GreaterOrEqual => comparison >= 0,
                ComparisonOperator.LessThan => comparison < 0,
                ComparisonOperator.LessOrEqual => comparison <= 0,
                _ => null
            };
        }

        bool? CompareBool(bool? left, bool? right)
        {
            if (!left.HasValue || !right.HasValue)
                return null;

            return Operator switch
            {
                ComparisonOperator.Equals => left.Value == right.Value,
                ComparisonOperator.NotEquals => left.Value != right.Value,
                _ => null
            };
        }
    }
}
