using System.Threading.Tasks;
using TinCan;
using WiDiD.ImmersiveAPI.Networking;

namespace WiDiD.ImmersiveAPI.Trainings
{
    /// <summary>
    /// One statement waiting its turn in StatementSendQueue, plus the Task its caller is holding.
    ///
    /// The Statement is built before it gets here, not when it is finally posted, so its xAPI
    /// timestamp records when the game actually did the thing rather than when the queue got round
    /// to it (see StatementBuilder). That timestamp is what carries the ordering guarantee on WebGL,
    /// where arrival order cannot be controlled at all.
    /// </summary>
    public class PendingStatement
    {
        readonly TaskCompletionSource<StatementSendResult> completion = new TaskCompletionSource<StatementSendResult>(TaskCreationOptions.RunContinuationsAsynchronously);

        public Verb Verb { get; }
        public Statement Statement { get; }

        /// <summary>Human-readable "verb Type 'id'" used for this statement's log lines.</summary>
        public string Context { get; }

        public Task<StatementSendResult> Completion => completion.Task;

        public PendingStatement(Verb verb, Statement statement, string context)
        {
            Verb = verb;
            Statement = statement;
            Context = context;
        }

        public void Complete(StatementSendResult result) => completion.TrySetResult(result);
    }
}
