namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class Files
    {
        private readonly string file;
        private readonly string fileType;
        private readonly long? fileSize;
        private readonly string version;

        public Files(string file, string fileType, long? fileSize, string version)
        {
            this.file = file;
            this.fileType = fileType;
            this.fileSize = fileSize;
            this.version = version;
        }

        public string File => file;
        public string FileType => fileType;
        public long? FileSize => fileSize;
        public string Version => version;
    }
}
