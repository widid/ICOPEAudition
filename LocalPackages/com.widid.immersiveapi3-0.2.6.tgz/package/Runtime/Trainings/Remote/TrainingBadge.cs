namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class TrainingBadge
    {
        private readonly int number;
        private readonly string lang;
        private readonly string name;
        private readonly string description;
        private readonly string logo;

        public TrainingBadge(int number, string lang, string name, string description, string logo)
        {
            this.number = number;
            this.lang = lang;
            this.name = name;
            this.description = description;
            this.logo = logo;
        }

        public int Number => number;
        public string Lang => lang;
        public string Name => name;
        public string Description => description;
        public string Logo => logo;
    }
}
