using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public interface ISkillCatalogService
    {
        Task<SkillCatalogDTO> FetchSkillCatalog(string targetUrl, string token, string langCode);
    }
}
