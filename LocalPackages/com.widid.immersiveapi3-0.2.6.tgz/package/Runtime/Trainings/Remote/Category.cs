namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class Category
    {
        private readonly int id;
        private readonly string name;
        private readonly bool custom;

        public Category(int id, string name, bool custom)
        {
            this.id = id;
            this.name = name;
            this.custom = custom;
        }

        public int Id => id;
        public string Name => name;
        public bool Custom => custom;
    }
}
