using System.Collections.Generic;
using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public interface ITrainingService
    {
        Task<List<TrainingDTO>> FetchTrainings(string targetUrl, string token, string langCode);
    }
}
