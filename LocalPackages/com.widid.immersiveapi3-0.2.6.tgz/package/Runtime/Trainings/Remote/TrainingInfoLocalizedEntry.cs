namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    /// <summary>
    /// One language's Title/BriefDescription for a training, from the trainings/{id}
    /// (IImmersiveEndpoints.TrainingInfoAdress) response's "trainings" array.
    /// </summary>
    public class TrainingInfoLocalizedEntry
    {
        public string Lang { get; set; }
        public string Title { get; set; }
        public string BriefDescription { get; set; }
    }
}
