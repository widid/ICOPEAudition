namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class PrimarySkillDTO
    {
        private readonly int id;
        private readonly string name;
        private readonly string skillType;

        public PrimarySkillDTO(int id, string name, string skillType)
        {
            this.id = id;
            this.name = name;
            this.skillType = skillType;
        }

        public int Id => id;
        public string Name => name;

        // e.g. "soft_skill_3"/"hard_skill_1" - see SkillsEndpoint's response. The trailing number,
        // not Id, is what the backend actually expects as the skill's identifier elsewhere.
        public string SkillType => skillType;
    }
}
