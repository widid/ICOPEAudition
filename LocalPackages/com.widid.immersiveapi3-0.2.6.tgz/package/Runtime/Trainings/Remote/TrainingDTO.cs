using System;
using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class TrainingDTO
    {
        private int id;
        private List<string> availableLanguages;
        private List<string> contentLanguages;
        private int durationInMinute;
        private int clientId;
        private Category category;
        private CustomCategory customCategory;
        private Partner partner;
        private string logo;
        private string file;
        private string version;
        private long? fileSize;
        private List<Files> files;
        private TrainingLocalizedContent training;
        private List<Skill> skills;
        private List<string> tags;
        private List<Headset> headsets;
        private List<TrainingBadge> badges;
        private int? masterContentId;
        private string launchParameter;
        private bool isUnlocked;
        private bool isOwner;
        private bool isFromPartner;
        private bool isSuggested;
        private bool isNew;
        private int progressionPercent;
        private DateTime lastModifiedDate;

        public TrainingDTO(
            int id,
            List<string> availableLanguages,
            List<string> contentLanguages,
            int durationInMinute,
            int clientId,
            Category category,
            CustomCategory customCategory,
            Partner partner,
            string logo,
            string file,
            string version,
            long? fileSize,
            List<Files> files,
            TrainingLocalizedContent training,
            List<Skill> skills,
            List<string> tags,
            List<Headset> headsets,
            List<TrainingBadge> badges,
            int? masterContentId,
            string launchParameter,
            bool isUnlocked,
            bool isOwner,
            bool isFromPartner,
            bool isSuggested,
            bool isNew,
            int progressionPercent,
            DateTime lastModifiedDate)
        {
            this.id = id;
            this.availableLanguages = availableLanguages;
            this.contentLanguages = contentLanguages;
            this.durationInMinute = durationInMinute;
            this.clientId = clientId;
            this.category = category;
            this.customCategory = customCategory;
            this.partner = partner;
            this.logo = logo;
            this.file = file;
            this.version = version;
            this.fileSize = fileSize;
            this.files = files;
            this.training = training;
            this.skills = skills;
            this.tags = tags;
            this.headsets = headsets;
            this.badges = badges;
            this.masterContentId = masterContentId;
            this.launchParameter = launchParameter;
            this.isUnlocked = isUnlocked;
            this.isOwner = isOwner;
            this.isFromPartner = isFromPartner;
            this.isSuggested = isSuggested;
            this.isNew = isNew;
            this.progressionPercent = progressionPercent;
            this.lastModifiedDate = lastModifiedDate;
        }

        public int Id => id;

        public List<string> AvailableLanguages => availableLanguages;

        public List<string> ContentLanguages => contentLanguages;

        public int DurationInMinute => durationInMinute;

        public int ClientId => clientId;

        public Category Category => category;

        public CustomCategory CustomCategory => customCategory;

        public Partner Partner => partner;

        public string Logo => logo;

        public string File => file;

        public string Version => version;

        public long? FileSize => fileSize;

        public List<Files> Files => files;

        public TrainingLocalizedContent Training => training;

        public List<Skill> Skills => skills;

        public List<string> Tags => tags;

        public List<Headset> Headsets => headsets;

        public List<TrainingBadge> Badges => badges;

        public int? MasterContentId => masterContentId;

        public string LaunchParameter => launchParameter;

        public bool IsUnlocked => isUnlocked;

        public bool IsOwner => isOwner;

        public bool IsFromPartner => isFromPartner;

        public bool IsSuggested => isSuggested;

        public bool IsNew => isNew;

        public int ProgressionPercent => progressionPercent;

        public DateTime LastModifiedDate => lastModifiedDate;
    }
}
