namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class Partner
    {
        private readonly int id;
        private readonly string name;
        private readonly string logo;

        public Partner(int id, string name, string logo)
        {
            this.id = id;
            this.name = name;
            this.logo = logo;
        }

        public int Id => id;
        public string Name => name;
        public string Logo => logo;
    }
}
