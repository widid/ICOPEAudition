using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class SkillCatalogService : ISkillCatalogService
    {
        private readonly ILogger logger;

        public SkillCatalogService(ILogger logger)
        {
            this.logger = logger;
        }

        // Matches ImmersiveEndpoints.SkillsEndpoint's URL (targetUrl + "trainings/skills") plus the
        // required lang query param - built directly rather than via ImmersiveEndpoints since that
        // needs a live UserSessionData (IUserSessionProvider), whereas editor tooling here already
        // only has the raw targetUrl/token strings, same as ITrainingService.FetchTrainings.
        public async Task<SkillCatalogDTO> FetchSkillCatalog(string targetUrl, string token, string langCode)
        {
            return await HttpCallerUtility<SkillCatalogDTO>.UnityWebRequestAsync(logger, $"{targetUrl}trainings/skills?lang={langCode}", HttpVerbs.GET, authToken: token, requestId: "Skill Catalog Fetch");
        }
    }
}
