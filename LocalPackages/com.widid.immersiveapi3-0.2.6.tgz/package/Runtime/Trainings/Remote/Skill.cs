namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class Skill
    {
        private readonly int id;
        private readonly string name;

        public Skill(int id, string name)
        {
            this.id = id;
            this.name = name;
        }

        public int Id => id;
        public string Name => name;
    }
}
