using System.Threading.Tasks;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public interface ITrainingLocalizationService
    {
        Task<TrainingLocalizationResult> Fetch(string trainingInfoUrl, string bearerToken);
    }
}
