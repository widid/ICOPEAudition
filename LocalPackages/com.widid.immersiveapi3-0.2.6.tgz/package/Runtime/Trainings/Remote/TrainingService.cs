using System.Collections.Generic;
using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class TrainingService : ITrainingService
    {
        private readonly ILogger logger;

        public TrainingService(ILogger logger)
        {
            this.logger = logger;
        }

        public async Task<List<TrainingDTO>> FetchTrainings(string targetUrl, string token, string langCode)
        {
            return await HttpCallerUtility<List<TrainingDTO>>.UnityWebRequestAsync(logger, $"{targetUrl}trainings?lang=" + langCode, HttpVerbs.GET, authToken: token, requestId: "Training Fetch");
        }
    }
}
