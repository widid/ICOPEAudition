using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    /// <summary>
    /// Fetches a training's Title/BriefDescription in every language it's available in, via a
    /// single call to IImmersiveEndpoints.TrainingInfoAdress - its "trainings" array already
    /// carries one entry per available language, so no per-language re-fetching is needed. Mirrors
    /// the Demo's TrainingLocalizationFetcher (Assets/Scripts/Demo/LoginManager).
    /// </summary>
    public class TrainingLocalizationService : ITrainingLocalizationService
    {
        public async Task<TrainingLocalizationResult> Fetch(string trainingInfoUrl, string bearerToken)
        {
            WebRequestResult result = await WebRequestUtility.GetAsync(trainingInfoUrl, bearerToken);
            if (!result.Success)
                throw new InvalidOperationException($"GET {trainingInfoUrl} failed ({result.StatusCode}): {result.Error}");

            TrainingInfoResponse response = JsonConvert.DeserializeObject<TrainingInfoResponse>(result.Text);
            if (response?.Trainings == null)
                throw new InvalidOperationException($"GET {trainingInfoUrl} returned no \"trainings\" array. Response body:\n{result.Text}");

            LanguageDictionary nameTranslations = new(Array.Empty<LanguageDictionary.LanguageKey>(), new[] { 0, 1 });
            LanguageDictionary descriptionTranslations = new(Array.Empty<LanguageDictionary.LanguageKey>(), new[] { 0, 1 });

            foreach (TrainingInfoLocalizedEntry entry in response.Trainings)
            {
                int languageIndex = FindLanguageIndex(entry.Lang);
                if (languageIndex < 0)
                    continue;

                nameTranslations.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = languageIndex, value = entry.Title });
                descriptionTranslations.TryAddLanguage(new LanguageDictionary.LanguageKey { localizationIndex = languageIndex, value = entry.BriefDescription });
            }

            return new TrainingLocalizationResult(nameTranslations, descriptionTranslations);
        }

        // "lang" comes back upper-case (e.g. "FR") - LanguageDictionary.AvailableLanguages is lower-case.
        static int FindLanguageIndex(string lang)
        {
            if (string.IsNullOrEmpty(lang))
                return -1;

            for (int i = 0; i < LanguageDictionary.AvailableLanguages.Length; i++)
            {
                if (string.Equals(LanguageDictionary.AvailableLanguages[i], lang, StringComparison.OrdinalIgnoreCase))
                    return i;
            }

            return -1;
        }
    }
}
