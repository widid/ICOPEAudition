using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    /// <summary>
    /// A training's Title/BriefDescription translated into each language it's available in, as
    /// produced by TrainingLocalizationService.
    /// </summary>
    public class TrainingLocalizationResult
    {
        public LanguageDictionary NameTranslations { get; }
        public LanguageDictionary DescriptionTranslations { get; }

        public TrainingLocalizationResult(LanguageDictionary nameTranslations, LanguageDictionary descriptionTranslations)
        {
            NameTranslations = nameTranslations;
            DescriptionTranslations = descriptionTranslations;
        }
    }
}
