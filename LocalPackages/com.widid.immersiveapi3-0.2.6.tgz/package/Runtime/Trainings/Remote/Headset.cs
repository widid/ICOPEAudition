namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    public class Headset
    {
        private readonly int id;
        private readonly string name;
        private readonly string type;

        public Headset(int id, string name, string type)
        {
            this.id = id;
            this.name = name;
            this.type = type;
        }

        public int Id => id;
        public string Name => name;
        public string Type => type;
    }
}
