using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    // Mirrors SkillsEndpoint's response shape. Only primarySkills is modeled - the sibling "skills"
    // list in that response isn't needed for sub-category picking and is left for Newtonsoft to
    // ignore rather than modeled here.
    public class SkillCatalogDTO
    {
        private readonly List<PrimarySkillDTO> primarySkills;

        public SkillCatalogDTO(List<PrimarySkillDTO> primarySkills)
        {
            this.primarySkills = primarySkills;
        }

        public List<PrimarySkillDTO> PrimarySkills => primarySkills;
    }
}
