namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    // Renamed from "Training" - that name is reserved for the new local, editor-authored
    // TrainingSO in the parent WiDiD.ImmersiveAPI.Trainings namespace. This class is just the
    // per-language title/description/goals content nested inside a TrainingDTO.
    public class TrainingLocalizedContent
    {
        private readonly string lang;
        private readonly string title;
        private readonly string briefDescription;
        private readonly string fullDescription;
        private readonly string videoLink;
        private readonly string goal1;
        private readonly string goal2;
        private readonly string goal3;

        public TrainingLocalizedContent(string lang, string title, string briefDescription, string fullDescription, string videoLink, string goal1, string goal2, string goal3)
        {
            this.lang = lang;
            this.title = title;
            this.briefDescription = briefDescription;
            this.fullDescription = fullDescription;
            this.videoLink = videoLink;
            this.goal1 = goal1;
            this.goal2 = goal2;
            this.goal3 = goal3;
        }

        public string Lang => lang;
        public string Title => title;
        public string BriefDescription => briefDescription;
        public string FullDescription => fullDescription;
        public string VideoLink => videoLink;
        public string Goal1 => goal1;
        public string Goal2 => goal2;
        public string Goal3 => goal3;
    }
}
