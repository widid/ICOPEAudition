using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Trainings.Remote
{
    /// <summary>
    /// Minimal shape of the trainings/{id} (IImmersiveEndpoints.TrainingInfoAdress) response - only
    /// the "trainings" array of per-language Title/BriefDescription entries this is used for.
    /// </summary>
    public class TrainingInfoResponse
    {
        public List<TrainingInfoLocalizedEntry> Trainings { get; set; } = new();
    }
}
