using System.Threading.Tasks;
using TinCan;
using WiDiD.ImmersiveAPI.Networking;
using WiDiD.XAPI;

namespace WiDiD.ImmersiveAPI.Trainings
{
    /// <summary>
    /// Builds and posts a single xAPI statement for a given verb/statementable. The one dependency
    /// StrategyProgressController/StepProgressController need from TrainingRuntime - they build
    /// statementables via the *StatementFactory classes but never talk to the LRS directly.
    /// </summary>
    public interface IStatementSender
    {
        Task<StatementSendResult> Send(Verb verb, IStatementable statementable);
    }
}
