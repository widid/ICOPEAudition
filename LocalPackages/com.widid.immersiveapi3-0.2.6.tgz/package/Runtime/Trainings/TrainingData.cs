using System;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings.GameFlow;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Trainings
{
    [Serializable]
    public class TrainingData
    {
        // Unique across the whole project - enforced by TrainingEditorWindow, not here.
        [field: SerializeField] public string Id { get; set; } = string.Empty;

        // Facultative - compared against UserSessionSO.Data.ModuleArgument at launch to decide
        // which Training to start. Uniqueness is not enforced: leaving it blank (or shared) just
        // means this Training can't be auto-selected that way.
        [field: SerializeField] public string ModuleId { get; set; } = string.Empty;

        // Which backend catalog Training (TrainingDTO.Id) this local Training corresponds to -
        // set via TrainingEditorWindow's remote-training picker. Editor/debug-only: lets
        // TrainingEditorWindow's "Set Active" button fill UserSessionSO.Data.TrainingId with a
        // real backend id so debug statement-sends hit a valid xapi-events URL, and lets it
        // determine which local Training is "active" by comparing this to that same field.
        [field: SerializeField] public string RemoteTrainingId { get; set; } = string.Empty;

        // Title/BriefDescription fetched from the backend (see TrainingLocalizationService) for
        // whichever training RemoteTrainingId points to - cached here so SimulationStatementFactory
        // can read them synchronously instead of fetching on every statement built. Populated by
        // TrainingEditorWindow whenever RemoteTrainingId is linked/refreshed.
        [field: SerializeField] public LanguageDictionary LocalizedName { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });
        [field: SerializeField] public LanguageDictionary LocalizedDescription { get; set; } = new LanguageDictionary(new LanguageDictionary.LanguageKey[0], new int[] { 0, 1 });

        // Authored via the nodal GameFlow graph editor (Editor-only), but this field never
        // references that tooling - it's plain data, kept in sync by the editor tool.
        [field: SerializeField] public TrainingGameFlowData GameFlow { get; private set; } = new TrainingGameFlowData();
    }
}
