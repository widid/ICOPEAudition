using System;
using TinCan;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Fired by StatementSender.Send right after every attempted send, regardless of caller -
    /// GameFlow (Strategy/Step), Performance, Interaction, Skill, Reward and Badge all funnel
    /// through that one method, so this is the single place to observe every xAPI statement this
    /// runtime ever sends without threading a callback through every recorder/controller. Purely a
    /// debug/observability hook (see RuntimeHarness's StatementLogPopupController) - a listener
    /// exception is caught and logged here rather than left to propagate, so a broken/misconfigured
    /// listener (e.g. a missing UI template reference) can never turn into a false "send failed"
    /// reported back to whichever recorder/controller actually sent the statement.
    /// </summary>
    public static class StatementSendLog
    {
        public static event Action<Verb, Statement, StatementSendResult> OnStatementSent;

        public static void Raise(Verb verb, Statement statement, StatementSendResult result)
        {
            try
            {
                OnStatementSent?.Invoke(verb, statement, result);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[StatementSendLog] A listener threw while handling OnStatementSent: {exception}");
            }
        }
    }
}
