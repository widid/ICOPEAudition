using System.Text;
using System.Threading.Tasks;
using TinCan;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Posts a single xAPI statement to the Immersive backend's xapi-events endpoint
    /// (IImmersiveEndpoints.XAPIPostAdress), authenticating with the signed-in user's Bearer token.
    /// </summary>
    public class ImmersiveXapiEventSender
    {
        public async Task<StatementSendResult> SendAsync(Statement statement, string url, string bearerToken)
        {
            byte[] body = Encoding.UTF8.GetBytes(statement.ToJSON(false));
            WebRequestResult result = await WebRequestUtility.PostAsync(url, body, "application/json", authToken: bearerToken);

            if (result.Success)
            {
                return StatementSendResult.Ok();
            }

            string detail = string.IsNullOrEmpty(result.Text) ? result.Error : result.Text;
            return StatementSendResult.Failed(result.StatusCode, detail);
        }
    }
}
