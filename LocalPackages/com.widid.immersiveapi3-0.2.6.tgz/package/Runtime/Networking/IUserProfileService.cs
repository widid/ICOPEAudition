using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Networking
{
    public interface IUserProfileService
    {
        Task<ProfileInfo> FetchProfile();
    }
}
