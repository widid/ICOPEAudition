using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking
{
    [Serializable]
    public class TargetUrlConfigData
    {
        [field: SerializeField] public string DevUrl { get; private set; }
        [field: SerializeField] public string ProdUrl { get; private set; }

        // A backend served from the developer's own machine. Optional: left empty, it simply never
        // shows up in the target url dropdown (see LoginManagerRuntimeController).
        [field: SerializeField] public string LocalUrl { get; private set; }
    }
}
