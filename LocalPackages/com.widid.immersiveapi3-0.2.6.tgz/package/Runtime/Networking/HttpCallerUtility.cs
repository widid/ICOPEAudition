using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace WiDiD.ImmersiveAPI.Networking
{
    public enum HttpVerbs
    {
        GET, POST, PUT, DELETE
    }

    /// <summary>
    /// Sends an HTTP request over UnityWebRequest and deserializes the JSON response into T.
    /// Used instead of System.Net.Http.HttpClient since HttpClient's default handler depends on
    /// OS sockets that aren't available in a WebGL build.
    /// </summary>
    public static class HttpCallerUtility<T>
    {
        public static async Task<T> UnityWebRequestAsync(ILogger logger, string url, HttpVerbs verb, string authToken = null, string jsonContent = null, string requestId = "")
        {
            Debug.Log(url);
            string requestIdSuffix = !string.IsNullOrEmpty(requestId) ? $" [RequestId: {requestId}]" : string.Empty;

            using (UnityWebRequest request = new UnityWebRequest(url, verb.ToString()))
            {
                request.downloadHandler = new DownloadHandlerBuffer();

                if (!string.IsNullOrEmpty(jsonContent))
                {
                    byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonContent);
                    request.uploadHandler = new UploadHandlerRaw(bodyRaw) { contentType = "application/json" };
                    request.SetRequestHeader("Content-Type", "application/json");
                }

                if (!string.IsNullOrEmpty(authToken))
                {
                    request.SetRequestHeader("Authorization", $"Bearer {authToken}");
                }

                try
                {
                    await request.SendWebRequest();

                    if (request.result == UnityWebRequest.Result.Success)
                    {
                        return JsonConvert.DeserializeObject<T>(request.downloadHandler.text);
                    }

                    logger.Log($"Failed to call API. Status Code: {request.responseCode}, Error: {request.error}{requestIdSuffix}");
                    return default;
                }
                catch (Exception ex)
                {
                    logger.Log($"Exception: {ex.Message}{requestIdSuffix}");
                    if (ex.InnerException != null)
                    {
                        logger.Log($"Inner Exception: {ex.InnerException.Message}{requestIdSuffix}");
                    }
                    return default;
                }
            }
        }
    }
}