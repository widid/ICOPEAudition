using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking.Shutdown
{
    /// <summary>
    /// Picks the transport that can still post a statement on this platform once the app is going
    /// away - mirrors LaunchArgumentsReaderFactory's shape, and splits along the same line: WebGL
    /// has no OS sockets, everything else does.
    ///
    /// Unlike that factory this returns a working poster in the Editor too, so the Play-mode quit
    /// path can be exercised rather than only ever tested in a real build.
    /// </summary>
    public static class ShutdownStatementPosterFactory
    {
        public static IShutdownStatementPoster Create()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            return new WebGlShutdownStatementPoster();
#elif UNITY_STANDALONE || UNITY_ANDROID || UNITY_IOS || UNITY_EDITOR
            return new BlockingShutdownStatementPoster();
#else
            Debug.LogError("[xAPI] No shutdown statement poster is implemented for this platform - Terminated_Simulation will not be sent on quit.");
            return null;
#endif
        }
    }
}
