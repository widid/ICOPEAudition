using System;
using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Networking.Shutdown
{
    /// <summary>
    /// Posts statements while the app is going away - the one job UnityWebRequest cannot do, since
    /// it only ever completes from Unity's player loop and no caller here still has frames left to
    /// pump (see BlockingShutdownStatementPoster).
    ///
    /// Split into staging and posting because the two platforms learn the app is ending at very
    /// different moments. A standalone/mobile build is told first and can do the work then, so it
    /// stages and posts back to back. A browser build is told by an unload event that cannot
    /// safely re-enter WASM to ask what to send, so it needs the payload handed over in advance
    /// and refreshed as the session goes on (see WebGlShutdownStatementPoster).
    ///
    /// Takes serialized JSON bodies rather than Statements because neither implementation can
    /// await: the statements are built while the runtime is still healthy, leaving this nothing to
    /// do but hand bytes to a transport that outlives the process or page.
    /// </summary>
    public interface IShutdownStatementPoster
    {
        /// <summary>
        /// Whether arrival order actually follows the order given to Stage. False on WebGL, where
        /// a browser gives an unload handler no further turns of the event loop, so every request
        /// has to be fired at once - each statement's own xAPI timestamp, stamped when it was
        /// built (see StatementBuilder), is what keeps them ordered there instead.
        /// </summary>
        bool PreservesArrivalOrder { get; }

        /// <summary>
        /// Declares what would have to be sent if the app ended right now - terminated last.
        /// Replaces anything staged before; safe to call repeatedly.
        /// </summary>
        void Stage(IReadOnlyList<string> bodies, string url, string bearerToken);

        /// <summary>
        /// Posts whatever is currently staged, once. Idempotent: a second call sends nothing, so a
        /// platform that raises more than one teardown signal cannot duplicate a statement.
        /// </summary>
        void PostStaged(TimeSpan timeout);
    }
}
