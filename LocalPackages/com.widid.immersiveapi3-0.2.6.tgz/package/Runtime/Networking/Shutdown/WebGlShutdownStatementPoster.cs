using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking.Shutdown
{
    /// <summary>
    /// Hands the final statements to the browser, which holds them and posts them with
    /// fetch(keepalive) when the page actually goes away, so each request outlives the teardown
    /// (see WiDiDShutdownPost.jslib and .jspre).
    ///
    /// A browser build has neither of the things the other implementation relies on. There are no
    /// OS sockets for HttpWebRequest, and there is no reliable "the app is ending" callback into
    /// managed code at all: Application.quitting is never raised, Application.Quit() is a no-op,
    /// and an unload handler that re-entered WASM to ask what to send would be racing the very
    /// teardown it is reacting to. Hence staging ahead of time - Stage is called repeatedly as the
    /// session runs, and the JS side owns the unload listeners and the sending.
    ///
    /// PostStaged exists for the deliberate exit that knows the app is ending before the browser
    /// does (see AppTermination.Terminate) and shares the one-shot flag with those listeners, so a
    /// statement cannot go out twice.
    /// </summary>
    public class WebGlShutdownStatementPoster : IShutdownStatementPoster
    {
        public bool PreservesArrivalOrder => false;

#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        static extern void WiDiD_StageShutdownStatements(string url, string bearerToken, string bodiesJson);

        [DllImport("__Internal")]
        static extern void WiDiD_PostStagedNow();
#endif

        public void Stage(IReadOnlyList<string> bodies, string url, string bearerToken)
        {
            string bodiesJson = JsonConvert.SerializeObject(bodies);

#if UNITY_WEBGL && !UNITY_EDITOR
            WiDiD_StageShutdownStatements(url, bearerToken ?? string.Empty, bodiesJson);
#else
            Debug.LogWarning($"[xAPI] WebGlShutdownStatementPoster was used outside a WebGL build - {bodies.Count} statement(s) were not staged.");
#endif
        }

        /// <summary>
        /// Timeout is ignored: nothing here waits for a response, and once the page is gone the
        /// browser owns the lifetime of a keepalive request.
        /// </summary>
        public void PostStaged(TimeSpan timeout)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            WiDiD_PostStagedNow();
#endif
        }
    }
}
