using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking.Shutdown
{
    /// <summary>
    /// Posts the final statements over HttpWebRequest, blocking the calling thread until each one
    /// is answered or times out, one after another.
    ///
    /// Deliberately not UnityWebRequest, which everything else in this package uses (see
    /// WebRequestUtility): a UnityWebRequest only completes when Unity raises AsyncOperation
    /// .completed from the player loop, and this runs either after the final frame
    /// (Application.quitting) or while frames are stopped (OnApplicationPause), so that completion
    /// would never arrive and the await behind it would never resume. HttpWebRequest needs no
    /// player loop at all - just the OS socket stack - which is also why WebGL, having no sockets,
    /// needs its own implementation instead (see WebGlShutdownStatementPoster).
    ///
    /// Blocking is the point rather than an oversight: returning before the server has answered
    /// would let the process exit out from under the request. It is also what makes arrival order
    /// match the staged order, so terminated genuinely lands last.
    /// </summary>
    public class BlockingShutdownStatementPoster : IShutdownStatementPoster
    {
        IReadOnlyList<string> staged;
        string endpointUrl;
        string token;
        bool posted;

        public bool PreservesArrivalOrder => true;

        public void Stage(IReadOnlyList<string> bodies, string url, string bearerToken)
        {
            staged = bodies;
            endpointUrl = url;
            token = bearerToken;
        }

        public void PostStaged(TimeSpan timeout)
        {
            if (posted || staged == null)
                return;

            posted = true;

            foreach (string body in staged)
                Post(body, endpointUrl, token, timeout);
        }

        static void Post(string body, string url, string bearerToken, TimeSpan timeout)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Timeout = (int)timeout.TotalMilliseconds;
                request.ReadWriteTimeout = (int)timeout.TotalMilliseconds;

                if (!string.IsNullOrEmpty(bearerToken))
                    request.Headers["Authorization"] = "Bearer " + bearerToken;

                byte[] payload = Encoding.UTF8.GetBytes(body);
                request.ContentLength = payload.Length;

                using (Stream stream = request.GetRequestStream())
                    stream.Write(payload, 0, payload.Length);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    Debug.Log($"[xAPI] Shutdown post -> OK ({(int)response.StatusCode})");
            }
            catch (WebException exception)
            {
                Debug.LogError($"[xAPI] Shutdown post failed ({Describe(exception)}): {exception.Message}");
            }
            catch (Exception exception)
            {
                Debug.LogError($"[xAPI] Shutdown post failed: {exception.Message}");
            }
        }

        static string Describe(WebException exception)
        {
            using (HttpWebResponse response = exception.Response as HttpWebResponse)
                return response != null ? $"HTTP {(int)response.StatusCode}" : "no response";
        }
    }
}
