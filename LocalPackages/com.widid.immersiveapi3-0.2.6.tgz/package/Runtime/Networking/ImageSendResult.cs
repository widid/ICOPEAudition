namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Outcome of uploading an image to the Immersive backend's file storage endpoint: whether it
    /// succeeded, the stored file's URL (only set on success), the HTTP status code (0 if the
    /// request never reached the server), and a human-readable message for display.
    /// </summary>
    public class ImageSendResult
    {
        public bool Success { get; }
        public string Url { get; }
        public long StatusCode { get; }
        public string Message { get; }

        private ImageSendResult(bool success, string url, long statusCode, string message)
        {
            Success = success;
            Url = url;
            StatusCode = statusCode;
            Message = message;
        }

        public static ImageSendResult Ok(string url)
        {
            return new ImageSendResult(true, url, 200, null);
        }

        public static ImageSendResult Failed(long statusCode, string message)
        {
            return new ImageSendResult(false, null, statusCode, message);
        }

        public static ImageSendResult Failed(string message)
        {
            return new ImageSendResult(false, null, 0, message);
        }
    }
}
