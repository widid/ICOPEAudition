using System.Threading.Tasks;
using Newtonsoft.Json;
using WiDiD.ImmersiveAPI.Networking.Progression;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Fetches a user's stored progression for a training from the Immersive backend.
    /// </summary>
    public class UserProgressionService : IUserProgressionService
    {
        private readonly IImmersiveEndpoints endpoints;
        private readonly ILogger logger;

        public UserProgressionService(IImmersiveEndpoints endpoints, ILogger logger)
        {
            this.endpoints = endpoints;
            this.logger = logger;
        }

        public async Task<UserProgressionData> FetchProgression(string userId, int trainingId, string langCode)
        {
            WebRequestResult result = await WebRequestUtility.GetAsync(endpoints.GetProgressionAdress(userId, trainingId, langCode), endpoints.UserSession.DecodedToken);

            if (!result.Success)
            {
                logger.Log($"Failed to fetch user progression ({result.StatusCode}): {result.Error}");
                return null;
            }

            return JsonConvert.DeserializeObject<UserProgressionData>(result.Text);
        }
    }
}
