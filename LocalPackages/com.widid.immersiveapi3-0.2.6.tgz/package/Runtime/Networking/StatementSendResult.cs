namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Outcome of posting a statement to an LRS or the Immersive backend: whether it succeeded,
    /// the HTTP status code (0 if the request never reached the server), and a human-readable
    /// message for display.
    ///
    /// Rejected separates the two kinds of failure a caller can get back: a rejection never left
    /// the process at all (unknown id, locked step, runtime not ready) and is entirely the caller's
    /// to fix, whereas a plain failure means the statement was built and posted but the server
    /// refused it or was unreachable. StatementFailureLog reports each kind from a different layer
    /// and relies on this to not report the same failure twice.
    /// </summary>
    public class StatementSendResult
    {
        public bool Success { get; }
        public long StatusCode { get; }
        public string Message { get; }
        public bool Rejected { get; }

        private StatementSendResult(bool success, long statusCode, string message, bool rejected = false)
        {
            Success = success;
            StatusCode = statusCode;
            Message = message;
            Rejected = rejected;
        }

        public static StatementSendResult Ok()
        {
            return new StatementSendResult(true, 200, null);
        }

        public static StatementSendResult Failed(long statusCode, string message)
        {
            return new StatementSendResult(false, statusCode, message);
        }

        public static StatementSendResult Failed(string message)
        {
            return new StatementSendResult(false, 0, message);
        }

        /// <summary>
        /// A statement that was never sent because the call itself was invalid. Reported by
        /// TrainingRuntime rather than by StatementSender, which never sees one.
        /// </summary>
        public static StatementSendResult Rejection(string message)
        {
            return new StatementSendResult(false, 0, message, rejected: true);
        }

        /// <summary>
        /// A statement the normal send path handed off rather than posting itself - specifically,
        /// one still queued when the app started tearing down, which the shutdown poster took over
        /// (see StatementSendQueue.TakeWaiting). Not a failure and not a rejection: its outcome is
        /// simply unknowable from here, since the process or page is gone before any response
        /// could come back. Deliberately not reported to StatementFailureLog, which would be
        /// claiming a failure nobody observed.
        /// </summary>
        public static StatementSendResult Deferred(string message)
        {
            return new StatementSendResult(false, 0, message);
        }
    }
}
