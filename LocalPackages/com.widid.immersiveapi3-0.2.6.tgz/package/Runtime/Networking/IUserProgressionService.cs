using System.Threading.Tasks;
using WiDiD.ImmersiveAPI.Networking.Progression;

namespace WiDiD.ImmersiveAPI.Networking
{
    // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    public interface IUserProgressionService
    {
        Task<UserProgressionData> FetchProgression(string userId, int trainingId, string langCode);
    }
}
