namespace WiDiD.ImmersiveAPI.Networking
{
    public interface ITargetUrlConfigProvider
    {
        TargetUrlConfigData Data { get; }
    }
}
