using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEngine.Networking;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Uploads an already-encoded image as multipart/form-data to the Immersive backend's file
    /// storage endpoint (IImmersiveEndpoints.FileSendingAdress) and reads back the resulting stored
    /// file's URL from the response. Mirrors the legacy StatImageCaptureManager/DataSender flow's
    /// request shape (single "file" form section, response JSON { "value": "<url>" }).
    /// </summary>
    public class ImmersiveImageSender
    {
        public async Task<ImageSendResult> SendAsync(byte[] encodedImage, string fileName, string contentType, string url, string bearerToken)
        {
            byte[] boundary = UnityWebRequest.GenerateBoundary();
            byte[] body = BuildMultipartBody(encodedImage, fileName, contentType, boundary);

            WebRequestResult result = await WebRequestUtility.PostAsync(url, body, $"multipart/form-data; boundary={Encoding.UTF8.GetString(boundary)}", authToken: bearerToken);

            if (!result.Success)
            {
                string detail = string.IsNullOrEmpty(result.Text) ? result.Error : result.Text;
                return ImageSendResult.Failed(result.StatusCode, detail);
            }

            Dictionary<string, string> response = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.Text);
            if (response != null && response.TryGetValue("value", out string storedUrl) && !string.IsNullOrEmpty(storedUrl))
            {
                return ImageSendResult.Ok(storedUrl);
            }

            return ImageSendResult.Failed(result.StatusCode, "Response did not contain a stored file url.");
        }

        private static byte[] BuildMultipartBody(byte[] encodedImage, string fileName, string contentType, byte[] boundary)
        {
            List<IMultipartFormSection> form = new() { new MultipartFormFileSection("file", encodedImage, fileName, contentType) };

            byte[] formSections = UnityWebRequest.SerializeFormSections(form, boundary);
            byte[] terminate = Encoding.UTF8.GetBytes("\r\n--" + Encoding.UTF8.GetString(boundary) + "--");

            byte[] body = new byte[formSections.Length + terminate.Length];
            Buffer.BlockCopy(formSections, 0, body, 0, formSections.Length);
            Buffer.BlockCopy(terminate, 0, body, formSections.Length, terminate.Length);
            return body;
        }
    }
}
