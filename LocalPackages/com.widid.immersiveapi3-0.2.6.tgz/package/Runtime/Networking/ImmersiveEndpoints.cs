namespace WiDiD.ImmersiveAPI
{
    public class ImmersiveEndpoints : IImmersiveEndpoints
    {
        public UserSessionData UserSession { get; }

        public ImmersiveEndpoints(IUserSessionProvider userSessionProvider)
        {
            UserSession = userSessionProvider.Data;
        }

        public string XAPIPostAdress => UserSession.TargetUrl + "trainings/" + UserSession.TrainingId + "/xapi-events";
        public string JsonStepAdress => UserSession.TargetUrl + "trainings/" + UserSession.TrainingId + "/json-step";
        public string TrainingInfoAdress => UserSession.TargetUrl + "trainings/" + UserSession.TrainingId;
        public string FileSendingAdress => UserSession.TargetUrl + "trainings/" + UserSession.TrainingId + "/my-stats/file";
        public string SkillsAdress => UserSession.TargetUrl + "trainings/skills";
        // TEMPORARY-STORED-PROGRESS
        public string GetProgressionAdress(string userId, int trainingId, string langCode) => UserSession.TargetUrl + "users/" + userId + "/stats/general?trainingId=" + trainingId + "&lang=" + langCode;
        public string UserProfileAdress => UserSession.TargetUrl + "users/profile";
    }
}
