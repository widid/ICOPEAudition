using System;
using System.Text;
using System.Threading.Tasks;
using TinCan;
using UnityEngine.Networking;
using WiDiD.Extension;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Posts a single xAPI statement to an LRS's /statements resource over UnityWebRequest,
    /// authenticating with the LRS Basic Auth key/secret pair.
    /// </summary>
    public class LrsStatementSender
    {
        private const string XApiVersion = "1.0.3";

        public async Task<StatementSendResult> SendAsync(Statement statement, string endpoint, string key, string secret)
        {
            string statementsUrl = BuildStatementsUrl(endpoint);
            byte[] body = Encoding.UTF8.GetBytes(statement.ToJSON(false));

            using UnityWebRequest request = new UnityWebRequest(statementsUrl, UnityWebRequest.kHttpVerbPOST)
            {
                uploadHandler = new UploadHandlerRaw(body) { contentType = "application/json" },
                downloadHandler = new DownloadHandlerBuffer()
            };

            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", BuildBasicAuthHeader(key, secret));
            request.SetRequestHeader("X-Experience-API-Version", XApiVersion);

            await request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                return StatementSendResult.Ok();
            }

            string responseBody = request.downloadHandler?.text;
            string detail = string.IsNullOrEmpty(responseBody) ? request.error : responseBody;
            return StatementSendResult.Failed(request.responseCode, detail);
        }

        /// <summary>
        /// Resolves the statements resource URL whether Endpoint is configured as the LRS root
        /// or already includes the resource path.
        /// </summary>
        private static string BuildStatementsUrl(string endpoint)
        {
            string trimmed = endpoint.TrimEnd('/');
            return trimmed.EndsWith("/statements", StringComparison.OrdinalIgnoreCase)
                ? trimmed
                : trimmed + "/statements";
        }

        private static string BuildBasicAuthHeader(string key, string secret)
        {
            return "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(key + ":" + secret));
        }
    }
}
