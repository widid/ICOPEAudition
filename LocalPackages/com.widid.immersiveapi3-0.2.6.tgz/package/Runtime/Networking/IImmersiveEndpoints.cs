namespace WiDiD.ImmersiveAPI
{
    public interface IImmersiveEndpoints
    {
        UserSessionData UserSession { get; }
        string XAPIPostAdress { get; }
        string JsonStepAdress { get; }
        string TrainingInfoAdress { get; }
        string FileSendingAdress { get; }
        // TEMPORARY-STORED-PROGRESS
        string GetProgressionAdress(string userId, int trainingId, string langCode);
        string UserProfileAdress { get; }
    }
}
