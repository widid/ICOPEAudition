using System;
using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// The single place every failed statement surfaces, so a caller that discards the
    /// Task&lt;StatementSendResult&gt; every TrainingRuntime send method returns - which host game code
    /// invariably does, calling them fire-and-forget from a void Unity callback with no compiler
    /// warning - still sees the failure in the console instead of nothing at all. Counterpart to
    /// StatementSendLog, which reports every send regardless of outcome; this one reports failures
    /// only, and includes the ones StatementSendLog never sees because they were rejected before a
    /// request was ever built (see StatementSendResult.Rejected).
    ///
    /// Reported from exactly two layers, kept from double-reporting by Rejected: StatementSender
    /// reports what it actually posted and the server refused (covering the automatic sends in
    /// StrategyProgressController/SimulationProgressController/SkillRecorder/BadgeRecorder, which
    /// never pass through TrainingRuntime's own methods), and TrainingRuntime reports the
    /// rejections its methods hand back before any send is attempted.
    ///
    /// A listener exception is caught and logged here rather than left to propagate, same as
    /// StatementSendLog - a broken listener must never turn into a second reported failure.
    /// </summary>
    public static class StatementFailureLog
    {
        public static event Action<StatementSendResult> OnStatementFailed;

        public static void Report(string context, StatementSendResult result)
        {
            if (result == null || result.Success)
                return;

            Debug.LogError($"[xAPI] {context} failed: {result.Message}{(result.StatusCode == 0 ? string.Empty : $" (HTTP {result.StatusCode})")}");

            try
            {
                OnStatementFailed?.Invoke(result);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[StatementFailureLog] A listener threw while handling OnStatementFailed: {exception}");
            }
        }
    }
}
