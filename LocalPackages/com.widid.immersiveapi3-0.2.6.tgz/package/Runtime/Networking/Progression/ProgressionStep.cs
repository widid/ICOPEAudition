namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// One step's stored progression. Succeeded is "was this step ever completed", not "was it
    /// passed" - a step completed without ever reaching its passing score still comes back
    /// succeeded, with Highscore reporting how far it got.
    /// </summary>
    public class ProgressionStep
    {
        public string Current { get; set; }
        public string Name { get; set; }
        public bool Succeeded { get; set; }
        public float Score { get; set; }
        public float Highscore { get; set; }
        public bool IsPercent { get; set; }
    }
}
