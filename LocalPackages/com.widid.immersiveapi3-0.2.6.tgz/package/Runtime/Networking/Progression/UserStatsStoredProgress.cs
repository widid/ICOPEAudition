using System;
using System.Collections.Generic;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;

namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// IStoredProgress read from the users/{id}/stats/general response. Performances and skills are
    /// matched by activity URI; points are training-wide, so every reward reads the same total.
    /// </summary>
    public class UserStatsStoredProgress : IStoredProgress
    {
        readonly Dictionary<string, float> performanceValues;
        readonly Dictionary<string, float> skillValues;
        readonly HashSet<int> badgeNumbers;
        readonly float totalPoint;

        public IReadOnlyList<StepProgressSnapshot> Steps { get; }

        public UserStatsStoredProgress(UserProgressionData data)
        {
            UserProgressionStat stat = data.UserStat;

            Steps = GameFlowProgressMapper.ToStepSnapshots(stat?.JsonStep);
            performanceValues = IndexByActivity(stat?.Stats);
            skillValues = IndexByActivity(stat?.Skills);
            badgeNumbers = stat?.BadgeNumbers != null ? new HashSet<int>(stat.BadgeNumbers) : new HashSet<int>();
            totalPoint = data.TotalPoint;
        }

        public bool TryGetPerformanceRaw(Uri performanceUri, out int raw)
        {
            bool found = performanceValues.TryGetValue(Key(performanceUri), out float value);
            raw = Mathf.RoundToInt(value);
            return found;
        }

        public bool TryGetSkillScaled(Uri skillUri, out float scaled) => skillValues.TryGetValue(Key(skillUri), out scaled);

        public bool TryGetRewardRaw(Uri rewardUri, out int raw)
        {
            raw = Mathf.RoundToInt(totalPoint);
            return totalPoint > 0f;
        }

        public bool HasReceivedBadge(int slotNumber) => badgeNumbers.Contains(slotNumber);

        static Dictionary<string, float> IndexByActivity(List<ProgressionStatEntry> entries)
        {
            Dictionary<string, float> index = new Dictionary<string, float>();

            if (entries == null)
                return index;

            foreach (ProgressionStatEntry entry in entries)
            {
                if (entry?.StatValue != null && Uri.TryCreate(entry.Stat, UriKind.Absolute, out Uri uri))
                    index[Key(uri)] = entry.StatValue.Value;
            }

            return index;
        }

        static string Key(Uri uri) => uri.AbsoluteUri.TrimEnd('/');
    }
}
