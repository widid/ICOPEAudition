using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    // One strategy's stored progression. "current" is the strategy's own authored Id (see
    // TrainingStrategyData.Id) - that's what the whole tree is keyed by on both sides.
    public class ProgressionSession
    {
        public string Current { get; set; }
        public string Name { get; set; }
        public List<ProgressionStep> Steps { get; set; } = new List<ProgressionStep>();
    }
}
