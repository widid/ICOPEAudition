using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// The "jsonStep" object of the progression response: the same session/step tree the
    /// trainings/{id}/json-step endpoint returns, but filled in with what this user actually did.
    /// Modeled separately from GameFlowData rather than reused, because the two payloads don't
    /// match: this one's names are already localized to a single string (the endpoint is queried
    /// with a lang parameter), where json-step returns a per-language object.
    /// </summary>
    public class ProgressionJsonStep
    {
        public List<ProgressionSession> Sessions { get; set; } = new List<ProgressionSession>();
    }
}
