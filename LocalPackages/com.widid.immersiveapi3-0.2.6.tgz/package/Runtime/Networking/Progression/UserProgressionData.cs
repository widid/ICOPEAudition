namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    // Maps to the users/{id}/stats/general response root - only the fields consumed at runtime are modeled.
    public class UserProgressionData
    {
        public float TotalPoint { get; set; }
        public UserProgressionStat UserStat { get; set; }
    }
}
