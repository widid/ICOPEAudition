namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    // One entry of the progression response's "stats"/"skills" arrays - Stat is the activity's xAPI URI.
    public class ProgressionStatEntry
    {
        public string Stat { get; set; }
        public float? StatValue { get; set; }
    }
}
