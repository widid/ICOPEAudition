using System;
using System.Globalization;
using System.Threading.Tasks;
using UnityEngine;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.Progress;
using WiDiD.ImmersiveAPI.Trainings.GameFlow.StoredProgress;
using WiDiD.Localization;

namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    /// <summary>
    /// TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    /// Reads stored progress from the Immersive backend's user stats for the session's training.
    /// </summary>
    public class UserStatsProgressSource : IStoredProgressSource
    {
        const string FallbackLanguageCode = "en";

        readonly IUserProgressionService service;
        readonly UserSessionData session;

        public UserStatsProgressSource(IUserProgressionService service, UserSessionData session)
        {
            this.service = service;
            this.session = session;
        }

        public async Task<IStoredProgress> Fetch()
        {
            if (!int.TryParse(session.TrainingId, out int trainingId))
            {
                Debug.LogWarning($"[UserStatsProgressSource] Training id '{session.TrainingId}' is not numeric - no stored progress can be read.");
                return null;
            }

            UserProgressionData data = await service.FetchProgression(session.UserId, trainingId, CurrentLanguageCode());
            return data == null ? null : new UserStatsStoredProgress(data);
        }

        static string CurrentLanguageCode()
        {
            string code = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
            return Array.IndexOf(LanguageDictionary.AvailableLanguages, code) >= 0 ? code : FallbackLanguageCode;
        }
    }
}
