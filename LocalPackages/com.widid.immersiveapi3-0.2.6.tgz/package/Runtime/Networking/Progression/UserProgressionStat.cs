using System.Collections.Generic;

namespace WiDiD.ImmersiveAPI.Networking.Progression
{
    // TEMPORARY-STORED-PROGRESS (see Documentation~/StoredProgressBridge.md).
    // The "userStat" object of the progression response - only the fields consumed at runtime are modeled.
    public class UserProgressionStat
    {
        public ProgressionJsonStep JsonStep { get; set; }
        public List<int> BadgeNumbers { get; set; } = new List<int>();
        public List<ProgressionStatEntry> Stats { get; set; } = new List<ProgressionStatEntry>();
        public List<ProgressionStatEntry> Skills { get; set; } = new List<ProgressionStatEntry>();
    }
}
