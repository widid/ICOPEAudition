using System.Threading.Tasks;
using Newtonsoft.Json;
using WiDiD.ImmersiveAPI.Networking.Authentification.User;

namespace WiDiD.ImmersiveAPI.Networking
{
    /// <summary>
    /// Reads the signed-in user's profile (name, email, roles) from the Immersive backend. The
    /// launch-argument flow never provides these - the launcher only passes a user id - so this is
    /// the only way to identify the actor by anything but its account (see ActorFactory).
    /// </summary>
    public class UserProfileService : IUserProfileService
    {
        private readonly IImmersiveEndpoints endpoints;
        private readonly ILogger logger;

        public UserProfileService(IImmersiveEndpoints endpoints, ILogger logger)
        {
            this.endpoints = endpoints;
            this.logger = logger;
        }

        public async Task<ProfileInfo> FetchProfile()
        {
            WebRequestResult result = await WebRequestUtility.GetAsync(endpoints.UserProfileAdress, endpoints.UserSession.DecodedToken);

            if (!result.Success)
            {
                logger.Log($"Failed to fetch user profile ({result.StatusCode}): {result.Error}");
                return null;
            }

            return JsonConvert.DeserializeObject<ProfileInfo>(result.Text);
        }
    }
}
