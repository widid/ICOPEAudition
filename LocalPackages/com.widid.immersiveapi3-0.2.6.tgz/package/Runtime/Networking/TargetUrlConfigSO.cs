using UnityEngine;

namespace WiDiD.ImmersiveAPI.Networking
{
    [CreateAssetMenu(fileName = "NewTargetUrlConfigSO", menuName = "Data/Target Url Config")]
    public class TargetUrlConfigSO : ScriptableObject, ITargetUrlConfigProvider
    {
        [field: SerializeField]
        public TargetUrlConfigData Data { get; private set; } = new TargetUrlConfigData();
    }
}
