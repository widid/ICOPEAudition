using System;
using System.IO;
using UnityEngine;

namespace WiDiD.Applications.Launch
{

    public static class SharedDataFolder
    {
        // Returns a path accessible to both client and apps
        public static string GetSharedFolder()
        {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            return GetWindowsSharedFolder();
#elif UNITY_ANDROID && !UNITY_EDITOR
        return GetAndroidSharedFolder();
#else
        return "";
#endif
        }

        // Creates the folder if it doesn't exist
        public static string GetOrCreateSharedFolder()
        {
            string path = GetSharedFolder();
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);

                // Set proper permissions (especially important for Android)
                SetFolderPermissions(path);
            }
            return path;
        }

        #region Platform-Specific Implementations

        private static string GetWindowsSharedFolder()
        {
            // Windows: Use CommonApplicationData (All Users)
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Launch Arguments");

            // Alternative for per-user storage:
            // Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)

            return path;
        }

        private static string GetAndroidSharedFolder()
        {
            //We could try simply folder like this : 
            //return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Launch Arguments");
            // Try external storage first
            // In both apps (need WRITE_EXTERNAL_STORAGE permission)


            // Fallback to internal storage
            return Path.Combine(Application.persistentDataPath, "Launch Arguments");
        }

        private static string GetAndroidExternalStorage()
        {
            try
            {
                // Check external storage availability via Android Java API
                using (AndroidJavaClass environment = new AndroidJavaClass("android.os.Environment"))
                using (AndroidJavaObject externalDir = environment.CallStatic<AndroidJavaObject>("getExternalStorageDirectory"))
                {
                    string externalPath = externalDir.Call<string>("getAbsolutePath");

                    // Check if storage is mounted
                    string state = environment.CallStatic<string>("getExternalStorageState");
                    if (state == "mounted" || state == "mounted_ro")
                    {
                        // Recommended app-specific directory
                        return Path.Combine(externalPath, "Android", "data", Application.identifier, "files");
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning($"Failed to get external storage: {e.Message}");
            }
            return null;
        }

        private static void SetFolderPermissions(string path)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
        try 
        {
            // Set world-readable/writable permissions on Android
            using (AndroidJavaClass file = new AndroidJavaClass("java.io.File"))
            using (AndroidJavaObject fileObj = new AndroidJavaObject("java.io.File", path))
            {
                // rwxrwx--x (771) permissions:
                // Owner: read/write/execute
                // Group: read/write/execute
                // Others: execute only
                bool success = fileObj.Call<bool>("setExecutable", true, false);
                success &= fileObj.Call<bool>("setReadable", true, false);
                success &= fileObj.Call<bool>("setWritable", true, false);
                
                if (!success)
                    Debug.LogWarning("Failed to set full permissions on Android folder");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Android permission error: {e.Message}");
        }
#endif

            // Windows permissions are typically fine by default
        }

        #endregion

        #region Utility Methods

        public static void CleanOldFiles()
        {
            string folder = GetSharedFolder();
            if (!Directory.Exists(folder)) return;


            foreach (string file in Directory.GetFiles(folder))
            {
                try
                {
                    FileInfo fi = new FileInfo(file);

                    fi.Delete();

                }
                catch (Exception e)
                {
                    Debug.LogWarning($"Couldn't delete old file {file}: {e.Message}");
                }
            }
        }

        public static string GetSharedFilePath(string filename)
        {
            return Path.Combine(GetOrCreateSharedFolder(), filename);
        }

        #endregion
    }
}