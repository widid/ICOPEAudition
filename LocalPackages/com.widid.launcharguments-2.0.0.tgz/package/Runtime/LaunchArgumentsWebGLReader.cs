using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using PlayerPrefs = Jammer.PlayerPrefs;
using System.Runtime.InteropServices;
using Cysharp.Threading.Tasks;

namespace WiDiD.Applications.Launch
{
#if UNITY_WEBGL || UNITY_EDITOR
    public class LaunchArgumentsWebGLReader : ILaunchArgumentsReader
    {
        private const string MasterContentsSegment = "master_contents";
        private const string FilesSegment = "files";
        private const string TrainingIdQueryKey = "trainingId";

        [DllImport("__Internal")]
        private static extern string GetURLFromPage();

        public async UniTask<LaunchArguments> WaitForLaunchArguments()
        {
            await UniTask.Yield();
            if (!PlayerPrefs.HasKey("token"))
            {
                Debug.LogError("This WiDiD Content has been launched outside the WiDiD Immersive context, features will be missing");
                return null;
            }
            string token = ASCIIEncoding.ASCII.GetString(System.Convert.FromBase64String(PlayerPrefs.GetString("token")));

            string pageUrl = GetURLFromPage();
            string path = SplitUrl(pageUrl, out string query);
            List<string> url = path.Split('/').ToList();

            int trainingId = url.Contains(MasterContentsSegment)
                ? ReadTrainingIdFromQuery(query)
                : ReadTrainingIdFromPath(url);
            string targetUrl = url[0] + "//" + url[2] + "/api/v1/";

            LaunchArguments args = new LaunchArguments(token, trainingId, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(), "", targetUrl, "Online", "");
            return args;
        }

        /// Returns the path part of the url and outputs its query string, both stripped of any fragment.
        private static string SplitUrl(string pageUrl, out string query)
        {
            query = string.Empty;
            if (string.IsNullOrEmpty(pageUrl)) return string.Empty;

            int fragmentIndex = pageUrl.IndexOf('#');
            if (fragmentIndex >= 0) pageUrl = pageUrl.Substring(0, fragmentIndex);

            int queryIndex = pageUrl.IndexOf('?');
            if (queryIndex < 0) return pageUrl;

            query = pageUrl.Substring(queryIndex + 1);
            return pageUrl.Substring(0, queryIndex);
        }

        private static int ReadTrainingIdFromPath(List<string> urlSegments)
        {
            int filesIndex = urlSegments.IndexOf(FilesSegment);
            if (filesIndex < 0 || filesIndex + 1 >= urlSegments.Count)
            {
                Debug.LogError($"No '{FilesSegment}' segment followed by a training id found in the page URL");
                return 0;
            }
            int.TryParse(urlSegments[filesIndex + 1], out int trainingId);
            return trainingId;
        }

        private static int ReadTrainingIdFromQuery(string query)
        {
            foreach (string parameter in query.Split('&'))
            {
                string[] keyValue = parameter.Split(new[] { '=' }, 2);
                if (keyValue.Length != 2) continue;
                if (!string.Equals(keyValue[0], TrainingIdQueryKey, StringComparison.OrdinalIgnoreCase)) continue;

                int.TryParse(keyValue[1], out int trainingId);
                return trainingId;
            }
            Debug.LogError($"No '{TrainingIdQueryKey}' query parameter found in the page URL");
            return 0;
        }
    }
#endif
}
