using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace WiDiD.Applications.Launch
{
    public class LaunchArgumentCommandLineReader : ILaunchArgumentsReader
    {

        public async UniTask<LaunchArguments> WaitForLaunchArguments()
        {
            await Task.Yield();
            Debug.Log("App version :" + Application.version);
            Debug.Log("Unity version : " + Application.unityVersion);

            string[] commandLineArgs = System.Environment.GetCommandLineArgs();
            string token = string.Empty;
            string trainingId = string.Empty;
            string moduleArgument = string.Empty;
            string targetUrl = string.Empty;
            string mode = string.Empty;
            string appLaunchTime = string.Empty;

            for (int i = 0; i < commandLineArgs.Length - 1; i++)
            {
                switch (commandLineArgs[i])
                {
                    case "-ImmersiveUserToken":
                        token = commandLineArgs[i + 1];
                        break;
                    case "-TrainingID":
                        trainingId = commandLineArgs[i + 1];
                        break;
                    case "-LaunchedAt":
                        appLaunchTime = commandLineArgs[i + 1];
                        break;
                    case "-ModuleArgument":
                        moduleArgument = commandLineArgs[i + 1];
                        break;
                    case "-ImmersiveURL":
                        targetUrl = commandLineArgs[i + 1];
                        break;
                    case "-Mode":
                        mode = commandLineArgs[i + 1];
                        break;
                }
            }

            if (string.IsNullOrEmpty(token) || !int.TryParse(trainingId, out int parsedTrainingId))
            {
                Debug.LogError("[LaunchArguments] Command line has no valid -ImmersiveUserToken / -TrainingID, launch arguments will not be read.");
                return null;
            }

            return new LaunchArguments(token, parsedTrainingId, appLaunchTime, moduleArgument, targetUrl, mode, "EXE");
        }
    }
}
