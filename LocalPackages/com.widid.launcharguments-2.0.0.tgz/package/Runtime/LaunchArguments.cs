namespace WiDiD.Applications.Launch
{
    public class LaunchArguments
    {
        public int TrainingID { get; private set; }
        public string UserToken { get; private set; }
        public int TrainningID { get; private set; }
        public string LaunchedAt { get; private set; }
        public string ModuleArgument { get; private set; }
        public string ImmersiveURL { get; private set; }
        public string LaunchMode { get; private set; }
        public string ExeName { get; private set; }
        public LaunchArguments(string userToken, int trainingID, string launchedAt, string moduleArgument, string immersiveURL, string launchMode, string exeName)
        {
            UserToken = userToken;
            TrainingID = trainingID;
            TrainningID = trainingID;
            LaunchedAt = launchedAt;
            ModuleArgument = moduleArgument;
            ImmersiveURL = immersiveURL;
            LaunchMode = launchMode;
            ExeName = exeName;
        }

        public bool IsValid()
        {
            if (UserToken == null || UserToken == string.Empty) return false;
            if (TrainingID <= 0) return false;
            if (LaunchedAt == null || LaunchedAt == string.Empty) return false;
            if (ImmersiveURL == null || ImmersiveURL == string.Empty) return false;

            return true;
        }
        public override string ToString()
        {
            string maskedToken = string.IsNullOrEmpty(UserToken)
                ? "null"
                : (UserToken.Length > 4 ? UserToken.Substring(0, 4) + "***" : "***");

            return $"[LaunchArguments] ID: {TrainingID}, Token: {maskedToken}, At: {LaunchedAt}, Mode: {LaunchMode}, Exe: {ExeName}, URL: {ImmersiveURL}";
        }
    }
}

