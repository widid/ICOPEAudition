namespace WiDiD.Applications.Launch
{
    public interface ILaunchMode
    {

    }
}