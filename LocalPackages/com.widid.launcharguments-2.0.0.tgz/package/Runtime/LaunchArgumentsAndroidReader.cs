using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using UnityEngine;

namespace WiDiD.Applications.Launch
{
    public class LaunchArgumentsAndroidReader : ILaunchArgumentsReader
    {
        public async UniTask<LaunchArguments> WaitForLaunchArguments()
        {
            Debug.Log("Try reading Intent Arguments ");
            await Task.Yield();
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject intent = activity.Call<AndroidJavaObject>("getIntent");

            string jsonArgs = intent.Call<string>("getStringExtra", "LAUNCH_ARGS");
            if (string.IsNullOrEmpty(jsonArgs))
            {
                Debug.LogError("[LaunchArguments] Intent has no LAUNCH_ARGS extra, launch arguments will not be read.");
                return null;
            }

            LaunchArguments args = JsonConvert.DeserializeObject<LaunchArguments>(jsonArgs);
            Debug.Log("UserToken: " + args.UserToken);
            return args;
        }

    }
}

