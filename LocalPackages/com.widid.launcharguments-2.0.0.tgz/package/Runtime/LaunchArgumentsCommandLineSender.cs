
using System.Diagnostics;

namespace WiDiD.Applications.Launch
{
    public class LaunchArgumentsCommandLineSender : ILaunchArgumentsSender<ProcessStartInfo>
    {
        public ProcessStartInfo SetupArguments(string userToken, int trainingId, string unixTimeSeconds, string moduleArgument, string immersiveURL, ILaunchMode mode, string exePath)
        {
            return new ProcessStartInfo()
            {
                Arguments = "-ImmersiveUserToken " + userToken +
            " -TrainningID " + trainingId.ToString() +
            " -TrainingID " + trainingId.ToString() +
            " -LaunchedAt " + unixTimeSeconds.ToString() +
            " -ModuleArgument " + moduleArgument +
            " -ImmersiveURL " + immersiveURL +
            " -Mode " + mode.ToString(),
                FileName = exePath
            };
        }
    }
}

