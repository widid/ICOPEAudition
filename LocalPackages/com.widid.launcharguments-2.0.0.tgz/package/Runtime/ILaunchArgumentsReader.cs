using System;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;

namespace WiDiD.Applications.Launch
{
    public interface ILaunchArgumentsReader
    {
        public UniTask<LaunchArguments> WaitForLaunchArguments();
    }
}