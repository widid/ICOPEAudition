namespace WiDiD.Applications.Launch
{
    public class OnlineMode : ILaunchMode
    {
        public override string ToString()
        {
            return "Online";
        }

    }
}

