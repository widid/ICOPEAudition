namespace WiDiD.Applications.Launch
{
    public interface ILaunchArgumentsSender<T>
    {
        public T SetupArguments(string userToken, int trainingId, string unixTimeSeconds, string moduleArgument, string immersiveURL, ILaunchMode mode, string exePath);
    }
}

