namespace WiDiD.Applications.Launch
{
    public class OfflineMode : ILaunchMode
    {
        public override string ToString()
        {
            return "Offline";
        }

    }
}