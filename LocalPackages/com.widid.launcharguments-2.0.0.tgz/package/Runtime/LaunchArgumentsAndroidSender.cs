using Newtonsoft.Json;
using UnityEngine;

namespace WiDiD.Applications.Launch
{
    public class LaunchArgumentsAndroidSender : ILaunchArgumentsSender<(AndroidJavaObject activity, AndroidJavaObject intent)>
    {
        public LaunchArgumentsAndroidSender() { }

        /// <summary>
        /// Returns the activity and the intent, after constructing launch arguments
        /// </summary>
        /// <param name="userToken"></param>
        /// <param name="trainingId"></param>
        /// <param name="unixTimeSeconds"></param>
        /// <param name="moduleArgument"></param>
        /// <param name="immersiveURL"></param>
        /// <param name="mode"></param>
        /// <param name="exePath"></param>
        /// <returns></returns>
        public (AndroidJavaObject activity, AndroidJavaObject intent) SetupArguments(string userToken, int trainingId, string unixTimeSeconds, string moduleArgument, string immersiveURL, ILaunchMode mode, string exePath)
        {
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            // Convert LaunchArguments to JSON
            LaunchArguments args = new LaunchArguments(userToken, trainingId, unixTimeSeconds, moduleArgument, immersiveURL, mode.ToString(), exePath);
            string jsonArgs = JsonConvert.SerializeObject(args);
            // Resolve the package's own declared launcher activity instead of assuming a fixed
            // class name: content built with the GameActivity entry point (default since Unity 2023.1)
            // has no UnityPlayerActivity, so an explicit setClassName intent would fail to resolve.
            AndroidJavaObject packageManager = activity.Call<AndroidJavaObject>("getPackageManager");
            AndroidJavaObject intent = packageManager.Call<AndroidJavaObject>("getLaunchIntentForPackage", exePath);
            if (intent == null)
            {
                Debug.LogError($"Could not resolve a launchable activity for package : {exePath}. Is it installed and does it declare a MAIN/LAUNCHER activity?");
                return (activity, null);
            }

            Debug.Log("Added arguments and created intent for  : " + exePath);
            intent.Call<AndroidJavaObject>("putExtra", "LAUNCH_ARGS", jsonArgs);
            return (activity, intent);
        }
    }

}
